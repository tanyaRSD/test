-- ============================================================================
-- _ledger_Parent sub-procedures — sargable date predicate
-- ----------------------------------------------------------------------------
-- ONLY change vs the current procedures: the date filter no longer wraps the
-- column in DATE(), so it can use an index range on MstDate.
--
--   BEFORE (not sargable — disables any MstDate index):
--       DATE(a.MstDate) BETWEEN pFrom AND pTo
--   AFTER (sargable — half-open range, includes all of the pTo day):
--       a.MstDate >= pFrom AND a.MstDate < pTo + INTERVAL 1 DAY
--
-- The half-open `< pTo + 1 day` is equivalent to the old inclusive BETWEEN even
-- when MstDate carries a time component (BETWEEN ... AND pTo silently dropped
-- rows later than midnight on the pTo day; this restores them — verify that is
-- the intended behaviour before deploying).
--
-- Pairs with index migration 1750600000005_ledger_parent_indexes.ts:
--   idx_chipdet_user_opp_date   (UserID,  oppAcID, MstDate)
--   idx_chipdet_child_type_date (ChildID, MstType, MstDate)
--
-- All other logic (columns, running balance, msttype rules, ordering, free-chip
-- branches) is byte-for-byte the same as the current procedures.
--
-- Apply: review, then run this whole file (it DROPs + re-CREATEs each proc).
-- Roll back: re-run your existing CREATE PROCEDURE definitions.
--
-- NOTE: the dispatcher `_ledger_Parent` is unchanged and is intentionally NOT
-- included here. It already CALLs each sub-proc with 7 args; ensure the live
-- `_ledgerParentMatch` actually accepts the 7th (pEntry) param — the dump you
-- shared declared it with 6. The definition below uses 7 to match the CALL.
-- ============================================================================

DELIMITER $$

-- ----------------------------------------------------------------------------
-- _ledger_parentALL
-- ----------------------------------------------------------------------------
DROP PROCEDURE IF EXISTS `_ledger_parentALL` $$
CREATE PROCEDURE `_ledger_parentALL`(
    IN `pType` INT,
    IN `pUserID` INT,
    IN `pChipType` INT,
    IN `pParentID` INT,
    IN `pFrom` DATE,
    IN `pTo` DATE,
    IN `pEntry` VARCHAR(255)
)
BEGIN
    SET @runtot := 0;
    SET @num := 0;
    SET @Where = CONCAT(' and UserID = ', pUserID);

    IF pFrom IS NOT NULL THEN
        SET @Where = CONCAT(@Where, ' and a.MstDate >= "', pFrom, '" and a.MstDate < ("', pTo, '" + INTERVAL 1 DAY)');
    END IF;

    IF pParentID > 0 THEN
        SELECT *, (@num := @num + 1) SrNo FROM (
            SELECT ROUND(ChipsCr, 2) Debit, ROUND(ChipsDr, 2) Credit, a.MatchId, a.MarketId, a.MstDate EDate, narration, msttype TypeID, a.UserID, IFNULL(a.childid, 0) ChildID, ROUND((@runtot := @runtot + a.ChipsDr - a.ChipsCr), 2) AS Balance, a.Mstcode, a.CrDr, 0 as oppAcID FROM tblchipdet a
            WHERE a.UserID = pUserID AND a.oppAcID = pParentID ORDER BY a.MstDate, a.MstCode, a.CrDr
        ) X ORDER BY EDate DESC, MstCode DESC, CrDr;
    ELSE
        IF pChipType = 4 THEN
            SET @query = CONCAT('SELECT *,(@num:=@num+1) SrNo FROM (SELECT case when a.CrDr = 11 then ROUND(Chips ,2) else 0 end Debit ,case when a.CrDr = 2 then ROUND(Chips ,2) else 0 end Credit ,0 MatchId ,0 MarketId , MstDate EDate, Narration narration, MstType TypeID,UserID UserID  ,0 ChildID ,ROUND((@runtot := @runtot + Chips), 2) AS Balance,MstCode ,a.CrDr, 0 as oppAcID FROM tblchips a where 1=1 ', @Where, ' and BetID is null and IsFree = 1 ORDER BY MstDate , MstCode , a.CrDr)xx ORDER BY EDate DESC, MstCode DESC, CrDr');
        ELSE
            SET @Where = CONCAT(@Where, ' and case when ', pChipType, '=2 then a.msttype in (6,9) when ', pChipType, '=3 then a.msttype = 50 else a.msttype > 4 and a.msttype < 50 end ');
            SET @query = CONCAT('SELECT *,(@num:=@num+1) SrNo FROM (
            SELECT  ROUND(ChipsCr, 2)  Debit , ROUND(ChipsDr, 2) Credit ,a.MatchId ,case when a.msttype = 8 then a.fancyid else a.MarketId end MarketId , a.MstDate EDate, narration , msttype TypeID , a.UserID, IFNULL(a.childid, 0) ChildID, ROUND((@runtot := @runtot + a.ChipsCr - a.ChipsDr), 2) AS Balance, a.Mstcode, a.CrDr, a.oppAcID FROM tblchipdet a
            WHERE 1=1 ', @Where, ' ORDER BY a.MstDate , a.MstCode , a.CrDr) X ORDER BY EDate DESC, MstCode DESC, CrDr');
        END IF;

        PREPARE stmt FROM @query;
        EXECUTE stmt;
        DEALLOCATE PREPARE stmt;
    END IF;
END $$

-- ----------------------------------------------------------------------------
-- _ledgerParentMatch
-- ----------------------------------------------------------------------------
DROP PROCEDURE IF EXISTS `_ledgerParentMatch` $$
CREATE PROCEDURE `_ledgerParentMatch`(
    IN `pType` INT,
    IN `pUserID` INT,
    IN `pChipType` INT,
    IN `pParentID` INT,
    IN `pFrom` DATE,
    IN `pTo` DATE,
    IN `pEntry` VARCHAR(255)
)
BEGIN
    SET @runtot := 0;
    SET @num := 0;
    SET @Where = CONCAT(' and UserID = ', pUserID);

    IF pFrom IS NOT NULL THEN
        SET @Where = CONCAT(@Where, ' and a.MstDate >= "', pFrom, '" and a.MstDate < ("', pTo, '" + INTERVAL 1 DAY)');
    END IF;

    IF pParentID > 0 THEN
        SELECT *, (@num := @num + 1) SrNo FROM (
            SELECT ROUND(ChipsCr, 2) Debit, ROUND(ChipsDr, 2) Credit, a.MatchId, a.MarketId, a.MstDate EDate, narration, msttype TypeID, a.UserID, IFNULL(a.childid, 0) ChildID, ROUND((@runtot := @runtot + a.ChipsDr - a.ChipsCr), 2) AS Balance, a.Mstcode, a.CrDr, 0 as oppAcID FROM tblchipdet a
            WHERE a.UserID = pUserID AND a.oppAcID = pParentID ORDER BY a.MstDate, a.MstCode, a.CrDr
        ) X ORDER BY EDate DESC, MstCode DESC, CrDr;
    ELSE
        IF pChipType = 4 THEN
            SET @query = CONCAT('SELECT *,(@num:=@num+1) SrNo FROM (SELECT case when a.CrDr = 11 then ROUND(Chips ,2) else 0 end Debit ,case when a.CrDr = 2 then ROUND(Chips ,2) else 0 end Credit ,0 MatchId ,0 MarketId , MstDate EDate, Narration narration, MstType TypeID,UserID UserID  ,0 ChildID ,ROUND((@runtot := @runtot + Chips), 2) AS Balance,MstCode ,a.CrDr, 0 as oppAcID FROM tblchips a where 1=1 ', @Where, ' and BetID is null and IsFree = 1 ORDER BY MstDate , MstCode , a.CrDr)xx ORDER BY EDate DESC, MstCode DESC, CrDr');
        ELSE
            SET @Where = CONCAT(@Where, ' and case when ', pChipType, '=2 then a.msttype in (6,9) when ', pChipType, '=3 then a.msttype = 50 else a.msttype > 4 and a.msttype < 50 end ');
            SET @query = CONCAT('SELECT *,(@num:=@num+1) SrNo FROM (
            SELECT  ROUND(ChipsCr, 2)  Debit , ROUND(ChipsDr, 2) Credit ,a.MatchId ,case when a.msttype = 8 then a.fancyid else a.MarketId end MarketId , a.MstDate EDate, narration , msttype TypeID , a.UserID, IFNULL(a.childid, 0) ChildID, ROUND((@runtot := @runtot + a.ChipsCr - a.ChipsDr), 2) AS Balance, a.Mstcode, a.CrDr, a.oppAcID FROM tblchipdet a
            WHERE 1=1 ', @Where, ' ORDER BY a.MstDate , a.MstCode , a.CrDr) X ORDER BY EDate DESC, MstCode DESC, CrDr');
        END IF;

        PREPARE stmt FROM @query;
        EXECUTE stmt;
        DEALLOCATE PREPARE stmt;
    END IF;
END $$

-- ----------------------------------------------------------------------------
-- _ledgerParentMatchId
-- ----------------------------------------------------------------------------
DROP PROCEDURE IF EXISTS `_ledgerParentMatchId` $$
CREATE PROCEDURE `_ledgerParentMatchId`(
    IN pType INT,
    IN pUserID INT,
    IN pChipType INT,
    IN pParentID INT,
    IN pFrom DATE,
    IN pTo DATE,
    IN `pEntry` VARCHAR(255)
)
BEGIN
    /* FREE CHIPS */
    IF pParentID = 0 AND pChipType = 4 THEN
        SELECT *, ROW_NUMBER() OVER (ORDER BY MatchId DESC) AS SrNo
        FROM (
            SELECT
                0 AS MatchId,
                'Free Chips' AS MatchName,
                ROUND(SUM(CASE WHEN a.CrDr = 1 THEN a.Chips ELSE 0 END), 2) AS TCredit,
                ROUND(SUM(CASE WHEN a.CrDr = 2 THEN a.Chips ELSE 0 END), 2) AS TDebit,
                ROUND(SUM(
                    CASE
                        WHEN a.CrDr = 1 THEN a.Chips
                        WHEN a.CrDr = 2 THEN -a.Chips
                    END
                ), 2) AS NetAmount
            FROM tblchips a
            WHERE a.IsFree = 1
              AND a.BetID IS NULL
              AND (pFrom IS NULL OR (a.MstDate >= pFrom AND a.MstDate < pTo + INTERVAL 1 DAY))
        ) t;

    /* NORMAL MATCHWISE LEDGER */
    ELSE
        SELECT
            ROW_NUMBER() OVER (ORDER BY MatchId DESC) AS SrNo,
            EDate,
            MatchId,
            narration,
            NetAmount,
            Credit,
            Debit
        FROM (
            SELECT
                MAX(a.MstDate) AS EDate,
                a.MatchId,
                m.matchName AS narration,
                ROUND(SUM(a.ChipsCr - a.ChipsDr), 2) AS NetAmount,
                /* Credit */
                GREATEST(ROUND(SUM(a.ChipsCr - a.ChipsDr), 2), 0) AS Credit,
                /* Debit */
                GREATEST(ROUND(SUM(a.ChipsDr - a.ChipsCr), 2), 0) AS Debit
            FROM tblchipdet a
            LEFT JOIN matchmst m ON m.MstCode = a.MatchId
            WHERE a.UserID = pUserID
              AND a.oppAcID = pParentID
              AND (pFrom IS NULL OR (a.MstDate >= pFrom AND a.MstDate < pTo + INTERVAL 1 DAY))
              AND (
                    (pChipType = 2 AND a.msttype IN (6, 9))
                 OR (pChipType = 3 AND a.msttype = 50)
                 OR (pChipType NOT IN (2, 3, 4) AND a.msttype > 4 AND a.msttype < 50)
                 OR (pChipType IS NULL)
              )
            GROUP BY a.MatchId, m.matchName
        ) x;
    END IF;
END $$

-- ----------------------------------------------------------------------------
-- _ledgerParentSettle
-- ----------------------------------------------------------------------------
DROP PROCEDURE IF EXISTS `_ledgerParentSettle` $$
CREATE PROCEDURE `_ledgerParentSettle`(
    IN pType INT,
    IN pUserID INT,
    IN pChipType INT,
    IN pParentID INT,
    IN pFrom DATE,
    IN pTo DATE,
    IN pEntry VARCHAR(255)
)
BEGIN
    /* FREE CHIPS */
    IF pParentID = 0 AND pChipType = 4 THEN
        SELECT *, ROW_NUMBER() OVER (ORDER BY MatchId DESC) AS SrNo
        FROM (
            SELECT
                0 AS MatchId,
                'Free Chips' AS MatchName,
                ROUND(SUM(CASE WHEN a.CrDr = 1 THEN a.Chips ELSE 0 END), 2) AS TCredit,
                ROUND(SUM(CASE WHEN a.CrDr = 2 THEN a.Chips ELSE 0 END), 2) AS TDebit,
                ROUND(SUM(
                    CASE
                        WHEN a.CrDr = 1 THEN a.Chips
                        WHEN a.CrDr = 2 THEN -a.Chips
                    END
                ), 2) AS NetAmount
            FROM tblchips a
            WHERE a.IsFree = 1
              AND a.BetID IS NULL
              AND (pFrom IS NULL OR (a.MstDate >= pFrom AND a.MstDate < pTo + INTERVAL 1 DAY))
        ) t;

    /* SETTLEMENT LEDGER */
    ELSE
        SELECT
            ROW_NUMBER() OVER (ORDER BY a.MatchId DESC) AS SrNo,
            a.MstDate AS EDate,
            a.MatchId,
            a.narration,
            CAST(a.ChipsCr AS DECIMAL(10, 2)) AS Credit,
            CAST(a.ChipsDr AS DECIMAL(10, 2)) AS Debit
        FROM tblchipdet a
        LEFT JOIN matchmst m ON m.MstCode = a.MatchId
        WHERE a.childID = pUserID
          AND (pFrom IS NULL OR (a.MstDate >= pFrom AND a.MstDate < pTo + INTERVAL 1 DAY))
          AND a.msttype = 50
        ORDER BY a.MstDate DESC;
    END IF;
END $$

DELIMITER ;
