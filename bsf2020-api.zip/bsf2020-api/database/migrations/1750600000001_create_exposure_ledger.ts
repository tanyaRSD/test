import BaseSchema from '@ioc:Adonis/Lucid/Schema'

/**
 * exposure_ledger
 * ------------------------------------------------------------------
 * One row per (account, match, market, selection). `net` is the running
 * profit/loss this account would realise if that selection wins, already
 * scaled by the account's partnership share (so it is valid for clients AND
 * every ancestor / upper panel).
 *
 * The market liability for an account is `MIN(net)` across the selections of a
 * market when that minimum is negative — this mirrors the `vewuserpnldetails`
 * worst-case logic inside the legacy `getLiability` stored procedure, but is
 * maintained incrementally instead of recomputed over the whole downline.
 *
 * This table is the source of truth for incremental liability maintenance.
 */
export default class extends BaseSchema {
  protected tableName = 'exposure_ledger'

  public async up() {
    this.schema.createTable(this.tableName, (table) => {
      table.bigIncrements('id').primary()

      table.integer('account_id').unsigned().notNullable()
      table.integer('match_id').notNullable()
      table.string('market_id', 100).notNullable()
      table.integer('selection_id').notNullable()

      // 'market' | 'bookmaker' | 'session' | 'updown' | 'lastdigit' |
      // 'unmatch' | 'oddeven' | 'poker' — which liability bucket this belongs to.
      table.string('market_type', 20).notNullable().defaultTo('market')

      // Running net P/L for this account on this selection (partnership-scaled).
      table.decimal('net', 18, 2).notNullable().defaultTo(0)

      table.timestamp('updated_at', { useTz: false }).nullable()

      // One ledger row per account/selection — used for atomic upserts.
      table.unique(['account_id', 'match_id', 'market_id', 'selection_id'])

      // Recompute a single market's worst-case for one account quickly.
      table.index(['account_id', 'match_id', 'market_id'], 'idx_ledger_account_market')

      // Sweep an entire market (all accounts) on result declaration.
      table.index(['match_id', 'market_id'], 'idx_ledger_market')
    })
  }

  public async down() {
    this.schema.dropTable(this.tableName)
  }
}
