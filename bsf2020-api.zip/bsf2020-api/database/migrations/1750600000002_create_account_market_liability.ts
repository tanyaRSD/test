import BaseSchema from '@ioc:Adonis/Lucid/Schema'

/**
 * account_market_liability
 * ------------------------------------------------------------------
 * Per (account, match, market) cached worst-case liability — always <= 0.
 * Derived from exposure_ledger as `LEAST(0, MIN(net))` over the market's
 * selections.
 *
 * Keeping this summary lets us maintain `createmaster.liability` with a pure
 * delta: when a market's worst-case moves from old -> new we apply
 * `(new - old)` to the account's column. No full-subtree recompute.
 *
 * `createmaster.liability` == SUM(account_market_liability.liability) for that
 * account at all times (the invariant the reconciliation job verifies).
 */
export default class extends BaseSchema {
  protected tableName = 'account_market_liability'

  public async up() {
    this.schema.createTable(this.tableName, (table) => {
      table.bigIncrements('id').primary()

      table.integer('account_id').unsigned().notNullable()
      table.integer('match_id').notNullable()
      table.string('market_id', 100).notNullable()
      table.string('market_type', 20).notNullable().defaultTo('market')

      // Worst-case (most negative) net across this market's selections. <= 0.
      table.decimal('liability', 18, 2).notNullable().defaultTo(0)

      table.timestamp('updated_at', { useTz: false }).nullable()

      table.unique(['account_id', 'match_id', 'market_id'])

      // Sum all open-market liabilities for one account (reconciliation).
      table.index(['account_id'], 'idx_aml_account')
    })
  }

  public async down() {
    this.schema.dropTable(this.tableName)
  }
}
