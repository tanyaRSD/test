import BaseSchema from '@ioc:Adonis/Lucid/Schema'
import Database from '@ioc:Adonis/Lucid/Database'

/**
 * _ledger_Parent indexes
 * ------------------------------------------------------------------
 * Speeds up POST /admin/chipHistoryParentID, which calls the `_ledger_Parent`
 * SP. That SP dispatches to four sub-procedures, all of which scan tblchipdet
 * (4.9M rows). Their access patterns:
 *
 *   ALL / Match / Single (the common path, parentId > 0):
 *       WHERE a.UserID = ? AND a.oppAcID = ?     ORDER BY a.MstDate, ...
 *   Settlement:
 *       WHERE a.ChildID = ? AND a.msttype = 50   ORDER BY a.MstDate DESC
 *
 * Existing indexes don't serve either:
 *   - idx_chipdet_collection_report (UserID, ChildID, oppAcID, ...) leads with
 *     (UserID, ChildID); the ledger queries don't filter ChildID, so MySQL can
 *     only use the UserID prefix and then row-checks every match for oppAcID.
 *   - idx_chipdet_opp_child_cover (oppAcID, ChildID, ...) leads with oppAcID,
 *     not UserID, and again has ChildID (unfiltered here) as the 2nd column.
 *
 * Two targeted indexes make the equality predicates index-driven and give the
 * MstDate ordering for free:
 *   idx_chipdet_user_opp_date   (UserID,  oppAcID, MstDate)  -> ALL/Match/Single
 *   idx_chipdet_child_type_date (ChildID, MstType, MstDate)  -> Settlement
 *
 * Not made covering on purpose: the ledger SELECTs pull a dozen wide columns
 * (narration, MatchId, MarketId, ...), so covering them would bloat a hot write
 * table for little gain — the equality predicates already narrow to a single
 * account's rows, making the residual look-ups cheap.
 *
 * Note: the SPs filter dates with `DATE(a.MstDate) BETWEEN ?` which wraps the
 * column in a function and is therefore NOT sargable — the MstDate trailing
 * column helps ordering, not the range scan. Making that range index-usable
 * would require editing the SP to compare MstDate against a datetime range
 * directly (a.MstDate >= ? AND a.MstDate < ? + 1 day); call that out separately.
 *
 * Idempotent: skips any index that already exists, matching migration 003/004.
 */
export default class extends BaseSchema {
  private indexes = [
    {
      table: 'tblchipdet',
      name: 'idx_chipdet_user_opp_date',
      cols: '`UserID`, `oppAcID`, `MstDate`',
    },
    {
      table: 'tblchipdet',
      name: 'idx_chipdet_child_type_date',
      cols: '`ChildID`, `MstType`, `MstDate`',
    },
  ]

  public async up() {
    for (const ix of this.indexes) {
      try {
        await Database.rawQuery(`CREATE INDEX ${ix.name} ON ${ix.table} (${ix.cols})`)
      } catch (e) {
        if (!/Duplicate key name/i.test(String((e && e.message) || e))) {
          throw e
        }
      }
    }
  }

  public async down() {
    for (const ix of this.indexes) {
      try {
        await Database.rawQuery(`DROP INDEX ${ix.name} ON ${ix.table}`)
      } catch (e) {
        // ignore if it doesn't exist
      }
    }
  }
}
