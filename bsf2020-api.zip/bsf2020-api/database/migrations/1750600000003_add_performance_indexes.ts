import BaseSchema from '@ioc:Adonis/Lucid/Schema'
import Database from '@ioc:Adonis/Lucid/Database'

/**
 * Performance indexes
 * ------------------------------------------------------------------
 * Fixes two pathologically slow admin endpoints (and many others that filter
 * by parentId or aggregate tblchipdet):
 *
 *  - createmaster had NO index on `parentId` (only (mstrid, parentId), whose
 *    leftmost column is mstrid) — so every `WHERE parentId = ?` did a full
 *    table scan. `GET /admin/masters` ran the per-row tblchipdet subqueries
 *    against ALL ~5k rows instead of the page → ~25s. (parentId, mstruserid)
 *    also serves the common sort, avoiding a filesort.
 *
 *  - The settlement/pl aggregations on tblchipdet (4.9M rows) scanned a bare
 *    single-column index then did row look-ups to filter ChildID and SUM.
 *    Covering indexes make them index-only:
 *      _settlement_amount(id) / masters `sa`  : (oppAcID, ChildID, ChipsDr, ChipsCr)
 *      masters `pl`                           : (UserID,  ChildID, ChipsCr, ChipsDr)
 *    Result: _settlement_amount(1) 7.1s -> 18ms, masters 25s -> <1s.
 *
 * Idempotent: skips any index that already exists, so it is safe to run on an
 * environment where these were already created by hand (e.g. dev).
 */
export default class extends BaseSchema {
  private indexes = [
    {
      table: 'createmaster',
      name: 'idx_createmaster_parent_userid',
      cols: '`parentId`, `mstruserid`',
    },
    {
      table: 'tblchipdet',
      name: 'idx_chipdet_opp_child_cover',
      cols: '`oppAcID`, `ChildID`, `ChipsDr`, `ChipsCr`',
    },
    {
      table: 'tblchipdet',
      name: 'idx_chipdet_user_child_cover',
      cols: '`UserID`, `ChildID`, `ChipsCr`, `ChipsDr`',
    },
  ]

  public async up() {
    // Idempotent: attempt the create and ignore "duplicate key name" so this is
    // safe on environments where the index was already added by hand (dev).
    for (const ix of this.indexes) {
      try {
        await Database.rawQuery(`CREATE INDEX ${ix.name} ON ${ix.table} (${ix.cols})`)
      } catch (e) {
        if (!/Duplicate key name/i.test(String((e && e.message) || e))) {
          throw e
        }
      }
    }
  }

  public async down() {
    for (const ix of this.indexes) {
      try {
        await Database.rawQuery(`DROP INDEX ${ix.name} ON ${ix.table}`)
      } catch (e) {
        // ignore if it doesn't exist
      }
    }
  }
}
