import BaseSchema from '@ioc:Adonis/Lucid/Schema'
import Database from '@ioc:Adonis/Lucid/Database'

/**
 * collectionReport covering index
 * ------------------------------------------------------------------
 * GET /admin/collectionReport aggregates tblchipdet (4.9M rows) once per call:
 *
 *   SELECT ... SUM(a.ChipsCr - a.ChipsDr)
 *   FROM tblchipdet a
 *   INNER JOIN createmaster b ON b.mstrid = a.oppAcID
 *   WHERE a.UserID = ? AND a.ChildID != 0
 *   GROUP BY b.mstrid, ..., a.ChildID
 *
 * Migration 003 added idx_chipdet_user_child_cover (UserID, ChildID, ChipsCr,
 * ChipsDr). That covers the filter + SUM, but NOT `oppAcID` — which this query
 * needs for the join and GROUP BY — so MySQL still does a row look-up per group.
 *
 * idx_chipdet_collection_report adds oppAcID, making the query index-only:
 *   (UserID, ChildID, oppAcID, ChipsCr, ChipsDr)
 *
 * This is a strict superset of idx_chipdet_user_child_cover (the leading
 * (UserID, ChildID) prefix plus all the SUM columns), so the older index is now
 * redundant for every query that used it — we drop it to keep write
 * amplification flat instead of carrying two overlapping indexes.
 *
 * Idempotent: skips the create if it already exists; tolerates the old index
 * already being gone.
 */
export default class extends BaseSchema {
  private newIndex = {
    table: 'tblchipdet',
    name: 'idx_chipdet_collection_report',
    cols: '`UserID`, `ChildID`, `oppAcID`, `ChipsCr`, `ChipsDr`',
  }

  private redundantIndex = {
    table: 'tblchipdet',
    name: 'idx_chipdet_user_child_cover',
    cols: '`UserID`, `ChildID`, `ChipsCr`, `ChipsDr`',
  }

  public async up() {
    try {
      await Database.rawQuery(
        `CREATE INDEX ${this.newIndex.name} ON ${this.newIndex.table} (${this.newIndex.cols})`
      )
    } catch (e) {
      if (!/Duplicate key name/i.test(String((e && e.message) || e))) {
        throw e
      }
    }

    try {
      await Database.rawQuery(
        `DROP INDEX ${this.redundantIndex.name} ON ${this.redundantIndex.table}`
      )
    } catch (e) {
      // ignore if it was never created / already dropped
    }
  }

  public async down() {
    // Restore the index 003 created...
    try {
      await Database.rawQuery(
        `CREATE INDEX ${this.redundantIndex.name} ON ${this.redundantIndex.table} (${this.redundantIndex.cols})`
      )
    } catch (e) {
      if (!/Duplicate key name/i.test(String((e && e.message) || e))) {
        throw e
      }
    }

    // ...and remove the superset.
    try {
      await Database.rawQuery(
        `DROP INDEX ${this.newIndex.name} ON ${this.newIndex.table}`
      )
    } catch (e) {
      // ignore if it doesn't exist
    }
  }
}
