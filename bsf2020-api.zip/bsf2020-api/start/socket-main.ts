import Cache from '@ioc:Adonis/Addons/Cache'
import Redis from '@ioc:Adonis/Addons/Redis'
import Ws from 'App/Services/Ws'

let activeMarkets: any = []

Ws.boot()

Redis.connection('main').psubscribe('*', async (channel, message) => {
  const data = parse(message)
  if (channel == 'MARKET_DATA') {
    handleMarketData(data.result).then()
  } else if (channel == 'FANCY_DATA') {
    if (data.data.length > 0) {
      Ws.io.sockets
        .in(`FANCY${data.marketId}`)
        .emit(`FANCY${data.marketId}`, JSON.stringify(data.data))
    }
  }
})

updateActiveMarkets().then()

async function updateActiveMarkets() {
  const data = await Redis.smembers('ACTIVE_MARKETS')
  activeMarkets = data.map((el: any) => JSON.parse(el))
  Ws.io.sockets.in(`ACTIVE_MARKETS`).emit(`ACTIVE_MARKETS`, activeMarkets.length)
}

async function handleMarketData(data) {
  for (const el of data) {
    const market = {
      id: el.marketId,
      data: {
        id: el.marketId,
        marketDefinition: {
          score: undefined,
          inPlay: el.inplay,
          status: el.status,
          multiplyBy: el?.multiplyBy,
          totalMatched: el?.totalMatched || 0,
          runners: el.runners.map((r, i) => {
            return {
              id: r.selectionId,
              status: r.status,
              sortPriority: i + 1,
              basePrice: r?.basePrice,
            }
          }),
        },
        rc: el.runners.map((r) => {
          const d = {
            batb: [],
            batl: [],
            id: r.selectionId,
          }

          if (r.hasOwnProperty('ex')) {
            if (r.ex.hasOwnProperty('availableToBack')) {
              d.batb = r.ex.availableToBack.map((b, bi) => {
                return [bi, b.price, b.size]
              })
            }

            if (r.ex.hasOwnProperty('availableToLay')) {
              d.batl = r.ex.availableToLay.map((l, li) => {
                return [li, l.price, l.size]
              })
            }
          }

          return d
        }),
        updated_at: el.updated_at,
      },
    }

    await fillData(market)

    //modify data
    await modifyData(market)

    Ws.io.sockets.in('EID' + market.id).emit('message', JSON.stringify(market.data))

    await Cache.put('dashboard_market:' + market.id, market.data, 3600)
  }
}

async function modifyData(market) {
  if (market.data.hasOwnProperty('rc')) {
    for (const r of market.data.rc) {
      if (r.hasOwnProperty('batb') && r.hasOwnProperty('batl')) {
        for (const l of r.batl) {
          if (l[0] == 0 && r.batb.length > 0) {
            if (l[1] == 1.01) {
              const u = r.batb.find((bb) => bb[0] == 0)

              if (u) {
                u[1] = 0
                u[2] = 0
              }
            }
          }
        }

        for (const b of r.batb) {
          if (b[0] == 0 && r.batl.length > 0) {
            if (b[1] == 1000) {
              const u = r.batl.find((ll) => ll[0] == 0)

              if (u) {
                u[1] = 0
                u[2] = 0
              }
            }
          }
        }
      }
    }
  }
}

async function fillData(market) {
  let diffInSeconds = 0
  if (market.updated_at) {
    diffInSeconds = Math.floor(
      Math.abs(new Date().getTime() - new Date(market.updated_at).getTime()) / 1000
    )
  }

  if (market.data.hasOwnProperty('rc')) {
    for (const r of market.data.rc) {
      if (r.hasOwnProperty('batb')) {
        if (diffInSeconds > 5) {
          r.batb = []
          ;[0, 1, 2].forEach((i) => {
            r.batb.push([i, 0, 0])
          })
        } else {
          r.batb.sort((a, b) => (a[0] > b[0] ? 1 : -1))

          if (r.batb.length == 0) {
            r.batb = []
            ;[0, 1, 2].forEach((i) => {
              r.batb.push([i, 0, 0])
            })
          } else if (r.batb.length == 1) {
            ;[1, 2].forEach((i) => {
              r.batb.push([i, 0, 0])
            })
          } else if (r.batb.length == 2) {
            r.batb.push([2, 0, 0])
          }
        }
      }

      if (r.hasOwnProperty('batl')) {
        if (diffInSeconds > 5) {
          r.batl = []
          ;[0, 1, 2].forEach((i) => {
            r.batl.push([i, 0, 0])
          })
        } else {
          r.batl.sort((a, b) => (a[0] > b[0] ? 1 : -1))

          if (r.batl.length == 0) {
            r.batl = []
            ;[0, 1, 2].forEach((i) => {
              r.batl.push([i, 0, 0])
            })
          } else if (r.batl.length == 1) {
            ;[1, 2].forEach((i) => {
              r.batl.push([i, 0, 0])
            })
          } else if (r.batl.length == 2) {
            r.batl.push([2, 0, 0])
          }
        }
      }
    }
  }
}

function parse(data: any) {
  try {
    return JSON.parse(data)
  } catch (e) {
    return null
  }
}
