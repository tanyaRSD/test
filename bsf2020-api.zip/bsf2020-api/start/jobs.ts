const jobs = [
  'App/Jobs/UserLog',
  'App/Jobs/LockUnlockUser',
  'App/Jobs/LockUnlockBetting',
  'App/Jobs/UpdateLiability',
  'App/Jobs/UpdateFancy',
  'App/Jobs/SaveOddsProfitLoss',
  'App/Jobs/FancyBook',
]

export default jobs
