import Route from '@ioc:Adonis/Core/Route'

Route.group(() => {
  Route.post('userRegister', 'AuthController.register').middleware(['throttle:register'])
  Route.post('verifyEmail', 'AuthController.verifyEmail').middleware(['throttle:register'])
  Route.post('sendOtp', 'AuthController.sendOtp').middleware(['throttle:otp_ip', 'throttle:otp'])
  Route.post('passwordOtp', 'ForgotPasswordController.passwordOtp').middleware([
    'throttle:otp_ip',
    'throttle:otp',
  ])
  Route.post('updatePassword', 'ForgotPasswordController.updatePassword').middleware([
    'throttle:password_ip',
    'throttle:password_phone',
  ])

  Route.get('dashboard/horse', 'DashboardController.horse').middleware([
    'auth:public',
    'throttle:global',
  ])

  Route.post('registerRequest', 'AuthController.registerRequest').middleware([
    'auth:public',
    'throttle:global',
  ])

  Route.post('requestLogin', 'AuthController.requestLogin').middleware([
    'auth:public',
    'throttle:global',
  ])

  Route.get('dashboard', 'DashboardController.index').middleware(['auth:public', 'throttle:global'])
  Route.get('poker/getPokerGameList', 'PokersController.getPokerGameList').middleware([
    'auth:public',
    'throttle:global',
  ])

  Route.post('requestDeposit', 'RegisterRequestController.deposit').middleware([
    'auth2',
    'throttle:global',
  ])

  Route.post('requestWithdraw', 'RegisterRequestController.withdraw').middleware([
    'auth2',
    'throttle:global',
  ])

  Route.post('checkForgetOtp', 'ForgotPasswordController.checkForgetOtp')

  Route.group(() => {
    Route.get('sports', 'SportsController.index')

    Route.post('bets/market', 'BetsController.market')
    Route.post('bets/fancy', 'BetsController.fancy')
    Route.post('bets/line', 'BetsController.line')

    Route.post('stakes', 'StakesController.store')

    Route.resource('userBanks', 'UserBanksController').apiOnly()

    Route.post('getBanks', 'BanksController.index')
    Route.post('deposit', 'BanksController.deposit')
    Route.post('depositNew', 'BanksController.depositNew')

    Route.post('getRequest', 'BanksController.getRequest')
    Route.post('withdraw', 'BanksController.withdraw')
    Route.post('fastWithdrawShow', 'BanksController.fastWithdrawShow')
    Route.post('cancelWithdraw', 'BanksController.cancelWithdraw')

    // Route.get('dream/gameList', 'DreamCasinoController.gameList')
    // Route.post('dream/gameUrl', 'DreamCasinoController.gameUrl')
    // Route.post('fixDream', 'DreamCasinoController.fixDream')
    Route.get('poker/getUrl', 'PokersController.getUrl')
    Route.get('poker/getGameUrl', 'PokersController.getGameUrl')
    Route.get('poker/getUserCasinoLimit', 'PokersController.getLimitByUserId')
    Route.get('fixPoker', 'PokersController.fixPoker').middleware('auth:public')

    Route.get('gamehub/gameList', 'GameHubController.gameList')
    Route.get('gamehub/vendorList', 'GameHubController.vendorList')
    Route.post('gamehub/gameUrl', 'GameHubController.gameUrl')

    Route.post('userDetails', 'UserController.update')
    // tanya changes start
    Route.post('clearLiability', 'UserController.clearLiability')
    // tanya changes end
  }).middleware(['auth', 'typeCheck:user', 'throttle:global'])

  // poker routes
  Route.group(async () => {
    Route.post('auth', 'PokersController.auth')
    Route.post('exposure', 'PokersController.exposure')
    Route.post('result', 'PokersController.result')
    // do not remove this route
    Route.post('results', 'PokersController.result')
    Route.post('refund', 'PokersController.refund')
  }).prefix('poker')

  // dream routes
  // Route.group(async () => {
  //   Route.post('wallet/balance', 'DreamCasinoController.balance')
  //   Route.post('wallet/bet', 'DreamCasinoController.bet')
  //   Route.post('wallet/win', 'DreamCasinoController.result')
  //   Route.post('wallet/rollback', 'DreamCasinoController.rollback')
  // }).prefix('dream')

  // gamehub routes
  Route.get('gamehub/wallet', 'GameHubController.wallet')

  Route.post('getRequestBanks', 'BanksController.index').middleware(['auth2'])
  Route.post('getfastWithdrawShow', 'BanksController.fastWithdrawShow').middleware('auth2')
}).namespace('App/Controllers/User')

// common code for admin and users
Route.group(() => {
  Route.post('login', 'AuthController.login').middleware(['throttle:login'])
  Route.get('me', 'AuthController.me').middleware(['throttle:login', 'auth:public'])
  Route.get('captcha', 'AuthController.captcha').middleware(['throttle:login', 'auth:public'])
  Route.get('me2', 'AuthController.me2').middleware(['throttle:login', 'auth:public'])
  Route.get('logout', 'AuthController.logout').middleware(['throttle:login'])
  Route.post('username', 'AuthController.username').middleware([
    'throttle:username_ip',
    'throttle:username',
  ])
  Route.post('requestUsername', 'AuthController.requestUsername').middleware([
    'throttle:username_ip',
    'throttle:username',
  ])

  Route.group(() => {
    Route.get('logs', 'AuthController.logs')
    Route.post('changePassword', 'AuthController.changePassword')
    Route.get('ip', 'AuthController.ip')

    Route.get('accountStatement', 'ReportsController.accountStatement')
    Route.get('ledger', 'ReportsController.ledger')
    Route.get('ledger/:matchId', 'ReportsController.ledgerByMatch')
    Route.post('betHistory', 'ReportsController.betHistory')
    Route.post('betHistoryFilter', 'ReportsController.betHistoryFilter')
    Route.post('profitLoss', 'ReportsController.profitLoss')
    Route.post('profitLossByMatch', 'ReportsController.profitLossByMatch')
    Route.post('profitLossBySport', 'ReportsController.profitLossBySport')
    Route.get('loginHistory', 'ReportsController.loginHistory')
    Route.get('passwordHistory', 'ReportsController.passwordHistory')
    Route.get('companyReport', 'ReportsController.companyReport')
    Route.get('declaredResults/toss', 'ReportsController.getTossResults')
    Route.get('loginLogs/today', 'ReportsController.getTodayLoginLogs')
    Route.get('bets/countPerUserForOnlyToday', 'ReportsController.getBetsCountPerUserForOnlyToday')
    Route.get('bets/countPerUser', 'ReportsController.getBetsCountPerUser')

    Route.get('matches/:id/markets', 'MatchesController.markets')
    Route.get('matches/:id/fancies', 'MatchesController.fancies')
    Route.get('matches/:id/fancyLiability', 'MatchesController.fancyLiability')
    Route.get('matches/:id/score', 'MatchesController.score')
    Route.get('matches/:id', 'MatchesController.show')
    Route.post('getOddsGraph', 'MatchesController.getOddsGraph')
    Route.post('oddsPlByMatch', 'MatchesController.oddsPlByMatch')
    Route.get('toggleFavorite', 'MatchesController.toggleFavorite')
    Route.get('bets', 'BetsController.index')
    Route.get('fancyBets', 'BetsController.fancyBets')
    Route.get('bookmakerBets', 'BetsController.bookmakerBets')
    Route.get('winnerBets', 'BetsController.winnerBets')
    Route.get('matchOddsBets', 'BetsController.matchOddsBets')
    Route.get('tiedMatchBets', 'BetsController.tiedMatchBets')
    Route.get('tossBets', 'BetsController.tossBets')
    Route.get('goalsBets', 'BetsController.goalsBets')
    Route.get('allBets', 'BetsController.allBets')
    Route.get('results', 'ResultsController.index')
    Route.post('queries', 'QueryController.store')
  }).middleware(['throttle:global', 'auth'])
  Route.get('blogs', 'BlogController.index')
  Route.get('getBlog', 'BlogController.getBlog')

  Route.get('getDomains', 'RequestDomainsController.index').middleware(['auth2', 'throttle:global'])

  Route.get('getRegisterRequests', 'RegisterRequestController.getRegisterRequests').middleware([
    'auth2',
    'throttle:global',
  ])
}).namespace('App/Controllers/Common')
