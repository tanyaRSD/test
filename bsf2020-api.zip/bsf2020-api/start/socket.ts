import Cache from '@ioc:Adonis/Addons/Cache'
import Redis from '@ioc:Adonis/Addons/Redis'
import Domains from 'App/Services/domains'
import UserService from 'App/Services/UserService'
import Ws from 'App/Services/Ws'
import Application from '@ioc:Adonis/Core/Application'
let activeMarkets: any = []

async function initDomains() {
  await Domains.init()
}

initDomains().then()

Ws.boot()

Redis.psubscribe('*', async (channel, message) => {
  const data = parse(message)
  if (channel == 'UPDATE_ACTIVE_MARKET') {
    updateActiveMarkets().then()
  }
  //  else if (channel == 'MARKET_DATA') {
  //   handleMarketData(data.result).then()
  // }
  else if (channel == 'notification' || channel == 'register-notification') {
    const name = 'USER_UPDATE_DATA:' + data.userId
    Ws.io.sockets.in(name).emit(name, JSON.stringify(data))
  }
  // else if (channel == 'FANCY_DATA') {
  //   Ws.io.sockets
  //     .in(`FANCY${data.marketId}`)
  //     .emit(`FANCY${data.marketId}`, JSON.stringify(data.data))
  // }
  else if (channel == 'BANK_UPDATE') {
    Ws.io.sockets
      .in(channel + ':' + data.userId)
      .emit(channel + ':' + data.userId, JSON.stringify(data))
  } else if (channel == 'PAYMENT_UPDATE') {
    Ws.io.sockets
      .in(channel + ':' + data.userId)
      .emit(channel + ':' + data.userId, JSON.stringify(data))
  } else if (channel == 'UPDATE_MATCH_DATA') {
    if (data.hasOwnProperty('match_id')) {
      const id = data.match_id
      Ws.io.sockets.in('UPDATE_MARKETS' + id).emit('UPDATE_MARKETS' + id, '')
    }
  } else if (channel == 'UPDATE_FANCY') {
    if (data.hasOwnProperty('matchId')) {
      const matchId = data.matchId
      Ws.io.sockets.in(channel + matchId).emit(channel + matchId, data)
    } else if (data.hasOwnProperty('match_id')) {
      const matchId = data.match_id
      Ws.io.sockets.in(channel + matchId).emit(channel + matchId, data)
    } else if (data.hasOwnProperty('MatchID')) {
      const matchId = data.MatchID
      Ws.io.sockets.in(channel + matchId).emit(channel + matchId, data)
    }
  } else if (channel == 'USER_UPDATE_DATA') {
    if (data.hasOwnProperty('user_id')) {
      Ws.io.sockets
        .in(channel + ':' + data.user_id)
        .emit(channel + ':' + data.user_id, JSON.stringify(data.data))
    }
  } else if (channel == 'MATCH_UPDATE_DATA') {
    if (data.hasOwnProperty('matchId')) {
      Ws.io.sockets
        .in(channel + ':' + data.matchId)
        .emit(channel + ':' + data.matchId, JSON.stringify(data))
    }
  } else if (channel == 'MARKET_UPDATE_DATA') {
    if (data.hasOwnProperty('match_id')) {
      Ws.io.sockets
        .in(channel + ':' + data.match_id)
        .emit(channel + ':' + data.match_id, JSON.stringify(data))
    }
  } else if (channel == 'BETS_UPDATE_DATA') {
    if (data.hasOwnProperty('user_id')) {
      Ws.io.sockets
        .in(channel + ':' + data.user_id + '_' + data.match_id)
        .emit(channel + ':' + data.user_id + '_' + data.match_id, JSON.stringify(data.data))
    }
  } else if (channel.startsWith('FANCY_BOOK_UPDATE') || channel.startsWith('LINE_BOOK_UPDATE')) {
    Ws.io.sockets.in(channel).emit(channel)
  } else if (channel == 'ALL_BETS_UPDATE_DATA') {
    if (data.hasOwnProperty('user_id')) {
      Ws.io.sockets
        .in(channel + ':' + data.user_id)
        .emit(channel + ':' + data.user_id, JSON.stringify(data.data))
    }
  } else if (channel == 'UPDATE_MATCH_EVENT') {
    if (data.data.hasOwnProperty('match_id')) {
      Ws.io.sockets
        .in(channel + ':' + data.data.match_id)
        .emit(channel + ':' + data.data.match_id, JSON.stringify(data.data))
    }
  } else if (['DASHBOARD_UPDATE_USER', 'DASHBOARD_UPDATE_ADMIN'].indexOf(channel) > -1) {
    await UserService.deleteKeys(await Redis.keys('dashboard:*'))
    Ws.io.sockets.in(channel).emit(channel, '')
  } else if (channel == 'ACTIVE_USERS') {
    updateActiveUsers().then()
  }
})

updateActiveMarkets().then()

/**
 * Middleware
 */
Ws.io.use((socket, next) => {
  const { auth, headers } = socket.handshake
  const origin = headers.origin
  const userAgent = headers['user-agent']
  const err = new Error('Authentication Error')

  if (!userAgent || (Application.inProduction && origin && Domains.list.indexOf(origin) == -1)) {
    Redis.sadd('fraud', JSON.stringify({ origin, userAgent, auth }))
    socket.data = { fakeUser: true }
    return next()
  } else if (
    auth.hasOwnProperty('xId') &&
    auth.hasOwnProperty('token') &&
    auth.hasOwnProperty('xType')
  ) {
    const { xId, xType, token } = auth

    Cache.get(token).then((value: any) => {
      if (value) {
        if (
          xType.toString() == value.usetype.toString() &&
          xId.toString() == value.mstrid.toString()
        ) {
          if (origin && Application.inProduction && origin != value.domain) {
            return next(err)
          } else {
            next()
          }
        } else {
          return next(err)
        }
      } else {
        return next(err)
      }
    })
  } else {
    return next(err)
  }
})

/**
 * Listen for incoming socket connections
 */
Ws.io.on('connection', (socket) => {
  // If the user is a fake user, send random data.
  if (socket.data.fakeUser) {
    const sendRandomData = () => {
      const types = [
        () => ({ id: Date.now(), value: Math.random() }), // Object with number
        () => [Math.random(), Math.random().toString(36).slice(2)], // Array with mixed types
        () => Math.random().toString(36).slice(2), // Random string
        () => Math.floor(Math.random() * 10000), // Integer
        () => Math.random() > 0.5, // Boolean
        () => null, // Null
        () => undefined, // Undefined
        () => ({ nested: [Math.random(), { x: null }] }), // Nested object
        () => Array(Math.floor(Math.random() * 5)).fill(Math.random()), // Random-length array
        () => String.fromCharCode(Math.floor(Math.random() * 1000)), // Random Unicode char
        () => ({ [Math.random()]: Math.random() }), // Object with random key
        () => Infinity, // Edge case number
        () => NaN, // Edge case number
      ]

      const randomData = types[Math.floor(Math.random() * types.length)]()
      try {
        socket.emit('message', JSON.stringify(randomData))
      } catch (error) {
        console.error('Error emitting random data:', error)
      }
    }

    // const getRandomInterval = () => Math.floor(Math.random() * 450) + 50
    const intervalId = setInterval(sendRandomData)

    socket.on('disconnect', () => {
      clearInterval(intervalId)
    })
  }
  // If the user is authenticated, join the appropriate rooms.
  else {
    socket.on('UPDATE_DASHBOARD', () => {
      socket.join('UPDATE_DASHBOARD')
    })

    socket.on('UPDATE_MARKETS', (v) => {
      socket.join('UPDATE_MARKETS' + v)
    })

    socket.on('UPDATE_FANCY', (v) => {
      socket.join('UPDATE_FANCY' + v)
    })

    socket.on('ACTIVE_MARKETS', () => {
      socket.join('ACTIVE_MARKETS')
      Ws.io.sockets.in(`ACTIVE_MARKETS`).emit(`ACTIVE_MARKETS`, activeMarkets.length)
    })

    socket.on('ACTIVE_USERS', async () => {
      socket.join('ACTIVE_USERS')

      updateActiveUsers().then()
    })

    socket.on('MANUAL_DATA', async (market) => {
      if (market.marketId.includes('M')) {
        market.updated_at = new Date()
        await Cache.forever('marketId:' + market.marketId, market)
        await Redis.publish('MARKET_DATA', JSON.stringify({ result: [market] }))
      }
    })

    socket.on('MANUAL_FANCY_DATA', async (fancy) => {
      const matchId = fancy?.matchId
      delete fancy.matchId

      if (fancy?.SelectionId.includes('M')) {
        const manualFancyData = await Cache.get(`manualFancyId:${matchId}`)
        const allFancyData = await Cache.get('FancyId:' + matchId)

        if (manualFancyData) {
          let index = manualFancyData.findIndex((m: any) => m.SelectionId == fancy?.SelectionId)

          if (index > -1) {
            manualFancyData.splice(index, 1, fancy)
          }
        }

        await Cache.forever('manualFancyId:' + matchId, manualFancyData)

        if (allFancyData) {
          let index = allFancyData?.session.findIndex(
            (m: any) => m.SelectionId == fancy?.SelectionId
          )

          if (index > -1) {
            allFancyData?.session.splice(index, 1, fancy)
            allFancyData.updated_at = new Date()
          }
        }

        await Cache.forever('FancyId:' + matchId, allFancyData)

        const d = allFancyData?.session

        if (d.length > 0) {
          await Redis.publish(`FANCY_DATA`, JSON.stringify({ marketId: matchId, data: d }))
        }
      }
    })

    //when room join request made
    socket.on('room', async (room) => {
      if (room) {
        if (room.hasOwnProperty('name')) {
          socket.join(room.name)

          if (room.name.startsWith('EID')) {
            const mid = room.name.slice(3)
            const market = activeMarkets.find((a: any) => a.marketId.toString() == mid.toString())

            if (mid.includes('M')) {
              const manualMarket = await Cache.use('main').get('marketId:' + mid)
              if (manualMarket) {
                handleMarketData([manualMarket]).then()
              }
            }

            if (market) {
              if (market.data !== null) {
                if (market.data instanceof Object) {
                  Ws.io.sockets.in(room.name).emit('message', JSON.stringify(market.data))
                }
              }
            }
          } else if (room.name.startsWith('FANCY')) {
            const mid = room.name.slice(5)

            let data: any = []

            const keys = await Redis.connection('main').keys(`manualFancyId:${mid}:*`)
            for (const key of keys) {
              let fancy: any = await Cache.use('redis').get(key)
              data.push(fancy)
            }

            const fancyIdData = await Cache.get(`FancyId:${mid}`)
            if (fancyIdData?.session && Array.isArray(fancyIdData.session)) {
              data = [...data, ...fancyIdData.session]
            }

            if (data.length > 0) {
              setTimeout(() => {
                Ws.io.sockets.in(`FANCY${mid}`).emit(`FANCY${mid}`, JSON.stringify(data))
              }, 1500)
            }
          }
        }
      }
    })

    //when room leave request made
    socket.on('leave_room', (room) => {
      if (room) {
        if (room.hasOwnProperty('name')) {
          socket.leave(room.name)
        }
      }
    })
  }
})

// async function updateActiveUsers() {
//   const keys = await Redis.keys('auth:*')
//   const userIds = new Set(keys.map((key) => key.split(':')[1].split('|')[0]))
//   const userCount = userIds.size

//   Ws.io.sockets.in(`ACTIVE_USERS`).emit(`ACTIVE_USERS`, userCount)
// }

async function updateActiveUsers() {
  const keys = await Redis.keys('auth:*')
  let exchbetUsers: any = []
  let exbetUsers: any = []

  for (let key of keys) {
    const value = await Cache.get(key)
    if (value) {
      if (value.hasOwnProperty('domain')) {
        if (value.usetype == '3' && value?.domain.includes('exchbet')) {
          exchbetUsers.push(key)
        } else if (value.usetype == '3' && value?.domain.includes('exbet')) {
          exbetUsers.push(key)
        }
      }
    }
  }
  const exchbetIds = new Set(exchbetUsers.map((key: any) => key.split(':')[1].split('|')[0]))
  const exchbetCount = exchbetIds.size
  const exbetIds = new Set(exbetUsers.map((key: any) => key.split(':')[1].split('|')[0]))
  const exbetCount = exbetIds.size

  Ws.io.sockets
    .in(`ACTIVE_USERS`)
    .emit(`ACTIVE_USERS`, JSON.stringify({ exchbetCount, exbetCount }))
}

async function updateActiveMarkets() {
  const data = await Redis.smembers('ACTIVE_MARKETS')
  activeMarkets = data.map((el: any) => JSON.parse(el))
  Ws.io.sockets.in(`ACTIVE_MARKETS`).emit(`ACTIVE_MARKETS`, activeMarkets.length)
}

async function handleMarketData(data) {
  for (const el of data) {
    const market = {
      id: el.marketId,
      data: {
        id: el.marketId,
        marketDefinition: {
          score: undefined,
          inPlay: el.inplay,
          status: el.status,
          multiplyBy: el?.multiplyBy,
          totalMatched: el?.totalMatched || 0,
          runners: el.runners.map((r, i) => {
            return {
              id: r.selectionId,
              status: r.status,
              sortPriority: i + 1,
              basePrice: r?.basePrice,
            }
          }),
        },
        rc: el.runners.map((r) => {
          const d = {
            batb: [],
            batl: [],
            id: r.selectionId,
          }

          if (r.hasOwnProperty('ex')) {
            if (r.ex.hasOwnProperty('availableToBack')) {
              d.batb = r.ex.availableToBack.map((b, bi) => {
                return [bi, b.price, b.size]
              })
            }

            if (r.ex.hasOwnProperty('availableToLay')) {
              d.batl = r.ex.availableToLay.map((l, li) => {
                return [li, l.price, l.size]
              })
            }
          }

          return d
        }),
        updated_at: el.updated_at,
      },
    }

    await fillData(market)

    //modify data
    await modifyData(market)

    Ws.io.sockets.in('EID' + market.id).emit('message', JSON.stringify(market.data))

    await Cache.put('dashboard_market:' + market.id, market.data, 3600)
  }
}

async function modifyData(market) {
  if (market.data.hasOwnProperty('rc')) {
    for (const r of market.data.rc) {
      if (r.hasOwnProperty('batb') && r.hasOwnProperty('batl')) {
        for (const l of r.batl) {
          if (l[0] == 0 && r.batb.length > 0) {
            if (l[1] == 1.01) {
              const u = r.batb.find((bb) => bb[0] == 0)

              if (u) {
                u[1] = 0
                u[2] = 0
              }
            }
          }
        }

        for (const b of r.batb) {
          if (b[0] == 0 && r.batl.length > 0) {
            if (b[1] == 1000) {
              const u = r.batl.find((ll) => ll[0] == 0)

              if (u) {
                u[1] = 0
                u[2] = 0
              }
            }
          }
        }
      }
    }
  }
}

async function fillData(market) {
  let diffInSeconds = 0
  if (market.updated_at) {
    diffInSeconds = Math.floor(
      Math.abs(new Date().getTime() - new Date(market.updated_at).getTime()) / 1000
    )
  }

  if (market.data.hasOwnProperty('rc')) {
    for (const r of market.data.rc) {
      if (r.hasOwnProperty('batb')) {
        if (diffInSeconds > 5) {
          r.batb = []
            ;[0, 1, 2].forEach((i) => {
              r.batb.push([i, 0, 0])
            })
        } else {
          r.batb.sort((a, b) => (a[0] > b[0] ? 1 : -1))

          if (r.batb.length == 0) {
            r.batb = []
              ;[0, 1, 2].forEach((i) => {
                r.batb.push([i, 0, 0])
              })
          } else if (r.batb.length == 1) {
            ;[1, 2].forEach((i) => {
              r.batb.push([i, 0, 0])
            })
          } else if (r.batb.length == 2) {
            r.batb.push([2, 0, 0])
          }
        }
      }

      if (r.hasOwnProperty('batl')) {
        if (diffInSeconds > 5) {
          r.batl = []
            ;[0, 1, 2].forEach((i) => {
              r.batl.push([i, 0, 0])
            })
        } else {
          r.batl.sort((a, b) => (a[0] > b[0] ? 1 : -1))

          if (r.batl.length == 0) {
            r.batl = []
              ;[0, 1, 2].forEach((i) => {
                r.batl.push([i, 0, 0])
              })
          } else if (r.batl.length == 1) {
            ;[1, 2].forEach((i) => {
              r.batl.push([i, 0, 0])
            })
          } else if (r.batl.length == 2) {
            r.batl.push([2, 0, 0])
          }
        }
      }
    }
  }
}

function parse(data: any) {
  try {
    return JSON.parse(data)
  } catch (e) {
    return null
  }
}
