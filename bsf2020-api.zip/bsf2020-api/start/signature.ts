import Signature from 'App/Services/Signature'

Signature.boot().then()
