// /*
// |--------------------------------------------------------------------------
// | Define HTTP rate limiters
// |--------------------------------------------------------------------------
// |
// | The "Limiter.define" method callback receives an instance of the HTTP
// | context you can use to customize the allowed requests and duration
// | based upon the user of the request.
// |
// */

// import { Limiter } from '@adonisjs/limiter/build/services'

// Limiter.define('global', () => {
//   return Limiter.allowRequests(1500).every('1 min')
// })

// Limiter.define('otp', ({ request }) => {
//   return Limiter.allowRequests(2)
//     .every('1 min')
//     .usingKey(request.input('mobile'))
//     .limitExceeded((error) => {
//       error.status = 429
//       error.message = `Otp request limit exceeded. Please try again after some time.`
//     })
// })

// Limiter.define('otp_ip', () => {
//   return Limiter.allowRequests(2)
//     .every('1 min')
//     .limitExceeded((error) => {
//       error.status = 429
//       error.message = `Otp request limit exceeded. Please try again after some time.`
//     })
// })

// Limiter.define('username', ({ request }) => {
//   return Limiter.allowRequests(50)
//     .every('1 min')
//     .usingKey(request.input('username'))
//     .limitExceeded((error) => {
//       error.status = 429
//       error.message = `Request limit exceeded. Please try again after some time.`
//     })
// })

// Limiter.define('username_ip', () => {
//   return Limiter.allowRequests(50)
//     .every('1 min')
//     .limitExceeded((error) => {
//       error.status = 429
//       error.message = `Request limit exceeded. Please try again after some time.`
//     })
// })

// Limiter.define('login', () => {
//   return Limiter.allowRequests(10)
//     .every('1 min')
//     .limitExceeded((error) => {
//       error.status = 429
//       error.message = `Request limit exceeded. Please try again after some time.`
//     })
// })

// Limiter.define('register', () => {
//   return Limiter.allowRequests(2)
//     .every('1 min')
//     .limitExceeded((error) => {
//       error.status = 429
//       error.message = `Request limit exceeded. Please try again after some time.`
//     })
// })

// Limiter.define('password_ip', () => {
//   return Limiter.allowRequests(3)
//     .every('1 min')
//     .limitExceeded((error) => {
//       error.status = 429
//       error.message = `Request limit exceeded. Please try again after some time.`
//     })
// })

// Limiter.define('password_phone', ({ request }) => {
//   return Limiter.allowRequests(3)
//     .every('1 min')
//     .usingKey(request.input('phone'))
//     .limitExceeded((error) => {
//       error.status = 429
//       error.message = `Request limit exceeded. Please try again after some time.`
//     })
// })
/*
|--------------------------------------------------------------------------
| Define HTTP rate limiters
|--------------------------------------------------------------------------
|
| The "Limiter.define" method callback receives an instance of the HTTP
| context you can use to customize the allowed requests and duration
| based upon the user of the request.
|
*/

import { Limiter } from '@adonisjs/limiter/build/services'

// Global limiter — higher capacity
Limiter.define('global', () => {
  return Limiter.allowRequests(20000).every('1 min')
})

// OTP via mobile number (and add IP-based as backup)
Limiter.define('otp', ({ request }) => {
  return Limiter.allowRequests(20)
    .every('1 min')
    .usingKey(request.input('mobile'))
    .limitExceeded((error) => {
      error.status = 429
      error.message = 'Too many OTP requests for this mobile. Try again later.'
    })
})

Limiter.define('otp_ip', ({ request }) => {
  return Limiter.allowRequests(40)
    .every('1 min')
    .usingKey(request.ip())
    .limitExceeded((error) => {
      error.status = 429
      error.message = 'Too many OTP requests from this IP. Try again later.'
    })
})

// Username-based rate limit
Limiter.define('username', ({ request }) => {
  return Limiter.allowRequests(400)
    .every('1 min')
    .usingKey(request.input('username'))
    .limitExceeded((error) => {
      error.status = 429
      error.message = 'Too many requests for this username. Please wait.'
    })
})

Limiter.define('username_ip', ({ request }) => {
  return Limiter.allowRequests(450)
    .every('1 min')
    .usingKey(request.ip())
    .limitExceeded((error) => {
      error.status = 429
      error.message = 'Too many username requests from this IP. Please wait.'
    })
})

// Login attempt limits
Limiter.define('login', ({ request }) => {
  return Limiter.allowRequests(45)
    .every('1 min')
    .usingKey(request.input('username') || request.ip())
    .limitExceeded((error) => {
      error.status = 429
      error.message = 'Too many login attempts. Please try again shortly.'
    })
})

// Registration rate limit
Limiter.define('register', ({ request }) => {
  return Limiter.allowRequests(20)
    .every('10 min') // Slower to prevent abuse
    .usingKey(request.ip())
    .limitExceeded((error) => {
      error.status = 429
      error.message = 'Too many registration attempts. Try again later.'
    })
})

// Password reset by IP
Limiter.define('password_ip', ({ request }) => {
  return Limiter.allowRequests(20)
    .every('10 min')
    .usingKey(request.ip())
    .limitExceeded((error) => {
      error.status = 429
      error.message = 'Too many password reset attempts from this IP.'
    })
})

// Password reset by phone number
Limiter.define('password_phone', ({ request }) => {
  return Limiter.allowRequests(12)
    .every('10 min')
    .usingKey(request.input('phone'))
    .limitExceeded((error) => {
      error.status = 429
      error.message = 'Too many password reset attempts for this phone.'
    })
})
