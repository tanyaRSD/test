class Domains {
  public list: string[] = []

  public async init() {
    const Database = (await import('@ioc:Adonis/Lucid/Database')).default

    const domains = await Database.from('domains').select('value', 'alternate_url')
    for (const domain of domains) {
      this.list.push(domain.value)
      if (domain.alternate_url) {
        this.list.push(domain.alternate_url)
      }
    }
  }
}

export default new Domains()
