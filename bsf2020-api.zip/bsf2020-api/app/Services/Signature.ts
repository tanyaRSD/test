import Cache from '@ioc:Adonis/Addons/Cache'
import Application from '@ioc:Adonis/Core/Application'
import Env from '@ioc:Adonis/Core/Env'
import crypto from 'crypto'
import fs from 'fs'
import reader from 'xlsx'

class Signature {
  private privateKey: any
  private dreamPublicKey: any
  private booted = false
  private algorithm = 'SHA256'
  public async boot() {
    if (this.booted) {
      return
    }

    this.privateKey = fs.readFileSync(Env.get('APP_PRIVATE_KEY'), 'utf8')
    this.dreamPublicKey = fs.readFileSync(Env.get('DREAM_PUBLIC_KEY'), 'utf8')

    this.booted = true
    this.loadGames()
  }

  public async sign(data: any) {
    data = Buffer.from(JSON.stringify(data))
    return crypto.sign(this.algorithm, data, this.privateKey)
  }

  public async verifyDream(data: any, signature: any) {
    return crypto.verify(
      this.algorithm,
      Buffer.from(data),
      this.dreamPublicKey,
      Buffer.from(signature, 'base64')
    )
  }

  public async loadGames() {
    const fileName = Application.inProduction ? './casino-list-prod.xlsx' : './casino-list-dev.xlsx'
    const file = reader.readFile(fileName)

    // await Cache.forget('dreamGameList')
    return await Cache.rememberForever('dreamGameList', async () => {
      let data: any = []
      const sheets = file.SheetNames

      for (const sheet of sheets) {
        if (Application.inProduction) {
          if (sheet == 'Full Gamelist' && Application.inProduction) {
            const temp: any = reader.utils.sheet_to_json(file.Sheets[sheet])
            if (Array.isArray(temp)) {
              const filtered = temp
                .filter((g) => g.sub_provider_name != 'Royal Gaming')
                .map((el: any) => {
                  el.product = el.sub_provider_name
                  return el
                })
              data.push(...filtered)
            }
          }
        } else {
          const temp: any = reader.utils.sheet_to_json(file.Sheets[sheet])
          data.push(...temp)
        }
      }

      return data
    })
  }
}

export default new Signature()
