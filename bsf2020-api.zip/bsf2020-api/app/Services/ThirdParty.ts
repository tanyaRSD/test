const exchBase = 'http://139.59.49.142/exch-api/'

class ThirdParty {
  public tokenApiUrl: any = 'http://18.132.86.137/api/abc.php'
  public pokerResults: any = 'https://fawk.app/api/exchange/odds/market/resultJson'
  public bookmakerApiUrl: any = 'http://139.59.162.241:3000/api/multiEvents/'

  // public directActiveApiUrl: any = 'https://oddsapi.247idhub.com/betfair_api/active_match/'
  public directActiveApiUrl: any = 'http://139.59.162.241:3000/api/events'
  public directActiveApiUrl2: any = 'http://139.59.162.241:3002/api/events'
  public directActiveApiUrl3: any = 'http://139.59.162.241:3003/api/events'
  public martetURL: any = 'http://139.59.162.241:3000/api/multiMarkets/'
  public marketRunnersApiUrl: any = exchBase + 'marketRunners?MarketID='
  public seriesListApiUrl: any = exchBase + 'series?EventTypeID='
  public matchListApiUrl: any = exchBase + 'match'
  public marketListApiUrl: any = exchBase + 'market?EventID='
  public horseMarketApi: any = exchBase + 'horse?EventTypeID='
  public channelsApi: any = exchBase + 'channels'
  public horseChannelsApi: any = ''
  public tvScoreApiUrl: any = 'https://score-session.dbm9.com/api/get-live-score?event_id='
  public paymentLoginUrl: any = 'https://api.step2pay.online/login'
  public paymentUrl: any = 'https://api.step2pay.online/partner/orders'
  public paymentWithdrawLogin = 'https://api.step2pay.online/login-merchant'
  public paymentWithdrawUrl: any = 'https://api.step2pay.online/partner/payout'
}

export default new ThirdParty()