import { MongoClient } from 'mongodb'
import Env from '@ioc:Adonis/Core/Env'

export const mongoInstance = new MongoClient(Env.get('MONGODB_CONNECTION'))
// export const mongoInstance = new MongoClient('mongodb://root:root@127.0.0.1:27017/', {
//   directConnection: true,
//   authSource: 'admin',
// })
export const Mongo = mongoInstance.db('happy')
