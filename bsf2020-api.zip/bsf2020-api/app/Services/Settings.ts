import Cache from '@ioc:Adonis/Addons/Cache'
import Database from '@ioc:Adonis/Lucid/Database'

class Settings {
  public defaultSportLimit: any = []
  public defaultSettings = [
    {
      name: 'line_fancy_volume',
      value: 10,
    },
    {
      name: 'match_odds_limit',
      value: 0,
    },
    {
      name: 'market_volume',
      value: 1,
    },
    {
      name: 'max_market_liability',
      value: 0,
    },
    {
      name: 'fancy_max_session_bet_liability',
      value: 2000000,
    },
    {
      name: 'fancy_max_session_liability',
      value: 2000000,
    },
    {
      name: 'line_fancy_delay',
      value: 3,
    },
  ]

  public fancyPriorities = [
    {
      name: 'Over Runs',
      value: 1,
    },
    {
      name: 'Wicket',
      value: 3,
    },
    {
      name: 'Player Run',
      value: 2,
    },
    {
      name: 'Others',
      value: 4,
    },
  ]

  // public fancyPriorities = [
  //   {
  //     name: 'Session',
  //     value: 1,
  //   },
  //   {
  //     name: 'Player',
  //     value: 2,
  //   },
  //   {
  //     name: 'Wicket',
  //     value: 3,
  //   },
  //   {
  //     name: 'Other',
  //     value: 4,
  //   },
  //   {
  //     name: 'Random',
  //     value: 5,
  //   },
  // ]

  constructor() {
    this.initLimit().then()
    setInterval(() => {
      if (this.defaultSportLimit.length === 0) {
        this.initLimit().then()
      }
    }, 2000)
  }

  public async initLimit() {
    this.defaultSportLimit = await Database.query().from('user_sport_limit').where('user_id', 1)
    if (this.defaultSportLimit.length == 0) {
      for (const sport of await Database.from('sportmst')) {
        let marketType = sport.id == 4 ? ['market', 'bookmaker', 'fancy', 'toss'] : ['market']
        for (const type of marketType) {
          try {
            if (type !== 'fancy' || (type === 'fancy' && sport.id === 4)) {
              await Database.table('user_sport_limit').insert({
                user_id: 1,
                sport_id: sport.id,
                type: type,
                max_stake: type == 'fancy' ? 1000000 : type == 'toss' ? 500000 : 5000000,
                min_stake: 10,
                max_profit: 500000,
                bet_delay: 0,
                market_volume: 1,
                max_market_liability: 0,
              })
            }
          } catch (e) { }
        }
      }
    }
  }

  public async all(): Promise<any> {
    const settings: any = await Cache.rememberForever('defaultSettings', async () => {
      return this.defaultSettings
    })

    // convert array to object
    let rv = {}
    for (const s of settings) {
      rv[s.name] = s.value
    }
    return rv
  }
}

export default new Settings()
