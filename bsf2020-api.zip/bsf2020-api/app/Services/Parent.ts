import UserService from './UserService'

class Parent {
  public async validate(user: any, userId: any) {
    const id = user?.mstrid
    const parentData: any = await UserService.parents(userId)
    const parentIds = parentData.map((i: any) => i.mstrid)
    return parentIds.length > 0 ? parentIds.indexOf(id) > -1 : false
  }
}

export default new Parent()
