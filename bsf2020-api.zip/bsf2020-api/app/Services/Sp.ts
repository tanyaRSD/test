import Database from '@ioc:Adonis/Lucid/Database'

class Sp {
  public async call(procedure: string, bindings?: any, raw = 'call ') {
    const data = await Database.rawQuery(raw + procedure, bindings, { mode: 'write' })
    try {
      return JSON.parse(JSON.stringify(data[0][0]))
    } catch (err) {
      return []
    }
  }

  public async readCall(procedure: string, bindings?: any, raw = 'call ') {
    console.log('SP readCall', procedure, bindings)
    const data = await Database.rawQuery(raw + procedure, bindings, { mode: 'write' })
    try {
      return JSON.parse(JSON.stringify(data[0][0]))
    } catch (err) {
      return []
    }
  }

  public async parents(id: string | number) {
    return Database.query()
      .withRecursive('tree', (query) => {
        query
          .from('createmaster')
          .select(
            'mstrid',
            'mstrname',
            'mstruserid',
            'parentId',
            'usetype',
            'allow_deposit_withdraw',
            'casino_limit',
            'partner_cricket'
          )
          .where('mstrid', id)
          .unionAll((subquery) => {
            subquery
              .from('createmaster as p')
              .select([
                'p.mstrid',
                'p.mstrname',
                'p.mstruserid',
                'p.parentId',
                'p.usetype',
                'p.allow_deposit_withdraw',
                'p.casino_limit',
                'p.partner_cricket'
              ])
              .innerJoin('tree', 'tree.parentId', '=', 'p.mstrid')
          })
      })
      .select('mstrid', 'mstrname', 'mstruserid', 'parentId', 'usetype', 'allow_deposit_withdraw', 'casino_limit', 'partner_cricket')
      .from('tree')
  }

  public parentsIds(id: string | number, excludeAdmin = false) {
    return Database.query()
      .withRecursive('tree', (query) => {
        query
          .from('createmaster')
          .select('mstrid', 'parentId')
          .where('mstrid', id)
          .unionAll((subquery) => {
            subquery
              .from('createmaster as p')
              .select(['p.mstrid', 'p.parentId'])
              .innerJoin('tree', 'tree.parentId', '=', 'p.mstrid')
          })
      })
      .select('mstrid')
      .if(excludeAdmin, (q) => {
        q.whereNot('mstrid', 1)
      })
      .from('tree')
  }
}

export default new Sp()
