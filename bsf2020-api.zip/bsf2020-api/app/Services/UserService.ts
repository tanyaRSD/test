import Cache from '@ioc:Adonis/Addons/Cache'
import Redis from '@ioc:Adonis/Addons/Redis'
import Database, { DatabaseQueryBuilderContract } from '@ioc:Adonis/Lucid/Database'
import User from 'App/Models/User'
import axios from 'axios'
import Sp from './Sp'
import crypto from 'crypto'
import { URLSearchParams } from 'url'
import { Mongo } from './Mongo'

class UserService {
  public adminCode: string = '9868'
  public dealerCode: string = '8721'
  public SystemConfPassword: string = 'Z5nW2k'

  public async changePassword(id: string | number, password: string, selfChange = true) {
    await Database.rawQuery(
      'UPDATE createmaster SET password_changed = :selfChange, mstrpassword = sha1(:newpassword) WHERE mstrid = :id',
      {
        newpassword: password,
        id: id,
        selfChange: selfChange ? 1 : 0,
      },
      {
        mode: 'write',
      }
    )

    // const keys = await Redis.keys('auth:' + id + '|*')
    // for (const key of keys) {
    //   await Redis.del(key)
    // }

    this.deleteKeys(await Redis.keys('auth:' + id + '|*')).then()
  }

  public async verifyPassword(id: string | number, password: string) {
    return await User.query()
      .where('mstrid', id)
      .whereRaw('mstrpassword = sha1(:oldPassword)', {
        oldPassword: password,
      })
      .first()
  }

  public async sendOtp(phone: string | number, otp: string, _name: string = '') {
    // const key = 'VpcSleQ0wJOnrxBstK7vaCAziER9kfNY1oIqdL4uTyW2H3D6mjC3NcBfztkW9ayqmwoipn1gPKOMdsH0'
    // const key = 'e7c4544b-ac4d-11ed-813b-0200cd936042'

    // return await axios.get(
    //   // `https://www.fast2sms.com/dev/bulkV2?authorization=${key}&route=${otp}&variables_values=&flash=0&numbers=${phone}`
    //   `https://2factor.in/API/V1/${key}/SMS/${phone}/${otp}/:otp_template_name`
    // )

    return await axios.post('http://mobicomm.dove-sms.com/REST/sendsms/', {
      listsms: [
        {
          sms: `Dear User # DO NOT SHARE: ${otp} is your OTP. This will expire in 10 minutes. Mayan Handi`,
          mobiles: phone,
          senderid: 'KOHNRO',
          clientsmsid: '1947692308',
          accountusagetypeid: '1',
          entityid: '1201159465873331672',
          tempid: '1207170841294813693',
        },
      ],
      password: '4e210b5716XX',
      user: 'Vinayank',
    })
  }

  public async sendOtpSmsNet(phone: string | number, otp: string) {
    return await axios.get(
      `https://api.sms.net.bd/sendsms?api_key=1stcn3TtI18rw5c2QxHE6xPSmF75tR3bncPWWSgO&msg=Your OTP Code is ${otp}&to=${phone}`
    )
  }

  public async sendOtpOnbuka(phone: string | number, otp: string) {
    const timestamp = Date.now() / 1000
    const apiKey = '7kpPwfFH'
    const apiSecret = '5EuTm1Iy'
    const appId = '3sESQo82'
    const sign = crypto
      .createHash('md5')
      .update(apiKey + apiSecret + timestamp)
      .digest('hex')

    return await axios.post(
      `https://api.onbuka.com/v3/sendSms`,
      {
        appId: appId,
        numbers: '880' + phone,
        content: `Your OTP code is ${otp}`,
      },
      {
        headers: {
          'Timestamp': timestamp,
          'Api-Key': apiKey,
          'Sign': sign,
          'Content-Type': 'application/json;charset=UTF-8',
        },
      }
    )
  }

  public async sendOtpGreenWeb(phone: string | number, otp: string) {
    const greenwebsms = new URLSearchParams()
    greenwebsms.append('token', '985214593617146403762ccbcdf5bc9a3c66e35cfe4619930936')
    greenwebsms.append('to', '+880' + phone)
    greenwebsms.append('message', otp + 'is your verification code.')
    return axios.post('http://api.greenweb.com.bd/api.php', greenwebsms)
  }

  public async parents(id: number | string) {
    return await Cache.rememberForever('parents:' + id, async () => {
      return Sp.parents(id)
    })
  }

  public async getLiability(id: string | number, _type?: string, mongoData?: any) {
    // if (type == 'RESULT') {
    //   return await Sp.call('getLiability_DeclareResult(:id)', {
    //     id: id,
    //   })
    // } else if (type == 'SETTLEMENT') {
    //   return await Sp.call('getLiability_Settlement(:id)', {
    //     id: id,
    //   })
    // } else if (type == 'DEPOSIT') {
    //   return await Sp.call('getLiability_Deposit(:id)', {
    //     id: id,
    //   })
    // } else if (type == 'WITHDRAW') {
    //   return await Sp.call('getLiability_Withdraw(:id)', {
    //     id: id,
    //   })
    // } else {
    //    return await Sp.call('getLiability(:id)', {
    //     id: id,
    //    })
    // }

    if (mongoData) {
      await Mongo.collection('logs').insertOne({
        ...mongoData,
        logType: 'Update Liability inside getLiability Started',
        createdAt: new Date(),
      })
    }
    console.log('mongoData for MatchId', JSON.stringify(mongoData));
    // ✅ Redis keys
    const successKey = mongoData?.matchId ? `MATCH:${mongoData.matchId}:GL_SUCCESS_COUNT` : null
    const failKey = mongoData?.matchId ? `MATCH:${mongoData.matchId}:GL_FAIL_COUNT` : null
    const failDataKey = mongoData?.matchId ? `MATCH:${mongoData.matchId}:GL_FAIL_DATA` : null

    let result
    // result = await Sp.call('getLiability(:id)', {
    //   id: id,
    // })
    // result = await this.getLiabilityQuery(id)
    try {
      result = await Sp.readCall('getLiability(:id)', {
        id: id,
      })
      console.log('test saveCoins->getLiabiligy 3.1 flag');
      console.log(result, mongoData);
      if (result.length > 0) {
        const data = result[0]
        if (mongoData) {
          await Mongo.collection('logs').insertOne({
            ...mongoData,
            logType: 'Update Liability inside getLiability Ended',
            liability: data.Liability,
            balance: data.Balance,
            createdAt: new Date(),
          })
        }

        // ✅ SUCCESS COUNT
        if (successKey) {
          await Redis.incr(successKey)
          await Redis.expire(successKey, 3600)
        }
      } else {
        // ⚠️ treat empty result as failure (optional but recommended)
        if (failKey && failDataKey) {
          await Redis.incr(failKey)
          await Redis.expire(failKey, 3600)

          await Redis.rpush(
            failDataKey,
            JSON.stringify({
              userId: id,
              reason: 'EMPTY_RESULT',
              payload: mongoData,
              time: new Date(),
            })
          )
          await Redis.expire(failDataKey, 3600)
        }
      }

      return result

    } catch (err: any) {
      console.error('getLiability failed:', id, err)

      // ❌ FAILURE COUNT + FULL DATA
      if (failKey && failDataKey) {
        await Redis.incr(failKey)
        await Redis.expire(failKey, 3600)

        await Redis.rpush(
          failDataKey,
          JSON.stringify({
            userId: id,
            error: err.message,
            stack: err.stack,
            payload: mongoData,
            time: new Date(),
          })
        )
        await Redis.expire(failDataKey, 3600)
      }

      throw err // ⚠️ important: don't swallow error
    }
  }
  // tanya changes start
  public async clearLiability(userId: number, mongoData?: any) {
    try {
      const liabilityKey = 'USER_LIABILITY' + userId
      await Redis.incr(liabilityKey)

      const rows: any = await this.getLiability(userId, mongoData?.type || '', mongoData)

      if (rows.length > 0) {
        const data = rows[0]

        const pokerLiability: any = await this.getPokerLiability(userId)
        const kingLiability: any = await this.getKingLiability(userId)

        const balance = parseFloat(data.Balance) - pokerLiability - kingLiability
        const liability = parseFloat(data.Liability) - pokerLiability - kingLiability

        const profitLoss = await this.getProfitLoss(userId)

        const finalData = {
          liability: 0,
          balance: balance,
          p_l: data.chipspnl,
          freechips: data.FreeChip,
          chip: data.Chip,
          sessionLiability: 0,
          unmatchliability: 0,
          profit_loss: profitLoss.total,
        }
        const user = await Database.query().from('createmaster').where('mstrid', userId).first()

        await Mongo.collection('logs').insertOne({
          ...mongoData,
          logType: 'Cleared Liability',
          createdAt: new Date(),
          afterBalance: balance,
          afterLiability: liability,
          beforeBalance: user?.balance,
          beforeLiability: user?.liability,
        })

        await Database.query().from('createmaster').where('mstrid', userId).update(finalData)

        let userData = {
          user_id: userId,
          data: {
            type: 'balance',
            data: finalData,
          },
        }

        await Redis.publish('USER_UPDATE_DATA', JSON.stringify(userData))

        const keys = await Redis.keys('auth:' + userId + '|*')

        for (const key of keys) {
          let user: any = await Cache.get(key)
          if (user) {
            user.liability = 0
            user.balance = balance
            user.p_l = data.chipspnl
            user.freechips = data.FreeChip
            user.chip = data.Chip
            user.profit_loss = profitLoss.total

            await Cache.put(key, user, 3600)
          }
        }
      }

      await Redis.del(liabilityKey)
    } catch (e) {
      console.log('In clear liability catch:', e)
    }
  }
  //tanya changes end
  // public async bets(
  //   userId: any,
  //   filters: {
  //     marketId?: any
  //     matchId?: any
  //     sportId?: any
  //     search?: any
  //     needPagination?: boolean
  //     page?: number
  //     limit?: number
  //     type?: any
  //     fancyId?: any
  //     afterResult?: boolean
  //     bet_deleted?: boolean
  //     bet_type?: any
  //     fromDate?: any
  //     toDate?: any
  //     latest?: boolean
  //     userId?: any
  //   } = {
  //     marketId: null,
  //     matchId: null,
  //     sportId: null,
  //     search: null,
  //     needPagination: false,
  //     page: 1,
  //     limit: 70,
  //     type: null,
  //     fancyId: null,
  //     afterResult: false,
  //     bet_deleted: false,
  //     bet_type: null,
  //     fromDate: null,
  //     toDate: null,
  //     latest: true,
  //     userId: null,
  //   }
  // ) {
  //   const table1 = filters.bet_deleted ? 'tblbets_bak' : 'tblbets'
  //   const table1Query = Database.query()
  //     .from(`${table1} as a`)
  //     .join('matchmst', 'matchmst.MstCode', '=', 'a.MatchId')
  //     .join('market', 'market.Id', '=', 'a.MarketId')
  //     .select(
  //       'a.ParentExchCompanyID',
  //       'a.CompanyID',
  //       'a.AdminID',
  //       'a.SAdminID',
  //       'a.SMasterID',
  //       'a.MasterID',
  //       'a.DealerID',
  //       'a.ParentExchCompany',
  //       'a.Company',
  //       'a.Admin',
  //       'a.SAdmin',
  //       'a.SMaster',
  //       'a.Master',
  //       'a.Dealer',
  //       'a.MstCode',
  //       'a.UserId',
  //       'a.UserName',
  //       'a.MatchId',
  //       'a.MarketId',
  //       'a.SelectionId',
  //       'a.selectionName',
  //       'a.MstDate',
  //       'a.Odds',
  //       'a.Stack',
  //       'a.P_L',
  //       'a.isBack',
  //       'a.IsMatched',
  //       'a.IP_ADDESSS as ip',
  //       Database.raw('0 as volume'),
  //       Database.raw('0 as void'),
  //       Database.raw('0 as is_fancy'),
  //       'matchmst.matchName as matchName',
  //       'market.Name as marketName',
  //       'market.sportsId as sportsId',
  //       Database.raw(
  //         "CONCAT(sportmst.Name, '>', matchmst.MatchName, '>', market.Name) AS Description"
  //       ), //0
  //       Database.raw("CASE WHEN a.isBack = 0 THEN 'Back' ELSE 'Lay' END AS Type"),
  //       Database.raw(
  //         'CASE WHEN IFNULL(a.result, 0) = 1 THEN CASE WHEN IFNULL(a.isBack, 0) = 0 THEN a.P_L ELSE a.Stack END END AS Profit'
  //       ), // 0
  //       Database.raw(
  //         'CASE WHEN IFNULL(a.result, 0) = 0 THEN CASE WHEN IFNULL(a.isBack, 0) = 0 THEN a.Stack ELSE a.P_L END END AS Liability'
  //       ), // 0
  //       Database.raw("CASE WHEN a.ResultID IS NULL THEN 'Open' ELSE 'Settled' END AS STATUS") // 0
  //     )
  //     .join('sportmst', 'sportmst.id', '=', 'market.sportsId')
  //     .select('sportmst.name as sportName')
  //     .if(
  //       filters.userId,
  //       (q) => {
  //         q.where('a.UserId', filters.userId)
  //       },
  //       (q) => {
  //         q.where((query) => {
  //           query
  //             .where('a.UserId', userId)
  //             .orWhere('a.ParantId', userId)
  //             .orWhere('a.DealerID', userId)
  //             .orWhere('a.MasterID', userId)
  //             .orWhere('a.SMasterID', userId)
  //             .orWhere('a.SAdminID', userId)
  //             .orWhere('a.AdminID', userId)
  //             .orWhere('a.CompanyID', userId)
  //             .orWhere('a.ParentExchCompanyID', userId)
  //         })
  //       }
  //     )

  //     .if(filters.marketId, (q) => {
  //       q.where('a.MarketId', filters.marketId)
  //     })
  //     .if(filters.sportId, (q) => {
  //       q.where('sportmst.id', filters.sportId)
  //     })
  //     .if(filters.matchId, (q) => {
  //       q.where('a.MatchId', filters.matchId)
  //     })
  //     .if(filters.type == 'market', (q) => {
  //       q.where('a.MarketId', 'NOT LIKE', `%B%`)
  //     })
  //     .if(filters.type == 'bookmaker', (q) => {
  //       q.andWhereILike('a.MarketId', `%B%`)
  //     })
  //     .if(filters.search, (b) => {
  //       b.where((q) => {
  //         q.whereILike('matchmst.matchName', '%' + filters.search + '%')
  //         q.orWhereILike('market.Name', '%' + filters.search + '%')
  //         q.orWhereILike('a.UserName', '%' + filters.search + '%')
  //         q.orWhereILike('a.selectionName', '%' + filters.search + '%')
  //         q.orWhereILike('a.IP_ADDESSS', '%' + filters.search + '%')
  //       })
  //     })
  //     .if(filters.bet_type, (q) => {
  //       q.if(filters.bet_type == 'M', (query) => {
  //         query.where('a.isMatched', 1)
  //         query.andWhereNull('a.ResultID')
  //       })
  //       q.if(filters.bet_type == 'U', (query) => {
  //         query.where('a.isMatched', 0)
  //         query.andWhereNull('a.ResultID')
  //       })
  //       q.if(filters.bet_type == 'P', (query) => {
  //         query.whereNotNull('a.ResultID')
  //       })
  //     })
  //     .if(filters.fromDate && filters.toDate, (q: any) => {
  //       q.where('a.MstDate', '>=', filters.fromDate + 'T00:00:00')
  //       q.where('a.MstDate', '<=', filters.toDate + 'T23:59:59')
  //     })
  //     .if(!filters.afterResult, (q) => q.whereNull('a.ResultID'))
  //   // .if(filters.latest, (q) => q.orderBy('a.MstDate', 'desc'))
  //   // .if(!filters.latest, (q) => q.orderBy('a.MstDate', 'asc'))

  //   const table2 = filters.bet_deleted ? 'bet_entry_bak' : 'bet_entry'

  //   let betDeleted = `CASE WHEN b.OddValue = 0 THEN 'Back' ELSE 'Lay' END AS Type`
  //   if (filters.bet_deleted) {
  //     betDeleted = `CASE WHEN b.TypeID = 1 THEN 'E/O' WHEN b.TypeID = 2 THEN 'Session' WHEN b.TypeID = 3 THEN 'Kaddal' WHEN b.TypeID = 4 THEN 'Last Digit' WHEN b.TypeID = 5 THEN 'UpDown' END AS Type`
  //   }
  //   const table2Query = (builer: DatabaseQueryBuilderContract) =>
  //     builer
  //       .from(`${table2} as b`)
  //       .join('matchmst', 'matchmst.MstCode', '=', 'b.MatchId')
  //       // .join('market', 'market.Id', '=', 'bet_entry.TypeID')
  //       .select(
  //         'b.ParentExchCompanyID',
  //         'b.CompanyID',
  //         'b.AdminID',
  //         'b.SAdminID',
  //         'b.SMasterID',
  //         'b.MasterID',
  //         'b.DealerID',
  //         'b.ParentExchCompany',
  //         'b.Company',
  //         'b.Admin',
  //         'b.SAdmin',
  //         'b.SMaster',
  //         'b.Master',
  //         'b.Dealer',
  //         'b.bet_id as MstCode',
  //         'b.userId as UserId',
  //         'b.UserName',
  //         'b.matchId as MatchId',
  //         'b.TypeID as MarketId',
  //         'b.fancyId as SelectionId',
  //         Database.raw(
  //           "CONCAT(FHeadName, ' (', session_no_size, '-', session_yes_size, ')') as selectionName"
  //         ),
  //         'b.dateTime as MstDate',
  //         Database.raw('FORMAT(OddsNumber, 0) as Odds'),
  //         'b.bet_value as Stack',
  //         Database.raw(
  //           'FORMAT((CASE WHEN OddValue = 1 THEN (bet_value * (session_no_size/100)) WHEN OddValue = 0 THEN (bet_value * (session_yes_size/100)) ELSE 0 END), 0) as P_L'
  //         ),
  //         Database.raw(
  //           '(CASE WHEN (b.TypeID = 5 OR b.TypeID = 2) AND OddValue = 0 THEN 0 ELSE 1 END) as isBack'
  //         ),
  //         Database.raw('0 as IsMatched'),
  //         'b.IP_ADDRESS as ip',
  //         Database.raw(
  //           '(CASE WHEN OddValue = 1 THEN session_no_size ELSE session_yes_size END) as volume'
  //         ),
  //         Database.raw('0 as void'),
  //         Database.raw('1 as is_fancy'),
  //         'matchmst.matchName as matchName',
  //         Database.raw('null as marketName'),
  //         'b.sportId as sportsId',
  //         Database.raw(
  //           "CONCAT(sportmst.Name, '>', matchmst.MatchName, '>', b.FheadName, '>', IFNULL(m.result, '')) AS Description"
  //         ),
  //         Database.raw(betDeleted),
  //         Database.raw('CASE WHEN IFNULL(b.Chips, 0) > 0 THEN Chips ELSE 0 END AS Profit'), // 0
  //         Database.raw('CASE WHEN IFNULL(b.Chips, 0) < 0 THEN Chips ELSE 0 END AS Liability'), //0
  //         Database.raw("CASE WHEN b.ResultID IS NULL THEN 'Open' ELSE 'Settled' END AS STATUS") // 0
  //       )
  //       .join('sportmst', 'sportmst.id', '=', 'b.sportId')
  //       .leftJoin('matchfancy AS m', 'b.fancyID', 'm.ID')
  //       .select('sportmst.name as sportName')
  //       .where((query) => {
  //         query
  //           .where('b.UserId', userId)
  //           .orWhere('b.ParantId', userId)
  //           .orWhere('b.DealerID', userId)
  //           .orWhere('b.MasterID', userId)
  //           .orWhere('b.SMasterID', userId)
  //           .orWhere('b.SAdminID', userId)
  //           .orWhere('b.AdminID', userId)
  //           .orWhere('b.CompanyID', userId)
  //           .orWhere('b.ParentExchCompanyID', userId)
  //       })
  //       .if(filters.marketId, (q) => {
  //         q.where('b.TypeID', filters.marketId)
  //       })
  //       .if(filters.sportId, (q) => {
  //         q.where('sportmst.id', filters.sportId)
  //       })
  //       .if(filters.matchId, (q) => {
  //         q.where('b.matchId', filters.matchId)
  //       })
  //       .if(filters.fancyId, (q) => {
  //         q.where('b.fancyId', filters.fancyId)
  //       })
  //       .if(filters.search, (b) => {
  //         b.where((q) => {
  //           q.whereILike('matchmst.matchName', '%' + filters.search + '%')
  //           q.orWhereILike('b.UserName', '%' + filters.search + '%')
  //           q.orWhereILike('b.FHeadName', '%' + filters.search + '%')
  //           q.orWhereILike('b.IP_ADDRESS', '%' + filters.search + '%')
  //         })
  //       })
  //       .if(filters.bet_type, (q) => {
  //         q.if(filters.bet_type == 'M', (query) => {
  //           query.andWhereNull('b.ResultID')
  //         })
  //         q.if(filters.bet_type == 'U', (query) => {
  //           query.andWhereNull('b.ResultID')
  //         })
  //         q.if(filters.bet_type == 'P', (query) => {
  //           query.whereNotNull('b.ResultID')
  //         })
  //       })
  //       .if(filters.fromDate && filters.toDate, (q: any) => {
  //         q.where('b.dateTime', '>=', filters.fromDate + 'T00:00:00')
  //         q.where('b.dateTime', '<=', filters.toDate + 'T23:59:59')
  //       })
  //       .if(!filters.afterResult, (q) => q.whereNull('b.ResultID'))
  //   // .if(filters.latest, (q) => q.orderBy('b.dateTime', 'desc'))
  //   // .if(!filters.latest, (q) => q.orderBy('b.dateTime', 'asc'))

  //   let query: any

  //   if (!filters.type) {
  //     query = table1Query.union(table2Query)
  //   } else if (filters.type !== 'fancy') {
  //     query = table1Query
  //   } else {
  //     query = Database.query().if(true, table2Query)
  //   }

  //   let q = query
  //     .if(filters.latest, (q: any) => q.orderBy('MstDate', 'asc'))
  //     .if(!filters.latest, (q: any) => q.orderBy('MstDate', 'desc'))

  //   if (filters.needPagination) {
  //     // @ts-ignore
  //     return await q.paginate(filters.page, filters.limit)
  //   }

  //   return await q
  // }

  public async bets(
    userId: any,
    filters: {
      marketId?: any
      matchId?: any
      sportId?: any
      search?: any
      needPagination?: boolean
      page?: number
      limit?: number
      type?: any
      fancyId?: any
      afterResult?: boolean
      bet_deleted?: boolean
      bet_type?: any
      fromDate?: any
      toDate?: any
      latest?: boolean
      userId?: any
    } = {
        marketId: null,
        matchId: null,
        sportId: null,
        search: null,
        needPagination: false,
        page: 1,
        limit: 70,
        type: null,
        fancyId: null,
        afterResult: false,
        bet_deleted: false,
        bet_type: null,
        fromDate: null,
        toDate: null,
        latest: true,
        userId: null,
      }
  ) {
    const table1 = filters.bet_deleted ? 'tblbets_bak' : 'tblbets'
    const table1Query = Database.query()
      .from(`${table1} as a`)
      .join('matchmst', 'matchmst.MstCode', '=', 'a.MatchId')
      .join('market', 'market.Id', '=', 'a.MarketId')
      .join('sportmst', 'sportmst.id', '=', 'market.sportsId')

      // ⭐ CORRECT JOIN FOR NORMAL BETS
      .join('createmaster', 'createmaster.mstrid', '=', 'a.UserId')

      .leftJoin('tblresult as r', function () {
        this.on('r.matchId', '=', 'a.MatchId').andOn('r.selectionId', '=', 'a.SelectionId')
      })
      .select(
        'a.ParentExchCompanyID',
        'a.CompanyID',
        'a.AdminID',
        'a.SAdminID',
        'a.SMasterID',
        'a.MasterID',
        'a.DealerID',
        'a.ParentExchCompany',
        'a.Company',
        'a.Admin',
        'a.SAdmin',
        'a.SMaster',
        'a.Master',
        'a.Dealer',
        'a.MstCode',
        'a.UserId',
        'a.UserName',
        'a.MatchId',
        'a.MarketId',
        'a.SelectionId',
        'a.selectionName',
        'a.MstDate',
        'a.Odds',
        'a.Stack',
        'a.P_L',
        'a.isBack',
        'a.IsMatched',
        'a.IP_ADDESSS as ip',
        Database.raw('0 as volume'),
        Database.raw('0 as void'),
        Database.raw('0 as is_fancy'),
        'matchmst.matchName as matchName',
        'market.Name as marketName',
        'market.sportsId as sportsId',
        Database.raw(
          "CONCAT(sportmst.Name, '>', matchmst.MatchName, '>', market.Name) AS Description"
        ),
        Database.raw("CASE WHEN a.isBack = 0 THEN 'Back' ELSE 'Lay' END AS Type"),
        Database.raw(
          'CASE WHEN IFNULL(a.result, 0) = 1 THEN CASE WHEN IFNULL(a.isBack, 0) = 0 THEN a.P_L ELSE a.Stack END END AS Profit'
        ),
        Database.raw(
          'CASE WHEN IFNULL(a.result, 0) = 0 THEN CASE WHEN IFNULL(a.isBack, 0) = 0 THEN a.Stack ELSE a.P_L END END AS Liability'
        ),
        Database.raw("CASE WHEN a.ResultID IS NULL THEN 'Open' ELSE 'Settled' END AS STATUS"),
        'sportmst.name as sportName',
        'r.selectionId as tblresult_selectionId',
        'r.result as tblresult_result',
        'r.isFancy as tblresult_isFancy',

        // ⭐ ADDED FIELD
        'createmaster.mstrname as mstrname'
      )
      .if(
        filters.userId,
        (q) => q.where('a.UserId', filters.userId),
        (q) => {
          q.where((query) => {
            query
              .where('a.UserId', userId)
              .orWhere('a.ParantId', userId)
              .orWhere('a.DealerID', userId)
              .orWhere('a.MasterID', userId)
              .orWhere('a.SMasterID', userId)
              .orWhere('a.SAdminID', userId)
              .orWhere('a.AdminID', userId)
              .orWhere('a.CompanyID', userId)
              .orWhere('a.ParentExchCompanyID', userId)
          })
        }
      )
      .if(filters.marketId, (q) => q.where('a.MarketId', filters.marketId))
      .if(filters.sportId, (q) => q.where('sportmst.id', filters.sportId))
      .if(filters.matchId, (q) => q.where('a.MatchId', filters.matchId))
      .if(filters.type == 'market', (q) => q.where('a.MarketId', 'NOT LIKE', `%B%`))
      .if(filters.type == 'bookmaker', (q) => q.andWhereILike('a.MarketId', `%B%`))
      .if(filters.search, (b) => {
        b.where((q) => {
          q.whereILike('matchmst.matchName', `%${filters.search}%`)
          q.orWhereILike('market.Name', `%${filters.search}%`)
          q.orWhereILike('a.UserName', `%${filters.search}%`)
          q.orWhereILike('a.selectionName', `%${filters.search}%`)
          q.orWhereILike('a.IP_ADDESSS', `%${filters.search}%`)
        })
      })
      .if(filters.bet_type, (q) => {
        q.if(filters.bet_type == 'M', (query) => {
          query.where('a.isMatched', 1).andWhereNull('a.ResultID')
        })
        q.if(filters.bet_type == 'U', (query) => {
          query.where('a.isMatched', 0).andWhereNull('a.ResultID')
        })
        q.if(filters.bet_type == 'P', (query) => {
          query.whereNotNull('a.ResultID')
        })
      })
      .if(filters.fromDate && filters.toDate, (q: any) => {
        q.where('a.MstDate', '>=', filters.fromDate + 'T00:00:00')
        q.where('a.MstDate', '<=', filters.toDate + 'T23:59:59')
      })
      .if(!filters.afterResult, (q) => q.whereNull('a.ResultID'))

    // ⭐ TABLE2 — FANCY BETS
    const table2 = filters.bet_deleted ? 'bet_entry_bak' : 'bet_entry'

    let betDeleted = `CASE WHEN b.OddValue = 0 THEN 'Back' ELSE 'Lay' END AS Type`
    if (filters.bet_deleted) {
      betDeleted = `CASE WHEN b.TypeID = 1 THEN 'E/O' WHEN b.TypeID = 2 THEN 'Session' WHEN b.TypeID = 3 THEN 'Kaddal' WHEN b.TypeID = 4 THEN 'Last Digit' WHEN b.TypeID = 5 THEN 'UpDown' END AS Type`
    }

    const table2Query = (builder: DatabaseQueryBuilderContract) =>
      builder
        .from(`${table2} as b`)
        .join('matchmst', 'matchmst.MstCode', '=', 'b.MatchId')
        .join('sportmst', 'sportmst.id', '=', 'b.sportId')

        // ⭐ CORRECT JOIN FOR FANCY BETS
        .join('createmaster', 'createmaster.mstrid', '=', 'b.userId')

        .leftJoin('matchfancy AS m', 'b.fancyID', 'm.ID')
        .leftJoin('tblresult as r', function () {
          this.on('r.matchId', '=', 'b.MatchId').andOn('r.selectionId', '=', 'b.fancyId')
        })
        .select(
          'b.ParentExchCompanyID',
          'b.CompanyID',
          'b.AdminID',
          'b.SAdminID',
          'b.SMasterID',
          'b.MasterID',
          'b.DealerID',
          'b.ParentExchCompany',
          'b.Company',
          'b.Admin',
          'b.SAdmin',
          'b.SMaster',
          'b.Master',
          'b.Dealer',
          'b.bet_id as MstCode',
          'b.userId as UserId',
          'b.UserName',
          'b.matchId as MatchId',
          'b.TypeID as MarketId',
          'b.fancyId as SelectionId',
          Database.raw(
            "CONCAT(FHeadName, ' (', session_no_size, '-', session_yes_size, ')') as selectionName"
          ),
          'b.dateTime as MstDate',
          Database.raw('FORMAT(OddsNumber, 0) as Odds'),
          'b.bet_value as Stack',
          Database.raw(
            'FORMAT((CASE WHEN OddValue = 1 THEN (bet_value * (session_no_size/100)) WHEN OddValue = 0 THEN (bet_value * (session_yes_size/100)) ELSE 0 END), 0) as P_L'
          ),
          Database.raw(
            '(CASE WHEN (b.TypeID = 5 OR b.TypeID = 2) AND OddValue = 0 THEN 0 ELSE 1 END) as isBack'
          ),
          Database.raw('0 as IsMatched'),
          'b.IP_ADDRESS as ip',
          Database.raw(
            '(CASE WHEN OddValue = 1 THEN session_no_size ELSE session_yes_size END) as volume'
          ),
          Database.raw('0 as void'),
          Database.raw('1 as is_fancy'),
          'matchmst.matchName as matchName',
          Database.raw('null as marketName'),
          'b.sportId as sportsId',
          Database.raw(
            "CONCAT(sportmst.Name, '>', matchmst.MatchName, '>', b.FheadName, '>', IFNULL(m.result, '')) AS Description"
          ),
          Database.raw(betDeleted),
          Database.raw('CASE WHEN IFNULL(b.Chips, 0) > 0 THEN Chips ELSE 0 END AS Profit'),
          Database.raw('CASE WHEN IFNULL(b.Chips, 0) < 0 THEN Chips ELSE 0 END AS Liability'),
          Database.raw("CASE WHEN b.ResultID IS NULL THEN 'Open' ELSE 'Settled' END AS STATUS"),
          'sportmst.name as sportName',
          'r.selectionId as tblresult_selectionId',
          'r.result as tblresult_result',
          'r.isFancy as tblresult_isFancy',

          // ⭐ ADDED FIELD
          'createmaster.mstrname as mstrname'
        )
        .where((query) => {
          query
            .where('b.UserId', userId)
            .orWhere('b.ParantId', userId)
            .orWhere('b.DealerID', userId)
            .orWhere('b.MasterID', userId)
            .orWhere('b.SMasterID', userId)
            .orWhere('b.SAdminID', userId)
            .orWhere('b.AdminID', userId)
            .orWhere('b.CompanyID', userId)
            .orWhere('b.ParentExchCompanyID', userId)
        })
        .if(filters.marketId, (q) => q.where('b.TypeID', filters.marketId))
        .if(filters.sportId, (q) => q.where('sportmst.id', filters.sportId))
        .if(filters.matchId, (q) => q.where('b.matchId', filters.matchId))
        .if(filters.fancyId, (q) => q.where('b.fancyId', filters.fancyId))
        .if(filters.search, (b) => {
          b.where((q) => {
            q.whereILike('matchmst.matchName', `%${filters.search}%`)
            q.orWhereILike('b.UserName', `%${filters.search}%`)
            q.orWhereILike('b.FHeadName', `%${filters.search}%`)
            q.orWhereILike('b.IP_ADDRESS', `%${filters.search}%`)
          })
        })
        .if(filters.bet_type, (q) => {
          q.if(filters.bet_type == 'M', (query) => query.andWhereNull('b.ResultID'))
          q.if(filters.bet_type == 'U', (query) => query.andWhereNull('b.ResultID'))
          q.if(filters.bet_type == 'P', (query) => query.whereNotNull('b.ResultID'))
        })
        .if(filters.fromDate && filters.toDate, (q: any) => {
          q.where('b.dateTime', '>=', filters.fromDate + 'T00:00:00')
          q.where('b.dateTime', '<=', filters.toDate + 'T23:59:59')
        })
        .if(!filters.afterResult, (q) => q.whereNull('b.ResultID'))

    // ⭐ UNION OR INDIVIDUAL QUERY
    let query: any

    if (!filters.type) {
      query = table1Query.union(table2Query)
    } else if (filters.type !== 'fancy') {
      query = table1Query
    } else {
      query = Database.query().if(true, table2Query)
    }

    let q = query
      .if(filters.latest, (q: any) => q.orderBy('MstDate', 'asc'))
      .if(!filters.latest, (q: any) => q.orderBy('MstDate', 'desc'))

    const getCounts = async () => {
      const isFancy = filters.type === 'fancy'
      const table = isFancy ? 'bet_entry' : 'tblbets'
      const uid = filters.userId || userId

      const sumColumn = isFancy ? 'bet_value' : 'stack'

      const result = await Database.from(table)
        .where((q: any) => {
          q.where('UserId', uid)
            .orWhere('ParantId', uid)
            .orWhere('DealerID', uid)
            .orWhere('MasterID', uid)
            .orWhere('SMasterID', uid)
            .orWhere('SAdminID', uid)
            .orWhere('AdminID', uid)
            .orWhere('CompanyID', uid)
            .orWhere('ParentExchCompanyID', uid)
        })
        .if(filters.matchId, (q: any) => q.where('matchId', filters.matchId))
        .select(
          Database.raw('COUNT(CASE WHEN ResultID IS NULL THEN 1 END) as unsettled_bets_count'),
          Database.raw('COUNT(CASE WHEN ResultID IS NOT NULL THEN 1 END) as settled_bets_count'),
          Database.raw(`SUM(${sumColumn}) as total_amount`)
        )
        .first()

      return {
        unsettled_bets_count: Number(result?.unsettled_bets_count || 0),
        settled_bets_count: Number(result?.settled_bets_count || 0),
        total_amount: Number(result?.total_amount || 0), // 🔥 dynamic (bet_value or stack)
      }
    }

    if (filters.needPagination) {
      const result = await q.paginate(filters.page, filters.limit)
      const counts = await getCounts()

      return {
        data: result.all(),
        meta: result.getMeta(),
        counts,
      }
    }

    const data = await q
    const counts = await getCounts()

    return { ...data, counts }
  }

  public async fancyBets(
    userId: any,
    filters: {
      marketId?: any
      matchId?: any
      sportId?: any
      search?: any
      needPagination?: boolean
      page?: number
      limit?: number
      type?: any
      fancyId?: any
      afterResult?: boolean
      bet_deleted?: boolean
      bet_type?: any
      fromDate?: any
      toDate?: any
      latest?: boolean
    } = {
        marketId: null,
        matchId: null,
        sportId: null,
        search: null,
        needPagination: false,
        page: 1,
        limit: 70,
        type: null,
        fancyId: null,
        afterResult: false,
        bet_deleted: false,
        bet_type: null,
        fromDate: null,
        toDate: null,
        latest: true,
      }
  ) {
    const table2 = filters.bet_deleted ? 'bet_entry_bak' : 'bet_entry'
    console.log('table2: ', table2);
    const fancy = this.fancyBetsQuery(table2, filters, userId)
    if (filters.needPagination) {
      // @ts-ignore
      return await fancy.paginate(filters.page, filters.limit)
    }
    return await fancy
  }
  //Only For Deleted Bets
  public async fancyDeletedBets(

    filters: {
      marketId?: any
      matchId?: any
      sportId?: any
      search?: any
      needPagination?: boolean
      page?: number
      limit?: number
      type?: any
      fancyId?: any
      afterResult?: boolean
      bet_deleted?: boolean
      bet_type?: any
      fromDate?: any
      toDate?: any
      latest?: boolean
    } = {
        marketId: null,
        matchId: null,
        sportId: null,
        search: null,
        needPagination: false,
        page: 1,
        limit: 70,
        type: null,
        fancyId: null,
        afterResult: false,
        bet_deleted: false,
        bet_type: null,
        fromDate: null,
        toDate: null,
        latest: true,
      }
  ) {

    const fancy = this.fancyDeletedBetsQuery(filters)
    if (filters.needPagination) {
      // @ts-ignore
      return await fancy.paginate(filters.page, filters.limit)
    }
    return await fancy
  }
  public async bookmakerBets(
    userId: any,
    filters: {
      marketId?: any
      matchId?: any
      sportId?: any
      search?: any
      needPagination?: boolean
      page?: number
      limit?: number
      type?: any
      fancyId?: any
      afterResult?: boolean
      bet_deleted?: boolean
      bet_type?: any
      fromDate?: any
      toDate?: any
      latest?: boolean
    } = {
        marketId: null,
        matchId: null,
        sportId: null,
        search: null,
        needPagination: false,
        page: 1,
        limit: 70,
        type: null,
        fancyId: null,
        afterResult: false,
        bet_deleted: false,
        bet_type: null,
        fromDate: null,
        toDate: null,
        latest: true,
      }
  ) {
    const table1 = filters.bet_deleted ? 'tblbets_bak' : 'tblbets'
    let bookmaker = this.tblBetsQuery(table1, filters, userId).where('market.Name', 'Bookmaker')
    if (filters.needPagination) {
      // @ts-ignore
      return await bookmaker.paginate(filters.page, filters.limit)
    }
    return await bookmaker
  }

  public async winnerBets(
    userId: any,
    filters: {
      marketId?: any
      matchId?: any
      sportId?: any
      search?: any
      needPagination?: boolean
      page?: number
      limit?: number
      type?: any
      fancyId?: any
      afterResult?: boolean
      bet_deleted?: boolean
      bet_type?: any
      fromDate?: any
      toDate?: any
      latest?: boolean
    } = {
        marketId: null,
        matchId: null,
        sportId: null,
        search: null,
        needPagination: false,
        page: 1,
        limit: 70,
        type: null,
        fancyId: null,
        afterResult: false,
        bet_deleted: false,
        bet_type: null,
        fromDate: null,
        toDate: null,
        latest: true,
      }
  ) {
    const table1 = filters.bet_deleted ? 'tblbets_bak' : 'tblbets'
    let winner = this.tblBetsQuery(table1, filters, userId).where('market.Name', 'Winner')
    if (filters.needPagination) {
      // @ts-ignore
      return await winner.paginate(filters.page, filters.limit)
    }
    return await winner
  }

  public async marketBetsMongoQuery(userId: number, matchId: number, marketName: string) {
    const query = {
      UserId: +userId,
      MatchId: +matchId,
      marketName: { $regex: new RegExp(`^${marketName}$`, 'i') }, // exact match, case-insensitive
    }

    const data = await Mongo.collection('bets').find(query).sort({ MstDate: -1 }).toArray()

    return data
  }

  public async allMarketBetsMongoQuery(userId: number, matchId: number) {
    const query = {
      UserId: +userId,
      MatchId: +matchId,
      is_fancy: 0, // Ensures you're only fetching market (non-fancy) bets
    }

    const data = await Mongo.collection('bets').find(query).sort({ MstDate: -1 }).toArray()

    return data
  }

  public async getFancyBetsByUserAndMatchWithPagination(
    userId: number | string,
    matchId: number | string,
    page: number = 1,
    limit: number = 50,
    search?: string
  ) {
    const uid = typeof userId === 'string' ? Number(userId) : userId
    const mid = typeof matchId === 'string' ? Number(matchId) : matchId
    const skip = (page - 1) * limit
    const userConditions = [
      { UserId: uid },
      { ParentId: uid },
      { DealerId: uid },
      { MasterId: uid },
      { SuperMasterId: uid },
      { SubAdminId: uid },
      { SuperAdminId: uid },
      { CompanyId: uid },
      { SuperDuperAdminId: uid },
    ]

    const query: any = {
      is_fancy: 1,
      $or: userConditions,
    }

    if (mid !== undefined && mid !== null) {
      query.MatchId = Number(mid)
    }

    if (search) {
      query.$and = [
        {
          $or: [{ UserName: { $regex: search, $options: 'i' } }],
        },
      ]
    }
    // Combine $or (user conditions) and $and (search)
    if (query.$and) {
      query.$and.unshift({ $or: userConditions })
      delete query.$or
    }

    const collection = Mongo.collection('fancy_bets')
    const [data, total] = await Promise.all([
      collection.find(query).sort({ MstDate: -1 }).skip(skip).limit(limit).toArray(),
      collection.countDocuments(query),
    ])
    const last_page = Math.ceil(total / limit) || 1
    const baseUrl = '/?page='
    const meta = {
      total,
      per_page: limit,
      current_page: page,
      last_page,
      first_page: 1,
      first_page_url: `${baseUrl}1`,
      last_page_url: `${baseUrl}${last_page}`,
      next_page_url: page < last_page ? `${baseUrl}${page + 1}` : null,
      previous_page_url: page > 1 ? `${baseUrl}${page - 1}` : null,
    }
    return {
      data,
      meta,
    }
  }

  public async allMarketBetsMongoQueryWithPagination(
    userId: number,
    matchId?: number,
    marketName?: string,
    page: number = 1,
    limit: number = 50,
    search?: string
  ) {
    const skip = (page - 1) * limit

    const userConditions = [
      { UserId: userId },
      { ParentId: userId },
      { DealerId: userId },
      { MasterId: userId },
      { SuperMasterId: userId },
      { SubAdminId: userId },
      { SuperAdminId: userId },
      { CompanyId: userId },
      { SuperDuperAdminId: userId },
    ]

    const query: any = {
      is_fancy: 0,
      $or: userConditions,
    }

    if (matchId !== undefined && matchId !== null) {
      query.MatchId = Number(matchId)
    }

    if (marketName) {
      query.marketName = marketName
    }

    if (search) {
      query.$and = [
        {
          $or: [
            { Username: { $regex: search, $options: 'i' } },
            { selectionName: { $regex: search, $options: 'i' } },
            { marketName: { $regex: search, $options: 'i' } },
          ],
        },
      ]
    }

    // Combine $or (user conditions) and $and (search)
    if (query.$and) {
      query.$and.unshift({ $or: userConditions })
      delete query.$or
    }

    const collection = Mongo.collection('bets')

    const [data, total] = await Promise.all([
      collection.find(query).sort({ MstDate: -1 }).skip(skip).limit(limit).toArray(),
      collection.countDocuments(query),
    ])

    const last_page = Math.ceil(total / limit)
    const baseUrl = '/?page='

    const meta = {
      total,
      per_page: limit,
      current_page: page,
      last_page,
      first_page: 1,
      first_page_url: `${baseUrl}1`,
      last_page_url: `${baseUrl}${last_page}`,
      next_page_url: page < last_page ? `${baseUrl}${page + 1}` : null,
      previous_page_url: page > 1 ? `${baseUrl}${page - 1}` : null,
    }

    return {
      data,
      meta,
    }
  }

  public async fancyBetsMongoQuery(userId: number, matchId: number, fancyId?: number) {
    // Create base query with a more flexible type
    const query: Record<string, any> = {
      MatchId: +matchId,
      is_fancy: 1,
    }

    // Include hierarchical user roles (like ParentId, DealerId, etc.)
    query.$or = [
      { UserId: +userId },
      { ParentId: +userId },
      { DealerId: +userId },
      { MasterId: +userId },
      { SuperMasterId: +userId },
      { SubAdminId: +userId },
      { SuperAdminId: +userId },
      { CompanyId: +userId },
      { SuperDuperAdminId: +userId },
    ]

    if (fancyId) {
      query.SelectionId = +fancyId // Add SelectionId if fancyId is provided
    }

    const data = await Mongo.collection('fancy_bets').find(query).sort({ MstDate: -1 }).toArray()

    return data
  }

  public async matchOddsBets(
    userId: any,
    filters: {
      marketId?: any
      matchId?: any
      sportId?: any
      search?: any
      needPagination?: boolean
      page?: number
      limit?: number
      type?: any
      fancyId?: any
      afterResult?: boolean
      bet_deleted?: boolean
      bet_type?: any
      fromDate?: any
      toDate?: any
      latest?: boolean
    } = {
        marketId: null,
        matchId: null,
        sportId: null,
        search: null,
        needPagination: false,
        page: 1,
        limit: 70,
        type: null,
        fancyId: null,
        afterResult: false,
        bet_deleted: false,
        bet_type: null,
        fromDate: null,
        toDate: null,
        latest: true,
      }
  ) {
    const table1 = filters.bet_deleted ? 'tblbets_bak' : 'tblbets'
    let marketOdds = this.tblBetsQuery(table1, filters, userId).where('market.Name', 'Match Odds')
    if (filters.needPagination) {
      // @ts-ignore
      return await marketOdds.paginate(filters.page, filters.limit)
    }
    return await marketOdds
  }

  public async tiedMatchBets(
    userId: any,
    filters: {
      marketId?: any
      matchId?: any
      sportId?: any
      search?: any
      needPagination?: boolean
      page?: number
      limit?: number
      type?: any
      fancyId?: any
      afterResult?: boolean
      bet_deleted?: boolean
      bet_type?: any
      fromDate?: any
      toDate?: any
      latest?: boolean
    } = {
        marketId: null,
        matchId: null,
        sportId: null,
        search: null,
        needPagination: false,
        page: 1,
        limit: 70,
        type: null,
        fancyId: null,
        afterResult: false,
        bet_deleted: false,
        bet_type: null,
        fromDate: null,
        toDate: null,
        latest: true,
      }
  ) {
    const table1 = filters.bet_deleted ? 'tblbets_bak' : 'tblbets'
    let tiedMatch = this.tblBetsQuery(table1, filters, userId).where('market.Name', 'Tied Match')
    if (filters.needPagination) {
      // @ts-ignore
      return await tiedMatch.paginate(filters.page, filters.limit)
    }

    return await tiedMatch
  }

  public async tossBets(
    userId: any,
    filters: {
      marketId?: any
      matchId?: any
      sportId?: any
      search?: any
      needPagination?: boolean
      page?: number
      limit?: number
      type?: any
      fancyId?: any
      afterResult?: boolean
      bet_deleted?: boolean
      bet_type?: any
      fromDate?: any
      toDate?: any
      latest?: boolean
    } = {
        marketId: null,
        matchId: null,
        sportId: null,
        search: null,
        needPagination: false,
        page: 1,
        limit: 70,
        type: null,
        fancyId: null,
        afterResult: false,
        bet_deleted: false,
        bet_type: null,
        fromDate: null,
        toDate: null,
        latest: true,
      }
  ) {
    const table1 = filters.bet_deleted ? 'tblbets_bak' : 'tblbets'
    let toss = this.tblBetsQuery(table1, filters, userId).whereIn('market.Name', [
      'Toss',
      'To Win the Toss',
    ])
    if (filters.needPagination) {
      // @ts-ignore
      return await toss.paginate(filters.page, filters.limit)
    }
    return await toss
  }

  public async goalsBets(
    userId: any,
    filters: {
      marketId?: any
      matchId?: any
      sportId?: any
      search?: any
      needPagination?: boolean
      page?: number
      limit?: number
      type?: any
      fancyId?: any
      afterResult?: boolean
      bet_deleted?: boolean
      bet_type?: any
      fromDate?: any
      toDate?: any
      latest?: boolean
    } = {
        marketId: null,
        matchId: null,
        sportId: null,
        search: null,
        needPagination: false,
        page: 1,
        limit: 70,
        type: null,
        fancyId: null,
        afterResult: false,
        bet_deleted: false,
        bet_type: null,
        fromDate: null,
        toDate: null,
        latest: true,
      }
  ) {
    const table1 = filters.bet_deleted ? 'tblbets_bak' : 'tblbets'
    let toss = this.tblBetsQuery(table1, filters, userId).where('market.Name', 'LIKE', '%Goals%')
    if (filters.needPagination) {
      // @ts-ignore
      return await toss.paginate(filters.page, filters.limit)
    }
    return await toss
  }

  private fancyBetsQuery(table: string, filters: any, userId: string) {
    try {
      return Database.query()
        .from(`${table} as b`)
        .join('matchmst', 'matchmst.MstCode', '=', 'b.MatchId')
        .select(
          'b.bet_id as MstCode',
          'b.userId as UserId',
          'b.UserName',
          'b.matchId as MatchId',
          'b.TypeID as MarketId',
          'b.fancyId as SelectionId',
          Database.raw(
            "CONCAT(FHeadName, ' (', session_no_size, '-', session_yes_size, ')') as selectionName"
          ),
          'b.dateTime as MstDate',
          Database.raw('FORMAT(OddsNumber, 0) as Odds'),
          'b.bet_value as Stack',
          Database.raw(
            'FORMAT((CASE WHEN OddValue = 1 THEN (bet_value * (session_no_size/100)) WHEN OddValue = 0 THEN (bet_value * (session_yes_size/100)) ELSE 0 END), 0) as P_L'
          ),
          Database.raw(
            '(CASE WHEN (b.TypeID = 5 OR b.TypeID = 2) AND OddValue = 0 THEN 0 ELSE 1 END) as isBack'
          ),
          Database.raw('0 as IsMatched'),
          'b.IP_ADDRESS as ip',
          Database.raw(
            '(CASE WHEN OddValue = 1 THEN session_no_size ELSE session_yes_size END) as volume'
          ),
          Database.raw('0 as void'),
          Database.raw('1 as is_fancy'),
          'matchmst.matchName as matchName',
          Database.raw('null as marketName'),
          'b.sportId as sportsId',
          Database.raw(
            "CONCAT(sportmst.Name, '>', matchmst.MatchName, '>', b.FheadName, '>', IFNULL(m.result, '')) AS Description"
          ),
          Database.raw('CASE WHEN IFNULL(b.Chips, 0) > 0 THEN Chips ELSE 0 END AS Profit'), // 0
          Database.raw('CASE WHEN IFNULL(b.Chips, 0) < 0 THEN Chips ELSE 0 END AS Liability'), //0
          Database.raw("CASE WHEN b.ResultID IS NULL THEN 'Open' ELSE 'Settled' END AS STATUS") // 0
        )
        .if(!filters.bet_deleted, (q) => {
          q.select(Database.raw(`CASE WHEN b.OddValue = 0 THEN 'Back' ELSE 'Lay' END AS Type`))
        })
        .if(filters.bet_deleted, (q) => {
          q.select(
            Database.raw(
              "CASE WHEN b.TypeID = 1 THEN 'E/O' WHEN b.TypeID = 2 THEN 'Session' WHEN b.TypeID = 3 THEN 'Kaddal' WHEN b.TypeID = 4 THEN 'Last Digit' WHEN b.TypeID = 5 THEN 'UpDown' END AS Type"
            )
          )
        })
        .join('sportmst', 'sportmst.id', '=', 'b.sportId')
        .leftJoin('matchfancy AS m', 'b.fancyID', 'm.ID')
        .select('sportmst.name as sportName')
        .where((query) => {
          query
            .where('b.UserId', userId)
            .orWhere('b.ParantId', userId)
            .orWhere('b.DealerID', userId)
            .orWhere('b.MasterID', userId)
            .orWhere('b.SMasterID', userId)
            .orWhere('b.SAdminID', userId)
            .orWhere('b.AdminID', userId)
            .orWhere('b.CompanyID', userId)
            .orWhere('b.ParentExchCompanyID', userId)
        })
        .if(filters.marketId, (q) => {
          q.where('b.TypeID', filters.marketId)
        })
        .if(filters.sportId, (q) => {
          q.where('sportmst.id', filters.sportId)
        })
        .if(filters.matchId, (q) => {
          q.where('b.matchId', filters.matchId)
        })
        .if(filters.fancyId, (q) => {
          q.where('b.fancyId', filters.fancyId)
        })
        .if(filters.search, (b) => {
          b.where((q) => {
            q.whereILike('matchmst.matchName', '%' + filters.search + '%')
            q.orWhereILike('b.UserName', '%' + filters.search + '%')
            q.orWhereILike('b.FHeadName', '%' + filters.search + '%')
            q.orWhereILike('b.IP_ADDRESS', '%' + filters.search + '%')
          })
        })
        .if(filters.bet_type, (q) => {
          q.if(filters.bet_type == 'M', (query) => {
            query.andWhereNull('b.ResultID')
          })
          q.if(filters.bet_type == 'U', (query) => {
            query.andWhereNull('b.ResultID')
          })
          q.if(filters.bet_type == 'P', (query) => {
            query.whereNotNull('b.ResultID')
          })
        })
        .if(filters.fromDate && filters.toDate, (q: any) => {
          q.where('b.dateTime', '>=', filters.fromDate + 'T00:00:00')
          q.where('b.dateTime', '<=', filters.toDate + 'T23:59:59')
        })
        .if(!filters.afterResult, (q) => q.whereNull('b.ResultID'))
        .if(filters.latest, (q: any) => q.orderBy('MstDate', 'asc'))
        .if(!filters.latest, (q: any) => q.orderBy('MstDate', 'desc'))
    } catch (e) {
      throw e.message
    }
  }
  private fancyDeletedBetsQuery(filters: any) {
    try {
      const query = Database.query()
        .from('bet_entry_bak as b')

        // ✅ Use LEFT JOIN to avoid row loss
        .leftJoin('matchmst', 'matchmst.MstCode', '=', 'b.MatchId')
        .leftJoin('sportmst', 'sportmst.id', '=', 'b.sportId')
        .leftJoin('matchfancy as m', 'b.fancyID', 'm.ID')

        // ✅ SELECT fields
        .select(
          'b.bet_id as MstCode',
          'b.userId as UserId',
          'b.UserName',
          'b.matchId as MatchId',
          'b.TypeID as MarketId',
          'b.fancyId as SelectionId',

          Database.raw(
            "CONCAT(b.FHeadName, ' (', b.session_no_size, '-', b.session_yes_size, ')') as selectionName"
          ),

          'b.dateTime as MstDate',

          Database.raw('FORMAT(b.OddsNumber, 0) as Odds'),

          'b.bet_value as Stack',

          Database.raw(`
        FORMAT(
          CASE 
            WHEN b.OddValue = 1 THEN (b.bet_value * (b.session_no_size/100)) 
            WHEN b.OddValue = 0 THEN (b.bet_value * (b.session_yes_size/100)) 
            ELSE 0 
          END
        , 0) as P_L
      `),

          Database.raw(`
        CASE 
          WHEN (b.TypeID = 5 OR b.TypeID = 2) AND b.OddValue = 0 THEN 0 
          ELSE 1 
        END as isBack
      `),

          Database.raw('0 as IsMatched'),
          'b.IP_ADDRESS as ip',

          Database.raw(`
        CASE 
          WHEN b.OddValue = 1 THEN b.session_no_size 
          ELSE b.session_yes_size 
        END as volume
      `),

          Database.raw('0 as void'),
          Database.raw('1 as is_fancy'),

          'matchmst.matchName as matchName',
          Database.raw('NULL as marketName'),

          'b.sportId as sportsId',
          'sportmst.name as sportName',

          Database.raw(`
        CONCAT(
          sportmst.Name, ' > ',
          matchmst.MatchName, ' > ',
          b.FheadName, ' > ',
          IFNULL(m.result, '')
        ) AS Description
      `),

          Database.raw(`
        CASE 
          WHEN IFNULL(b.Chips, 0) > 0 THEN b.Chips 
          ELSE 0 
        END AS Profit
      `),

          Database.raw(`
        CASE 
          WHEN IFNULL(b.Chips, 0) < 0 THEN b.Chips 
          ELSE 0 
        END AS Liability
      `),

          Database.raw(`
        CASE 
          WHEN b.ResultID IS NULL THEN 'Open' 
          ELSE 'Settled' 
        END AS STATUS
      `)
        )

        // ✅ TYPE COLUMN (clean logic)
        .if(!filters.bet_deleted, (q) => {
          q.select(
            Database.raw(`
          CASE 
            WHEN b.OddValue = 0 THEN 'Back' 
            ELSE 'Lay' 
          END AS Type
        `)
          )
        })
        .if(filters.bet_deleted, (q) => {
          q.select(
            Database.raw(`
          CASE 
            WHEN b.TypeID = 1 THEN 'E/O'
            WHEN b.TypeID = 2 THEN 'Session'
            WHEN b.TypeID = 3 THEN 'Kaddal'
            WHEN b.TypeID = 4 THEN 'Last Digit'
            WHEN b.TypeID = 5 THEN 'UpDown'
          END AS Type
        `)
          )
        })

        // ✅ BASE FILTER (ONLY ONCE)
        .where('b.matchId', filters.matchId)

        // ✅ OPTIONAL FILTERS
        .if(filters.marketId, (q) => {
          q.where('b.TypeID', filters.marketId)
        })

        .if(filters.sportId, (q) => {
          q.where('b.sportId', filters.sportId)
        })

        .if(filters.fancyId, (q) => {
          q.where('b.fancyId', filters.fancyId)
        })

        .if(filters.search, (q) => {
          q.where((sub) => {
            sub.whereILike('matchmst.matchName', `%${filters.search}%`)
            sub.orWhereILike('b.UserName', `%${filters.search}%`)
            sub.orWhereILike('b.FHeadName', `%${filters.search}%`)
            sub.orWhereILike('b.IP_ADDRESS', `%${filters.search}%`)
          })
        })

        // ✅ BET TYPE FILTER
        .if(filters.bet_type, (q) => {
          if (filters.bet_type === 'M' || filters.bet_type === 'U') {
            q.whereNull('b.ResultID')
          }
          if (filters.bet_type === 'P') {
            q.whereNotNull('b.ResultID')
          }
        })

        // ✅ DATE FILTER
        .if(filters.fromDate && filters.toDate, (q) => {
          q.where('b.dateTime', '>=', `${filters.fromDate}T00:00:00`)
          q.where('b.dateTime', '<=', `${filters.toDate}T23:59:59`)
        })

        // ❗ IMPORTANT: CONTROL THIS
        .if(filters.afterResult === false, (q) => {
          q.whereNull('b.ResultID')
        })

        // ✅ SORTING
        .if(filters.latest, (q) => {
          q.orderBy('MstDate', 'asc')
        })
        .if(!filters.latest, (q) => {
          q.orderBy('MstDate', 'desc')
        })

      // ✅ DEBUG SQL
      // const sqlData = query.toSQL()
      // console.log('sqlData: ', sqlData);
      return query

    } catch (error) {
      console.error('Query Error:', error)
      throw error
    }
  }

  private tblBetsQuery(table: string, filters: any, userId: string) {
    try {
      return Database.query()
        .from(`${table} as a`)
        .join('matchmst', 'matchmst.MstCode', '=', 'a.MatchId')
        .join('market', 'market.Id', '=', 'a.MarketId')
        .select(
          'a.MstCode',
          'a.UserId',
          'a.UserName',
          'a.MatchId',
          'a.MarketId',
          'a.SelectionId',
          'a.selectionName',
          'a.MstDate',
          'a.Odds',
          'a.Stack',
          'a.P_L',
          'a.isBack',
          'a.IsMatched',
          'a.IP_ADDESSS as ip',
          Database.raw('0 as volume'),
          Database.raw('0 as void'),
          Database.raw('0 as is_fancy'),
          'matchmst.matchName as matchName',
          'market.Name as marketName',
          'market.sportsId as sportsId',
          Database.raw(
            "CONCAT(sportmst.Name, '>', matchmst.MatchName, '>', market.Name) AS Description"
          ), //0
          Database.raw("CASE WHEN a.isBack = 0 THEN 'Back' ELSE 'Lay' END AS Type"),
          Database.raw(
            'CASE WHEN IFNULL(a.result, 0) = 1 THEN CASE WHEN IFNULL(a.isBack, 0) = 0 THEN a.P_L ELSE a.Stack END END AS Profit'
          ), // 0
          Database.raw(
            'CASE WHEN IFNULL(a.result, 0) = 0 THEN CASE WHEN IFNULL(a.isBack, 0) = 0 THEN a.Stack ELSE a.P_L END END AS Liability'
          ), // 0
          Database.raw("CASE WHEN a.ResultID IS NULL THEN 'Open' ELSE 'Settled' END AS STATUS") // 0
        )
        .join('sportmst', 'sportmst.id', '=', 'market.sportsId')
        .select('sportmst.name as sportName')
        .where((query) => {
          query
            .where('a.UserId', userId)
            .orWhere('a.ParantId', userId)
            .orWhere('a.DealerID', userId)
            .orWhere('a.MasterID', userId)
            .orWhere('a.SMasterID', userId)
            .orWhere('a.SAdminID', userId)
            .orWhere('a.AdminID', userId)
            .orWhere('a.CompanyID', userId)
            .orWhere('a.ParentExchCompanyID', userId)
        })
        .if(filters.marketId, (q) => {
          q.where('a.MarketId', filters.marketId)
        })
        .if(filters.sportId, (q) => {
          q.where('sportmst.id', filters.sportId)
        })
        .if(filters.matchId, (q) => {
          q.where('a.MatchId', filters.matchId)
        })
        .if(filters.search, (b) => {
          b.where((q) => {
            q.whereILike('matchmst.matchName', '%' + filters.search + '%')
            q.orWhereILike('market.Name', '%' + filters.search + '%')
            q.orWhereILike('a.UserName', '%' + filters.search + '%')
            q.orWhereILike('a.selectionName', '%' + filters.search + '%')
            q.orWhereILike('a.IP_ADDESSS', '%' + filters.search + '%')
          })
        })
        .if(filters.bet_type, (q) => {
          q.if(filters.bet_type == 'M', (query) => {
            query.where('a.isMatched', 1)
            query.andWhereNull('a.ResultID')
          })
          q.if(filters.bet_type == 'U', (query) => {
            query.where('a.isMatched', 0)
            query.andWhereNull('a.ResultID')
          })
          q.if(filters.bet_type == 'P', (query) => {
            query.whereNotNull('a.ResultID')
          })
        })
        .if(filters.fromDate && filters.toDate, (q: any) => {
          q.where('a.MstDate', '>=', filters.fromDate + 'T00:00:00')
          q.where('a.MstDate', '<=', filters.toDate + 'T23:59:59')
        })
        .if(!filters.afterResult, (q) => q.whereNull('a.ResultID'))
        .if(filters.latest, (q: any) => q.orderBy('MstDate', 'asc'))
        .if(!filters.latest, (q: any) => q.orderBy('MstDate', 'desc'))
    } catch (error) {
      throw error.message
    }
  }

  public async accountStatement(
    userId: any,
    fromDate: string,
    toDate: string,
    transactionType: string = 'all',
    accountType = 'all',
    page = 1,
    limit = 70
  ) {

    /**
     * 🎯 Define usertype behavior
     */
    const RESTRICT_MSTTYPE_USERS = [3, 11, 10, 9, 8] // agent-like users

    /**
     * 🔁 Common Filters (Reusable)
     */
    // const applyCommonFilters = (query, accountType) => {
    //   query
    //     // ✅ Handle all restricted usertypes
    //     .where((q) => {
    //       q.whereNotIn('cm.usetype', RESTRICT_MSTTYPE_USERS)
    //         .orWhere('tcd.msttype', '!=', 50)
    //     })

    //     // ✅ Partnership logic
    //     .if(accountType != '3', (q) => {
    //       q.where((sub) => {
    //         sub.where('tcd.is_partnership', '!=', 0)
    //           .orWhere('tcd.msttype', 50)
    //           .orWhere((s) => {
    //             s.where('tcd.LevelV', '!=', 0)
    //               .where('tcd.ChildID', '!=', 0)
    //           })
    //           .orWhere((s) => {
    //             s.where('tcd.LevelV', 0)
    //               .where('tcd.ChildID', 0)
    //           })
    //       })
    //     })

    //   return query
    // }

    /**
     * 🧮 1. Past Balance
     */
    let pastBalance = await Database.query()
      .select(
        'Sdate',
        'mstrUserId',
        'userId',
        Database.raw(`
        ROUND(SUM(amount) OVER (PARTITION BY userId ORDER BY Sdate), 2) AS balance
      `)
      )
      .from(
        Database.from('tblchipdet as tcd')
          .select(
            'tcd.MstDate AS Sdate',
            'cm.mstrUserId',
            'cm.mstrid as userId',
            Database.raw('(tcd.ChipsCr - tcd.ChipsDr) AS amount')
          )
          .innerJoin('createmaster as cm', 'cm.mstrid', 'tcd.UserId')
          .where('tcd.UserId', userId)
          .whereRaw('(tcd.ChipsCr - tcd.ChipsDr) != 0')
          .where((q) => {
            q.whereNotIn('cm.usetype', RESTRICT_MSTTYPE_USERS)
              .orWhere('tcd.msttype', '!=', 50)
          })
          .if(accountType != '3', (q) => {
            q.where((sub) => {
              sub.where('tcd.is_partnership', '!=', 0)
                .orWhere('tcd.msttype', 50)
                .orWhere((s) => {
                  s.where('tcd.LevelV', '!=', 0)
                    .where('tcd.ChildID', '!=', 0)
                })
                .orWhere((s) => {
                  s.where('tcd.LevelV', 0)
                    .where('tcd.ChildID', 0)
                })
            })
          })

          .unionAll(
            Database.from('tblchips as T0')
              .select(
                'T0.MstDate AS Sdate',
                'T1.mstrUserId',
                'T1.mstrid as userId',
                Database.raw('T0.Chips AS amount')
              )
              .innerJoin('createmaster as T1', 'T1.mstrid', 'T0.UserId')
              .where('T0.UserId', userId)
          )
          .as('transactions')
      )
      .where('Sdate', '<', fromDate + 'T00:00:00')
      .orderBy('Sdate', 'desc')
      .first()

    pastBalance = pastBalance ? pastBalance.balance : 0

    /**
     * 💰 2. Deposit / Withdraw
     */
    const depositWithdrawQuery = Database.from('tblchips as T0')
      .select(
        'T0.MstDate AS Sdate',
        'T1.mstrUserId',
        'T1.mstrid as userId',
        Database.raw('CASE WHEN T0.Crdr = 1 THEN T0.Chips ELSE 0 END AS ChipsCr'),
        Database.raw('CASE WHEN T0.Crdr = 2 THEN T0.Chips ELSE 0 END AS ChipsDr'),
        Database.raw('T0.Chips AS amount'),
        Database.raw(`
        CONCAT(Narration, IF(RefID <> '', CONCAT(' | ', RefID), '')) AS Narration
      `),
        Database.raw('null AS marketId'),
        Database.raw('null AS matchId'),
        Database.raw('null AS fancyId')
      )
      .innerJoin('createmaster as T1', 'T1.mstrid', 'T0.UserId')
      .where('T0.UserId', userId)
      .if(transactionType == 'DR', (q) => q.where('T0.Chips', '<', 0))
      .if(transactionType == 'CR', (q) => q.where('T0.Chips', '>', 0))

    /**
     * 📊 3. Other Transactions
     */
    const otherQuery = Database.from('tblchipdet as tcd')
      .select(
        'tcd.MstDate AS Sdate',
        'cm.mstrUserId',
        'cm.mstrid as userId',
        Database.raw('tcd.ChipsCr as ChipsCr'),
        Database.raw('tcd.ChipsDr as ChipsDr'),
        Database.raw('(tcd.ChipsCr - tcd.ChipsDr) AS amount'),
        'tcd.Narration',
        'tcd.MarketId as marketId',
        'tcd.MatchId as matchId',
        'tcd.FancyId as fancyId'
      )
      .innerJoin('createmaster as cm', 'cm.mstrid', 'tcd.UserId')
      .where('tcd.UserId', userId)
      .whereRaw('(tcd.ChipsCr - tcd.ChipsDr) != 0')
      .where((q) => {
        q.whereNotIn('cm.usetype', RESTRICT_MSTTYPE_USERS)
          .orWhere('tcd.msttype', '!=', 50)
      })
      .if(accountType != '3', (q) => {
        q.where((sub) => {
          sub.where('tcd.is_partnership', '!=', 0)
            .orWhere('tcd.msttype', 50)
            .orWhere((s) => {
              s.where('tcd.LevelV', '!=', 0)
                .where('tcd.ChildID', '!=', 0)
            })
            .orWhere((s) => {
              s.where('tcd.LevelV', 0)
                .where('tcd.ChildID', 0)
            })
        })
      })

      // ✅ accountType filters
      .if(accountType == '1', (q) => {
        q.whereBetween('tcd.msttype', [5, 49])
      })
      .if(accountType == '2', (q) => {
        q.whereIn('tcd.msttype', [6, 7, 9])
      })
      .if(accountType == '3', (q) => {
        q.where('tcd.msttype', 50)
      })

      // ✅ transactionType filters
      .if(transactionType == 'DR', (q) => {
        q.where('tcd.ChipsDr', '>', 0)
      })
      .if(transactionType == 'CR', (q) => {
        q.where('tcd.ChipsCr', '>', 0)
      })

    /**
     * 📈 4. Final Select
     */
    const selectQuery = Database.query().select(
      'Sdate',
      'mstrUserId',
      'userId',
      Database.raw('ROUND(ChipsCr, 2) as Credit'),
      Database.raw('ROUND(ChipsDr, 2) as Debit'),
      Database.raw(`
      ROUND(SUM(amount) OVER (PARTITION BY userId ORDER BY Sdate) + ${pastBalance}, 2) AS balance
    `),
      'Narration',
      'marketId',
      'matchId',
      'fancyId'
    )

    /**
     * 🧾 5. Opening Balance
     */
    let openingBalance = await selectQuery
      .clone()
      .from(otherQuery.clone().unionAll(depositWithdrawQuery.clone()).as('transactions'))
      .whereBetween('Sdate', [
        fromDate + 'T00:00:00',
        toDate + 'T23:59:59'
      ])
      .orderBy('Sdate', 'desc')
      .offset(page * limit)
      .first()

    openingBalance = openingBalance ? openingBalance.balance : 0

    /**
     * 📦 6. Final Result
     */
    const result = await selectQuery
      .clone()
      .if(
        accountType == '4',
        (builder) => {
          builder.from(depositWithdrawQuery.clone().as('transactions'))
        },
        (builder) => {
          builder.if(
            accountType == 'all',
            (query) => {
              query.from(
                otherQuery.clone().unionAll(depositWithdrawQuery.clone()).as('transactions')
              )
            },
            (query) => {
              query.from(otherQuery.clone().as('transactions'))
            }
          )
        }
      )
      .whereBetween('Sdate', [
        fromDate + 'T00:00:00',
        toDate + 'T23:59:59'
      ])
      .orderBy('Sdate', 'desc')
      .paginate(page, limit)

    return {
      data: result.all(),
      meta: result.getMeta(),
      openingBalance
    }
  }

  public async ledger(userId: any, page = 1, limit = 200) {
    let data = Database.from(
      Database.from('tblchipdet as a1')
        .select(
          Database.raw('max(date_format(a1.MstDate, "%Y-%m-%d")) as modified_MstDate'),
          Database.raw('round(sum(a1.chipsCr), 2) as Credit'),
          Database.raw('round(sum(a1.chipsdr), 2) as Debit'),
          Database.raw('a2.matchname as MatchName'),
          'matchid'
        )
        .join('matchmst as a2', 'a2.MstCode', 'a1.MatchId')
        .where('a1.UserId', userId)
        .where('a1.MatchId', '>', '99999')
        .whereRaw('ROUND(a1.ChipsCr - a1.ChipsDr, 2) != 0')
        .whereRaw(
          'CASE WHEN a1.is_partnership = 0 AND a1.msttype != 50 THEN CASE WHEN (a1.LevelV != 0) THEN a1.ChildID != 0 ELSE a1.ChildID = 0 END ELSE 1 = 1 END'
        )
        .whereBetween('a1.msttype', [4, 50])
        .orderByRaw('modified_MstDate desc')
        .groupByRaw('4,5')
        .as('p1')
    )
      .select(
        'modified_MstDate',
        Database.raw('(CASE WHEN Credit - Debit > 0 THEN Credit - Debit ELSE 0 END) AS Credit'),
        'MatchName',
        Database.raw('(CASE WHEN Debit - Credit > 0 THEN Debit - Credit ELSE 0 END) AS Debit'),
        'matchid'
      )
      .paginate(page, limit)
    return {
      data: (await data).all(),
      meta: (await data).getMeta(),
    }
  }

  public async getBook(bets: any[], minValue = 5, startWithZero = false) {
    const result: any = []
    let min: number
    if (startWithZero) {
      min = 0
    } else {
      min = Math.min(...bets.map((bet) => bet.odds)) - minValue
    }

    const max = Math.max(...bets.map((bet) => bet.odds)) + minValue

    for (let i = min < minValue ? 0 : min; i < max; i++) {
      result.push({ odds: i, value: 0 })
    }

    for (const bet of bets) {
      if (bet.isBack == 0) {
        result.map((rs: any) => {
          const { odds, value } = rs
          if (odds >= bet.odds) {
            rs.value += (bet.Stack * bet.volume) / 100
          } else {
            rs.value -= bet.Stack
          }

          return { odds, value }
        })
      } else {
        result.map((rs: any) => {
          const { odds, value } = rs
          if (odds < bet.odds) {
            rs.value += bet.Stack
          } else {
            rs.value -= (bet.Stack * bet.volume) / 100
          }

          return { odds, value }
        })
      }
    }

    return result
  }

  public async getUserLiability(userId: number, newBet: any) {
    const bets = await this.bets(userId)
    return this.getExposure([...bets, newBet])
  }

  public async getExposure(bets: any[], marketId = null, considerPlus = true) {
    const marketIds = [...new Set(bets.map((bet) => bet.MarketId))]
    let markets: any = []

    if (marketIds.length > 0) {
      markets = await Database.from('market').whereIn('Id', marketIds)
    }

    let liability = 0
    for (const market of markets) {
      const minLiability: any = []
      for (const id of JSON.parse(market.market_runner_json).map((runner: any) => runner.id)) {
        const marketBets = bets.filter((bet) => bet.is_fancy == 0 && bet.MarketId == market.Id)
        const pl: any = await this.getMaxProfit(marketBets, id)

        if (marketId !== null) {
          if (marketId === market.Id) {
            if (pl !== 0) {
              minLiability.push(pl)
            }
          } else {
            if (pl < 0) {
              minLiability.push(pl)
            }
          }
        } else {
          if (pl !== 0) {
            if (considerPlus) {
              minLiability.push(pl)
            } else {
              if (pl < 0) {
                minLiability.push(pl)
              }
            }
          }
        }
      }

      liability += Math.min(...minLiability)
    }

    const fancyIds = [...new Set(bets.filter((bet) => bet.is_fancy == 1).map((bet) => bet.fancyId))]
    for (const fancyId of fancyIds) {
      const maxLiability: number[] = []
      const book: any[] = await this.getBook(
        bets.filter((bet) => bet.is_fancy && bet.fancyId === fancyId)
      )
      const bk = Math.min(...book.map((b) => b.value))
      if (bk !== 0) {
        maxLiability.push(bk)
      }

      liability += Math.min(...maxLiability)
    }

    return liability
  }

  public async getMaxProfit(bets: any[], selectionId: any) {
    let pl = 0
    pl += bets
      .filter((bet: any) => bet.isBack == 0 && bet.SelectionId == selectionId)
      .reduce((sum: any, bet: any) => sum + parseFloat(bet.P_L), 0)
    pl -= bets
      .filter((bet: any) => bet.isBack == 0 && bet.SelectionId != selectionId)
      .reduce((sum: any, bet: any) => sum + parseFloat(bet.Stack), 0)
    pl -= bets
      .filter((bet: any) => bet.isBack == 1 && bet.SelectionId == selectionId)
      .reduce((sum: any, bet: any) => sum + parseFloat(bet.P_L), 0)
    pl += bets
      .filter((bet) => bet.isBack == 1 && bet.SelectionId != selectionId)
      .reduce((sum, bet) => sum + parseFloat(bet.Stack), 0)
    return pl
  }

  public async getPokerLiability(id: string | number, marketId: any = null) {
    let pokerLiability: any = 0
    for (const key of await this.scanKeys(`poker:${id}:${marketId || '*'}`)) {
      const liability = await Cache.get(key)
      if (liability) {
        pokerLiability += parseFloat(liability)
      }
    }
    console.log('test saveCoins->getPokerLiability 3.2 flag');
    return parseFloat(pokerLiability)
  }

  public async getKingLiability(id: string | number, marketId: any = null) {
    let kingLiability: any = 0
    for (const key of await this.scanKeys(`king:${id}:${marketId || '*'}`)) {
      const liability = await Cache.get(key)
      if (liability) {
        kingLiability += parseFloat(liability)
      }
    }
    console.log('test saveCoins->getKingLiability 3.3 flag');
    return parseFloat(kingLiability)
  }

  public async betUserIds(matchId, marketId) {
    const ids = await Database.from('tblbets')
      .distinct('UserId as id')
      .where('MatchId', matchId)
      .where('MarketId', marketId)
      .union(
        [
          (query) => {
            query
              .from('tblbets')
              .distinct('ParantId as id')
              .where('MatchId', matchId)
              .where('MarketId', marketId)
          },
          (query) => {
            query
              .from('tblbets')
              .distinct('DealerID as id')
              .where('MatchId', matchId)
              .where('MarketId', marketId)
          },
          (query) => {
            query
              .from('tblbets')
              .distinct('MasterID as id')
              .where('MatchId', matchId)
              .where('MarketId', marketId)
          },
          (query) => {
            query
              .from('tblbets')
              .distinct('SMasterID as id')
              .where('MatchId', matchId)
              .where('MarketId', marketId)
          },
          (query) => {
            query
              .from('tblbets')
              .distinct('SAdminID as id')
              .where('MatchId', matchId)
              .where('MarketId', marketId)
          },
          (query) => {
            query
              .from('tblbets')
              .distinct('AdminID as id')
              .where('MatchId', matchId)
              .where('MarketId', marketId)
          },
          (query) => {
            query
              .from('tblbets')
              .distinct('CompanyID as id')
              .where('MatchId', matchId)
              .where('MarketId', marketId)
          },
          (query) => {
            query
              .from('tblbets')
              .distinct('ParentExchCompanyID as id')
              .where('MatchId', matchId)
              .where('MarketId', marketId)
          },
        ],
        true
      )

    return ids
  }

  public async updateLiability(data: any[], mongoData?: any, type?: 'add' | 'delete') {
    let finalData: any
    console.log('test saveCoins->updateLiability 4.1 flag');

    try {
      for (const user of data) {
        if (user.hasOwnProperty('id')) {
          const liabilityKey = 'USER_LIABILITY:' + user.id

          // ✅ Redis keys for match tracking
          const successKey = mongoData?.matchId ? `MATCH:${mongoData.matchId}:SUCCESS_COUNT` : null
          const failKey = mongoData?.matchId ? `MATCH:${mongoData.matchId}:FAIL_COUNT` : null
          const failDataKey = mongoData?.matchId ? `MATCH:${mongoData.matchId}:FAIL_DATA` : null

          const lock = await Redis.set(liabilityKey, '1', 'EX', 5, 'NX')
          if (!lock) {
            console.log('Lock exists, skipping user:', user.id)
            continue
          }

          try {
            console.log('test saveCoins->updateLiability 4.2 flag');

            await Mongo.collection('logs').insertOne({
              ...mongoData,
              logType: 'Update Liability Started',
              createdAt: new Date(),
            })

            console.log('test saveCoins->updateLiability 4.3 flag');

            const rows: any = await this.getLiability(user.id, mongoData?.type || '', mongoData)

            console.log('test saveCoins->updateLiability 4.4 flag');

            if (rows.length > 0) {
              const data = rows[0]

              console.log('test saveCoins->updateLiability 4.5 flag');

              const pokerLiability: any = await this.getPokerLiability(user.id)

              console.log('test saveCoins->updateLiability 4.6 flag');

              const kingLiability: any = await this.getKingLiability(user.id)

              console.log('test saveCoins->updateLiability 4.7 flag');

              const balance = parseFloat(data.Balance) - pokerLiability - kingLiability
              const liability = parseFloat(data.Liability) - pokerLiability - kingLiability

              console.log('test saveCoins->updateLiability 4.8 flag');

              const profitLoss = await this.getProfitLoss(user.id)

              console.log('test saveCoins->updateLiability 4.9 flag');

              if (mongoData?.type == 'WITHDRAW' || mongoData?.type == 'DEPOSIT') {
                finalData = {
                  balance: balance,
                  freechips: data.FreeChip,
                }
                await Sp.call('update_createmaster(:userid, :type, :balance, :freechips, :liability, :p_l, :chip, :sessionLiability, :unmatchliability, :profit_loss)', {
                  userid: user.id,
                  type: mongoData?.type || '',
                  balance: balance,
                  freechips: data.FreeChip,
                  liability: 0,
                  p_l: 0,
                  chip: 0,
                  sessionLiability: 0,
                  unmatchliability: 0,
                  profit_loss: 0,
                })
              } else {
                finalData = {
                  liability: liability,
                  balance: balance,
                  p_l: data.chipspnl,
                  freechips: data.FreeChip,
                  chip: data.Chip,
                  sessionLiability: data.sessionLiability,
                  unmatchliability: data.unmatchliability,
                  profit_loss: profitLoss.total,
                }
                await Sp.call('update_createmaster(:userid, :type, :balance, :freechips, :liability, :p_l, :chip, :sessionLiability, :unmatchliability, :profit_loss)', {
                  userid: user.id,
                  type: mongoData?.type || '',
                  balance: balance,
                  freechips: data.FreeChip,
                  liability: liability,
                  p_l: data.chipspnl,
                  chip: data.Chip,
                  sessionLiability: data.sessionLiability,
                  unmatchliability: data.unmatchliability,
                  profit_loss: profitLoss.total,
                })
              }

              // ✅ SUCCESS COUNT INCREMENT
              if (successKey) {
                await Redis.incr(successKey)
                await Redis.expire(successKey, 3600)
              }

              let userData = {
                user_id: user.id,
                data: {
                  type: 'balance',
                  data: finalData,
                },
              }

              try {
                if (mongoData && mongoData.userId == user.id) {
                  if (type == 'add') {
                    Mongo.collection('logs').insertOne({
                      ...mongoData,
                      logType: 'Update Liability Ended',
                      afterBalance: balance,
                      afterLiability: liability,
                      createdAt: new Date(),
                    })
                  } else {
                    Mongo.collection('logs').deleteOne(mongoData)
                  }
                }
              } catch (e) {
                console.error(e)
              }

              console.log('test saveCoins->updateLiability 4.12 flag');

              await Redis.publish('USER_UPDATE_DATA', JSON.stringify(userData))

              const keys = await Redis.keys('auth:' + user.id + '|*')

              for (const key of keys) {
                let userCache: any = await Cache.get(key)
                if (userCache) {
                  userCache.liability = liability
                  userCache.balance = balance
                  userCache.p_l = data.chipspnl
                  userCache.freechips = data.FreeChip
                  userCache.chip = data.Chip
                  userCache.profit_loss = profitLoss.total
                  await Cache.put(key, userCache, 3600)
                }
              }
            }
          } catch (err: any) {
            console.error('User failed:', user.id, err)

            // ❌ FAILURE COUNT + DATA
            if (failKey && failDataKey) {
              await Redis.incr(failKey)
              await Redis.expire(failKey, 3600)

              await Redis.rpush(
                failDataKey,
                JSON.stringify({
                  userId: user.id,
                  error: err.message,
                  payload: mongoData,
                  time: new Date(),
                })
              )
              await Redis.expire(failDataKey, 3600)
            }
          } finally {
            console.log('test saveCoins->updateLiability 4.13 flag');
            await Redis.del(liabilityKey)
            // try {
            //   setTimeout(async () => {
            //     console.log('test saveCoins->updateLiability 4.14 flag');
            //     await Database.query()
            //       .from('createmaster')
            //       .where('mstrid', user.id)
            //       .update(finalData)

            //     console.log('test saveCoins->updateLiability 4.15 flag');

            //   }, 200)
            // } catch (err: any) {
            //   console.log('DB Update Error:', err)
            // }
            console.log('test saveCoins->updateLiability 4.16 flag');
            // ✅ Always release lock
          }
        }
      }
    } catch (e) {
      console.log('In liability catch:', e)
    }

    return finalData
  }

  public async getProfitLoss(userId) {
    console.log('test saveCoins 3.0 flag');
    return (
      (await Database.from('tblchipdet as a')
        .join('createmaster', 'createmaster.mstrid', 'a.UserId')
        .where('a.is_deleted', 'N')
        // @ts-ignore
        .where('a.UserId', userId)
        .whereIn('a.MstType', [5, 6, 8])
        .whereRaw(
          'CASE WHEN a.is_partnership = 0 THEN CASE WHEN (a.LevelV != 0) THEN a.ChildID != 0 ELSE a.ChildID = 0 END ELSE 1 = 1 END'
        )
        .select(
          Database.raw(
            'ROUND(SUM(a.ChipsCr - a.ChipsDr),2) + IFNULL((SELECT SUM(amountV) FROM tblcashentry WHERE childId = a.UserID GROUP BY childId),0) * (IF(createmaster.usetype = 3, -1, 1)) as total'
          )
        )
        .groupBy('a.UserID')
        .first()) || { total: 0 }
    )
  }

  public async deleteKeys(keys: string[]) {
    for (const key of keys) {
      await Redis.del(key)
    }
  }

  /**
   * Non-blocking replacement for `Redis.keys(pattern)`. `KEYS` is O(N) over the
   * entire keyspace and blocks single-threaded Redis — fatal under high
   * concurrency. `SCAN` walks the keyspace incrementally in bounded chunks.
   * Prefer this everywhere a pattern match is needed.
   */
  public async scanKeys(pattern: string, count = 250): Promise<string[]> {
    const found: string[] = []
    let cursor = '0'
    do {
      const [next, keys] = await Redis.scan(cursor, 'MATCH', pattern, 'COUNT', count)
      cursor = next
      if (keys.length) found.push(...keys)
    } while (cursor !== '0')
    return found
  }

  public async checkBalanceAfterBet(authUser, betPlaceVal, isMarket = false) {
    const rows = await this.getLiability(authUser?.mstrid)
    const data = rows[0]

    const pokerLiability = await this.getPokerLiability(authUser?.mstrid)
    const kingLiability = await this.getKingLiability(authUser?.mstrid)

    let balance = parseFloat(data.Balance) - pokerLiability - kingLiability

    let attemptExceed = false

    if (balance < 0) {
      let attempts = 0
      const maxAttempts = 3 // Define a maximum number of attempts to avoid infinite loop

      while (attempts < maxAttempts) {
        const l = await this.getLiability(authUser?.mstrid)
        balance = parseFloat(l[0].Balance) - pokerLiability - kingLiability

        if (balance < 0) {
          attempts++
          // Wait a short duration before retrying
          await new Promise((resolve) => setTimeout(resolve, 500)) // Adjust the delay as needed
        } else {
          break // Exit the loop if the conditions are met
        }
      }

      if (attempts >= maxAttempts) {
        // throw new Error('Balance and liability did not update in a reasonable time.')
        attemptExceed = true
      }
    }

    if (balance < 0 || attemptExceed) {
      if (isMarket) {
        await Database.from('tblbets').where('MstCode', betPlaceVal[0].LID).delete()
      } else {
        await Database.from('bet_entry').where('bet_id', betPlaceVal[0].LID).delete()
      }

      await this.updateLiability([{ id: authUser?.mstrid }])

      return attemptExceed ? 'Server error!, bet not placed.' : 'Insufficient balance!'
    }

    return false
  }

  public async checkPersmission(helper: any, permission: string = 'pass') {
    if (
      helper.usetype == 55 &&
      (JSON.parse(helper.permissions).indexOf(permission) > -1 || permission == 'pass')
    ) {
      if (permission == 'Deposit Request' || permission == 'Withdraw Request') {
        return await Database.from('createmaster')
          .where('domain', helper.domain)
          .where('usetype', 1)
          .where('allow_deposit_withdraw', 1)
          .first()
      } else if (permission == 'Bank Account Add/Remove') {
        const { usetype } = await Database.from('createmaster')
          .select('usetype')
          .where('mstrid', helper.parentId)
          .first()

        if (usetype == 11) {
          return await Database.from('createmaster')
            .where('domain', helper.domain)
            .where('usetype', 1)
            .where('allow_deposit_withdraw', 1)
            .where('parentId', helper.parentId)
            .first()
        } else if (usetype == 1) {
          return await Database.from('createmaster').where('mstrid', helper.parentId).first()
        }
      } else {
        return await Database.from('createmaster').where('mstrid', helper.parentId).firstOrFail()
      }
    } else if (helper.usetype == 55) {
      return false
    }
  }

  public async getLiabilityQuery(userId: string | number) {
    // Step 1: Get usertype

    // 🔹 Step 1: usertype (separate, fast)
    const userTypeRow = await Database
      .from('createmaster')
      .where('mstrid', userId)
      .select('usetype')
      .first()

    const usertype = userTypeRow?.usetype || 0

    // 🔹 Step 2: EXACT SAME QUERY (no logic change)
    const result = await Database.rawQuery(`
    SELECT 
      ROUND((IFNULL(c.Chips,0) + IFNULL(cs.amount,0)),2) FreeChip,
      ROUND(IFNULL(d.Chips,0), 2) Chip,
      IFNULL(a.Lay,0) AS Lay,
      IFNULL(b.Stack,0) AS Back,

      CASE 
        WHEN ROUND(IFNULL(i.Liability, 0) + IFNULL(L.Liability, 0) + IFNULL(N.Liability, 0) + IFNULL(k.Liability, 0) + IFNULL(M.Liability, 0) + IFNULL(O.Liability, 0) + IFNULL(qryOddEven.Liability, 0), 2) < 0 
        THEN ROUND(IFNULL(i.Liability, 0) + IFNULL(L.Liability, 0) + IFNULL(N.Liability, 0) + IFNULL(k.Liability, 0) + IFNULL(M.Liability, 0) + IFNULL(O.Liability, 0) + IFNULL(qryOddEven.Liability, 0), 2) 
        ELSE 0 
      END AS Liability,

      ROUND(
        IFNULL(c.Chips,0) + 
        CASE WHEN ? = 3 THEN IFNULL(j.ChipBal, 0) ELSE 0 END +
        CASE 
          WHEN ROUND(IFNULL(i.Liability, 0) + IFNULL(L.Liability, 0) + IFNULL(N.Liability, 0) + IFNULL(k.Liability, 0) + IFNULL(M.Liability, 0) + IFNULL(O.Liability, 0) + IFNULL(qryOddEven.Liability, 0), 2) < 0 
          THEN ROUND(IFNULL(i.Liability, 0) + IFNULL(L.Liability, 0) + IFNULL(N.Liability, 0) + IFNULL(k.Liability, 0) + IFNULL(M.Liability, 0) + IFNULL(O.Liability, 0) + IFNULL(qryOddEven.Liability, 0), 2) 
          ELSE 0 
        END, 
      2) AS Balance,

      IFNULL((e.P_L + f.P_L + g.P_L + h.P_L),0) P_L,
      IFNULL(i.Liability, 0) AS marketliability,
      ROUND(IFNULL(d.Chips,0), 2) AS chipspnl,
      IFNULL(L.Liability, 0) AS otherLiability,
      IFNULL(M.Liability, 0) AS upDownLiability,
      IFNULL(N.Liability, 0) AS lastdigit,
      IFNULL(k.Liability, 0) AS sessionLiability,
      IFNULL(O.Liability, 0) AS unmatchliability,
      IFNULL(qryOddEven.Liability, 0) AS oddEvenLiability

    FROM 

    (SELECT SUM(P_L) Lay FROM tblbets WHERE isBack = 1 AND UserId = ? AND Result IS NULL AND ResultID IS NULL AND is_poker = 0) a,

    (SELECT SUM(Stack) Stack FROM tblbets WHERE isBack = 0 AND UserId = ? AND Result IS NULL AND ResultID IS NULL AND is_poker = 0) b,

    (SELECT SUM(Chips) Chips FROM tblchips WHERE IsFree = 1 AND ResultID IS NULL AND BetID IS NULL AND UserID = ?) c,

    (SELECT SUM(CASE WHEN CrDr = 1 AND childId = ? THEN amountV ELSE -amountV END) AS amount 
     FROM tblcashentry WHERE typeId = 50 AND (parentId = ? OR childId = ?)) cs,

    (SELECT SUM(a.ChipsCr-a.ChipsDr) Chips FROM tblchipdet a WHERE a.UserID = ? AND MstType != 50) d,

    (SELECT IFNULL(SUM(P_L),0) P_L FROM tblbets WHERE result = 1 AND isBack = 0 AND UserID = ?) e,

    (SELECT IFNULL(SUM(-P_L),0) P_L FROM tblbets WHERE result = 1 AND isBack = 1 AND UserID = ?) f,

    (SELECT IFNULL(SUM(-Stack),0) P_L FROM tblbets WHERE result = 0 AND isBack = 0 AND UserID = ? AND is_poker = 0) g,

    (SELECT IFNULL(SUM(Stack),0) P_L FROM tblbets WHERE result = 0 AND isBack = 1 AND UserID = ? AND is_poker = 0) h,

    (SELECT SUM(X.mSum) Liability FROM (
        SELECT MIN(a.pnlvalue) mSum 
        FROM (
            SELECT SUM(winValue + lossValue) pnlvalue, matchId, MarketId, SelectionId 
            FROM vewuserpnldetails 
            WHERE userId = ? 
            GROUP BY matchId, MarketId, SelectionId
        ) a 
        WHERE a.pnlvalue < 0 
        GROUP BY MarketId
    ) X) i,

    (SELECT SUM(IFNULL(ChipsCr, 0) - IFNULL(ChipsDr, 0)) ChipBal 
     FROM tblchipdet WHERE UserID = ? AND MstType != 50) j,

    (SELECT SUM(minvalue) Liability FROM (
        SELECT MIN(pnlvalue) minvalue, matchId, MarketId 
        FROM (
            SELECT SUM(aa) pnlvalue, matchId, fancyid MarketId, yes 
            FROM vewsessionliability 
            WHERE userId = ? 
            GROUP BY yes, matchId, fancyid
        ) X GROUP BY matchId, MarketId
    ) Y) k,

    (SELECT SUM(bet_value) * -1 Liability 
     FROM bet_entry WHERE TypeID IN (3) AND ResultID IS NULL AND userid = ?) L,

    (SELECT SUM(minvalue) Liability FROM (
        SELECT MIN(pnlvalue) minvalue, matchId, MarketId 
        FROM (
            SELECT SUM(aa) pnlvalue, matchId, fancyid MarketId, runvalue 
            FROM vewupdownliability 
            WHERE userId = ? 
            GROUP BY runvalue, matchId, fancyid
        ) X1 GROUP BY matchId, MarketId
    ) Y1) M,

    (SELECT SUM(bet_value) * -1 Liability 
     FROM bet_entry a 
     INNER JOIN matchfancy b ON a.fancyId = b.ID 
     WHERE a.TypeID = 4 AND ResultID IS NULL AND userid = ?) N,

    (SELECT SUM(winValue) Liability 
     FROM vewuserpnlunmonly WHERE userId = ?) O,

    (SELECT IFNULL(Liability, 0) * CASE WHEN IFNULL(Liability, 0) > 0 THEN -1 ELSE 1 END Liability 
     FROM (
        SELECT SUM(CASE WHEN OddValue = 1 THEN 1 ELSE -1 END * bet_value) Liability 
        FROM bet_entry WHERE TypeID IN (1) AND ResultID IS NULL AND userid = ?
     ) qryOEinner) qryOddEven
  `, [
      usertype,
      userId, userId, userId,
      userId, userId, userId,
      userId,
      userId,
      userId,
      userId,
      userId,
      userId,
      userId,
      userId,
      userId,
      userId,
      userId,
      userId,
      userId
    ])

    return result[0]
  }
}

export default new UserService()
