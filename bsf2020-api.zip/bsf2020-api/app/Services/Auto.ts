class Auto {
  public code: string = '7686'
}

export default new Auto()
