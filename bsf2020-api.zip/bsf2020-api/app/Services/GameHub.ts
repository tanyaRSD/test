import crypto from 'crypto'
import { URLSearchParams } from 'url'
import Env from '@ioc:Adonis/Core/Env'
const salt = Env.get('GAMEHUB_SALT', 'Klaow918wi')

class GameHub {
  public async verifyHash(data: any) {
    const key: string = data.key

    delete data.key

    const queryString: string = new URLSearchParams(data).toString()
    const hash: string = crypto
      .createHash('sha1')
      .update(salt + queryString)
      .digest('hex')

    return key == hash
  }
}

export default new GameHub()
