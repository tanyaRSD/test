import Env from '@ioc:Adonis/Core/Env'
const jioPayments = [
  {
    id: 1,
    name: 'Phone Pay',
  },
  {
    id: 2,
    name: 'Paytm',
  },
  {
    id: 3,
    name: 'Gpay',
  },
  {
    id: 4,
    name: 'IMPS',
  },
  {
    id: 5,
    name: 'Neteller',
  },
  {
    id: 6,
    name: 'Bkash MFS',
  },
  {
    id: 7,
    name: 'Nagad MFS',
  },
  {
    id: 8,
    name: 'Rocket MFS ',
  },
  {
    id: 9,
    name: 'Bank Transfer',
  },
  {
    id: 10,
    name: 'USDT',
  },
]

const baziwalaPayments = [
  {
    id: 1,
    name: 'Bkash MFS',
    isActive: false,
    data: [],
    image: 'bkash.png',
  },
  {
    id: 2,
    name: 'Nagad MFS',
    isActive: false,
    data: [],
    image: 'NagadMFS.png',
  },
  {
    id: 3,
    name: 'Rocket MFS',
    isActive: false,
    data: [],
    image: 'RocketMFS.png',
  },
  {
    id: 5,
    name: 'City',
    isActive: false,
    data: [],
    image: 'Neteller.png',
  },
  {
    id: 6,
    name: 'BRAC',
    isActive: false,
    data: [],
    image: 'phonepay.png',
  },
  {
    id: 7,
    name: 'Ibb2',
    isActive: false,
    data: [],
    image: 'PayTM.png',
  },
  {
    id: 8,
    name: 'USDT',
    isActive: false,
    data: [],
    image: 'GPay.png',
  },
  {
    id: 10,
    name: 'DBB2',
    isActive: false,
    data: [],
    image: 'imps.png',
  },
  {
    id: 11,
    name: 'Bitcoin',
    isActive: false,
    data: [],
    image: 'bank.png',
  },
]

class Payment {
  public list = Env.get('baziwala', 0) == 1 ? baziwalaPayments : jioPayments
}

export default new Payment()
