class KingService {
  public liveGames = [
    { id: '362514', name: '20 - 20 Teen Patti' },
    { id: '362518', name: 'Lucky 7' },
    { id: '968574', name: 'Card Race' },
    { id: '632518', name: 'Dragon Tiger' },
    { id: '302514', name: '32 Cards' },
    { id: '145892', name: '1 Day Dragon Tiger' },
    { id: '365247', name: 'Andar Bahar' },
    { id: '362489', name: 'Eu Lucky 7' },
    { id: '743658', name: '1 Day Teen Patti' },
    { id: '842369', name: 'Baccarat 1' },
    { id: '452387', name: 'Eu Dragon Tiger' },
    { id: '852634', name: 'Eu 20-20 Teen Patti' },
    { id: '695847', name: 'Muflis Teen Patti' },
    { id: '623897', name: 'Baccarat 2' },
  ]
}

export default new KingService()
