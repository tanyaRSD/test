import Redis from '@ioc:Adonis/Addons/Redis'
import Database from '@ioc:Adonis/Lucid/Database'
import Settings from 'App/Services/Settings'
import Env from '@ioc:Adonis/Core/Env'

class MarketService {
  public async createMarket(data, isBookmaker = false, market = null) {
    if (!market) {
      market = await Database.query().from('market').where('Id', data.marketId).first()

      if (market) {
        return 0
      }
    }

    if (!market) {
      const settings = await Settings.all()

      const defaultLimits = Settings.defaultSportLimit
      const limit = defaultLimits.find(
        (el: any) =>
          el.type == (isBookmaker ? 'bookmaker' : 'market') && el.sport_id == data.sports_id
      )

      const maxStake = limit?.max_stake || 100000
      const minStake = limit?.min_stake || 10
      const maxMarketProfit = limit?.max_profit || 500000
      const maxMarketLiability = settings?.max_market_liability || 0
      const marketVolume = settings?.market_volume || 1

      let oddsLimit = 0

      if (Env.get('project') == 2) {
        oddsLimit = 100
        if (isBookmaker) {
          oddsLimit = 1000
        }
      }

      await Database.insertQuery()
        .table('market')
        .insert({
          Id: data.marketId,
          Name: data.marketName,
          sportsId: data.sports_id,
          seriesId: data.series_id,
          matchId: data.match_id,
          totalMatched: 0,
          max_stack: maxStake,
          min_stack: minStake,
          createdOn: new Date(),
          active: 1,
          market_runner_json: data.market_runner_json,
          max_market_profit: maxMarketProfit,
          max_market_liability: maxMarketLiability,
          volume: marketVolume,
          HelperID: data.HelperID ? data.HelperID : 0,
          start_time: data.startTime,
          odds_limit: oddsLimit,
          is_manual: data.is_manual,
        })

      let index = 1
      for (let runner of data.runners) {
        await Database.insertQuery().table('tblselection').insert({
          sportId: data.sports_id,
          matchId: data.match_id,
          selectionId: runner.selectionId,
          selectionName: runner.runnerName,
          marketId: data.marketId,
          teamType: index,
        })

        index++
      }
    }
    return 1
  }

  public async removeMarketCache(matchId: any) {
    const keys = await Redis.keys(`matchmarkets:*:${matchId}:*`)
    if (keys.length > 0) {
      await Redis.del(...keys)
    }
  }
}

export default new MarketService()
