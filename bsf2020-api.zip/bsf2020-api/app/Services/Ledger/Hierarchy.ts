/**
 * Hierarchy
 * ==================================================================
 * Single source of truth for the account hierarchy (the "levels") and how a
 * bet row maps to the chain of upper panels that share its exposure.
 *
 * Every bet in `tblbets` (and `bet_entry`) is denormalised with, for each
 * upper level, BOTH the ancestor's id and the partnership % that level keeps:
 *
 *     DealerID / Dealer , MasterID / Master , SMasterID / SMaster ,
 *     SAdminID / SAdmin , AdminID / Admin , CompanyID / Company ,
 *     ParentExchCompanyID / ParentExchCompany
 *
 * The `usetype` -> share-column mapping below is the same one the legacy
 * `_get_odds_profit_loss` procedure uses to weight each level's P/L, so the
 * incremental engine stays bug-for-bug compatible with the stored procedures.
 */

/** `usetype` codes as used throughout createmaster. */
export enum UserType {
  SuperDuperAdmin = 0, // root — shares via ParentExchCompany column
  Master = 1,
  Dealer = 2,
  Client = 3, // leaf player — bears its own raw P/L, no share column
  SuperMaster = 8,
  SubAdmin = 9,
  SuperAdmin = 10,
  Company = 11,
  Helper = 55, // staff sub-account — not part of the money chain
}

/** Describes one upper level present on a denormalised bet row. */
export interface LevelDef {
  /** createmaster.usetype this level represents. */
  usetype: UserType
  /** Human label, matches the LevelV narration in the result procedures. */
  name: string
  /** Column on tblbets holding this level's partnership % (0-100). */
  shareColumn:
    | 'Dealer'
    | 'Master'
    | 'SMaster'
    | 'SAdmin'
    | 'Admin'
    | 'Company'
    | 'ParentExchCompany'
  /** Column on tblbets holding this level's account id. */
  idColumn:
    | 'DealerID'
    | 'MasterID'
    | 'SMasterID'
    | 'SAdminID'
    | 'AdminID'
    | 'CompanyID'
    | 'ParentExchCompanyID'
}

/**
 * Upper levels ordered from nearest-to-client (Dealer) up to the root
 * (ParentExchCompany / super-duper-admin). The client itself is not in this
 * list — it is handled separately because it carries the full, unscaled P/L.
 */
export const LEVELS: LevelDef[] = [
  { usetype: UserType.Dealer, name: 'Dealer', shareColumn: 'Dealer', idColumn: 'DealerID' },
  { usetype: UserType.Master, name: 'Master', shareColumn: 'Master', idColumn: 'MasterID' },
  {
    usetype: UserType.SuperMaster,
    name: 'Super Master',
    shareColumn: 'SMaster',
    idColumn: 'SMasterID',
  },
  { usetype: UserType.SubAdmin, name: 'Sub Admin', shareColumn: 'SAdmin', idColumn: 'SAdminID' },
  { usetype: UserType.SuperAdmin, name: 'Super Admin', shareColumn: 'Admin', idColumn: 'AdminID' },
  { usetype: UserType.Company, name: 'Company', shareColumn: 'Company', idColumn: 'CompanyID' },
  {
    usetype: UserType.SuperDuperAdmin,
    name: 'Super Duper Admin',
    shareColumn: 'ParentExchCompany',
    idColumn: 'ParentExchCompanyID',
  },
]

/** A resolved upper panel and the fraction of the client's P/L it carries. */
export interface ChainShare {
  accountId: number
  /** Partnership fraction in [0,1] — the % column divided by 100. */
  fraction: number
}

/** Minimal shape of a bet row needed to resolve its upper-panel chain. */
export type BetChainRow = Record<LevelDef['idColumn'] | LevelDef['shareColumn'], number | null>

/**
 * Resolve the upper panels that share a bet's exposure, with each panel's
 * partnership fraction. Levels whose id is 0/null (absent for this client's
 * depth) are skipped.
 *
 * The book (upper panel) sits on the OPPOSITE side of the client, so the caller
 * applies the returned fraction with a negated client P/L when writing the
 * ledger. This function only resolves "who" and "how much share", never sign.
 */
export function resolveChain(bet: BetChainRow): ChainShare[] {
  const chain: ChainShare[] = []
  for (const level of LEVELS) {
    const accountId = Number(bet[level.idColumn] ?? 0)
    if (!accountId) continue
    const pct = Number(bet[level.shareColumn] ?? 0)
    chain.push({ accountId, fraction: pct / 100 })
  }
  return chain
}

/**
 * Liability buckets — mirrors the separate components summed inside
 * getLiability (market `i`, session `k`, bookmaker `L`, updown `M`,
 * lastdigit `N`, unmatch `O`, oddeven). `createmaster.liability` is the sum of
 * all buckets, each of which is <= 0.
 */
export enum LiabilityBucket {
  Market = 'market',
  Bookmaker = 'bookmaker',
  Session = 'session',
  UpDown = 'updown',
  LastDigit = 'lastdigit',
  Unmatch = 'unmatch',
  OddEven = 'oddeven',
  Poker = 'poker',
}
