/**
 * PartnershipCalculator
 * ==================================================================
 * Builds the `tblpartner` share matrix for a newly created account.
 *
 * Replaces the ~600 lines of hand-unrolled per-(typeId × game × level)
 * assignments in UsersController.create, which had accumulated a large class of
 * copy-paste bugs (e.g. dream/binary reading the soccer column, master/super-
 * admin election reading super_duper/super_master columns). The rule is uniform
 * across every level, so expressing it once as data removes those bugs by
 * construction.
 *
 * The rule (partnership accounts):
 *   For every level above the new account:
 *     - the immediate parent's level         -> parent_share - requested   (>= 0)
 *     - any other ancestor / skipped level   -> inherited from parent row
 *   The new account's own level               -> requested
 *   Every level below                         -> 0
 *
 * The leaf client/player (usetype 3) is a special case: it sits below every
 * level in ORDER and owns no tblpartner column of its own. Because the client
 * takes no partnership share, every upline keeps exactly the share it already
 * had, so the client's row is a verbatim copy of the parent's matrix (no
 * requested subtraction). This matches the original per-game typeId==3 branch.
 *
 * Non-partnership accounts get a flat 100 in every cell (the bet's
 * `is_partnership = 0` flag makes the result procedures ignore these weights).
 */

/** Hierarchy in seniority order, with each level's tblpartner column prefix. */
const ORDER: { typeId: number; prefix: string }[] = [
  { typeId: 0, prefix: 'super_duper_admin' },
  { typeId: 11, prefix: 'company' },
  { typeId: 10, prefix: 'super_admin' },
  { typeId: 9, prefix: 'sub_admin' },
  { typeId: 8, prefix: 'super_master' },
  { typeId: 1, prefix: 'master' },
  { typeId: 2, prefix: 'dealer' },
]

/**
 * The leaf client/player level. It is below every entry in ORDER and has no
 * tblpartner column, so it is handled as pure inheritance rather than a row in
 * ORDER (which would emit non-existent `client_*` columns).
 */
const LEAF_TYPE_ID = 3

const GAMES = [
  'cricket',
  'soccer',
  'tennis',
  'casino',
  'dream',
  'binary',
  'election',
  'virtual_casino',
] as const

type Game = (typeof GAMES)[number]

/** Requested partnership % per game for the new account (0-100). */
export type RequestedShares = Record<Game, number>

/** A full tblpartner share row (56 cells), excluding the id/parent/type keys. */
export type PartnerShareRow = Record<string, number>

const handleMinus = (v: number) => (v < 0 ? 0 : v)

class PartnershipCalculator {
  /**
   * Compute the share matrix for a new account.
   *
   * @param parentRow    The parent's existing tblpartner row (its `UserID` row).
   * @param parentTypeId The parent's usetype (its tblpartner.TypeID).
   * @param newTypeId    The new account's usetype.
   * @param requested    Requested % per game (ignored when isPartnership=false).
   * @param isPartnership Whether this account participates in partnership splits.
   */
  public compute(
    parentRow: Record<string, any> | null,
    parentTypeId: number,
    newTypeId: number,
    requested: RequestedShares,
    isPartnership: boolean
  ): PartnerShareRow {
    const row: PartnerShareRow = {}

    if (!isPartnership) {
      for (const level of ORDER) {
        for (const g of GAMES) row[`${level.prefix}_${g}`] = 100
      }
      return row
    }

    const isLeaf = newTypeId === LEAF_TYPE_ID
    const newIdx = ORDER.findIndex((l) => l.typeId === newTypeId)
    if (newIdx === -1 && !isLeaf) {
      throw new Error(`PartnershipCalculator: unknown usetype ${newTypeId}`)
    }

    ORDER.forEach((level, idx) => {
      for (const g of GAMES) {
        const col = `${level.prefix}_${g}`
        // The parent owns 100% at its own level before distributing, so when the
        // parent row is missing that column (e.g. root has no tblpartner row),
        // default the immediate-parent slot to 100. Other ancestors default to 0.
        const parentVal = Number(parentRow?.[col] ?? (level.typeId === parentTypeId ? 100 : 0))
        if (isLeaf) {
          // Leaf client (usetype 3): takes no share, so every upline level is
          // inherited from the parent verbatim — including the immediate parent
          // (no requested subtraction).
          row[col] = parentVal
        } else if (idx < newIdx) {
          // Above the new account.
          row[col] =
            level.typeId === parentTypeId
              ? handleMinus(parentVal - Number(requested[g] ?? 0)) // immediate parent slot
              : parentVal // inherited / skipped ancestor
        } else if (idx === newIdx) {
          row[col] = Number(requested[g] ?? 0) // the new account's own slot
        } else {
          row[col] = 0 // below the new account
        }
      }
    })

    return row
  }
}

export default new PartnershipCalculator()
