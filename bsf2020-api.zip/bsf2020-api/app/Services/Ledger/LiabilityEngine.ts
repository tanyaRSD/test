import Database from '@ioc:Adonis/Lucid/Database'
import type { TransactionClientContract } from '@ioc:Adonis/Lucid/Database'
import { LiabilityBucket } from './Hierarchy'

/**
 * A single change to one account's net on one selection. `delta` is the
 * partnership-scaled change to "what this account earns if this selection wins"
 * (positive = better for the account). Sign is the caller's responsibility:
 * the client passes its raw P/L, an upper panel passes `-rawP/L * fraction`.
 */
export interface ExposureDelta {
  accountId: number
  matchId: number
  marketId: string
  selectionId: number
  delta: number
}

/** Movement of settled money on an account's `createmaster` columns. */
export interface ChipDelta {
  accountId: number
  /** Change to free/deposit chips (deposits, withdrawals). */
  freechips?: number
  /** Change to settled ledger P/L (result/settlement). Affects balance for clients only. */
  chip?: number
}

/**
 * LiabilityEngine
 * ==================================================================
 * Maintains `exposure_ledger`, `account_market_liability` and the denormalised
 * `createmaster` money columns incrementally, inside a caller-supplied
 * transaction. It never recomputes a downline — it applies deltas to the acting
 * account and each ancestor the caller resolves from the bet row.
 *
 * All public methods REQUIRE a transaction client so the money mutation and the
 * ledger update commit or roll back together.
 *
 * Invariants maintained (see docs/LIABILITY_ENGINE.md):
 *   createmaster.liability == Σ account_market_liability.liability  (≤ 0)
 *   account_market_liability.liability == LEAST(0, MIN(exposure_ledger.net))
 *   createmaster.balance   == freechips + (isClient ? chip : 0) + liability
 */
class LiabilityEngine {
  /**
   * Apply a batch of per-selection exposure deltas (one market may touch many
   * accounts/selections), then refresh every affected market's worst-case and
   * patch the owning accounts' liability/balance columns.
   *
   * Batching the whole event in one call keeps it to a single recompute per
   * affected (account, market) regardless of how many selections moved.
   */
  public async applyExposure(
    trx: TransactionClientContract,
    bucket: LiabilityBucket,
    deltas: ExposureDelta[]
  ): Promise<void> {
    if (deltas.length === 0) return

    // 1. Upsert the running net for each touched selection.
    for (const d of deltas) {
      if (!d.delta) continue
      await trx.rawQuery(
        `INSERT INTO exposure_ledger
           (account_id, match_id, market_id, selection_id, market_type, net, updated_at)
         VALUES (?, ?, ?, ?, ?, ?, NOW())
         ON DUPLICATE KEY UPDATE net = net + VALUES(net), updated_at = NOW()`,
        [d.accountId, d.matchId, d.marketId, d.selectionId, bucket, d.delta]
      )
    }

    // 2. Recompute each distinct (account, market) worst-case exactly once.
    const markets = this.distinctMarkets(deltas)
    for (const m of markets) {
      await this.recomputeMarket(trx, bucket, m.accountId, m.matchId, m.marketId)
    }
  }

  /**
   * Recompute one market's worst-case for one account from the ledger, persist
   * it to `account_market_liability`, and patch the delta into the account's
   * `createmaster.liability` and `.balance`.
   */
  private async recomputeMarket(
    trx: TransactionClientContract,
    bucket: LiabilityBucket,
    accountId: number,
    matchId: number,
    marketId: string
  ): Promise<void> {
    // Worst-case across this market's selections, never positive.
    const worstRow = await trx
      .from('exposure_ledger')
      .where('account_id', accountId)
      .where('match_id', matchId)
      .where('market_id', marketId)
      .min('net as worst')
      .first()
    const newLiability = Math.min(0, Number(worstRow?.worst ?? 0))

    // Previous cached worst-case for this market.
    const prevRow = await trx
      .from('account_market_liability')
      .where('account_id', accountId)
      .where('match_id', matchId)
      .where('market_id', marketId)
      .select('liability')
      .first()
    const oldLiability = Number(prevRow?.liability ?? 0)

    if (newLiability === oldLiability) return

    await trx.rawQuery(
      `INSERT INTO account_market_liability
         (account_id, match_id, market_id, market_type, liability, updated_at)
       VALUES (?, ?, ?, ?, ?, NOW())
       ON DUPLICATE KEY UPDATE liability = VALUES(liability), updated_at = NOW()`,
      [accountId, matchId, marketId, bucket, newLiability]
    )

    // liability is always ≤ 0, and balance always includes it, so the same
    // delta applies to both columns.
    const delta = newLiability - oldLiability
    await this.patchColumns(trx, accountId, { liability: delta, balance: delta })
  }

  /**
   * Release an entire market (all accounts) when its result is declared: open
   * exposure becomes realised, so liability returns to 0. Reverses each
   * account's cached market liability out of `createmaster` and clears the
   * ledger/summary rows for that market.
   */
  public async releaseMarket(
    trx: TransactionClientContract,
    matchId: number,
    marketId: string
  ): Promise<void> {
    const open = await trx
      .from('account_market_liability')
      .where('match_id', matchId)
      .where('market_id', marketId)
      .whereNot('liability', 0)
      .select('account_id', 'liability')

    for (const row of open) {
      const delta = -Number(row.liability) // back to zero
      await this.patchColumns(trx, row.account_id, { liability: delta, balance: delta })
    }

    await trx
      .from('account_market_liability')
      .where('match_id', matchId)
      .where('market_id', marketId)
      .delete()
    await trx
      .from('exposure_ledger')
      .where('match_id', matchId)
      .where('market_id', marketId)
      .delete()
  }

  /**
   * Apply settled-money movements (deposit, withdrawal, realised P/L) to an
   * account's columns. `freechips` always flows to balance; `chip` flows to
   * balance only for clients (usetype 3), mirroring getLiability.
   */
  public async applyChip(trx: TransactionClientContract, move: ChipDelta): Promise<void> {
    const freechips = move.freechips ?? 0
    const chip = move.chip ?? 0
    if (!freechips && !chip) return

    const acc = await trx
      .from('createmaster')
      .where('mstrid', move.accountId)
      .select('usetype')
      .first()
    const isClient = Number(acc?.usetype) === 3

    const balanceDelta = freechips + (isClient ? chip : 0)
    await this.patchColumns(trx, move.accountId, { freechips, chip, balance: balanceDelta })
  }

  /**
   * Atomically add deltas to an account's money columns. COALESCE guards the
   * legacy NULLs left by the old code. Done as one UPDATE so concurrent events
   * on the same account serialise on the row lock rather than racing.
   */
  private async patchColumns(
    trx: TransactionClientContract,
    accountId: number,
    deltas: { liability?: number; balance?: number; freechips?: number; chip?: number }
  ): Promise<void> {
    const sets: string[] = []
    const bindings: any[] = []
    for (const [col, val] of Object.entries(deltas)) {
      if (!val) continue
      sets.push(`\`${col}\` = COALESCE(\`${col}\`, 0) + ?`)
      bindings.push(val)
    }
    if (sets.length === 0) return
    bindings.push(accountId)
    await trx.rawQuery(`UPDATE createmaster SET ${sets.join(', ')} WHERE mstrid = ?`, bindings)
  }

  /** Collapse a delta batch to the distinct (account, market) pairs to recompute. */
  private distinctMarkets(deltas: ExposureDelta[]) {
    const seen = new Map<string, { accountId: number; matchId: number; marketId: string }>()
    for (const d of deltas) {
      const key = `${d.accountId}|${d.matchId}|${d.marketId}`
      if (!seen.has(key)) {
        seen.set(key, { accountId: d.accountId, matchId: d.matchId, marketId: d.marketId })
      }
    }
    return [...seen.values()]
  }

  /**
   * Build exposure-ledger deltas for the ANCESTORS of one matched market bet.
   *
   * Clients are intentionally excluded: getLiability computes a client's market
   * liability live from `vewuserpnldetails`, so the client needs no ledger. Only
   * upper panels (for whom getLiability returns ~0) are maintained here.
   *
   * Per-selection client value mirrors `vewuserpnldetails`:
   *   - on the backed/laid selection : isBack ? -P_L : P_L
   *   - on every other selection     : isBack ?  Stack : -Stack
   * Each ancestor is the book, so its value is `-(clientValue) * share/100`
   * (the `-1 * share` weighting from `_get_odds_profit_loss`).
   *
   * @param sign +1 when placing a bet, -1 when deleting/voiding it.
   */
  public marketBetAncestorDeltas(params: {
    matchId: number
    marketId: string
    betSelectionId: number
    stake: number
    pl: number
    isBack: number
    selections: number[]
    ancestors: { accountId: number; sharePct: number }[]
    sign: number
  }): ExposureDelta[] {
    const { matchId, marketId, betSelectionId, stake, pl, isBack, selections, ancestors, sign } =
      params
    const back = Number(isBack) === 1
    const deltas: ExposureDelta[] = []
    for (const sel of selections) {
      const clientValue =
        Number(sel) === Number(betSelectionId) ? (back ? -pl : pl) : back ? stake : -stake
      for (const anc of ancestors) {
        if (!anc.accountId || !anc.sharePct) continue
        const delta = sign * -clientValue * (anc.sharePct / 100)
        if (delta) {
          deltas.push({ accountId: anc.accountId, matchId, marketId, selectionId: sel, delta })
        }
      }
    }
    return deltas
  }

  /** Convenience wrapper for callers that don't already own a transaction. */
  public async inTransaction<T>(fn: (trx: TransactionClientContract) => Promise<T>): Promise<T> {
    return Database.transaction(fn)
  }
}

export default new LiabilityEngine()
