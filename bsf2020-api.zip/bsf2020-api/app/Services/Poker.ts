class PokerService {
  public liveGames = [
    {
      id: '56767',
      category: 'live',
      image:
        'https://auraimgs.imgix.net/virtual%20game%20posters%20copy-04.webp?auto=format&fit=max&w=800&q=65',
      name: 'Teenpatti one day',
    },
    {
      id: '56768',
      category: 'live',
      image:
        'https://auraimgs.imgix.net/virtual%20game%20posters%20copy-02.webp?auto=format&fit=max&w=800&q=65',
      name: 'Teenpatti T20',
    },
    {
      id: '56967',
      category: 'live',
      image:
        'https://auraimgs.imgix.net/virtual%20game%20posters%20copy-08.webp?auto=format&fit=max&w=800&q=65',
      name: '32 card casino',
    },
    {
      id: '56968',
      category: 'live',
      image:
        'https://auraimgs.imgix.net/virtual%20game%20posters%20copy-07.webp?auto=format&fit=max&w=800&q=65',
      name: 'Hi LOW',
    },
    {
      id: '67564',
      category: 'live',
      image:
        'https://auraimgs.imgix.net/virtual%20game%20posters%20copy-09.webp?auto=format&fit=max&w=800&q=65',
      name: 'Poker',
    },
    {
      id: '67565',
      category: 'live',
      image:
        'https://auraimgs.imgix.net/virtual%20game%20posters%20copy-06.webp?auto=format&fit=max&w=800&q=65',
      name: 'Six player poker',
    },
    {
      id: '87564',
      category: 'live',
      image:
        'https://auraimgs.imgix.net/virtual%20game%20posters%20copy-05.webp?auto=format&fit=max&w=800&q=65',
      name: 'Andar Bahar',
    },
    {
      id: '92037',
      category: 'live',
      image:
        'https://auraimgs.imgix.net/virtual%20game%20posters%20copy-10.webp?auto=format&fit=max&w=800&q=65',
      name: 'Matka',
    },
    {
      id: '98789',
      category: 'live',
      image:
        'https://auraimgs.imgix.net/virtual%20game%20posters%20copy-11.webp?auto=format&fit=max&w=800&q=65',
      name: '7 up & down',
    },
    {
      id: '98790',
      category: 'live',
      image:
        'https://auraimgs.imgix.net/virtual%20game%20posters%20copy-19.webp?auto=format&fit=max&w=800&q=65',
      name: 'Dragon Tiger',
    },
    {
      id: '98791',
      category: 'live',
      image:
        'https://auraimgs.imgix.net/virtual%20game%20posters%20copy-01.webp?auto=format&fit=max&w=800&q=65',
      name: 'Amar Akbar Anthony',
    },
    {
      id: '90100',
      category: 'live',
      image:
        'https://auraimgs.imgix.net/virtual%20game%20posters%20copy-14.webp?auto=format&fit=max&w=800&q=65',
      name: 'Race 20-20',
    },
    {
      id: '67570',
      category: 'live',
      image:
        'https://auraimgs.imgix.net/virtual%20game%20posters%20copy-12.webp?auto=format&fit=max&w=800&q=65',
      name: 'Bollywood Casino',
    },
    {
      id: '98788',
      category: 'live',
      image:
        'https://auraimgs.imgix.net/virtual%20game%20posters%20copy-03.webp?auto=format&fit=max&w=800&q=65',
      name: 'Roulette',
    },
    {
      id: '98566',
      category: 'live',
      image: 'https://auraimgs.imgix.net/24-26.webp?auto=format&fit=max&w=800&q=65',
      name: 'Sicbo',
    },
    {
      id: '67600',
      category: 'live',
      image:
        'https://auraimgs.imgix.net/virtual%20game%20posters%20copy-17.webp?auto=format&fit=max&w=800&q=65',
      name: 'Muflis Teenpatti',
    },
    {
      id: '67610',
      category: 'live',
      image:
        'https://auraimgs.imgix.net/virtual%20game%20posters%20copy-20.webp?auto=format&fit=max&w=800&q=65',
      name: 'Trio',
    },
    {
      id: '92038',
      category: 'live',
      image:
        'https://auraimgs.imgix.net/virtual%20game%20posters%20copy-13.webp?auto=format&fit=max&w=800&q=65',
      name: 'Baccarat',
    },
    {
      id: '67575',
      category: 'live',
      image:
        'https://auraimgs.imgix.net/virtual%20game%20posters%20copy-16.webp?auto=format&fit=max&w=800&q=65',
      name: 'Casino Meter',
    },
    {
      id: '67567',
      category: 'live',
      image:
        'https://auraimgs.imgix.net/virtual%20game%20posters%20copy-15.webp?auto=format&fit=max&w=800&q=65',
      name: 'Poker 20-20',
    },
    {
      id: '67660',
      category: 'live',
      image: 'https://auraimgs.imgix.net/33-33.webp?auto=format&fit=max&w=800&q=65',
      name: '2 Card Teenpatti',
    },
    {
      id: '67620',
      category: 'live',
      image:
        'https://auraimgs.imgix.net/virtual%20game%20posters%20copy-21.webp?auto=format&fit=max&w=800&q=65',
      name: 'Queen Race',
    },
    {
      id: '67630',
      category: 'live',
      image:
        'https://auraimgs.imgix.net/virtual%20game%20posters%20copy-22.webp?auto=format&fit=max&w=800&q=65',
      name: 'Teenpatti Test',
    },
    {
      id: '67680',
      category: 'live',
      image: 'https://auraimgs.imgix.net/24-30.webp?auto=format&fit=max&w=800&q=65',
      name: 'Trap',
    },
    {
      id: '67640',
      category: 'live',
      image:
        'https://auraimgs.imgix.net/virtual%20game%20posters%20copy-23.webp?auto=format&fit=max&w=800&q=65',
      name: 'Teenpatti Open',
    },
    {
      id: '67580',
      category: 'live',
      image:
        'https://auraimgs.imgix.net/virtual%20game%20posters%20copy-18.webp?auto=format&fit=max&w=800&q=65',
      name: 'Casino War',
    },
    {
      id: '67690',
      category: 'live',
      image: 'https://auraimgs.imgix.net/24-31.webp?auto=format&fit=max&w=800&q=65',
      name: '29 Card Baccarat',
    },
    {
      id: '67710',
      category: 'live',
      image: 'https://auraimgs.imgix.net/24-29.webp?auto=format&fit=max&w=800&q=65',
      name: 'Race to 17',
    },
    {
      id: '67720',
      category: 'live',
      image: 'https://auraimgs.imgix.net/24-27.webp?auto=format&fit=max&w=800&q=65',
      name: 'Super Over',
    },
    {
      id: '98567',
      category: 'live',
      image: 'https://auraimgs.imgix.net/o-17.png?auto=format&fit=max&w=800&q=65',
      name: 'Dream Catcher',
    },
    {
      id: '67670',
      category: 'live',
      image: 'https://auraimgs.imgix.net/24-28.webp?auto=format&fit=max&w=800&q=65',
      name: '3 Card Judgement',
    },
    {
      id: '80001',
      category: 'live',
      image: '',
      name: 'Teenpatti T20 Fast',
    },
    {
      id: '80002',
      category: 'live',
      image: '',
      name: '7 Up Down Fast',
    },
    {
      id: '80003',
      category: 'live',
      image: '',
      name: '2 card Teenpatti Fast',
    },
    {
      id: '80004',
      category: 'live',
      image: '',
      name: 'Dragon Tiger Fast',
    },
    {
      id: '67722',
      category: 'live',
      image: '',
      name: 'Blastoff',
    },
    {
      id: '67722',
      category: 'live',
      image: '',
      name: 'Aviator',
    },
    {
      id: '70001',
      category: 'live',
      image: '',
      name: 'Spin Wheel',
    },
    {
      id: '70003',
      category: 'live',
      image: '',
      name: 'Coin Toss',
    },
    {
      id: '70004',
      category: 'live',
      image: '',
      name: 'Limbo',
    },
    {
      id: '70005',
      category: 'live',
      image: '',
      name: 'Slot Game',
    },
    {
      id: '70006',
      category: 'live',
      image: '',
      name: 'Rock Paper Scissors',
    },
    {
      id: '70007',
      category: 'live',
      image: '',
      name: 'Double',
    },
    {
      id: '70008',
      category: 'live',
      image: '',
      name: 'Cricket',
    },
    {
      id: '70009',
      category: 'live',
      image: '',
      name: 'Classic Dice',
    },
    {
      id: '70010',
      category: 'live',
      image: '',
      name: 'Crash',
    },
    {
      id: '70011',
      category: 'live',
      image: '',
      name: 'Mines',
    },
    {
      id: '70013',
      category: 'live',
      image: '',
      name: 'Tower Legends',
    },
  ]

  public virtualGames = [
    {
      category: 'virtual',
      name: 'Amar Akbar Anthony (virtual)',
      id: 98795,
      image: 'https://d.fawk.app/assets/images/Games/Amar%20Akbar%20Anthony%20(Virtual).png',
    },
    {
      category: 'virtual',
      name: 'Teenpatti T20 (virtual)',
      id: 56769,
      image: 'https://d.fawk.app/assets/images/Games/Teenpatti%20T20%20(Virtual).png',
    },
    {
      category: 'virtual',
      name: '7 up & down (virtual)',
      id: 98793,
      image: 'https://d.fawk.app/assets/images/Games/7%20up%20&%20Down%20(Virtual).png',
    },
    {
      category: 'virtual',
      name: 'Dragon Tiger (virtual)',
      id: 98794,
      image: 'https://d.fawk.app/assets/images/Games/Dragon%20Tiger%20(Virtual).png',
    },
    {
      category: 'virtual',
      name: 'Teenpatti one day (virtual)',
      id: 56766,
      image: 'https://d.fawk.app/assets/images/Games/Teenpatti%20One-Day%20(Virtual).png',
    },
    {
      category: 'virtual',
      name: 'Andar Bahar (virtual)',
      id: 87565,
      image: 'https://d.fawk.app/assets/images/Games/Andar%20Bahar%20(Virtual).png',
    },
    {
      category: 'virtual',
      name: 'Six player poker (virtual)',
      id: 67566,
      image: 'https://d.fawk.app/assets/images/Games/Six%20player%20poker%20(Virtual).png',
    },
    {
      category: 'virtual',
      name: 'Hi Low (virtual)',
      id: 56969,
      image: 'https://d.fawk.app/assets/images/Games/Hi%20Low%20(Virtual).png',
    },
    {
      category: 'virtual',
      name: '32 card casino (virtual)',
      id: 56966,
      image: 'https://d.fawk.app/assets/images/Games/32%20cards%20casino%20(Virtual).png',
    },
    {
      category: 'virtual',
      name: 'Poker (virtual)',
      id: 67563,
      image: 'https://d.fawk.app/assets/images/Games/Poker%20%20(Virtual).png',
    },
    {
      category: 'virtual',
      name: 'Matka (virtual)',
      id: 92036,
      image: 'https://d.fawk.app/assets/images/Games/Matka%20(Virtual).png',
    },
    {
      category: 'virtual',
      name: 'Roulette (virtual)',
      id: 98792,
      image: 'https://d.fawk.app/assets/images/Games/Roulette%20(Virtual).png',
    },
    {
      category: 'virtual',
      name: 'Bollywood Casino (virtual)',
      id: 67571,
      image: 'https://d.fawk.app/assets/images/Games/Bollywood%20Casino%20(Virtual).png',
    },
    {
      category: 'virtual',
      name: 'Casino War (virtual)',
      id: 67581,
      image: 'https://d.fawk.app/assets/images/Games/Casino%20War%20(Virtual).png',
    },
    {
      category: 'virtual',
      name: 'Baccarat (virtual)',
      id: 92039,
      image: 'https://d.fawk.app/assets/images/Games/Baccarat%20(Virtual).png',
    },
    {
      category: 'virtual',
      name: 'Race 20-20 (virtual)',
      id: 90101,
      image: 'https://d.fawk.app/assets/images/Games/Race%2020-20%20(Virtual).png',
    },
    {
      category: 'virtual',
      name: 'Poker 20-20 (virtual)',
      id: 67568,
      image: 'https://d.fawk.app/assets/images/Games/Poker%2020-20%20(Virtual).png',
    },
    {
      category: 'virtual',
      name: 'Casino Meter (virtual)',
      id: 67576,
      image: 'https://d.fawk.app/assets/images/Games/Casino%20Meter%20(Virtual).png',
    },
    {
      category: 'virtual',
      name: 'Muflis Teenpatti (virtual)',
      id: 67601,
      image: 'https://d.fawk.app/assets/images/Games/Muflis%20Teenpatti%20(virtual).png',
    },
    {
      category: 'virtual',
      name: 'Trio (virtual)',
      id: 67611,
      image: 'https://d.fawk.app/assets/images/Games/Trio%20(virtual).png',
    },
    {
      category: 'virtual',
      name: 'Queen Race (virtual)',
      id: 67621,
      image: 'https://d.fawk.app/assets/images/Games/Queen%20(virtual).png',
    },
    {
      category: 'virtual',
      name: 'Teenpatti Test (virtual)',
      id: 67631,
      image: 'https://d.fawk.app/assets/images/Games/Teenpatti%20Test%20(virtual).png',
    },
    {
      category: 'virtual',
      name: 'Teenpatti Open (virtual)',
      id: 67641,
      image: 'https://d.fawk.app/assets/images/Games/Teenpatti%20Open%20(virtual).png',
    },
  ]
}

export default new PokerService()
