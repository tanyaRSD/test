import Cache from '@ioc:Adonis/Addons/Cache'
import Redis from '@ioc:Adonis/Addons/Redis'
import { HttpContextContract } from '@ioc:Adonis/Core/HttpContext'

/**
 * Silent auth middleware can be used as a global middleware to silent check
 * if the user is logged-in or not.
 *
 * The request continues as usual, even when the user is not logged-in.
 */
export default class Auth2 {
  /**
   * Handle request
   */
  public async handle(ctx: HttpContextContract, next: () => Promise<void>) {
    /**
     * Check if user is logged-in or not. If yes, then `ctx.auth.user` will be
     * set to the instance of the currently logged in user.
     */
    const { request, response } = ctx

    const token = request.header('authorization')?.substr(7)

    if (token) {
      const user = await Cache.get(token)
      if (user) {
        ctx.authUser = user
        await Redis.expire(token, 3600)
        // @ts-ignore

        await next()
      }
    } else {
      response.unauthorized({ error: 'Must be logged in' })
      return
    }
  }
}
