import Cache from '@ioc:Adonis/Addons/Cache'
import { HttpContextContract } from '@ioc:Adonis/Core/HttpContext'

export default class DomainCheck {
  public async handle({ request, response }: HttpContextContract, next: () => Promise<void>) {
    // code for middleware goes here. ABOVE THE NEXT CALL
    const token = request.header('authorization')?.substr(7)
    if (token) {
      const data = await Cache.get(token)
      if (data) {
        if (data.domain !== request.header('origin')) {
          return response.json({
            status: false,
            message: "You don't have permission",
          })
        }
        // @ts-ignore
        await next()
      } else {
        response.unauthorized({ error: 'Must be logged in.' })
        return
      }
    } else {
      response.unauthorized({ error: 'Must be logged in' })
      return
    }
  }
}
