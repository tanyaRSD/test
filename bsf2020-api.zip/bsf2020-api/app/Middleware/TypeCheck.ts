import type { HttpContextContract } from '@ioc:Adonis/Core/HttpContext'

export default class TypeCheck {
  public async handle(
    { response, authUser }: HttpContextContract,
    next: () => Promise<void>,
    guards?: string[]
  ) {
    // code for middleware goes here. ABOVE THE NEXT CALL

    if (guards?.[0] == 'admin' && authUser.usetype == 3) {
      return response.unauthorized({ error: 'Must be logged in.' })
    } else if (guards?.[0] == 'user' && authUser.usetype != 3) {
      return response.unauthorized({ error: 'Must be logged in.' })
    } else {
      await next()
    }
  }
}
