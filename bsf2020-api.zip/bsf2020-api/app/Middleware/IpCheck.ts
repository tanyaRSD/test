import type { HttpContextContract } from '@ioc:Adonis/Core/HttpContext'
import Env from '@ioc:Adonis/Core/Env'

export default class IpCheck {
  public async handle({ request, response }: HttpContextContract, next: () => Promise<void>) {
    if (Env.get('NODE_ENV') !== 'development' && request.ip() == '127.0.0.1') {
      return response.unauthorized({ error: 'You are not authorized.' })
    } else {
      await next()
    }
  }
}
