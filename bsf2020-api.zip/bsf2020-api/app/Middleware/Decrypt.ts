import { HttpContextContract } from '@ioc:Adonis/Core/HttpContext'
import * as CryptoJS from 'crypto-js'

export default class Decrypt {
  public async handle({ request }: HttpContextContract, next: () => Promise<void>) {
    const decrypted = CryptoJS.AES.decrypt(request.input('inputstring'), 'u/Gu5posvwDsXUnV5Zaq4g==')
    const data = decrypted.toString(CryptoJS.enc.Utf8)
    request.updateBody(JSON.parse(data))
    await next()
  }
}
