import Cache from '@ioc:Adonis/Addons/Cache'
import Redis from '@ioc:Adonis/Addons/Redis'
import { HttpContextContract } from '@ioc:Adonis/Core/HttpContext'
import Auto from 'App/Services/Auto'
import UserService from 'App/Services/UserService'
import { DateTime } from 'luxon'

/**
 * Silent auth middleware can be used as a global middleware to silent check
 * if the user is logged-in or not.
 *
 * The request continues as usual, even when the user is not logged-in.
 */
export default class Auth {
  /**
   * Handle request
   */
  public async handle(ctx: HttpContextContract, next: () => Promise<void>, guards?: string[]) {
    /**
     * Check if user is logged-in or not. If yes, then `ctx.auth.user` will be
     * set to the instance of the currently logged in user.
     */
    const { request, response } = ctx
    const code = Auto.code

    const autoCode = request.header('X-code')
    const token = request.header('authorization')?.substr(7)

    if (autoCode) {
      if (autoCode == code) {
        ctx.authUser = { usetype: 0, mstrid: 1, parentIds: [1] }
        await next()
        return
      }
      return response.unauthorized({ error: 'Must be logged in.' })
    }

    if (token) {
      const user = await Cache.get(token)
      if (user) {
        if (!user.parentIds) {
          const parentData: any = await UserService.parents(user.mstrid)
          user.parentIds = parentData.map((i: any) => i.mstrid)
        }

        ctx.authUser = user
        await Redis.expire(token, 3600)
        // @ts-ignore

        // patch date fields
        let body = request.body()
        if (typeof body === 'object') {
          for (const f of ['from_date', 'fromDate', 'to_date', 'toDate']) {
            if (body.hasOwnProperty(f)) {
              if (body[f]) body[f] = DateTime.fromJSDate(new Date(body[f])).toFormat('yyyy-MM-dd')
            }
          }

          request.updateBody(body)
        }

        let qs = request.qs()
        if (typeof qs === 'object') {
          for (const f of ['from_date', 'fromDate', 'to_date', 'toDate']) {
            if (qs.hasOwnProperty(f)) {
              if (qs[f]) qs[f] = DateTime.fromJSDate(new Date(qs[f])).toFormat('yyyy-MM-dd')
            }
          }

          request.updateQs(qs)
        }

        await next()
      } else {
        if (guards?.includes('public')) {
          await next()
          return
        }
        return response.unauthorized({ error: 'Must be logged in.' })
      }
    } else {
      if (guards?.includes('public')) {
        await next()
        return
      }
      response.unauthorized({ error: 'Must be logged in' })
      return
    }
  }
}
