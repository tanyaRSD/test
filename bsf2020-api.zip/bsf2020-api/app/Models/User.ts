import { BaseModel, column } from '@ioc:Adonis/Lucid/Orm'

export default class User extends BaseModel {
  public static table = 'createmaster'

  @column({ isPrimary: true })
  public mstrid: number

  @column()
  public mstrname: string

  @column()
  public mstruserid: string

  @column()
  public phone: string

  @column()
  public mstrremarks: string

  @column()
  public usetype: number

  @column({ serializeAs: null })
  public mstrpassword: string

  @column({ serializeAs: null })
  public password?: string
}
