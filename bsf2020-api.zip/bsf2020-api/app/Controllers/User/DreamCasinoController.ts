import Cache from '@ioc:Adonis/Addons/Cache'
import Redis from '@ioc:Adonis/Addons/Redis'
import Application from '@ioc:Adonis/Core/Application'
import Env from '@ioc:Adonis/Core/Env'
import { HttpContextContract } from '@ioc:Adonis/Core/HttpContext'
import Logger from '@ioc:Adonis/Core/Logger'
import { RequestContract } from '@ioc:Adonis/Core/Request'
import { schema } from '@ioc:Adonis/Core/Validator'
import Database from '@ioc:Adonis/Lucid/Database'
import { Mongo } from 'App/Services/Mongo'
import Signature from 'App/Services/Signature'
import Sp from 'App/Services/Sp'
import UserService from 'App/Services/UserService'
import axios from 'axios'

const sportId = '1235'
const partnerId = Env.get('DREAM_PARTNER_ID')
const currency = Env.get('DREAM_CURRENCY')
const betKey = 'dream_bet'
const resultKey = 'dream_result'
const rollbackKey = 'dream_rollback'
export default class DreamCasinoController {
  public async gameList({ response, authUser }: HttpContextContract) {
    try {
      const sport = await Database.from('blocked_sports')
        .select('sport_id')
        .where('sport_id', sportId)
        .whereIn('user_id', authUser.parentIds)
        .first()

      if (sport) {
        return response.json({
          status: false,
          message: 'Casino is blocked.',
        })
      }

      const data = await Signature.loadGames()

      return response.json({
        data: data,
      })
    } catch (err) {
      console.log('📢: err: ', err)
      return response.badRequest({
        message: err,
        data: [],
      })
    }
  }

  public async gameUrl({ request, response, authUser }: HttpContextContract) {
    const sport = await Database.from('blocked_sports')
      .select('sport_id')
      .where('sport_id', sportId)
      .whereIn('user_id', authUser.parentIds)
      .first()

    if (sport) {
      return response.json({
        status: false,
        message: 'Casino is blocked.',
      })
    }

    const requestData = await request.validate({
      schema: schema.create({
        desktop: schema.boolean(),
        lobby_url: schema.string(),
        game_code: schema.string(),
      }),
    })

    const data = {
      partner_id: partnerId,
      user: authUser.mstrid.toString(),
      token: authUser.TokenId,
      platform: requestData.desktop ? 'GPL_DESKTOP' : 'GPL_MOBILE',
      lobby_url: requestData.lobby_url,
      lang: 'en',
      ip: request.ip(),
      game_code: requestData.game_code,
      country: 'IN',
    }

    const signature = await Signature.sign(data)

    try {
      let base = 'https://dev-api.dreamdelhi.com'
      if (Application.inProduction) {
        base = 'https://api.dreamdelhi.com'
      }
      const res = await axios.post(base + '/games/url', data, {
        headers: {
          'casino-signature': signature.toString('base64'),
          'content-type': 'application/json',
        },
      })
      return response.json({
        data: res.data,
      })
    } catch (err) {
      console.log('📢: err: ', err)
      return response.badRequest({
        message: err.response.status,
      })
    }
  }

  public async balance({ request, response }: HttpContextContract) {
    const isVerified = await this.verifySignature(request)

    if (!isVerified) {
      return response.json({
        balance: 0,
        currency: currency,
        request_uuid: request.input('request_uuid'),
        status: 'RS_ERROR_INVALID_SIGNATURE',
      })
    }

    const data = await request.validate({
      schema: schema.create({
        user: schema.string(),
        token: schema.string(),
        request_uuid: schema.string(),
      }),
    })

    let token: any = data.token

    let user = await Cache.get(token)

    if (user) {
      await Redis.expire(token, 3600)

      const res = {
        balance: parseInt(user.balance) * 100000,
        currency: currency,
        request_uuid: data.request_uuid,
        status: 'RS_OK',
        user: user.mstrid.toString(),
      }

      console.log('📢BALANCE RESPONSE ', res)

      return response.json(res)
    }

    user = await Database.from('createmaster').where('mstrid', data.user).first()

    const res = {
      balance: parseInt(user.balance) ?? 0,
      currency: currency,
      request_uuid: data.request_uuid,
      status: 'RS_ERROR_TOKEN_EXPIRED',
      User: data.user.toString(),
    }

    console.log('📢BALANCE RESPONSE ', res)

    return response.json(res)
  }

  public async bet({ request, response }: HttpContextContract) {
    const isVerified = await this.verifySignature(request)

    if (!isVerified) {
      return response.json({
        balance: 0,
        currency: currency,
        request_uuid: request.input('request_uuid'),
        status: 'RS_ERROR_INVALID_SIGNATURE',
      })
    }

    console.log('=============BET START=================')
    console.log('📢BET', request.all())
    console.log('=============BET END===========')

    try {
      const data: any = await request.validate({
        schema: schema.create({
          user: schema.string(),
          transaction_uuid: schema.string(),
          token: schema.string(),
          round_closed: schema.boolean.nullable(),
          round: schema.string(),
          request_uuid: schema.string(),
          game_id: schema.number.optional(),
          game_code: schema.string.optional(),
          currency: schema.string(),
          amount: schema.number(),
        }),
      })

      let isGameExists = data.game_code && data.game_id
      if (isGameExists) {
        const list = await Signature.loadGames()
        const game = list.find((el: any) => el.game_id == data.game_id)
        if (!game) {
          isGameExists = false
        }
      } else {
        if ((data.game_code || data.game_id) && !isGameExists) {
          const list = await Signature.loadGames()
          if (!data.game_code && data.game_id) {
            const game = list.find((el: any) => el.game_id == data.game_id)
            if (game) {
              isGameExists = true
              data.game_code = game.game_code
            } else {
              isGameExists = false
            }
          } else if (data.game_code && !data.game_id) {
            const game = list.find((el: any) => el.game_code == data.game_code)
            if (game) {
              isGameExists = true
              data.game_id = game.game_id
            } else {
              isGameExists = false
            }
          } else {
            isGameExists = false
          }
        }
      }

      if (!isGameExists) {
        const res = {
          balance: 0,
          currency: currency,
          request_uuid: request.input('request_uuid'),
          status: 'RS_ERROR_WRONG_SYNTAX',
        }
        console.log('📢BET RESPONSE ', res)
        return response.json(res)
      }

      data.amount = data.amount / 100000

      const selectionId = this.grabNumber(data.round)

      let token: any = data.token
      const user = await Cache.get(token)

      if (user) {
        await Redis.expire(token, 3600)

        if (data.amount <= 0) {
          const res = {
            balance: parseInt(user.balance) * 100000,
            currency: currency,
            request_uuid: data.request_uuid,
            status: data.amount == 0 ? 'RS_OK' : 'RS_ERROR_WRONG_TYPES',
            user: user.mstrid.toString(),
          }
          console.log('📢BET RESPONSE ', res)
          return response.json(res)
        }

        // check for duplicate request
        if (await Redis.sismember(betKey, data.transaction_uuid)) {
          const bet = await Database.from('tblbets')
            .where('MarketId', data.round)
            .where('transaction_uuid', data.transaction_uuid)
            .where('Stack', data.amount)
            .first()

          const res = {
            balance: parseInt(user.balance) * 100000,
            currency: currency,
            request_uuid: data.request_uuid,
            status: bet ? 'RS_OK' : 'RS_ERROR_DUPLICATE_TRANSACTION',
            user: data.user.toString(),
          }

          console.log('📢BET RESPONSE ', res)

          return response.json(res)
        }

        // check user have sufficient balance or not
        if (user.balance >= data.amount) {
          await Redis.sadd(betKey, data.transaction_uuid)

          await this.match(data)
          await this.market(data, selectionId)

          let exposure = data.amount

          const parentData: any = await UserService.parents(user.mstrid)

          const defaultValue = { mstrid: 0, mstruserid: '' }

          let { mstrid: superDuperAdminId, mstruserid: superDuperAdminName } =
            parentData.find((el: any) => el.usetype == 0) ?? defaultValue

          let { mstrid: companyId, mstruserid: companyName } =
            parentData.find((el: any) => el.usetype == 11) ?? defaultValue

          let { mstrid: superAdminId, mstruserid: superAdminName } =
            parentData.find((el: any) => el.usetype == 10) ?? defaultValue

          let { mstrid: subAdminId, mstruserid: subAdminName } =
            parentData.find((el: any) => el.usetype == 9) ?? defaultValue

          let { mstrid: superMasterId, mstruserid: superMasterName } =
            parentData.find((el: any) => el.usetype == 8) ?? defaultValue

          let { mstrid: masterId, mstruserid: masterName } =
            parentData.find((el: any) => el.usetype == 1) ?? defaultValue

          let { mstrid: dealerId, mstruserid: dealerName } =
            parentData.find((el: any) => el.usetype == 2) ?? defaultValue

          let { mstruserid: userName } = parentData.find((el: any) => el.usetype == 3) ?? {
            mstruserid: '',
          }

          let userId = user?.mstrid

          const partnershipData: any = await Cache.rememberForever(
            'partnership:' + userId,
            async () => {
              return await Database.from('tblpartner').where('UserID', userId).firstOrFail()
            }
          )

          const superDuperAdminPartnership = partnershipData['super_duper_admin_casino']
          const companyPartnership = partnershipData['company_casino']
          const superAdminPartnership = partnershipData['super_admin_casino']
          const subAdminPartnership = partnershipData['sub_admin_casino']
          const superMasterPartnership = partnershipData['super_master_casino']
          const masterPartnership = partnershipData['master_casino']
          const dealerPartnership = partnershipData['dealer_casino']

          // call sp teen place bet
          let betPlaceVal = await Sp.call(
            '_bet_place_dream(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,1,"auto",?)',
            [
              userId,
              userId,
              user?.parentId,
              dealerId,
              masterId,
              superMasterId,
              subAdminId,
              superAdminId,
              companyId,
              superDuperAdminId,
              userName,
              dealerName,
              masterName,
              superMasterName,
              subAdminName,
              superAdminName,
              companyName,
              superDuperAdminName,
              superDuperAdminPartnership,
              companyPartnership,
              superAdminPartnership,
              subAdminPartnership,
              superMasterPartnership,
              masterPartnership,
              dealerPartnership,
              data.game_id,
              selectionId,
              exposure,
              data.round,
              selectionId.toString(), // runner name
              new Date(),
              1,
              exposure,
              0, // isback
              1,
              'Chip Deducted From Betting >> ',
              'chrome',
              request.ip(),
              1,
              data.transaction_uuid,
            ]
          )

          if (betPlaceVal[0].resultV == 0) {
            const mongoData = {
              type: `BET PLACE for ${data.betInfo.reqStake}`,
              category: 'DREAM CASINO',
              userId: user.mstrid,
              username: user.mstruserid,
              betId: betPlaceVal[0].LID,
              beforeBalance: user.balance,
              beforeLiability: user.liability,
              matchName: data.matchName,
              selectionName: data.betInfo.runnerName,
              marketId: data.betInfo.marketId,
            }

            const rows: any = await this.updateLiability(user?.mstrid, mongoData, 'add')
            const d = rows[0]

            const pokerLiability: any = await UserService.getPokerLiability(user?.mstrid)
            const kingLiability: any = await UserService.getKingLiability(user?.mstrid)
            const balance: any = parseFloat(d.Balance) - pokerLiability - kingLiability
            if (balance < 0) {
              await Database.from('tblbets').where('MstCode', betPlaceVal[0].LID).delete()
              await Redis.srem(betKey, data.transaction_uuid)
              await this.updateLiability([{ id: user?.mstrid }])

              const res = {
                balance: parseInt(user.balance) * 100000,
                currency: currency,
                errorCode: 3,
                request_uuid: data.request_uuid,
                round: data.round,
                status: 'RS_ERROR_NOT_ENOUGH_MONEY',
                token: token,
                transactionId: data.transaction_uuid,
                user: user.mstrid.toString(),
              }

              console.log('📢BET RESPONSE ', res)

              return response.json(res)
            }

            const res = {
              balance: parseInt(balance) * 100000,
              currency: currency,
              request_uuid: data.request_uuid,
              status: 'RS_OK',
              user: user.mstrid.toString(),
            }

            return response.json(res)
          } else {
            await Database.from('tblbets').where('MstCode', betPlaceVal[0].LID).delete()

            await Redis.srem(betKey, data.transaction_uuid)

            const res = {
              balance: parseInt(user.balance) * 100000,
              currency: currency,
              request_uuid: data.request_uuid,
              status: 'RS_ERROR_UNKNOWN',
              user: data.user.toString(),
            }

            console.log('📢BET RESPONSE ', res)

            return response.json(res)
          }
        } else {
          const res = {
            balance: parseInt(user.balance) * 100000,
            currency: currency,
            errorCode: 3,
            request_uuid: data.request_uuid,
            round: data.round,
            status: 'RS_ERROR_NOT_ENOUGH_MONEY',
            token: token,
            transactionId: data.transaction_uuid,
            user: user.mstrid.toString(),
          }

          console.log('📢BET RESPONSE ', res)

          return response.json(res)
        }
      } else {
        const res = {
          balance: 0,
          currency: currency,
          request_uuid: data.request_uuid,
          status: 'RS_ERROR_TOKEN_EXPIRED',
          user: data.user.toString(),
        }

        console.log('📢BET RESPONSE ', res)

        return response.json(res)
      }
    } catch (e) {
      Logger.error('DREAM BET PLACE %o', e)

      return response.json({
        balance: 0,
        currency: currency,
        request_uuid: request.input('request_uuid'),
        status: 'RS_ERROR_WRONG_SYNTAX',
      })
    }
  }

  public async result({ request, response }: HttpContextContract) {
    const isVerified = await this.verifySignature(request)

    if (!isVerified) {
      return response.json({
        balance: 0,
        currency: currency,
        request_uuid: request.input('request_uuid'),
        status: 'RS_ERROR_INVALID_SIGNATURE',
      })
    }
    console.log('=============RESULT START=================')
    console.log('📢RESULT 1', request.all())
    console.log('=============RESULT END===========')
    try {
      const data = await request.validate({
        schema: schema.create({
          user: schema.string(),
          transaction_uuid: schema.string(),
          round_closed: schema.boolean.nullable(),
          round: schema.string(),
          request_uuid: schema.string(),
          game_id: schema.number.optional(),
          game_code: schema.string.optional(),
          currency: schema.string(),
          amount: schema.number(),
          reference_transaction_uuid: schema.string(),
          token: schema.string.optional(),
        }),
      })

      let isGameExists = data.game_code && data.game_id

      if ((data.game_code || data.game_id) && !isGameExists) {
        const list = await Signature.loadGames()
        if (!data.game_code && data.game_id) {
          const game = list.find((el: any) => el.game_id == data.game_id)
          if (game) {
            data.game_code = game.game_code
          }
        } else if (data.game_code && !data.game_id) {
          const game = list.find((el: any) => el.game_code == data.game_code)
          if (game) {
            data.game_id = game.game_id
          }
        }
      }
      const originalAmount = data.amount
      data.amount = data.amount / 100000

      const selectionId = this.grabNumber(data.round)
      const winner = { id: selectionId, name: selectionId.toString() }

      let token: any = data.token
      let user: any = await Cache.get(token)

      if (user) {
        await Redis.expire(token, 3600)
      } else {
        user = await Database.from('createmaster').where('mstrid', data.user).first()
      }

      if (!(await Redis.sismember(betKey, data.reference_transaction_uuid))) {
        const res = {
          balance: parseInt(user.balance) * 100000,
          currency: currency,
          request_uuid: data.request_uuid,
          status: 'RS_ERROR_TRANSACTION_DOES_NOT_EXIST',
          user: data.user.toString(),
        }

        console.log('📢RESULT RESPONSE 2', res)

        return response.json(res)
      }

      const results = await Redis.smembers(resultKey + ':' + data.transaction_uuid)
      await Redis.sadd(resultKey + ':' + data.transaction_uuid, JSON.stringify(request.body()))
      let count = 0
      for (const r of results) {
        const result = JSON.parse(r)
        if (
          result.round == data.round &&
          result.amount == originalAmount &&
          result.transaction_uuid == data.transaction_uuid
        ) {
          count++
          break
        }
      }

      if (results.length > 0) {
        const res = {
          balance: parseInt(user.balance) * 100000,
          currency: currency,
          request_uuid: data.request_uuid,
          status: count > 0 ? 'RS_OK' : 'RS_ERROR_DUPLICATE_TRANSACTION',
          user: data.user.toString(),
        }

        console.log('📢RESULT RESPONSE 3', res)

        return response.json(res)
      }

      const lockKey = `lock:${data.round}`

      const isLocked = await Redis.rpush(lockKey, data.transaction_uuid)
      if (isLocked > 1) {
        // If the transaction is already being processed, wait for it to complete
        await new Promise((resolve) => {
          const intervalId = setInterval(async () => {
            const checkLock = await Redis.lindex(lockKey, 0)
            // @ts-ignore
            if (checkLock == data.transaction_uuid) {
              clearInterval(intervalId)
              resolve(true)
            }
          }, 200)
        })
      }

      const marketId = data.round

      const result = await Database.from('tblresult').where('marketId', marketId).first()

      if (result) {
        const trx = await Database.transaction()
        try {
          await trx.rawQuery(
            'UPDATE tblbets SET Chips = Chips + Stack WHERE transaction_uuid = :transactionUuid AND Result = 1',
            {
              ResultID: result.resId,
              transactionUuid: data.reference_transaction_uuid,
            }
          )

          await trx.from('market').where({ Id: marketId }).update({ active: 1 })
          await trx.from('tblchipdet').where('ResultID', result.resId).delete()
          await trx.from('tblresult').where('resid', result.resId).delete()

          await trx.commit()
        } catch (e) {
          await Redis.lpop(lockKey)
          Logger.error('DREAM RESULT %o', e)
          await trx.rollback()

          const res = {
            balance: parseInt(user.balance) * 100000,
            currency: currency,
            request_uuid: data.request_uuid,
            status: 'RS_ERROR_UNKNOWN',
            user: user.mstrid.toString(),
          }

          console.log('==========================================')
          console.log(e)
          console.log('==========================================')
          console.log('📢RESULT RESPONSE 4', res)

          return response.json(res)
        }
      } else {
        await Database.rawQuery(
          'UPDATE tblbets SET Chips = Chips - Stack WHERE MarketId = :marketId AND UserId = :userId',
          {
            marketId: marketId,
            userId: user.mstrid,
          }
        )
      }

      await Redis.sadd(resultKey, data.transaction_uuid)

      const resVal = await Sp.call(
        '_result_dream(:sportId,:matchId,:marketId,:selectionId,:fancyId,:resultId,:sportNM,:matchNM, :marketNM, :selectionNM,:pl,:referenceTransactionUuid)',
        {
          sportId: sportId,
          matchId: data.game_id,
          marketId: marketId,
          selectionId: winner.id,
          fancyId: 0,
          resultId: '1',
          sportNM: 'Dream Casino',
          matchNM: data.game_code,
          marketNM: data.game_code,
          selectionNM: winner.name,
          pl: data.amount,
          referenceTransactionUuid: data.reference_transaction_uuid,
        }
      )

      console.log('📢RESULT ', resVal)

      if (resVal[0].resultV == 0) {
        await Redis.lpop(lockKey)

        const mongoData = {
          type: 'RESULT',
          category: 'DREAM CASINO',
          userId: user.mstrid,
          username: user.mstruserid,
          betId: null,
          beforeBalance: user.balance,
          beforeLiability: user.liability,
          matchName: data.game_code,
          selectionName: winner.name,
          marketId: marketId,
        }
        const rows: any = await this.updateLiability(user?.mstrid, mongoData, 'add')

        const d = rows[0]

        const res = {
          balance: parseInt(d.Balance) * 100000,
          request_uuid: data.request_uuid,
          status: 'RS_OK',
          currency: currency,
          user: user.mstrid.toString(),
        }

        console.log('📢RESULT RESPONSE 5', res)

        return response.json(res)
      } else {
        await Redis.lpop(lockKey)
        const res = {
          balance: parseInt(user.balance) * 100000,
          currency: currency,
          request_uuid: data.request_uuid,
          status: 'RS_OK',
          user: data.user.toString(),
        }

        console.log('📢RESULT RESPONSE 6', res)

        return response.json(res)
      }
    } catch (e) {
      Logger.error('DREAM RESULT2 %o', e)
      return response.json({
        balance: 0,
        currency: currency,
        request_uuid: request.input('request_uuid'),
        status: 'RS_ERROR_WRONG_SYNTAX',
      })
    }
  }

  public async rollback({ request, response }: HttpContextContract) {
    const isVerified = await this.verifySignature(request)

    if (!isVerified) {
      return response.json({
        balance: 0,
        currency: currency,
        request_uuid: request.input('request_uuid'),
        status: 'RS_ERROR_INVALID_SIGNATURE',
      })
    }

    console.log('📢ROLLBACK 1', request.all())

    try {
      const data = await request.validate({
        schema: schema.create({
          user: schema.string(),
          transaction_uuid: schema.string(),
          round_closed: schema.boolean.nullable(),
          round: schema.string(),
          request_uuid: schema.string(),
          game_id: schema.number.optional(),
          game_code: schema.string.optional(),
          reference_transaction_uuid: schema.string(),
          token: schema.string.optional(),
        }),
      })

      let isGameExists = data.game_code && data.game_id

      if ((data.game_code || data.game_id) && !isGameExists) {
        const list = await Signature.loadGames()
        if (!data.game_code && data.game_id) {
          const game = list.find((el: any) => el.game_id == data.game_id)
          if (game) {
            data.game_code = game.game_code
          }
        } else if (data.game_code && !data.game_id) {
          const game = list.find((el: any) => el.game_code == data.game_code)
          if (game) {
            data.game_id = game.game_id
          }
        }
      }

      // const matchId: any = data.game_id

      let token: any = data.token
      let user = await Cache.get(token)

      if (user) {
        await Redis.expire(token, 3600)
      } else {
        user = await Database.from('createmaster').where('mstrid', data.user).first()
      }

      if (await Redis.sismember(rollbackKey, data.transaction_uuid)) {
        const isResult = await Redis.sismember(betKey, data.reference_transaction_uuid)

        const res = {
          balance: parseInt(user.balance) * 100000,
          currency: currency,
          request_uuid: data.request_uuid,
          status: isResult ? 'RS_ERROR_DUPLICATE_TRANSACTION' : 'RS_OK',
          user: data.user.toString(),
        }

        console.log('📢ROLLBACK RESPONSE 2', res)

        return response.json(res)
      }

      await Redis.sadd(rollbackKey, data.transaction_uuid)
      await Redis.srem(betKey, data.reference_transaction_uuid)

      await Database.from('tblbets')
        .where('transaction_uuid', data.reference_transaction_uuid)
        .delete()

      // await Sp.call('p_l_by_match(:matchId)', {
      //   matchId: matchId,
      // })

      const rows: any = await this.updateLiability(user?.mstrid)

      const d = rows[0]
      const res = {
        balance: parseInt(d.Balance) * 100000,
        currency: currency,
        request_uuid: data.request_uuid,
        status: 'RS_OK',
        user: user.mstrid.toString(),
      }
      console.log('📢ROLLBACK RESPONSE 3', res)
      return response.json(res)
    } catch (e) {
      Logger.error('DREAM ROLLBACK %o', e)
      return response.json({
        balance: 0,
        currency: currency,
        request_uuid: request.input('request_uuid'),
        status: 'RS_ERROR_WRONG_SYNTAX',
      })
    }
  }

  private async updateLiability(id: any, mongoData?: any, type?: 'add' | 'delete') {
    // await Mongo.collection('logs').insertOne({
    //   ...mongoData,
    //   logType: 'Update Liability Started',
    //   createdAt: new Date(),
    // })
    const rows: any = await UserService.getLiability(id, mongoData?.type || '', mongoData)

    if (rows.length > 0) {
      const data = rows[0]

      const pokerLiability: any = await UserService.getPokerLiability(id)
      const kingLiability: any = await UserService.getKingLiability(id)
      const balance: any = parseFloat(data.Balance) - pokerLiability - kingLiability
      const liability = parseFloat(data.Liability) - pokerLiability - kingLiability
      const profitLoss = await UserService.getProfitLoss(id)

      const finalData = {
        liability: liability,
        balance: parseInt(balance),
        p_l: data.chipspnl,
        freechips: data.FreeChip,
        chip: data.Chip,
        sessionLiability: data.sessionLiability,
        unmatchliability: data.unmatchliability,
        profit_loss: profitLoss.total,
      }
      await Database.query().from('createmaster').where('mstrid', id).update(finalData)

      let userData = {
        user_id: id,
        data: {
          type: 'balance',
          data: finalData,
        },
      }

      try {
        if (mongoData && mongoData.userId == id) {
          if (type == 'add') {
            Mongo.collection('logs').insertOne({
              ...mongoData,
              logType: 'Update Liability Ended',
              afterBalance: balance,
              afterLiability: liability,
              createdAt: new Date(),
            })
          } else {
            Mongo.collection('logs').deleteOne(mongoData)
          }
        }
      } catch (e) {
        console.error(e)
      }

      await Redis.publish('USER_UPDATE_DATA', JSON.stringify(userData))

      const keys = await Redis.keys('auth:' + id + '|*')

      for (const key of keys) {
        let user: any = await Cache.get(key)
        if (user) {
          user.liability = liability
          user.balance = balance
          user.p_l = data.chipspnl
          user.freechips = data.FreeChip
          user.chip = data.Chip
          user.profit_loss = profitLoss.total
          await Cache.put(key, user, 3600)
        }
      }
    }

    return rows
  }

  private async match(data: any) {
    const seriesId = sportId + '3'
    const runners = []
    const key = 'DREAM_MATCH'
    if (!(await Redis.sismember(key, data.game_id))) {
      const match = await Database.query().from('matchmst').where('MstCode', data.game_id).first()
      if (!match) {
        await Database.insertQuery()
          .table('matchmst')
          .insert({
            MstCode: data.game_id,
            mstDate: new Date(),
            matchName: data.game_code,
            seriesId: seriesId,
            SportID: sportId,
            marketCount: 0,
            createdOn: new Date(),
            active: 1,
            runner_json: JSON.stringify(runners),
            tvUrl: '',
            score_board_json: '',
          })

        await Redis.sadd(key, data.game_id)
      }
    }
  }

  private async market(data: any, selectionId: any) {
    const seriesId = sportId + '3'
    const key = 'DREAM_MARKET'

    if (!(await Redis.sismember(key, data.round))) {
      const market = await Database.query().from('market').where('Id', data.round).first()
      if (!market) {
        const runnersJson: any = []
        const runners: any = []

        for (const r of [
          { id: selectionId, name: selectionId.toString() },
          { id: 2, name: 'B' },
        ]) {
          const backLay: any = []

          // @ts-ignore
          for (const i of [1, 2, 3]) {
            backLay.push({ size: '--', price: '--' })
          }

          runnersJson.push({
            id: r.id,
            name: r.name,
            back: backLay,
            lay: backLay,
          })

          runners.push({
            selectionId: r.id,
            runnerName: r.name,
          })
        }

        await Database.insertQuery()
          .table('market')
          .insert({
            Id: data.round,
            Name: data.game_code,
            sportsId: sportId,
            seriesId: seriesId,
            matchId: data.game_id,
            totalMatched: 0,
            createdOn: new Date(),
            active: 1,
            market_runner_json: JSON.stringify(runnersJson),
          })

        let index = 1

        for (let runner of [
          { id: selectionId, name: selectionId.toString() },
          { id: 2, name: 'B' },
        ]) {
          await Database.insertQuery().table('tblselection').insert({
            sportId: sportId,
            matchId: data.game_id,
            selectionId: runner.id,
            selectionName: runner.name,
            marketId: data.round,
            teamType: index,
          })

          index++
        }
        await Redis.sadd(key, data.round)
      }
    }
  }

  // private convertToNumber(str: string) {
  //   str = str.toUpperCase();
  //   let len = str.length;
  //   str = str.substring(0, 4) + str.substring(len - 4);
  //   len = str.length;

  //   let out = 0;
  //   for (let pos = 0; pos < len; pos++) {
  //     out += (str.charCodeAt(pos) - 64) * Math.pow(26, len - pos - 1);
  //   }

  //   const outputLength = out.toString().length;

  //   if (outputLength > 10) {
  //     out = Math.round(out / (outputLength * 100))
  //   }

  //   return out;
  // }

  private grabNumber(str: string) {
    let out = str.replace(/\D/g, '').substring(0, 6)
    if (out.length === 0) {
      out = '123'
    }
    return out
  }

  private async verifySignature(request: RequestContract) {
    const sign = request.header('Casino-Signature')
    const isVerified = await Signature.verifyDream(request.raw(), sign)
    if (!isVerified) {
      console.log('📢: isVerified: ', isVerified)
    }
    return isVerified
  }
}
