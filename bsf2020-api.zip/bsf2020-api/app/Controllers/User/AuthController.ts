import Cache from '@ioc:Adonis/Addons/Cache'
import Redis from '@ioc:Adonis/Addons/Redis'
import Application from '@ioc:Adonis/Core/Application'
import Encryption from '@ioc:Adonis/Core/Encryption'
import Env from '@ioc:Adonis/Core/Env'
import { cuid } from '@ioc:Adonis/Core/Helpers'
import { HttpContextContract } from '@ioc:Adonis/Core/HttpContext'
import Logger from '@ioc:Adonis/Core/Logger'
import { RequestContract } from '@ioc:Adonis/Core/Request'
import { rules, schema } from '@ioc:Adonis/Core/Validator'
import Database from '@ioc:Adonis/Lucid/Database'
import UserService from 'App/Services/UserService'
import { DateTime } from 'luxon'

const phoneLimit = Env.get('PHONE_LIMIT', 10)
const depositBonus = Env.get('DEPOSIT_BONUS', 0)
const project = Env.get('project')

export default class AuthController {
  public async register({ request, response }: HttpContextContract) {
    const data = await request.validate({
      schema: schema.create({
        name: schema.string(),
        code: schema.string.optional(),
        phone: schema.string([rules.mobile()]),
        phoneOtp: schema.number(),
        username: schema.string({}, [
          rules.unique({ table: 'createmaster', column: 'mstruserid' }),
          rules.alphaNum({
            allow: ['underscore'],
          }),
        ]),
        password: schema.string(),
        FromDate: schema.string.optional(),
      }),
      messages: {
        'username.alphaNum': 'The username can only include letters, numbers, and underscores.',
        'username.unique': 'Username is not available.',
        'email.unique': 'Email is not available.',
        'phone.unique': 'Phone no is not available.',
        'password.minLength': 'Password must be at least {{ options.minLength }} characters.',
        'password.regex': 'Password must contain at least one uppercase letter.',
      },
    })

    if (data.phone.toString().length != phoneLimit && project == 1) {
      return response.badRequest({
        message: `Phone no must be ${phoneLimit} digits.`,
        status: false,
      })
    }

    let dealerCode: any
    if (data.code) {
      dealerCode = await Database.from('dealer_code').where('code', data.code).first()
    }

    const dealer = await this.verifyDealer(request, dealerCode?.user_id)

    response.abortIf(!dealer, {
      message: 'Invalid request. Dealer not found.',
      status: false,
    })

    response.abortIf(!dealer.show_register, {
      message: 'Invalid request.',
      status: false,
    })

    let bonus = 0

    if (project == 1) {
      if (depositBonus == '1') {
        let masterId = dealer.mstrid
        if (dealer.usetype == 2) {
          const master = await Database.from('createmaster')
            .where('parentId', dealer.mstrid)
            .where('usetype', 1)
            .first()
          if (master) {
            masterId = master.mstrid
          }
        }

        const key = 'dealer_setting:' + masterId
        const dealerSetting: any = await Cache.get(key)
        bonus = dealerSetting?.deposit_bonus || 0
      }

      // check mobile number is registered in dealer's domain
      const mobileUser = await Database.from('createmaster')
        .where('domain', dealer.domain)
        .where('phone', data.phone)
        .first()

      response.abortIf(mobileUser, {
        message: 'Phone no is not available.',
        status: false,
      })
    }

    const c = await Database.from('createmaster')
      .select(
        'createmaster.create_no_of_child as childuser',
        Database.from('createmaster')
          .where('parentId', dealer.mstrid)
          .count('mstrid as tot_childcount')
          .as('tot_childcount')
      )
      .where('createmaster.mstrid', dealer.mstrid)
      .first()

    if (!c) {
      return response.badRequest({
        message: 'Could not generate otp.',
      })
    }

    const phoneKey = 'forgotPassword:' + data.phone

    const phoneOtp: any = await Cache.get(phoneKey)

    response.abortIf(phoneOtp != data.phoneOtp, {
      message: `OTP for ${project == 1 ? 'phone' : 'email'} no is wrong.`,
    })

    if (!(c.tot_childcount < c.childuser)) {
      return response.badRequest({
        message: 'Child limit reached',
      })
    }

    data.FromDate = DateTime.now().toFormat('yyyy-MM-dd')
    // console.log({ dealer })

    const addUser = await Database.table('createmaster')
      .returning('mstrid')
      .insert({
        mstrname: data.name,
        mstruserid: data.username,
        mstrpassword: Database.raw('sha1(:password)', { password: data.password }),
        usetype: 3,
        mstrremarks: '',
        phone: data.phone,
        ipadress: request.ip(),
        loginid: dealer.mstrid,
        parentId: dealer.mstrid,
        usecrdt: new Date(),
        partner: 0,
        Commission: dealer.Commission,
        SessionComm: dealer.SessionComm,
        OtherComm: 0,
        rolling_commission: dealer.rolling_commission,
        fancy_rolling_commission: dealer.fancy_rolling_commission,
        create_no_of_child: 0,
        HelperID: 0,
        isPartnership: dealer.isPartnership,
        partner_casino: 0,
        partner_cricket: 0,
        partner_tennis: 0,
        partner_soccer: 0,
        partner_dream: 0,
        partner_binary: 0,
        partner_election: 0,
        partner_virtual_casino: 0,
        domain: dealer.domain,
        payment_type: dealer.payment_type,
        allow_deposit_withdraw: dealer.allow_deposit_withdraw,
        gamehub_password: Encryption.encrypt(cuid().toLowerCase()),
        deposit_bonus: bonus,
      })

    response.abortIf(addUser.length == 0, {
      message: 'Could not save user.',
    })

    let mstrid = addUser[0]

    let superDuperAdminCricket: number
    let companyCricket: number
    let superAdminCricket: number
    let subAdminCricket: number
    let superMasterCricket: number
    let masterCricket: number
    let dealerCricket: number

    let companySoccer: number
    let superDuperAdminSoccer: number
    let superAdminSoccer: number
    let subAdminSoccer: number
    let superMasterSoccer: number
    let masterSoccer: number
    let dealerSoccer: number

    let superDuperAdminTennis: number
    let companyTennis: number
    let superAdminTennis: number
    let subAdminTennis: number
    let superMasterTennis: number
    let masterTennis: number
    let dealerTennis: number

    let superDuperAdminCasino: number
    let companyCasino: number
    let superAdminCasino: number
    let subAdminCasino: number
    let superMasterCasino: number
    let masterCasino: number
    let dealerCasino: number

    let superDuperAdminDream: number
    let companyDream: number
    let superAdminDream: number
    let subAdminDream: number
    let superMasterDream: number
    let masterDream: number
    let dealerDream: number

    let superDuperAdminBinary: number
    let companyBinary: number
    let superAdminBinary: number
    let subAdminBinary: number
    let superMasterBinary: number
    let masterBinary: number
    let dealerBinary: number

    let superDuperAdminElection: number
    let companyElection: number
    let superAdminElection: number
    let subAdminElection: number
    let superMasterElection: number
    let masterElection: number
    let dealerElection: number

    let superDuperAdminVirtualCasino: number
    let companyVirtualCasino: number
    let superAdminVirtualCasino: number
    let subAdminVirtualCasino: number
    let superMasterVirtualCasino: number
    let masterVirtualCasino: number
    let dealerVirtualCasino: number

    if (
      project == 1 ? !dealer.isPartnership : !dealer.isPartnership || dealer.allow_deposit_withdraw
    ) {
      superDuperAdminCricket = 100
      companyCricket = 100
      superAdminCricket = 100
      subAdminCricket = 100
      superMasterCricket = 100
      masterCricket = 100
      dealerCricket = 100

      companySoccer = 100
      superDuperAdminSoccer = 100
      superAdminSoccer = 100
      subAdminSoccer = 100
      superMasterSoccer = 100
      masterSoccer = 100
      dealerSoccer = 100

      superDuperAdminTennis = 100
      companyTennis = 100
      superAdminTennis = 100
      subAdminTennis = 100
      superMasterTennis = 100
      masterTennis = 100
      dealerTennis = 100

      superDuperAdminCasino = 100
      companyCasino = 100
      superAdminCasino = 100
      subAdminCasino = 100
      superMasterCasino = 100
      masterCasino = 100
      dealerCasino = 100

      superDuperAdminDream = 100
      companyDream = 100
      superAdminDream = 100
      subAdminDream = 100
      superMasterDream = 100
      masterDream = 100
      dealerDream = 100

      superDuperAdminBinary = 100
      companyBinary = 100
      superAdminBinary = 100
      subAdminBinary = 100
      superMasterBinary = 100
      masterBinary = 100
      dealerBinary = 100

      superDuperAdminElection = 100
      companyElection = 100
      superAdminElection = 100
      subAdminElection = 100
      superMasterElection = 100
      masterElection = 100
      dealerElection = 100

      superDuperAdminVirtualCasino = 100
      companyVirtualCasino = 100
      superAdminVirtualCasino = 100
      subAdminVirtualCasino = 100
      superMasterVirtualCasino = 100
      masterVirtualCasino = 100
      dealerVirtualCasino = 100
    } else {
      let partner: any = await Database.from('tblpartner').where('UserID', dealer.mstrid).first()

      superDuperAdminCricket = partner.super_duper_admin_cricket
      companyCricket = partner.company_cricket
      superAdminCricket = partner.super_admin_cricket
      subAdminCricket = partner.sub_admin_cricket
      superMasterCricket = partner.super_master_cricket
      masterCricket = partner.master_cricket
      dealerCricket = partner.dealer_cricket

      superDuperAdminSoccer = partner.super_duper_admin_soccer
      companySoccer = partner.company_soccer
      superAdminSoccer = partner.super_admin_soccer
      subAdminSoccer = partner.sub_admin_soccer
      superMasterSoccer = partner.super_master_soccer
      masterSoccer = partner.master_soccer
      dealerSoccer = partner.dealer_soccer

      superDuperAdminTennis = partner.super_duper_admin_tennis
      companyTennis = partner.company_tennis
      superAdminTennis = partner.super_admin_tennis
      subAdminTennis = partner.sub_admin_tennis
      superMasterTennis = partner.super_master_tennis
      masterTennis = partner.master_tennis
      dealerTennis = partner.dealer_tennis

      superDuperAdminCasino = partner.super_duper_admin_casino
      companyCasino = partner.company_casino
      superAdminCasino = partner.super_admin_casino
      subAdminCasino = partner.sub_admin_casino
      superMasterCasino = partner.super_master_casino
      masterCasino = partner.master_casino
      dealerCasino = partner.dealer_casino

      superDuperAdminDream = partner.super_duper_admin_dream
      companyDream = partner.company_dream
      superAdminDream = partner.super_admin_dream
      subAdminDream = partner.sub_admin_dream
      superMasterDream = partner.super_master_dream
      masterDream = partner.master_dream
      dealerDream = partner.dealer_dream

      superDuperAdminBinary = partner.super_duper_admin_binary
      companyBinary = partner.company_binary
      superAdminBinary = partner.super_admin_binary
      subAdminBinary = partner.sub_admin_binary
      superMasterBinary = partner.super_master_binary
      masterBinary = partner.master_binary
      dealerBinary = partner.dealer_binary

      superDuperAdminElection = partner.super_duper_admin_election
      companyElection = partner.company_election
      superAdminElection = partner.super_admin_election
      subAdminElection = partner.sub_admin_election
      superMasterElection = partner.super_master_election
      masterElection = partner.master_election
      dealerElection = partner.dealer_election

      superDuperAdminVirtualCasino = partner.super_duper_admin_virtual_casino
      companyVirtualCasino = partner.company_virtual_casino
      superAdminVirtualCasino = partner.super_admin_virtual_casino
      subAdminVirtualCasino = partner.sub_admin_virtual_casino
      superMasterVirtualCasino = partner.super_master_virtual_casino
      masterVirtualCasino = partner.master_virtual_casino
      dealerVirtualCasino = partner.dealer_virtual_casino
    }

    const insertData = {
      TypeID: 3,
      ParentID: dealer.mstrid,
      UserID: mstrid,
      super_duper_admin_cricket: superDuperAdminCricket,
      super_duper_admin_soccer: superDuperAdminSoccer,
      super_duper_admin_tennis: superDuperAdminTennis,
      super_duper_admin_casino: superDuperAdminCasino,
      super_duper_admin_dream: superDuperAdminDream,
      super_duper_admin_binary: superDuperAdminBinary,
      super_duper_admin_election: superDuperAdminElection,
      super_duper_admin_virtual_casino: superDuperAdminVirtualCasino,
      company_cricket: companyCricket,
      company_soccer: companySoccer,
      company_tennis: companyTennis,
      company_casino: companyCasino,
      company_dream: companyDream,
      company_binary: companyBinary,
      company_election: companyElection,
      company_virtual_casino: companyVirtualCasino,
      super_admin_cricket: superAdminCricket,
      super_admin_soccer: superAdminSoccer,
      super_admin_tennis: superAdminTennis,
      super_admin_casino: superAdminCasino,
      super_admin_dream: superAdminDream,
      super_admin_binary: superAdminBinary,
      super_admin_election: superAdminElection,
      super_admin_virtual_casino: superAdminVirtualCasino,
      sub_admin_cricket: subAdminCricket,
      sub_admin_soccer: subAdminSoccer,
      sub_admin_tennis: subAdminTennis,
      sub_admin_casino: subAdminCasino,
      sub_admin_dream: subAdminDream,
      sub_admin_binary: subAdminBinary,
      sub_admin_election: subAdminElection,
      sub_admin_virtual_casino: subAdminVirtualCasino,
      super_master_cricket: superMasterCricket,
      super_master_soccer: superMasterSoccer,
      super_master_tennis: superMasterTennis,
      super_master_casino: superMasterCasino,
      super_master_dream: superMasterDream,
      super_master_binary: superMasterBinary,
      super_master_election: superMasterElection,
      super_master_virtual_casino: superMasterVirtualCasino,

      master_cricket: masterCricket,
      master_casino: masterCasino,
      master_soccer: masterSoccer,
      master_tennis: masterTennis,
      master_dream: masterDream,
      master_binary: masterBinary,
      master_election: masterElection,
      master_virtual_casino: masterVirtualCasino,
      dealer_cricket: dealerCricket,
      dealer_soccer: dealerSoccer,
      dealer_tennis: dealerTennis,
      dealer_casino: dealerCasino,
      dealer_dream: dealerDream,
      dealer_binary: dealerBinary,
      dealer_election: dealerElection,
      dealer_virtual_casino: dealerVirtualCasino,
    }

    await Database.table('tblpartner').insert(insertData)

    let v: any = await Cache.get('defaultStake')
    if (v) {
      await Database.query()
        .from('createmaster')
        .where('mstrid', mstrid)
        .update({
          match_stake: JSON.stringify(v.map((el: any) => el.value)),
        })
    } else {
      await Database.query()
        .from('createmaster')
        .where('mstrid', mstrid)
        .update({
          match_stake: JSON.stringify([100, 200, 300, 500, 1000]),
        })
    }

    await Redis.del(phoneKey)

    const dataToPublish = {
      userId: dealer.mstrid,
      type: 'register-notification',
    }

    await Redis.publish('register-notification', JSON.stringify(dataToPublish))

    return response.json({
      message: 'Registered successfully.',
      status: true,
    })
  }

  public async verifyEmail({ response }: HttpContextContract) {
    return response.badRequest({
      message: 'Coming soon.',
      status: false,
    })
  }

  public async sendOtp({ request, response }: HttpContextContract) {
    const data = await request.validate({
      schema: schema.create({
        phone: schema.string([rules.mobile()]),
        code: schema.string.optional(),
      }),
    })

    if (data.phone.toString().length != phoneLimit) {
      return response.badRequest({
        message: `Phone no must be ${phoneLimit} digits.`,
        status: false,
      })
    }

    let dealerCode
    if (data.code) {
      dealerCode = await Database.from('dealer_code').where('code', data.code).first()
    }

    const dealer = await this.verifyDealer(request, dealerCode?.user_id)
    if (!dealer) {
      return response.badRequest({
        message: 'Invalid request. Dealer not found.',
        status: false,
      })
    }

    response.abortIf(!dealer.show_register, {
      message: 'Invalid request.',
      status: false,
    })

    const c = await Database.from('createmaster')
      .select(
        'createmaster.create_no_of_child as childuser',
        Database.from('createmaster')
          .where('parentId', dealer.mstrid)
          .count('mstrid as tot_childcount')
          .as('tot_childcount')
      )
      .where('createmaster.mstrid', dealer.mstrid)
      .first()

    if (!c) {
      return response.badRequest({
        message: 'Could not generate otp.',
      })
    }

    if (!(c.tot_childcount < c.childuser || dealer.mstrid == 1)) {
      return response.badRequest({
        message: 'Child limit reached.',
      })
    }

    // const data = await request.validate({
    //   schema: schema.create({
    //     phone: schema.number(),
    //   }),
    // })

    if (data.phone.toString().length != phoneLimit) {
      return response.badRequest({
        message: `Phone no must be ${phoneLimit} digits.`,
        status: false,
      })
    }

    const user = await Database.query()
      .from('createmaster')
      .where('phone', data.phone)
      .where('domain', dealer.domain)
      .first()

    if (user) {
      return response.badRequest({
        message: 'Phone no already exist.',
        status: false,
      })
    }

    const otp = this.generateOTP()
    // console.log({ otp })

    try {
      if (Env.get('SMS') == 'portal.sms.net') {
        const res = await UserService.sendOtpSmsNet(data.phone, otp)
        if (res.status === 200) {
          const r = res.data

          if (r.error == 0) {
            await Cache.put('forgotPassword:' + data.phone, otp, 600)
            return response.json({
              message: 'OTP has been sent your mobile no.',
              status: true,
            })
          } else {
            return response.badRequest({
              message: res.data.msg,
              status: false,
            })
          }
        }
      } else if (Env.get('SMS') == 'onbuka') {
        const res = await UserService.sendOtpOnbuka(data.phone, otp)
        if (res.status === 200) {
          const r = res.data
          if (r.status == 0) {
            await Cache.put('forgotPassword:' + data.phone, otp, 600)
            return response.json({
              message: 'OTP has been sent your mobile no.',
              status: true,
            })
          } else {
            return response.badRequest({
              message: r.reason,
              status: false,
            })
          }
        }
      } else if (Env.get('SMS') == 'greenweb') {
        const res = await UserService.sendOtpGreenWeb(data.phone, otp)
        if (res.status === 200) {
          const r = res.data
          if (typeof r == 'string' && r.toLowerCase().startsWith('ok')) {
            await Cache.put('forgotPassword:' + data.phone, otp, 600)
            return response.json({
              message: 'OTP has been sent your mobile no.',
              status: true,
            })
          } else {
            return response.badRequest({
              message: 'Server error.',
              status: false,
            })
          }
        }
      } else if (Env.get('SMS') == 'smsnet') {
        const res = await UserService.sendOtp(data.phone, otp)

        if (res.status === 200) {
          const r = res.data?.smslist?.sms?.code

          if (r == '000') {
            await Cache.put('forgotPassword:' + data.phone, otp, 600)
            return response.json({
              message: 'OTP has been sent your mobile no.',
              status: true,
            })
          }
        }
      } else {
        return response.badRequest({
          message: 'Please contact admin to enable SMS service.',
          status: false,
        })
      }
    } catch (e) {
      Logger.error('SEND OTP: %o', e)
      return response.badRequest({
        message: 'OTP service issue.',
        status: false,
      })
    }
  }

  public async registerRequest({ request, response }: HttpContextContract) {
    const data: any = await request.validate({
      schema: schema.create({
        name: schema.string(),
        password: schema.string(),
        phone: schema.number(),
        // deposit_amount: schema.number(),
        // domain: schema.string([
        //   rules.url({
        //     protocols: ['http', 'https'],
        //   }),
        //   rules.normalizeUrl({
        //     stripWWW: true,
        //     removeSingleSlash: true,
        //   }),
        // ]),
        username: schema.string({}, [
          rules.unique({ table: 'request_users', column: 'mstruserid' }),
          rules.alphaNum({
            allow: ['underscore'],
          }),
        ]),
        // password: schema.string([rules.minLength(6), rules.regex(/[A-Z]/)]),
      }),
      messages: {
        'username.alphaNum': 'The username can only include letters, numbers, and underscores.',
        'username.unique': 'Username is not available.',
        'email.unique': 'Email is not available.',
        'phone.unique': 'Phone no is not available.',
        'password.minLength': 'Password must be at least {{ options.minLength }} characters.',
        'password.regex': 'Password must contain at least one uppercase letter.',
      },
    })

    const mobileUser = await Database.from('request_users').where('phone', data.phone).first()

    response.abortIf(mobileUser, {
      message: 'Phone no is not available.',
      status: false,
    })

    let dealerUsername = 'vd'

    if (Application.inProduction) {
      dealerUsername = 'bpexch'
    }

    const dealer = await Database.from('createmaster').where('mstruserid', dealerUsername).first()

    response.abortIf(!dealer, {
      message: 'No dealer found.',
      status: false,
    })

    // response.abortIf(data.deposit_amount < 1000, {
    //   message: 'Minimum deposit amount is 1000.',
    //   status: false,
    // })

    await Database.table('request_users').insert({
      mstrname: data.name,
      mstruserid: data.username,
      mstrpassword: data.password,
      phone: data.phone,
      usecrdt: new Date(),
      parentId: dealer.mstrid,
    })

    return response.json({
      message: 'Registered successfully.',
      status: true,
    })
  }

  public async requestLogin({ request, response }: HttpContextContract) {
    const data = await request.validate({
      schema: schema.create({
        username: schema.string({ trim: true }),
        password: schema.string(),
        browser_info: schema.string(),
        device_info: schema.string(),
        dom: schema.string(),
      }),
      messages: {
        'username.alphaNum': 'The username can only include letters, numbers, and underscores.',
      },
    })

    let origin: any = request.input('origin', request.header('origin'))

    const user = await Database.from('request_users')
      .where('mstruserid', data.username)
      .where('mstrpassword', data.password)
      .first()

    response.abortIf(!user, {
      status: false,
      message: 'Invalid username or password',
    })

    let host = ''
    host = '|' + (user?.domain || origin).substring(8).split('.')[0]

    user.TokenId = 'auth2:' + user.mstrid + '|' + cuid().toLowerCase() + host

    await Cache.put(user.TokenId, user, 3600)

    return response.json({
      token: user.TokenId,
      user: user,
    })
  }

  public async getRequestStatus({ request, response }: HttpContextContract) {
    const data = await request.validate({
      schema: schema.create({
        username: schema.string({ trim: true }),
        password: schema.string(),
      }),
      messages: {
        'username.alphaNum': 'The username can only include letters, numbers, and underscores.',
      },
    })

    const user = await Database.from('register_requests')
      .where('mstruserid', data.username)
      .where('mstrpassword', data.password)
      .first()

    response.abortIf(!user, {
      status: false,
      message: 'Invalid username or password',
    })

    return response.json({
      user: user,
    })
  }

  public async request({ request, response }: HttpContextContract) {
    const data = await request.validate({
      schema: schema.create({
        user_id: schema.number(),
        deposit_amount: schema.number(),
        domain: schema.string([
          rules.url({
            protocols: ['http', 'https'],
          }),
          rules.normalizeUrl({
            stripWWW: true,
            removeSingleSlash: true,
          }),
        ]),
        type: schema.number(),
      }),
    })

    const user = await Database.from('request_users').where('mstrid', data.user_id).first()

    response.abortIf(!user, {
      status: false,
      message: 'User does not exist',
    })

    const pendingRequest = await Database.from('register_requests')
      .where('user_id', data.user_id)
      .where('status', 'PENDING')
      .first()

    response.abortIf(pendingRequest, {
      message: 'Requests are pending.',
      status: false,
    })

    const domain: any = await Database.from('request_domains').where('value', data.domain).first()

    response.abortIf(!domain, {
      message: 'Domain not found.',
      status: false,
    })

    response.abortIf(data.deposit_amount < 1000, {
      message: 'Minimum deposit amount is 1000.',
      status: false,
    })

    await Database.table('register_requests').insert({
      user_id: data.user_id,
      deposit_amount: data.deposit_amount,
      domain: data.domain,
      status: 'PENDING',
      date: new Date(),
      type: data.type,
    })

    return response.json({
      message: 'Request Received Successfully',
      status: true,
    })
  }

  private generateOTP() {
    const digits = '0123456789'
    let OTP = ''
    for (let i = 0; i < 4; i++) {
      OTP += digits[Math.floor(Math.random() * 10)]
    }
    return OTP
  }

  private async verifyDealer(request: RequestContract, dealerId: number) {
    const origin = request.input('origin', request.header('origin'))
    if (!origin) {
      return null
    }

    return await Database.query()
      .from('createmaster')
      .leftJoin('domains', 'domains.value', '=', 'createmaster.domain')
      .if(!origin?.startsWith('http://localhost'), (builder) => {
        builder.where('domain', origin.replace('www.', ''))
      })
      .if(
        dealerId,
        (q) => {
          q.where('mstrid', dealerId).where('useType', 2)
        },
        (q) => {
          q.where('useType', 1)
        }
      )
      .select('createmaster.*', 'domains.show_register')
      .first()
  }
}
