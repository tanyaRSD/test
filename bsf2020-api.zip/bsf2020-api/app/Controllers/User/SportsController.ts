import { HttpContextContract } from '@ioc:Adonis/Core/HttpContext'
import Database from '@ioc:Adonis/Lucid/Database'
import Redis from '@ioc:Adonis/Addons/Redis'

export default class SportsController {
  // public async index({ response, authUser }: HttpContextContract) {
  //   const sports: any = await Database.from('sportmst').whereNotIn(
  //     'id',
  //     Database.from('blocked_sports')
  //       .select('sport_id')
  //       .whereNot('user_id', authUser.mstrid)
  //       .whereIn('user_id', authUser.parentIds)
  //       .orderBy('sportmst.order')
  //   )

  //   return response.json({
  //     data: sports,
  //   })
  // }
  public async index({ response, authUser }: HttpContextContract) {

    const redisKey = `sports:${authUser.mstrid}`

    // 🔥 1. Try Redis
    const cached = await Redis.get(redisKey)
    if (cached) {
      return response.json(JSON.parse(cached))
    }

    // 🔥 2. DB Query (same as yours)
    const sports: any = await Database.from('sportmst').whereNotIn(
      'id',
      Database.from('blocked_sports')
        .select('sport_id')
        .whereNot('user_id', authUser.mstrid)
        .whereIn('user_id', authUser.parentIds)
        .orderBy('sportmst.order')
    )

    const result = {
      data: sports,
    }

    // 🔥 3. Save in Redis
    await Redis.set(redisKey, JSON.stringify(result), 'EX', 86400) // Cache for 24 hours
    return response.json(result)
  }
}
