import Cache from '@ioc:Adonis/Addons/Cache'
import Redis from '@ioc:Adonis/Addons/Redis'
import { HttpContextContract } from '@ioc:Adonis/Core/HttpContext'
import { schema } from '@ioc:Adonis/Core/Validator'
import Database from '@ioc:Adonis/Lucid/Database'
import Bull from '@ioc:Rocketseat/Bull'
import { LiabilityBucket } from 'App/Services/Ledger/Hierarchy'
import LiabilityEngine from 'App/Services/Ledger/LiabilityEngine'
import { Mongo } from 'App/Services/Mongo'
import Sp from 'App/Services/Sp'
import UserService from 'App/Services/UserService'

export default class BetsController {
  /**
   * Maintain upper-panel (ancestor) open-bet liability for a market bet.
   * Clients are excluded — getLiability computes their liability live from
   * vewuserpnldetails. Best-effort: any miss is corrected by the nightly
   * `liability:rebuild-exposure` recompute, so failures never block the bet.
   */
  private async maintainAncestorMarketExposure(
    bet: {
      matchId: number
      marketId: string
      selectionId: number
      stake: number
      pl: number
      isBack: number
      ancestors: { accountId: number; sharePct: number }[]
    },
    sign: number
  ) {
    try {
      const selections = (
        await Database.from('tblselection').where('marketId', bet.marketId).distinct('selectionId')
      ).map((r: any) => Number(r.selectionId))
      if (selections.length === 0) return

      const deltas = LiabilityEngine.marketBetAncestorDeltas({
        matchId: bet.matchId,
        marketId: bet.marketId,
        betSelectionId: bet.selectionId,
        stake: bet.stake,
        pl: bet.pl,
        isBack: bet.isBack,
        selections,
        ancestors: bet.ancestors,
        sign,
      })
      if (deltas.length === 0) return

      await LiabilityEngine.inTransaction((trx) =>
        LiabilityEngine.applyExposure(trx, LiabilityBucket.Market, deltas)
      )
    } catch (e) {
      // Best-effort; the nightly rebuild reconciles ancestor liability from truth.
    }
  }

  public async market({ request, authUser, response }: HttpContextContract) {
    const data = await request.validate({
      schema: schema.create({
        matchId: schema.number(),
        selectionId: schema.string(),
        marketId: schema.string(),
        stake: schema.number(),
        price: schema.number(),
        isBack: schema.number(),
        deviceInfo: schema.string(),
        isCashout: schema.boolean(),
        // domain: schema.string(),
      }),
    })

    const isLocked = await Redis.get('declaring_result:global')
    if (isLocked) {
      return response.badRequest({
        message:
          'Bets are temporarily disabled while result is being declared. Please try again shortly.',
      })
    }

    const isBack = data.isBack == 0
    const pl = isBack ? data.stake : data.price * data.stake - data.stake

    const liabilityKey = 'USER_LIABILITY' + authUser?.mstrid
    if ((await Redis.incr(liabilityKey)) > 1) {
      await Redis.del(liabilityKey)
      await UserService.updateLiability([{ id: authUser?.mstrid }])
    }

    const userKey = 'USER_BET:' + authUser?.mstrid
    const check = await this.checkUser(authUser, userKey)
    if (check) {
      return response.json({
        status: false,
        message: check,
        debug: 'check0'
      })
    }

    const lock = await Cache.rememberForever('system_bet_lock', async () => {
      return false
    })

    if (lock) {
      await Redis.del(userKey)
      return response.json({
        status: false,
        message: `Bet was not placed! Try again later.`,
      })
    }

    const blockedMarkets = await Database.from('blocked_markets')
      .select('market_id')
      .whereIn('user_id', authUser.parentIds)

    const isMarketExists = blockedMarkets.find((obj) => obj.market_id == data.marketId)

    if (isMarketExists) {
      await Redis.del(userKey)
      return response.json({
        status: false,
        message: 'Market is blocked.',
      })
    }

    const blockedMatches = await Database.from('user_deactive_match')
      .select('match_id')
      .whereIn('user_id', authUser.parentIds)

    const isMatchExists = blockedMatches.find((obj) => obj.match_id == data.matchId)

    if (isMatchExists) {
      await Redis.del(userKey)
      return response.json({
        status: false,
        message: 'Match is blocked.',
      })
    }

    if (authUser?.mstrlock == 0 || authUser.mstrid == 3522) {
      await Redis.del(userKey)
      return response.json({
        status: false,
        message: 'Your account is in active.',
      })
    }

    if (authUser?.account_closed == 0) {
      await Redis.del(userKey)
      return response.json({
        status: false,
        message: 'Your account is closed.',
      })
    }

    if (authUser?.bet_lock == 0 || authUser.mstrid == 3522) {
      await Redis.del(userKey)
      return response.json({
        status: false,
        message: 'Your betting is locked.',
      })
    }

    if (data.price < 1.01) {
      await Redis.del(userKey)
      return response.json({
        status: false,
        message: 'Run must be greater than 0.',
      })
    }

    if (data.stake < 1) {
      await Redis.del(userKey)
      return response.json({
        status: false,
        message: 'Stack can not be zero.',
      })
    }

    // get Market Data from database
    const key = 'marketDb:' + data.marketId + ':' + authUser?.mstrid

    const parentData: any = await UserService.parents(authUser.mstrid)
    const parents = parentData.map((i: any) => i.mstrid)

    const marketDBVal: any = await Cache.remember(key, 300, async () => {
      return await Database.from('market')
        .join('sportmst', 'market.sportsId', '=', 'sportmst.id')
        .join('matchmst', 'market.matchId', '=', 'matchmst.MstCode')
        .joinRaw(
          `LEFT JOIN user_sport_limit as usl ON usl.id = (SELECT id FROM user_sport_limit WHERE user_id IN (${parents.toString()}) AND sport_id = market.sportsId AND type = CASE WHEN market.Id LIKE '%B%' THEN 'bookmaker' ELSE 'market' END ORDER BY user_id DESC LIMIT 1)`
        )
        .joinRaw(
          `LEFT JOIN market_settings as ms ON ms.id = (SELECT id FROM market_settings WHERE user_id IN (${parents.toString()}) AND market_id = market.Id ORDER BY user_id DESC LIMIT 1)`
        )
        .select('market.*')
        .select('sportmst.name as sportName', 'sportmst.id as sportId')
        .select(
          Database.raw('COALESCE(usl.bet_delay, 0) as betDelay'),
          Database.raw(
            'ROUND(GREATEST(market.min_stack, COALESCE(usl.min_stake, 0), COALESCE(ms.min_stack, 0)),0) as min_stack'
          ),
          Database.raw('GREATEST(market.volume, COALESCE(usl.market_volume, 1)) as volume'),

          Database.raw(
            'LEAST(market.max_market_liability, COALESCE(usl.max_market_liability, market.max_market_liability)) as max_market_liability'
          ),
          Database.raw(
            'ROUND(LEAST(market.max_stack, COALESCE(usl.max_stake, 5000000), COALESCE(ms.max_stack, 0)),0) as max_stack'
          ),
          Database.raw(
            'ROUND(LEAST(market.max_market_profit, COALESCE(usl.max_profit, 5000000), COALESCE(ms.max_profit, 0)),0) as max_profit'
          ),
          'matchmst.matchName as matchName',
          'matchmst.oddsLimit as oddsLimit'
        )
        .where('market.Id', data.marketId)
        .whereNotIn(
          'matchmst.SportID',
          Database.from('blocked_sports').select('sport_id').whereIn('user_id', authUser.parentIds)
        )
        .whereNotIn(
          'market.Id',
          Database.from('blocked_markets')
            .select('market_id')
            .whereNot('user_id', authUser.mstrid)
            .whereIn('user_id', authUser.parentIds)
        )
        .whereNotIn(
          'matchmst.mstcode',
          Database.from('user_deactive_match')
            .select('match_id')
            .whereIn('user_id', authUser.parentIds)
        )
        .firstOrFail()
    })

    const isBookmaker = data.marketId.includes('B')

    // if (['7', '4339'].indexOf(marketDBVal.sportId.toString()) > -1 && !isBack) {
    //   await Redis.del(userKey)
    //   return response.json({
    //     status: false,
    //     message: 'Lay bet not allowed.',
    //   })
    // }

    const runners = JSON.parse(marketDBVal.market_runner_json)
    const runner = runners.find((el) => el.id == data.selectionId)

    if (!runner) {
      await Redis.del(userKey)
      return response.json({
        status: false,
        message: 'Runner not found.',
      })
    }

    const getOddsPL: any = await Sp.readCall(
      '_get_odds_profit_loss(:userId,:userType,:matchId,:marketId)',
      {
        userId: authUser?.mstrid,
        userType: authUser?.usetype,
        matchId: marketDBVal.matchId,
        marketId: data.marketId,
      }
    )

    const maxMarketLiability: any = marketDBVal.max_market_liability

    if (maxMarketLiability > 0 && getOddsPL.length > 0) {
      const maxLiability = Math.min(
        ...getOddsPL.map((o: any) => {
          if (isBack) {
            if (o.SelectionId != data.selectionId) {
              return parseFloat(o.winValue) + parseFloat(o.lossValue) - data.stake
            } else {
              return parseFloat(o.winValue) + parseFloat(o.lossValue) + pl
            }
          } else {
            if (o.SelectionId != data.selectionId) {
              return parseFloat(o.winValue) + parseFloat(o.lossValue) + data.stake
            } else {
              return parseFloat(o.winValue) + parseFloat(o.lossValue) - pl
            }
          }
        })
      )

      if (Math.abs(maxLiability) > maxMarketLiability) {
        await Redis.del(userKey)
        return response.json({
          status: false,
          message: 'Max market liability reached.',
        })
      }
    } else if (maxMarketLiability > 0 && (isBack ? data.stake : pl) > maxMarketLiability) {
      await Redis.del(userKey)
      return response.json({
        status: false,
        message: 'Max market liability reached.',
      })
    }

    if (authUser?.balance < pl) {
      if (getOddsPL.length == 0) {
        if (authUser?.balance < pl) {
          await Redis.del(userKey)
          return response.json({
            status: false,
            message: 'Balance is not enough!',
          })
        }
      } else {
        const currentRunner = getOddsPL.find((el: any) => el.SelectionId == data.selectionId)
        if (!currentRunner) {
          await Redis.del(userKey)
          return response.json({
            status: false,
            message: 'Selection not found.',
          })
        }

        const runnerLiability =
          parseFloat(currentRunner.winValue) + parseFloat(currentRunner.lossValue)

        if (isBack) {
          const maxLiability = Math.min(
            ...getOddsPL
              .filter((el: any) => el.SelectionId != data.selectionId)
              .map((o: any) => parseFloat(o.winValue) + parseFloat(o.lossValue))
          )
          if (runnerLiability < 0 && maxLiability < 0) {
            if (maxLiability - data.stake > authUser?.balance) {
              await Redis.del(userKey)
              return response.json({
                status: false,
                message: 'Balance is not enough',
              })
            }
          } else {
            if (maxLiability + authUser?.balance + pl < data.stake) {
              await Redis.del(userKey)
              return response.json({
                status: false,
                message: 'Balance is not enough.',
              })
            }
          }
        } else {
          if (runnerLiability < 0) {
            if (authUser?.balance < pl) {
              await Redis.del(userKey)
              return response.json({
                status: false,
                message: 'Balance is not enough.',
              })
            }
          } else {
            if (runnerLiability + pl < 0) {
              if (authUser?.balance + runnerLiability + pl < 0) {
                await Redis.del(userKey)
                return response.json({
                  status: false,
                  message: 'Balance is not enough.',
                })
              }
            }
          }
        }
      }

      // await Redis.del(userKey)
      // return response.json({
      //   status: false,
      //   message: 'Balance is not enough.',
      // })
    }

    const minStakes: any = marketDBVal.min_stack
    const maxStakes: any = marketDBVal.max_stack

    //market validations
    if (maxStakes > 0 && data.stake > maxStakes) {
      await Redis.del(userKey)
      return response.json({
        status: false,
        message: 'Please check the stake limit :' + maxStakes,
      })
    } else if (minStakes > 0 && data.stake < minStakes) {
      await Redis.del(userKey)
      return response.json({
        status: false,
        message: 'Check min stake :' + minStakes,
      })
    } else if (marketDBVal.active == 0) {
      await Redis.del(userKey)
      return response.json({
        status: false,
        message: 'Market is not active or result has been declared.',
      })
    }

    await this.sleep(parseInt(marketDBVal.betDelay) * 1000)

    //get Market from redis
    let market = await Cache.use('main').get('marketId:' + data.marketId)
    if (!market) {
      await Redis.del(userKey)
      return response.json({
        status: false,
        message: 'Market not found.',
      })
    }

    if (['7', '4339'].indexOf(marketDBVal.sportId.toString()) > -1 && market.inplay) {
      await Redis.del(userKey)
      return response.json({
        status: false,
        message: 'Gray/Horse is Inplay, You can not bet place!',
      })
    }

    if (market.updated_at) {
      const diffInSeconds = Math.floor(
        Math.abs(new Date().getTime() - new Date(market.updated_at).getTime()) / 1000
      )

      if (!market.marketId.includes('M')) {
        if (diffInSeconds > 5) {
          await Redis.del(userKey)
          return response.json({
            status: false,
            message: 'Odds not matched.',
          })
        }
      }
    }

    let priceVal: any = data.price

    //check market status
    if (market.status == 'CLOSED' || market.status == 'SUSPENDED') {
      await Redis.del(userKey)
      return response.json({
        status: false,
        message: 'Market ' + market.status,
      })
    }
    //get current runner by selection id
    let currentRunner = market.runners.find(
      (x: any) => x.selectionId.toString() == data.selectionId.toString()
    )

    if (!currentRunner) {
      await Redis.del(userKey)
      return response.json({
        status: false,
        message: 'Bet not available.',
      })
    }
    //check runner status
    if (isBookmaker && currentRunner.status != 'ACTIVE') {
      await Redis.del(userKey)
      return response.json({
        status: false,
        message: 'Runner status changed.',
      })
    }

    const volumeMultiplier = parseFloat(marketDBVal.volume)
    let volume = 0

    if (data.isBack == 0) {
      //back
      if (currentRunner.ex.availableToBack.length == 0) {
        await Redis.del(userKey)
        return response.json({
          status: false,
          message: 'Back Not available.',
        })
      }

      let redisPrice = parseFloat(currentRunner.ex.availableToBack[0].price)

      if (isBookmaker) {
        redisPrice = parseFloat((parseFloat((redisPrice / 100).toFixed(3)) + 1).toFixed(3))
      } else {
        volume = parseFloat(currentRunner.ex.availableToBack[0].size) * volumeMultiplier

        if (volumeMultiplier > 1 && volume <= data.stake) {
          data.stake = volume
        }
      }

      if (redisPrice >= data.price) {
        if (!data.isCashout) {
          priceVal = redisPrice
        }
      } else {
        await Redis.del(userKey)
        return response.json({
          status: false,
          message: 'Unmatched bet not available.',
        })
      }
    } else {
      //lay
      if (currentRunner.ex.availableToLay.length == 0) {
        await Redis.del(userKey)
        return response.json({
          status: false,
          message: 'Lay not available.',
        })
      }

      let redisPrice = parseFloat(currentRunner.ex.availableToLay[0].price)

      if (isBookmaker) {
        redisPrice = parseFloat((parseFloat((redisPrice / 100).toFixed(3)) + 1).toFixed(3))
      } else {
        volume = parseFloat(currentRunner.ex.availableToBack[0].size) * volumeMultiplier

        if (volumeMultiplier > 1 && volume <= data.stake) {
          data.stake = volume
        }
      }

      if (redisPrice <= data.price) {
        if (!data.isCashout) {
          priceVal = redisPrice
          if (priceVal < 1) {
            await Redis.del(userKey)
            return response.json({
              status: false,
              message: 'Odds must be greater than 0.',
            })
          }
        }
      } else {
        await Redis.del(userKey)
        return response.json({
          status: false,
          message: 'Unmatched bet not available.',
        })
      }
    }

    if (priceVal < 1.01) {
      await Redis.del(userKey)
      return response.json({
        status: false,
        message: 'Run must be greater than 0.',
      })
    }

    if (!isBookmaker && parseFloat(marketDBVal.odds_limit) == 0) {
      await Redis.del(userKey)
      return response.json({
        status: false,
        message: 'Odds limit is not set.',
      })
    }

    if (
      !isBookmaker &&
      parseFloat(marketDBVal.odds_limit) > 0 &&
      parseFloat(priceVal) > parseFloat(marketDBVal.odds_limit)
    ) {
      await Redis.del(userKey)
      return response.json({
        status: false,
        message: 'Odds limit reached :' + marketDBVal.odds_limit,
      })
    }

    const profitLoss = (priceVal * data.stake - data.stake).toFixed(2)

    if (marketDBVal.max_market_profit > 0 || marketDBVal.max_profit > 0) {
      // if (!getOddsPL) {
      //   getOddsPL = await Sp.call('_get_odds_profit_loss(:userId,:userType,:matchId,:marketId)', {
      //     userId: authUser?.mstrid,
      //     userType: authUser?.usetype,
      //     matchId: marketDBVal.matchId,
      //     marketId: data.marketId,
      //   })
      // }

      let userMaxProfit = 0
      // let userMaxLoss = 0;
      if (getOddsPL.length == 0) {
        userMaxProfit = data.isBack == 0 ? parseFloat(profitLoss) : data.stake
        // userMaxLoss = data.isBack == 0 ? parseFloat(data.stake) : parseFloat(profitLoss);

        if (marketDBVal.max_market_profit > 0 && userMaxProfit > marketDBVal.max_market_profit) {
          await Redis.del(userKey)
          return response.json({
            status: false,
            message: 'Max profit reached.',
          })
        }
        if (marketDBVal.max_profit > 0 && userMaxProfit > marketDBVal.max_profit) {
          await Redis.del(userKey)
          return response.json({
            status: false,
            message: 'Max profit reached.',
          })
        }
      } else {
        let flag = false
        for (const PL of getOddsPL) {
          let winValue = 0
          // let lossValue = 0
          // back
          if (data.isBack == 0) {
            if (data.selectionId == PL.SelectionId) {
              winValue +=
                parseFloat(PL.winValue) + parseFloat(PL.lossValue) + parseFloat(profitLoss)
            } else {
              winValue += parseFloat(PL.winValue) + parseFloat(PL.lossValue) - data.stake
            }
          }
          // lay
          else {
            if (data.selectionId == PL.SelectionId) {
              winValue +=
                parseFloat(PL.winValue) + parseFloat(PL.lossValue) - parseFloat(profitLoss)
            } else {
              winValue += parseFloat(PL.winValue) + parseFloat(PL.lossValue) + data.stake
            }
          }

          if (marketDBVal.max_market_profit > 0 && winValue > marketDBVal.max_market_profit) {
            await Redis.del(userKey)
            flag = true
            break
          }
          if (marketDBVal.max_profit > 0 && winValue > marketDBVal.max_profit) {
            await Redis.del(userKey)
            flag = true
            break
          }
        }

        if (flag) {
          await Redis.del(userKey)
          return response.json({
            status: false,
            message: 'Max profit reached.',
          })
        }
      }
    }

    let { mstrid: superDuperAdminId, mstruserid: superDuperAdminName } = parentData.find(
      (el: any) => el.usetype == 0
    ) ?? {
      mstrid: 0,
      mstruserid: '',
    }
    let { mstrid: companyId, mstruserid: companyName } = parentData.find(
      (el: any) => el.usetype == 11
    ) ?? {
      mstrid: 0,
      mstruserid: '',
    }
    let { mstrid: superAdminId, mstruserid: superAdminName } = parentData.find(
      (el: any) => el.usetype == 10
    ) ?? {
      mstrid: 0,
      mstruserid: '',
    }
    let { mstrid: subAdminId, mstruserid: subAdminName } = parentData.find(
      (el: any) => el.usetype == 9
    ) ?? {
      mstrid: 0,
      mstruserid: '',
    }
    let { mstrid: superMasterId, mstruserid: superMasterName } = parentData.find(
      (el: any) => el.usetype == 8
    ) ?? {
      mstrid: 0,
      mstruserid: '',
    }
    let { mstrid: masterId, mstruserid: masterName } = parentData.find(
      (el: any) => el.usetype == 1
    ) ?? {
      mstrid: 0,
      mstruserid: '',
    }
    let { mstrid: dealerId, mstruserid: dealerName } = parentData.find(
      (el: any) => el.usetype == 2
    ) ?? {
      mstrid: 0,
      mstruserid: '',
    }

    let { mstruserid: userName } = parentData.find((el: any) => el.usetype == 3) ?? {
      mstruserid: '',
    }
    let userId = authUser?.mstrid

    let sportName = 'cricket'

    if (marketDBVal.sportId == 1) {
      sportName = 'soccer'
    } else if (marketDBVal.sportId == 2) {
      sportName = 'tennis'
    } else if (marketDBVal.sportId == 11) {
      sportName = 'virtual_casino'
    } else if (marketDBVal.sportId == 6) {
      sportName = 'election'
    } else if (marketDBVal.sportId == 77) {
      sportName = 'binary'
    }

    const partnershipData: any = await Cache.rememberForever(
      'partnership:' + authUser.mstrid,
      async () => {
        return await Database.from('tblpartner').where('UserID', authUser.mstrid).firstOrFail()
      }
    )

    const superDuperAdminPartnership = partnershipData['super_duper_admin_' + sportName]
    const companyPartnership = partnershipData['company_' + sportName]
    const superAdminPartnership = partnershipData['super_admin_' + sportName]
    const subAdminPartnership = partnershipData['sub_admin_' + sportName]
    const superMasterPartnership = partnershipData['super_master_' + sportName]
    const masterPartnership = partnershipData['master_' + sportName]
    const dealerPartnership = partnershipData['dealer_' + sportName]

    // const totalPartnership =
    //   superDuperAdminPartnership +
    //   companyPartnership +
    //   superAdminPartnership +
    //   subAdminPartnership +
    //   superMasterPartnership +
    //   masterPartnership +
    //   dealerPartnership

    // if (totalPartnership < 100) {
    //   await Redis.del(userKey)
    //   return response.json({
    //     status: false,
    //     message: 'There is an issue in partnership.',
    //   })
    // }

    let betPlaceVal = await Sp.call(
      "_bet_place_market(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,1,'auto')",
      [
        userId,
        userId,
        authUser?.parentId,
        dealerId,
        masterId,
        superMasterId,
        subAdminId,
        superAdminId,
        companyId,
        superDuperAdminId,
        userName,
        dealerName,
        masterName,
        superMasterName,
        subAdminName,
        superAdminName,
        companyName,
        superDuperAdminName,
        superDuperAdminPartnership,
        companyPartnership,
        superAdminPartnership,
        subAdminPartnership,
        superMasterPartnership,
        masterPartnership,
        dealerPartnership,
        marketDBVal.matchId,
        data.selectionId,
        data.stake,
        data.marketId,
        runner.name,
        new Date(),
        priceVal,
        profitLoss,
        data.isBack,
        1,
        'Chip Deducted From Betting >> ' + marketDBVal.matchName,
        data.deviceInfo,
        request.ip(),
        market.inplay ? 1 : 0,
        // data.domain,
      ]
    )

    if (betPlaceVal[0].resultV == 0) {
      const mongoData = {
        type: `BET PLACE for ${data.stake}`,
        category: 'MARKET',
        userId: authUser?.mstrid,
        username: authUser?.mstruserid,
        betId: betPlaceVal[0].LID,
        beforeBalance: authUser?.balance,
        beforeLiability: authUser?.liability,
        matchName: marketDBVal.matchName,
        marketName: marketDBVal.Name,
        selectionName: runner.name,
      }

      // Write the client's post-bet liability to the column (one getLiability),
      // then gate on the column — replaces the separate checkBalanceAfterBet
      // getLiability call + 500ms retry loop, halving the SP cost per bet.
      await UserService.updateLiability([{ id: authUser?.mstrid }], mongoData, 'add')

      const acct = await Database.from('createmaster')
        .where('mstrid', authUser?.mstrid)
        .select('balance')
        .first()

      if (Number(acct?.balance ?? 0) < 0) {
        await Database.from('tblbets').where('MstCode', betPlaceVal[0].LID).delete()
        await UserService.updateLiability([{ id: authUser?.mstrid }])
        await Redis.del(userKey)
        return response.json({ status: false, message: 'Insufficient balance!' })
      }

      const companyData = await Database.rawQuery(`
        WITH RECURSIVE user_tree AS (
          SELECT mstrid, parentId, usetype
          FROM createmaster
          WHERE mstrid = ?

          UNION ALL

          SELECT t.mstrid, t.parentId, t.usetype
          FROM createmaster t
          INNER JOIN user_tree ut ON t.mstrid = ut.parentId
        )
        SELECT mstrid AS company_id
        FROM user_tree
        WHERE usetype = 11
        LIMIT 1
      `, [authUser?.mstrid]);

      console.log('Company Data:', companyData);

      await Mongo.collection('bets').insertOne({
        MstCode: betPlaceVal[0].LID,
        UserId: authUser?.mstrid,
        companyId: companyData?.[0]?.[0]?.company_id,
        Username: authUser?.mstruserid,
        MatchId: marketDBVal.matchId,
        matchName: marketDBVal.matchName,
        MarketId: data.marketId,
        marketName: marketDBVal.Name,
        SelectionId: data.selectionId,
        selectionName: runner.name,
        Odds: priceVal,
        Stack: data.stake,
        isBack: data.isBack,
        Type: data.isBack === 1 ? 'Back' : 'Lay',
        P_L: profitLoss,
        deviceInfo: data.deviceInfo,
        ip: request.ip(),
        inplay: market.inplay ? 1 : 0,
        is_fancy: 0,
        MstDate: new Date(),

        // Additional hierarchy fields
        ParentId: authUser?.parentId,
        DealerId: dealerId,
        MasterId: masterId,
        SuperMasterId: superMasterId,
        SubAdminId: subAdminId,
        SuperAdminId: superAdminId,
        CompanyId: companyId,
        SuperDuperAdminId: superDuperAdminId,

        UsernameActual: userName,
        DealerName: dealerName,
        MasterName: masterName,
        SuperMasterName: superMasterName,
        SubAdminName: subAdminName,
        SuperAdminName: superAdminName,
        CompanyName: companyName,
        SuperDuperAdminName: superDuperAdminName,
      })

      await Bull.add(
        'SaveOddsProfitLoss',
        [
          {
            userId: authUser?.mstrid,
            betId: betPlaceVal[0].LID,
            matchId: marketDBVal.matchId,
            marketId: data.marketId,
          },
        ],
        { removeOnComplete: true }
      )

      // Upper-panel (ancestor) open-bet liability — the piece getLiability does
      // not compute. The client's own liability is handled by updateLiability above.
      await this.maintainAncestorMarketExposure(
        {
          matchId: Number(marketDBVal.matchId),
          marketId: data.marketId,
          selectionId: Number(data.selectionId),
          stake: data.stake,
          pl: Number(profitLoss),
          isBack: data.isBack,
          ancestors: [
            { accountId: Number(dealerId), sharePct: Number(dealerPartnership) },
            { accountId: Number(masterId), sharePct: Number(masterPartnership) },
            { accountId: Number(superMasterId), sharePct: Number(superMasterPartnership) },
            { accountId: Number(subAdminId), sharePct: Number(subAdminPartnership) },
            { accountId: Number(superAdminId), sharePct: Number(superAdminPartnership) },
            { accountId: Number(companyId), sharePct: Number(companyPartnership) },
            { accountId: Number(superDuperAdminId), sharePct: Number(superDuperAdminPartnership) },
          ],
        },
        1
      )

      for (const p of parentData) {
        await Redis.publish(
          'BETS_UPDATE_DATA',
          JSON.stringify({ user_id: p.mstrid, match_id: marketDBVal.matchId, data: {} })
        )

        await Redis.publish('ALL_BETS_UPDATE_DATA', JSON.stringify({ user_id: p.mstrid, data: {} }))
      }

      await Redis.del(userKey)

      return response.json({
        status: true,
        message: betPlaceVal[0].retMess,
        debug: 'check3'
      })
    } else {
      await Database.from('tblbets').where('MstCode', betPlaceVal[0].LID).delete()

      await UserService.updateLiability(
        [{ id: authUser?.mstrid }],
        { betId: betPlaceVal[0].LID, category: 'MARKET' },
        'delete'
      )

      // Reverse the ancestor exposure for the rejected/deleted bet.
      await this.maintainAncestorMarketExposure(
        {
          matchId: Number(marketDBVal.matchId),
          marketId: data.marketId,
          selectionId: Number(data.selectionId),
          stake: data.stake,
          pl: Number(profitLoss),
          isBack: data.isBack,
          ancestors: [
            { accountId: Number(dealerId), sharePct: Number(dealerPartnership) },
            { accountId: Number(masterId), sharePct: Number(masterPartnership) },
            { accountId: Number(superMasterId), sharePct: Number(superMasterPartnership) },
            { accountId: Number(subAdminId), sharePct: Number(subAdminPartnership) },
            { accountId: Number(superAdminId), sharePct: Number(superAdminPartnership) },
            { accountId: Number(companyId), sharePct: Number(companyPartnership) },
            { accountId: Number(superDuperAdminId), sharePct: Number(superDuperAdminPartnership) },
          ],
        },
        -1
      )

      await Redis.del(userKey)
      return response.json({
        status: false,
        message: betPlaceVal[0].retMess,
        debug: 'check4'
      })
    }
  }

  public async fancy({ request, authUser, response }: HttpContextContract) {
    const data = await request.validate({
      schema: schema.create({
        matchId: schema.number(),
        price: schema.number(), //price
        side: schema.number(), // back or lay
        stake: schema.number(), //stack value
        fancyId: schema.number(),
        deviceDesc: schema.string(),
        sessSizeYes: schema.number(),
        sessSizeNo: schema.number(),
      }),
    })

    const isLocked = await Redis.get('declaring_result:global')
    if (isLocked) {
      return response.badRequest({
        message:
          'Bets are temporarily disabled while result is being declared. Please try again shortly.',
      })
    }

    const liabilityKey = 'USER_LIABILITY' + authUser?.mstrid
    if ((await Redis.incr(liabilityKey)) > 1) {
      await Redis.del(liabilityKey)
      await UserService.updateLiability([{ id: authUser?.mstrid }])
    }

    const userKey = 'USER_BET:' + authUser?.mstrid
    const check = await this.checkUser(authUser, userKey)
    if (check) {
      return response.json({
        status: false,
        message: check
      })
    }

    const parentData: any = await UserService.parents(authUser.mstrid)
    const parents = parentData.map((i: any) => i.mstrid)

    const currentFancy = await Database.from('matchfancy')
      .innerJoin('matchmst', 'matchfancy.MatchID', 'matchmst.MstCode')
      .joinRaw(
        `LEFT JOIN user_sport_limit as usl ON usl.id = (SELECT id FROM user_sport_limit WHERE user_id IN (${parents.toString()}) AND sport_id = matchfancy.SprtId AND type = 'fancy' ORDER BY user_id DESC LIMIT 1)`
      )
      .joinRaw(
        `LEFT JOIN fancy_settings as fs ON fs.id = (SELECT id FROM fancy_settings WHERE user_id IN (${parents.toString()}) AND fancy_id = matchfancy.ID ORDER BY user_id DESC LIMIT 1)`
      )
      .whereNull('matchfancy.result')
      .whereNotIn(
        'matchfancy.SprtId',
        Database.from('blocked_sports')
          .select('sport_id')
          .whereNot('user_id', authUser.mstrid)
          .whereIn('user_id', authUser.parentIds)
      )
      .whereNotIn(
        'matchmst.MstCode',
        Database.from('user_deactive_match')
          .select('match_id')
          .whereIn('user_id', authUser.parentIds)
      )
      .whereNotIn(
        'matchfancy.Id',
        Database.from('blocked_fancies').select('fancy_id').whereIn('user_id', authUser.parentIds)
      )
      .where('matchfancy.Id', data.fancyId)
      .select(
        'matchfancy.*',
        'matchmst.matchName',
        Database.raw('COALESCE(usl.bet_delay, 0) as betDelay'),
        Database.raw(
          'ROUND(GREATEST(matchfancy.MinStake, COALESCE(usl.min_stake, 0), COALESCE(fs.min_stack, 0)),0) as min_stack'
        ),
        Database.raw(
          'ROUND(LEAST(matchfancy.MaxStake, COALESCE(usl.max_stake, 5000000), COALESCE(fs.max_stack, 0)),0) as max_stack'
        )
      )
      .first()

    if (!currentFancy) {
      await Redis.del(userKey)
      return response.json({
        status: false,
        message: 'Fancy not found.',
      })
    }

    const lock = await Cache.rememberForever('system_bet_lock', async () => {
      return false
    })

    if (lock) {
      await Redis.del(userKey)
      return response.json({
        status: false,
        message: `Bet was not placed! Try again later.`,
      })
    }

    const minStakes: any = currentFancy.min_stack
    const maxStakes: any = currentFancy.max_stack

    if (minStakes > data.stake || (maxStakes > 0 && maxStakes < data.stake)) {
      await Redis.del(userKey)
      return response.json({
        status: false,
        message: 'Please check the stake limit.',
      })
    }

    //get sum session liability
    const { sum_session_liability: sumLiability } = await Database.from('bet_entry')
      .where('fancyId', data.fancyId)
      .where('userId', authUser?.mstrid)
      .sum('bet_value as sum_session_liability')
      .first()

    const sessionLiability = +sumLiability + data.stake

    if (data.stake <= 0) {
      await Redis.del(userKey)
      return response.json({
        status: false,
        message: 'Stack cannot be zero.',
      })
    } else if (
      currentFancy.max_session_bet_liability > 0 &&
      currentFancy.max_session_bet_liability != '' &&
      data.stake > currentFancy.max_session_bet_liability
    ) {
      await Redis.del(userKey)
      return response.json({
        status: false,
        message: 'Max Session bet liability is ' + currentFancy.max_session_bet_liability,
      })
    } else if (
      currentFancy.max_session_bet_liability > 0 &&
      sessionLiability > currentFancy.max_session_bet_liability
    ) {
      await Redis.del(userKey)
      return response.json({
        status: false,
        message: 'Max Session bet liability is ' + sessionLiability,
      })
    } else if (!authUser?.mstrid) {
      await Redis.del(userKey)
      return response.json({
        status: false,
        message: 'Something went wrong.',
      })
    } else if (authUser?.account_closed == 0) {
      await Redis.del(userKey)
      return response.json({
        status: false,
        message: 'Your account is closed.',
      })
    } else if (data.price < 1) {
      await Redis.del(userKey)
      return response.json({
        status: false,
        message: 'Run must be greater than 0.',
      })
    } else if (authUser?.mstrlock == 0) {
      await Redis.del(userKey)
      return response.json({
        status: false,
        message: 'Your account is in active.',
      })
    } else if (authUser?.bet_lock == 0) {
      await Redis.del(userKey)
      return response.json({
        status: false,
        message: 'Your betting is locked.',
      })
    } else if (maxStakes > 0 && maxStakes < data.stake) {
      await Redis.del(userKey)
      return response.json({
        status: false,
        message: 'Your stake limit is over.',
      })
    }

    await this.sleep(parseInt(currentFancy.betDelay) * 1000)

    let fancyData: any = await Cache.use('main').get('FancyId:' + currentFancy.MatchID)
    if (!fancyData) {
      await Redis.del(userKey)
      return response.json({
        status: false,
        message: 'Fancy not found.',
      })
    }

    if (fancyData.updated_at) {
      const diffInSeconds = Math.floor(
        Math.abs(new Date().getTime() - new Date(fancyData.updated_at).getTime()) / 1000
      )
      if (diffInSeconds > 5) {
        await Redis.del(userKey)
        return response.json({
          status: false,
          message: 'Run changed.',
        })
      }
    }

    let f: any
    if (fancyData.hasOwnProperty('session')) {
      f = fancyData.session.find(
        (el: any) => el.SelectionId.toString() == currentFancy.ind_fancy_selection_id.toString()
      )
      if (!f) {
        await Redis.del(userKey)
        return response.json({
          status: false,
          message: 'Fancy not found.',
        })
      }
      if (data.side == 0) {
        if (
          !(f.BackPrice1 == data.price && f.BackSize1 == data.sessSizeYes && f.GameStatus == '')
        ) {
          await Redis.del(userKey)
          return response.json({
            status: false,
            message: 'Runs changed or game status changed or volume changed.',
          })
        }
      } else {
        if (!(f.LayPrice1 == data.price && f.LaySize1 == data.sessSizeNo && f.GameStatus == '')) {
          await Redis.del(userKey)
          return response.json({
            status: false,
            message: 'Runs changed or game status changed or volume changed.',
          })
        }
      }
    } else {
      await Redis.del(userKey)
      return response.json({
        status: false,
        message: 'Fancy not found.',
      })
    }

    let { mstrid: superDuperAdminId, mstruserid: superDuperAdminName } = parentData.find(
      (el: any) => el.usetype == 0
    ) ?? {
      mstrid: 0,
      mstruserid: '',
    }
    let { mstrid: companyId, mstruserid: companyName } = parentData.find(
      (el: any) => el.usetype == 11
    ) ?? {
      mstrid: 0,
      mstruserid: '',
    }
    let { mstrid: superAdminId, mstruserid: superAdminName } = parentData.find(
      (el: any) => el.usetype == 10
    ) ?? {
      mstrid: 0,
      mstruserid: '',
    }
    let { mstrid: subAdminId, mstruserid: subAdminName } = parentData.find(
      (el: any) => el.usetype == 9
    ) ?? {
      mstrid: 0,
      mstruserid: '',
    }
    let { mstrid: superMasterId, mstruserid: superMasterName } = parentData.find(
      (el: any) => el.usetype == 8
    ) ?? {
      mstrid: 0,
      mstruserid: '',
    }
    let { mstrid: masterId, mstruserid: masterName } = parentData.find(
      (el: any) => el.usetype == 1
    ) ?? {
      mstrid: 0,
      mstruserid: '',
    }
    let { mstrid: dealerId, mstruserid: dealerName } = parentData.find(
      (el: any) => el.usetype == 2
    ) ?? {
      mstrid: 0,
      mstruserid: '',
    }

    let { mstruserid: userName } = parentData.find((el: any) => el.usetype == 3) ?? {
      mstruserid: '',
    }
    let userId = authUser?.mstrid

    let sportName = 'cricket'

    if (currentFancy.SprtId == 1) {
      sportName = 'soccer'
    } else if (currentFancy.SprtId == 2) {
      sportName = 'tennis'
    } else if (currentFancy.SprtId == 11) {
      sportName = 'virtual_casino'
    } else if (currentFancy.SprtId == 6) {
      sportName = 'election'
    } else if (currentFancy.SprtId == 77) {
      sportName = 'binary'
    }

    const partnershipData: any = await Cache.rememberForever(
      'partnership:' + authUser.mstrid,
      async () => {
        return await Database.from('tblpartner').where('UserID', authUser.mstrid).firstOrFail()
      }
    )

    const superDuperAdminPartnership = partnershipData['super_duper_admin_' + sportName]
    const companyPartnership = partnershipData['company_' + sportName]
    const superAdminPartnership = partnershipData['super_admin_' + sportName]
    const subAdminPartnership = partnershipData['sub_admin_' + sportName]
    const superMasterPartnership = partnershipData['super_master_' + sportName]
    const masterPartnership = partnershipData['master_' + sportName]
    const dealerPartnership = partnershipData['dealer_' + sportName]

    // const totalPartnership =
    //   superDuperAdminPartnership +
    //   companyPartnership +
    //   superAdminPartnership +
    //   subAdminPartnership +
    //   superMasterPartnership +
    //   masterPartnership +
    //   dealerPartnership

    // response.abortIf(totalPartnership < 100, {
    //   message: 'There is an issue in partnership.',
    // })

    const betPlaceVal = await Sp.call(
      '_bet_place_fancy(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',
      [
        data.stake,
        data.side,
        data.price,
        currentFancy.TypeID,
        currentFancy.MatchID,
        data.fancyId,
        userId,
        authUser?.parentId,
        dealerId,
        masterId,
        superMasterId,
        subAdminId,
        superAdminId,
        companyId,
        superDuperAdminId,
        userName,
        dealerName,
        masterName,
        superMasterName,
        subAdminName,
        superAdminName,
        companyName,
        superDuperAdminName,
        superDuperAdminPartnership,
        companyPartnership,
        superAdminPartnership,
        subAdminPartnership,
        superMasterPartnership,
        masterPartnership,
        dealerPartnership,
        new Date(),
        userId,
        currentFancy.ind_fancy_selection_id,
        currentFancy.HeadName,
        f.BackPrice1,
        f.LayPrice1,
        currentFancy.SprtId,
        request.ip(),
        currentFancy.pointDiff,
        data.deviceDesc,
        null,
        data.sessSizeYes,
        data.sessSizeNo,
      ]
    )

    if (betPlaceVal[0].resultV == 0) {

      const companyData = await Database.rawQuery(`
        WITH RECURSIVE user_tree AS (
          SELECT mstrid, parentId, usetype
          FROM createmaster
          WHERE mstrid = ?

          UNION ALL

          SELECT t.mstrid, t.parentId, t.usetype
          FROM createmaster t
          INNER JOIN user_tree ut ON t.mstrid = ut.parentId
        )
        SELECT mstrid AS company_id
        FROM user_tree
        WHERE usetype = 11
        LIMIT 1
      `, [authUser?.mstrid]);

      console.log('Company Data:', companyData);

      const message = await UserService.checkBalanceAfterBet(authUser, betPlaceVal)
      if (message) {
        await Redis.del(userKey)
        return response.json({
          status: false,
          message: 'Insufficient balance!',
        })
      }

      await Mongo.collection('fancy_bets').insertOne({
        Description: `Cricket>${currentFancy.matchName}>${currentFancy.HeadName}`,
        IsMatched: 0,
        Liability: '0',
        MarketId: currentFancy.TypeID,
        MatchId: currentFancy.MatchID,
        MstCode: betPlaceVal[0].LID,
        MstDate: new Date(), // or pull match start time if available
        Odds: data.price.toString(),
        P_L: data.stake.toLocaleString(), // "1,000"
        Profit: '0',
        STATUS: 'Open',
        SelectionId: data.fancyId,
        Stack: data.stake,
        Type: data.side == 0 ? 'Back' : 'Lay',
        UserId: authUser?.mstrid,
        companyId: companyData?.[0]?.[0]?.company_id,
        UserName: authUser?.mstruserid,
        ip: request.ip(),
        isBack: data.side == 0 ? 0 : 1,
        is_fancy: 1,
        marketName: null,
        matchName: currentFancy.matchName,
        selectionName: `${currentFancy.HeadName} (${data.sessSizeYes}-${data.sessSizeNo})`,
        sportName: sportName.charAt(0).toUpperCase() + sportName.slice(1),
        sportsId: currentFancy.SprtId,
        void: 0,
        volume: data.side == 0 ? data.sessSizeYes : data.sessSizeNo,

        // Additional fields to match relational DB
        DealerId: dealerId,
        DealerName: dealerName,
        MasterId: masterId,
        MasterName: masterName,
        SuperMasterId: superMasterId,
        SuperMasterName: superMasterName,
        SubAdminId: subAdminId,
        SubAdminName: subAdminName,
        SuperAdminId: superAdminId,
        SuperAdminName: superAdminName,
        CompanyId: companyId,
        CompanyName: companyName,
        SuperDuperAdminId: superDuperAdminId,
        SuperDuperAdminName: superDuperAdminName,
      })
      //fancy update topic
      // await Bull.add('UpdateFancy', {
      //   SessInptYes: f.BackPrice1,
      //   SessInptNo: f.LayPrice1,
      //   fancyId: data.fancyId,
      // }, { removeOnComplete: true })

      const userIds = [
        dealerId,
        masterId,
        superMasterId,
        subAdminId,
        superAdminId,
        companyId,
        superDuperAdminId,
      ]

      await Bull.add(
        'FancyBook',
        {
          fancyId: currentFancy.ID,
          matchId: currentFancy.MatchID,
          userIds: userIds,
        },
        { removeOnComplete: true }
      )

      // await Bull.add('UpdateLiability', [{id: user?.mstrid}], { removeOnComplete: true });
      const mongoData = {
        type: `BET PLACE for ${data.stake}`,
        category: 'FANCY',
        userId: authUser?.mstrid,
        companyId: companyData?.[0]?.[0]?.company_id,
        username: authUser?.mstruserid,
        betId: betPlaceVal[0].LID,
        betType: data.side == 1 ? 'LAY' : 'BACK', // BACK_LAY_TYPE 
        volume: data.price,
        beforeBalance: authUser?.balance,
        beforeLiability: authUser?.liability,
        matchName: currentFancy.matchName,
        selectionName: currentFancy.HeadName,
        matchId: data.matchId || 0,
      }
      await UserService.updateLiability([{ id: authUser?.mstrid }], mongoData, 'add')

      for (const p of parentData) {
        await Redis.publish(
          'BETS_UPDATE_DATA',
          JSON.stringify({ user_id: p.mstrid, match_id: data.matchId, data: {} })
        )

        await Redis.publish('ALL_BETS_UPDATE_DATA', JSON.stringify({ user_id: p.mstrid, data: {} }))
      }

      await Redis.del(userKey)

      for (const id of parents) {
        for (const k of await Redis.keys(`fancy_position:${id}:*`)) {
          await Redis.del(k)
        }
      }

      return response.json({
        status: true,
        message: 'Bet placed Successfully.',
      })
    } else {
      await Database.from('bet_entry').where('bet_id', betPlaceVal[0].LID).delete()

      await UserService.updateLiability(
        [{ id: authUser?.mstrid }],
        { betId: betPlaceVal[0].LID, category: 'FANCY' },
        'delete'
      )
      await Redis.del(userKey)
      return response.json({
        status: false,
        message: betPlaceVal[0].retMess,
      })
    }
  }

  public async line({ request, authUser, response }: HttpContextContract) {
    const data = await request.validate({
      schema: schema.create({
        price: schema.number(), //price
        side: schema.number(), // back or lay
        stake: schema.number(), //stack value
        typeId: schema.number(),
        matchId: schema.number(),
        marketId: schema.string(),
        fancyId: schema.number(),
        selectionId: schema.string(),
        fHeadName: schema.string(),
        sessInpYes: schema.number(),
        sessInpNo: schema.number(),
        sportId: schema.number(),
        pointDiff: schema.number(),
        deviceDesc: schema.string(),
        sessSizeYes: schema.number(),
        sessSizeNo: schema.number(),
      }),
    })

    const liabilityKey = 'USER_LIABILITY' + authUser?.mstrid
    if ((await Redis.incr(liabilityKey)) > 1) {
      await Redis.del(liabilityKey)
      await UserService.updateLiability([{ id: authUser?.mstrid }])
    }

    const userKey = 'USER_BET:' + authUser?.mstrid
    const check = await this.checkUser(authUser, userKey)
    if (check) {
      return response.json({
        status: false,
        message: check,
      })
    }

    const parentData: any = await UserService.parents(authUser.mstrid)

    const parents = parentData.map((i: any) => i.mstrid)

    const currentFancy = await Database.from('matchfancy')
      .innerJoin('matchmst', 'matchfancy.MatchID', 'matchmst.MstCode')
      .joinRaw(
        `LEFT JOIN user_sport_limit as usl ON usl.id = (SELECT id FROM user_sport_limit WHERE user_id IN (${parents.toString()}) AND sport_id = matchfancy.SprtId AND type = 'fancy' ORDER BY user_id DESC LIMIT 1)`
      )
      .joinRaw(
        `LEFT JOIN fancy_settings as fs ON fs.id = (SELECT id FROM fancy_settings WHERE user_id IN (${parents.toString()}) AND fancy_id = matchfancy.ID ORDER BY user_id DESC LIMIT 1)`
      )
      .whereNull('matchfancy.result')
      .whereNotIn(
        'matchfancy.SprtId',
        Database.from('blocked_sports')
          .select('sport_id')
          .whereNot('user_id', authUser.mstrid)
          .whereIn('user_id', authUser.parentIds)
      )
      .whereNotIn(
        'matchmst.MstCode',
        Database.from('user_deactive_match')
          .select('match_id')
          .whereIn('user_id', authUser.parentIds)
      )
      .whereNotIn(
        'matchfancy.Id',
        Database.from('blocked_fancies').select('fancy_id').whereIn('user_id', authUser.parentIds)
      )
      .where('matchfancy.Id', data.fancyId)
      .select(
        'matchfancy.*',
        'matchmst.matchName',
        'matchmst.line_fancy_delay AS betDelay',
        'matchmst.line_fancy_volume AS volumeMultiplier',
        Database.raw(
          'ROUND(GREATEST(matchfancy.MinStake, COALESCE(usl.min_stake, 0), COALESCE(fs.min_stack, 0)),0) as min_stack'
        ),
        Database.raw(
          'ROUND(LEAST(matchfancy.MaxStake, COALESCE(usl.max_stake, 5000000), COALESCE(fs.max_stack, 0)),0) as max_stack'
        )
      )
      .first()

    if (!currentFancy) {
      await Redis.del(userKey)
      return response.json({
        status: false,
        message: 'Fancy not found.',
      })
    }

    const lock = await Cache.rememberForever('system_bet_lock', async () => {
      return false
    })

    if (lock) {
      await Redis.del(userKey)
      return response.json({
        status: false,
        message: `Bet was not placed! Try again later.`,
      })
    }

    const minStakes: any = currentFancy.min_stack
    const maxStakes: any = currentFancy.max_stack

    if (minStakes > data.stake || (maxStakes > 0 && maxStakes < data.stake)) {
      await Redis.del(userKey)
      return response.json({
        status: false,
        message: 'Please check the stake limit.',
      })
    }

    //get sum session liability
    const { sum_session_liability: sumLiability } = await Database.from('bet_entry')
      .where('fancyId', data.fancyId)
      .where('userId', authUser?.mstrid)
      .sum('bet_value as sum_session_liability')
      .first()

    const sessionLiability = +sumLiability + data.stake
    if (data.stake <= 0) {
      await Redis.del(userKey)
      return response.json({
        status: false,
        message: 'Stack cannot be zero.',
      })
    } else if (
      currentFancy.max_session_bet_liability > 0 &&
      currentFancy.max_session_bet_liability != '' &&
      data.stake > currentFancy.max_session_bet_liability
    ) {
      await Redis.del(userKey)
      return response.json({
        status: false,
        message: 'Max Session bet liability is ' + currentFancy.max_session_bet_liability,
      })
    } else if (
      currentFancy.max_session_bet_liability > 0 &&
      sessionLiability > currentFancy.max_session_bet_liability
    ) {
      await Redis.del(userKey)
      return response.json({
        status: false,
        message: 'Max Session bet liability is ' + sessionLiability,
      })
    } else if (!authUser?.mstrid) {
      await Redis.del(userKey)
      return response.json({
        status: false,
        message: 'Something went wrong.',
      })
    } else if (authUser?.account_closed == 0) {
      await Redis.del(userKey)
      return response.json({
        status: false,
        message: 'Your account is closed.',
      })
    } else if (data.price < 1) {
      await Redis.del(userKey)
      return response.json({
        status: false,
        message: 'Run must be greater than 0.',
      })
    } else if (authUser?.mstrlock == 0) {
      await Redis.del(userKey)
      return response.json({
        status: false,
        message: 'Your account is in active.',
      })
    } else if (authUser?.bet_lock == 0) {
      await Redis.del(userKey)
      return response.json({
        status: false,
        message: 'Your betting is locked.',
      })
    } else if (maxStakes > 0 && maxStakes < data.stake) {
      await Redis.del(userKey)
      return response.json({
        status: false,
        message: 'Your Stake limit is over.',
      })
    }

    await this.sleep(parseInt(currentFancy.betDelay) * 1000)

    let market = await Cache.use('main').get('marketId:' + currentFancy.market_id)
    if (!market) {
      await Redis.del(userKey)
      return response.json({
        status: false,
        message: 'Market not found.',
      })
    }

    if (market.updated_at) {
      const diffInSeconds = Math.floor(
        Math.abs(new Date().getTime() - new Date(market.updated_at).getTime()) / 1000
      )
      if (diffInSeconds > 5) {
        await Redis.del(userKey)
        return response.json({
          status: false,
          message: 'Run changed.',
        })
      }
    }

    //check market status
    if (market.status == 'CLOSED' && market.status == 'SUSPENDED') {
      await Redis.del(userKey)
      return response.json({
        status: false,
        message: 'Market ' + market.status,
      })
    }

    let currentRunner = market.runners.find(
      (x) => x.selectionId.toString() == data.selectionId.toString()
    )

    if (!currentRunner) {
      await Redis.del(userKey)
      return response.json({
        status: false,
        message: 'Bet not available.',
      })
    }

    if (currentRunner.status != 'ACTIVE') {
      await Redis.del(userKey)
      return response.json({
        status: false,
        message: 'Runner status changed.',
      })
    }

    let price = 0
    let volume = 0

    let volumeMultiplier: any = parseInt(currentFancy.volumeMultiplier)

    if (data.side == 0) {
      //back
      if (currentRunner.ex.availableToBack.length == 0) {
        await Redis.del(userKey)
        return response.json({
          status: false,
          message: 'Back not available.',
        })
      }

      price = parseFloat(currentRunner.ex.availableToBack[0].price)
      volume = parseFloat(currentRunner.ex.availableToBack[0].size) * volumeMultiplier
    } else {
      //lay
      if (currentRunner.ex.availableToLay.length == 0) {
        await Redis.del(userKey)
        return response.json({
          status: false,
          message: 'Lay not available.',
        })
      }

      price = parseFloat(currentRunner.ex.availableToLay[0].price)
      volume = parseFloat(currentRunner.ex.availableToLay[0].size) * volumeMultiplier
    }

    if (Math.floor(price) !== data.price) {
      await Redis.del(userKey)
      return response.json({
        status: false,
        message: 'Runs changed.',
      })
    }

    if (volume < 100) {
      await Redis.del(userKey)
      return response.json({
        status: false,
        message: 'Volume is less.',
      })
    }

    if (volume <= data.stake) {
      data.stake = volume
    }

    let { mstrid: superDuperAdminId, mstruserid: superDuperAdminName } = parentData.find(
      (el: any) => el.usetype == 0
    ) ?? {
      mstrid: 0,
      mstruserid: '',
    }
    let { mstrid: companyId, mstruserid: companyName } = parentData.find(
      (el: any) => el.usetype == 11
    ) ?? {
      mstrid: 0,
      mstruserid: '',
    }
    let { mstrid: superAdminId, mstruserid: superAdminName } = parentData.find(
      (el: any) => el.usetype == 10
    ) ?? {
      mstrid: 0,
      mstruserid: '',
    }
    let { mstrid: subAdminId, mstruserid: subAdminName } = parentData.find(
      (el: any) => el.usetype == 9
    ) ?? {
      mstrid: 0,
      mstruserid: '',
    }
    let { mstrid: superMasterId, mstruserid: superMasterName } = parentData.find(
      (el: any) => el.usetype == 8
    ) ?? {
      mstrid: 0,
      mstruserid: '',
    }
    let { mstrid: masterId, mstruserid: masterName } = parentData.find(
      (el: any) => el.usetype == 1
    ) ?? {
      mstrid: 0,
      mstruserid: '',
    }
    let { mstrid: dealerId, mstruserid: dealerName } = parentData.find(
      (el: any) => el.usetype == 2
    ) ?? {
      mstrid: 0,
      mstruserid: '',
    }

    let { mstruserid: userName } = parentData.find((el: any) => el.usetype == 3) ?? {
      mstruserid: '',
    }
    let userId = authUser?.mstrid

    let sportName = 'cricket'

    if (currentFancy.SprtId == 1) {
      sportName = 'soccer'
    } else if (currentFancy.SprtId == 2) {
      sportName = 'tennis'
    } else if (currentFancy.SprtId == 11) {
      sportName = 'virtual_casino'
    } else if (currentFancy.SprtId == 6) {
      sportName = 'election'
    } else if (currentFancy.SprtId == 77) {
      sportName = 'binary'
    }

    const partnershipData: any = await Cache.rememberForever(
      'partnership:' + authUser.mstrid,
      async () => {
        return await Database.from('tblpartner').where('UserID', authUser.mstrid).firstOrFail()
      }
    )

    const superDuperAdminPartnership = partnershipData['super_duper_admin_' + sportName]
    const companyPartnership = partnershipData['company_' + sportName]
    const superAdminPartnership = partnershipData['super_admin_' + sportName]
    const subAdminPartnership = partnershipData['sub_admin_' + sportName]
    const superMasterPartnership = partnershipData['super_master_' + sportName]
    const masterPartnership = partnershipData['master_' + sportName]
    const dealerPartnership = partnershipData['dealer_' + sportName]

    // const totalPartnership =
    //   superDuperAdminPartnership +
    //   companyPartnership +
    //   superAdminPartnership +
    //   subAdminPartnership +
    //   superMasterPartnership +
    //   masterPartnership +
    //   dealerPartnership

    // response.abortIf(totalPartnership < 100, {
    //   message: 'There is an issue in partnership.',
    // })

    data.sessSizeYes = 100
    data.sessSizeNo = 100
    const betPlaceVal = await Sp.call(
      '_bet_place_fancy(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',
      [
        data.stake,
        data.side,
        data.price,
        data.typeId,
        data.matchId,
        data.fancyId,
        userId,
        authUser?.parentId,
        dealerId,
        masterId,
        superMasterId,
        subAdminId,
        superAdminId,
        companyId,
        superDuperAdminId,
        userName,
        dealerName,
        masterName,
        superMasterName,
        subAdminName,
        superAdminName,
        companyName,
        superDuperAdminName,
        superDuperAdminPartnership,
        companyPartnership,
        superAdminPartnership,
        subAdminPartnership,
        superMasterPartnership,
        masterPartnership,
        dealerPartnership,
        new Date(),
        userId,
        data.selectionId,
        data.fHeadName,
        data.sessInpYes,
        data.sessInpNo,
        data.sportId,
        request.ip(),
        data.pointDiff,
        data.deviceDesc,
        null,
        data.sessSizeYes,
        data.sessSizeNo,
      ]
    )

    if (betPlaceVal[0].resultV == 0) {
      const message = await UserService.checkBalanceAfterBet(authUser, betPlaceVal)
      if (message) {
        await Redis.del(userKey)
        return response.json({
          status: false,
          message: 'Insufficient balance!',
        })
      }

      // fancy update topic
      // await Bull.add('UpdateFancy', {
      //   SessInptYes: data.sessInpYes,
      //   SessInptNo: data.sessInpNo,
      //   fancyId: data.fancyId,
      // }, { removeOnComplete: true })

      const userIds = [
        dealerId,
        masterId,
        superMasterId,
        subAdminId,
        superAdminId,
        companyId,
        superDuperAdminId,
      ]

      await Bull.add(
        'FancyBook',
        {
          fancyId: currentFancy.ID,
          matchId: currentFancy.MatchID,
          userIds: userIds,
        },
        { removeOnComplete: true }
      )

      // await Bull.add('UpdateLiability', [{id: user?.mstrid}], { removeOnComplete: true });

      const mongoData = {
        type: `BET PLACE for ${data.stake}`,
        category: 'FANCY',
        userId: authUser?.mstrid,
        username: authUser?.mstruserid,
        betId: betPlaceVal[0].LID,
        beforeBalance: authUser?.balance,
        beforeLiability: authUser?.liability,
        matchName: currentFancy.matchName,
        selectionName: currentFancy.HeadName,
        betType: data.side == 1 ? 'LAY' : 'BACK', // BACK_LAY_TYPE 
        volume: data.price,
        matchId: data.matchId || 0,
      }

      await UserService.updateLiability([{ id: authUser?.mstrid }], mongoData, 'add')

      for (const p of parentData) {
        await Redis.publish(
          'BETS_UPDATE_DATA',
          JSON.stringify({ user_id: p.mstrid, match_id: data.matchId, data: {} })
        )

        await Redis.publish('ALL_BETS_UPDATE_DATA', JSON.stringify({ user_id: p.mstrid, data: {} }))
      }

      await Redis.del(userKey)

      for (const id of parents) {
        for (const k of await Redis.keys(`fancy_position:${id}:*`)) {
          await Redis.del(k)
        }
      }

      return response.json({
        status: true,
        message: 'Bet placed Successfully.',
      })
    } else {
      await Database.from('bet_entry').where('bet_id', betPlaceVal[0].LID).delete()
      await UserService.updateLiability(
        [{ id: authUser?.mstrid }],
        { betId: betPlaceVal[0].LID, category: 'FANCY' },
        'delete'
      )

      await Redis.del(userKey)
      return response.json({
        status: false,
        message: betPlaceVal[0].retMess,
      })
    }
  }

  private sleep(ms: number) {
    return new Promise((resolve) => {
      setTimeout(resolve, ms)
    })
  }

  private async checkUser(authUser, userKey) {
    if ((await Redis.incr(userKey)) > 1) {
      return 'Previous bet is in process.'
    }

    await Redis.expire(userKey, 120)

    if (!authUser) {
      await Redis.del(userKey)
      return 'Something went wrong.'
    }

    if (authUser?.usetype != 3) {
      await Redis.del(userKey)
      return 'Invalid request.'
    }

    return false
  }
}
