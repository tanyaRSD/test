import Cache from '@ioc:Adonis/Addons/Cache'
import { HttpContextContract } from '@ioc:Adonis/Core/HttpContext'
import { rules, schema } from '@ioc:Adonis/Core/Validator'
import Database from '@ioc:Adonis/Lucid/Database'
import Payment from 'App/Services/Payment'
import moment from 'moment'

export default class RegisterRequest {
  public async getRegisterRequests({ request, authUser, response }: HttpContextContract) {
    const status = request.input('status', null)
    const limit = request.input('limit', 50)
    const page = request.input('page', 1)

    if (authUser.usetype == 2) {
      const registerRequests = await Database.from('register_requests')
        .leftJoin('request_users', 'register_requests.user_id', 'request_users.mstrid')
        .select(
          'register_requests.*',
          'request_users.mstrname',
          'request_users.mstruserid',
          'request_users.phone'
        )
        .where('status', status)
        .orderBy('date', 'desc')
        .paginate(page, limit)

      return response.json({
        status: true,
        data: registerRequests,
      })
    } else {
      return response.badRequest({
        message: "You don't have permission.",
      })
    }
  }

  public async request({ request, response }: HttpContextContract) {
    const data = await request.validate({
      schema: schema.create({
        user_id: schema.number(),
        deposit_amount: schema.number(),
        domain: schema.string([
          rules.url({
            protocols: ['http', 'https'],
          }),
          rules.normalizeUrl({
            stripWWW: true,
            removeSingleSlash: true,
          }),
        ]),
        type: schema.number(),
      }),
    })

    const user = await Database.from('request_users').where('mstrid', data.user_id).first()

    response.abortIf(!user, {
      status: false,
      message: 'User does not exist',
    })

    const pendingRequest = await Database.from('register_requests')
      .where('user_id', data.user_id)
      .where('status', 'PENDING')
      .first()

    response.abortIf(pendingRequest, {
      message: 'Requests are pending.',
      status: false,
    })

    const domain: any = await Database.from('request_domains').where('value', data.domain).first()

    response.abortIf(!domain, {
      message: 'Domain not found.',
      status: false,
    })

    response.abortIf(data.deposit_amount < 1000, {
      message: 'Minimum deposit amount is 1000.',
      status: false,
    })

    await Database.table('register_requests').insert({
      user_id: data.user_id,
      deposit_amount: data.deposit_amount,
      domain: data.domain,
      status: 'PENDING',
      date: new Date(),
      type: data.type,
    })

    return response.json({
      message: 'Request Received Successfully',
      status: true,
    })
  }

  public async deposit({ request, authUser, response }: HttpContextContract) {
    let data: any

    data = await request.validate({
      schema: schema.create({
        is_utr: schema.boolean(),
        // amount: schema.number([rules.range(1, 1000000)]),
        amount: schema.number(),
        acc_type: schema.number(),
        senderName: schema.string.optional(),
        receiverName: schema.string.optional(),
        screenShotsFile: schema.file({
          size: '5mb',
          extnames: ['jpg', 'png', 'jpeg', 'JPEG'],
        }),
        utr_no: schema.string.optional(),
        domain: schema.string([
          rules.url({
            protocols: ['http', 'https'],
          }),
          rules.normalizeUrl({
            stripWWW: true,
            removeSingleSlash: true,
          }),
        ]),
      }),
    })

    // const dealer: any = await Database.from('createmaster')
    //   .where('mstrid', authUser.parentId || 3)
    //   .select('*')
    //   .firstOrFail()

    // await this.updateUserPendingRequests(authUser.mstrid)

    if (data.amount < 1) {
      return response.badRequest({
        message: 'Amount must be positive',
      })
    }

    const pendingRequests = await this.getUserPendingRequests(authUser.mstrid)

    if (pendingRequests) {
      return response.badRequest({
        message: 'Previous requests are pending.',
      })
    }

    // if (depositLimit) {
    //   const reqPerDay = await Database.from('bank_entry')
    //     .where('user_id', authUser.mstrid)
    //     .where('req_date', '>=', DateTime.now().toFormat('yyyy-MM-dd') + 'T00:00:00')
    //     .where('req_date', '<=', DateTime.now().toFormat('yyyy-MM-dd') + 'T23:59:59')
    //     .where('type', '1')
    //     .where('status', 'COMPLETE')
    //     .count('* as total')
    //     .first()

    //   if (reqPerDay.total >= 3) {
    //     return response.badRequest({
    //       message: 'Maximum deposit request per day exceeded!',
    //     })
    //   }
    // }

    const parentSettings = await Cache.rememberForever(
      'dealer_setting:' + authUser.parentId,
      async () => {
        return {
          fast_withdraw: 0,
          min_deposit: 10,
          max_deposit: 1000000,
          min_withdraw: 10,
          max_withdraw: 1000000,
          deposit_bonus: 0,
        }
      }
    )
    if (parentSettings) {
      const minDeposit = parentSettings.min_deposit
      const maxDeposit = parentSettings.max_deposit
      if (minDeposit > 0 && data.amount < minDeposit) {
        return response.badRequest({
          message: 'Minimum deposit value is.' + minDeposit,
        })
      } else if (maxDeposit > 0 && data.amount > maxDeposit) {
        return response.badRequest({
          message: 'Maximun deposit value is.' + maxDeposit,
        })
      }
    }

    data['type'] = 1
    data['status'] = 'PENDING'

    const bank = await Database.from('bank_details')
      .where('id', data.acc_type)
      .where('mstrid', authUser.parentId)
      .firstOrFail()

    const payment: any = Payment.list.find((el: any) => el.id == bank.payment)

    if (!payment) {
      return response.badRequest({
        message: 'Please add this payment method.',
      })
    }

    bank.paymentName = payment.name

    let insertData: any = {
      sender_name: data.senderName,
      receiver_name: data.receiverName,
      user_id: authUser.mstrid, // 1
      dealer_id: authUser.parentId,
      status: 'PENDING', // 1
      type: 1, // 1
      date: moment().format('YYYY-MM-DD HH:mm:ss'), // date
      amount: data.amount, // amount
      acc_type: data.acc_type,
      bank_details: JSON.stringify(bank),
      username: authUser.mstruserid,
      desc: `${payment.name || ''} -> Deposit`,
      fast_withdraw: 0,
      req_method: 0,
    }

    // In baziwala, is_utr is always 1 and user side transaction Id is utr_no
    // Also the agent cashout number stored as upi in deposit

    // if (data.is_utr) {
    //   insertData.utr = data.utr_no
    //   const entry = await Database.from('bank_entry').where('utr', insertData.utr).first()

    //   if (entry) {
    //     return response.badRequest({
    //       message: 'UTR number already exists.',
    //       status: false,
    //     })
    //   }
    // }

    if (data.screenShotsFile) {
      await data.screenShotsFile.moveToDisk('deposit-requests', {}, 's3')
      // @ts-ignore
      insertData.screen_shots = data.screenShotsFile.filePath
    }

    await Database.table('register_requests').insert(insertData)

    // const dataToPublish = {
    //   userId: authUser.parentId,
    //   type: 'notification',
    //   message: 'User sent request for deposit.',
    //   reqType: 1,
    // }

    // await Redis.publish('notification', JSON.stringify(dataToPublish))

    return response.json({
      status: true,
      message: 'Request received successfully.',
    })
  }

  public async withdraw({ request, authUser, response }: HttpContextContract) {
    let data: any = await request.validate({
      schema: schema.create({
        // acc_type: schema.string(),
        payment: schema.string(),
        acc_name: schema.string(),
        acc_num: schema.string.optional([rules.requiredWhen('payment', 'in', ['1', '4', '9'])]),
        ifsc_code: schema.string.optional([rules.requiredWhen('payment', '=', 4)]),
        // upi: schema.string.optional([rules.requiredWhen('payment', 'notIn', ['4', '9'])]),
        bank_name: schema.string.optional([rules.requiredWhen('payment', 'in', ['9'])]),
        branch_name: schema.string.optional([rules.requiredWhen('payment', '=', 9)]),
        // amount: schema.number([rules.range(1000, 1000000)]),
        amount: schema.number(),
        fast_withdraw: schema.number(),
        req_method: schema.number(),
      }),
    })

    // const dealer: any = await Database.from('createmaster')
    //   .where('mstrid', authUser.parentId)
    //   .select('*')
    //   .firstOrFail()

    // if (dealer.payment_type == 0) {
    //   if (data.payment != 4)
    //     return response.badRequest({
    //       message: 'Only IMPS allowed',
    //     })
    // }

    if (data.amount < 1000) {
      return response.badRequest({
        message: 'Amount must be greater than 1000',
      })
    }

    const pendingRequests = await this.getUserPendingRequests(authUser.mstrid)

    if (pendingRequests) {
      return response.badRequest({
        message: 'Previous requests are pending.',
      })
    }

    // const reqPerDay = await Database.from('bank_entry')
    //   .where('user_id', authUser.mstrid)
    //   .where('req_date', '>=', DateTime.now().toFormat('yyyy-MM-dd') + 'T00:00:00')
    //   .where('req_date', '<=', DateTime.now().toFormat('yyyy-MM-dd') + 'T23:59:59')
    //   .where('type', '2')
    //   .where('status', 'COMPLETE')
    //   .count('* as total')
    //   .first()

    // if (reqPerDay.total >= 5) {
    //   return response.badRequest({
    //     message: 'Maximum withdraw request per day exceeded!',
    //   })
    // }

    const parentSettings = await Cache.rememberForever(
      'dealer_setting:' + authUser.parentId,
      async () => {
        return {
          fast_withdraw: 0,
          min_deposit: 10,
          max_deposit: 1000000,
          min_withdraw: 10,
          max_withdraw: 1000000,
          deposit_bonus: 0,
        }
      }
    )
    if (parentSettings) {
      const minWithdraw = parentSettings.min_withdraw
      const maxWithdraw = parentSettings.max_withdraw
      if (minWithdraw > 0 && data.amount < minWithdraw) {
        return response.badRequest({
          message: 'Minimum withdraw value is ' + minWithdraw,
        })
      } else if (maxWithdraw > 0 && data.amount > maxWithdraw) {
        return response.badRequest({
          message: 'Maximun withdraw value is ' + maxWithdraw,
        })
      }
    }

    // const userLiability = await UserService.getLiability(authUser.mstrid)
    // const pokerLiability: any = await UserService.getPokerLiability(authUser.mstrid)
    // const kingLiability: any = await UserService.getKingLiability(authUser.mstrid)
    // if (data.amount > userLiability[0].Balance - pokerLiability - kingLiability) {
    //   return response.badRequest({
    //     message: 'Insufficient balance',
    //   })
    // }

    const bank = await Database.from('bank_details')
      // .if(project == 1, (q) => {
      //   q.where('id', data.acc_type)
      // })
      .where('mstrid', authUser.parentId)
      .firstOrFail()

    const payment: any = Payment.list.find((el: any) => el.id == bank.payment)

    if (!payment) {
      return response.badRequest({
        message: 'Please add this payment method.',
      })
    }

    data.date = moment().format('YYYY-MM-DD HH:mm:ss')
    data.dealer_id = authUser.parentId
    data.user_id = authUser.mstrid
    data.status = 'PENDING'
    data.type = 2
    data.sender_name = authUser.mstruserid
    data.desc = `${payment.name || ''} -> Withdrawal`
    data.username = authUser.mstruserid
    // data.req_amount = data.amount
    data.bank_details = JSON.stringify({
      payment: payment.id,
      paymentName: payment.name,
      acc_name: data.acc_name,
      acc_num: data.acc_num,
      upi: data.upi,
      bank_name: data.bank_name,
      branch_name: data.branch_name,
    })

    // const chips = data.amount

    delete data.payment

    await Database.table('register_requests').insert(data)

    // const b = await Database.from('bank_entry').where('id', requestId).firstOrFail()

    // const userdetails = await Database.query()
    //   .from('createmaster')
    //   .where('mstrid', b.user_id)
    //   .firstOrFail()

    // data['UserName'] = userdetails.mstrname
    // data['IsFree'] = 1
    // data['RefID'] = data.remark

    // const user = await Database.from('createmaster')
    //   .where('mstrid', b.user_id)
    //   .select('parentId')
    //   .first()

    // await Database.table('tblchips').insert({
    //   MstDate: new Date(),
    //   UserID: b.user_id,
    //   RefID: data.RefID,
    //   LoginID: authUser.mstrid,
    //   CrDr: b.type,
    //   Chips: b.type == 2 ? -chips : chips,
    //   txnId: 0,
    //   //@ts-ignore
    //   IsFree: data.IsFree || '',
    //   //@ts-ignore
    //   Narration:
    //     data.IsFree == 1
    //       ? b.type == 1 // 1 deposit to user
    //         ? 'Chip deposit to ' + data.UserName
    //         : 'Chip withdraw from ' + data.UserName
    //       : b.type == 1
    //         ? 'Coins deposited to ' + data.UserName
    //         : 'Withdrawl coin from ' + data.UserName,
    //   HelperID: 0,
    //   withdrawId: requestId,
    // })

    // const insId = insertId[0].insertId

    // await Bull.add(new UpdateLiability().key, [{ id: b.user_id }, { id: user.parentId }], {
    //   removeOnComplete: true,
    // })

    // await Redis.publish(
    //   'notification',
    //   JSON.stringify({
    //     userId: authUser.parentId,
    //     type: 'notification',
    //     message: 'User send request for withdraw.',
    //     reqType: 2,
    //   })
    // )

    return response.json({
      status: true,
      message: 'Request received successfully.',
    })
  }

  private async getUserPendingRequests(userId) {
    return await Database.query()
      .from('register_requests')
      .where('user_id', userId)
      .andWhere('status', 'PENDING')
      .first()
  }
}
