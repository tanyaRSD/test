import Cache from '@ioc:Adonis/Addons/Cache'
import Redis from '@ioc:Adonis/Addons/Redis'
import { HttpContextContract } from '@ioc:Adonis/Core/HttpContext'
import Database from '@ioc:Adonis/Lucid/Database'
import axios from 'axios'
import ThirdParty from 'App/Services/ThirdParty'
import { Mongo } from 'App/Services/Mongo'

export default class DashboardController {
  // public async index({ request, authUser, response }: HttpContextContract) {
  //   let sportId = request.input('sport_id', 0)

  //   const key = 'dashboard:' + authUser?.mstrid + ':' + sportId

  //   let data = await Cache.remember(key, 30, async () => {
  //     const matches: any = await Database.query()
  //       .from('matchmst as match')
  //       .leftJoin('market', (builder) => {
  //         builder
  //           .andOnVal('market.Name', '=', 'Match Odds')
  //           .andOn('market.matchid', 'match.mstcode')
  //       })
  //       .innerJoin('seriesmst as series', 'series.seriesid', 'match.seriesid')
  //       .innerJoin('sportmst as sport', 'match.sportid', 'sport.id')
  //       .where('sport.active', 1)
  //       .where('match.completed', 0)
  //       .where('match.active', 1)
  //       .if(sportId != 0, (query) => {
  //         query.where('sport.id', sportId)
  //       })
  //       .whereNotIn('match.SportID', [1233, 1234, 1235, 1236, 7, 4339])
  //       .where((q) => {
  //         q.whereExists((query) => {
  //           query
  //             .from('market')
  //             .whereColumn('match.MstCode', 'market.matchId')
  //             .where('active', 1)
  //             .limit(1)
  //         }).orWhereExists((query) => {
  //           query
  //             .from('matchfancy')
  //             .whereColumn('match.MstCode', 'matchfancy.MatchID')
  //             .whereNull('matchfancy.result')
  //             .limit(1)
  //         })
  //       })
  //       .if(authUser, (q) => {
  //         q.whereNotIn('match.mstcode', (query) => {
  //           query
  //             .select('match_id')
  //             .from('user_deactive_match')
  //             .whereIn('user_id', authUser.parentIds)
  //         }).whereNotIn('match.SportID', (query) => {
  //           query.select('sport_id').from('blocked_sports').whereIn('user_id', authUser.parentIds)
  //         })
  //       })
  //       .select(
  //         'match.matchName',
  //         'match.mstcode AS matchid',
  //         'match.oddslimit',
  //         'match.volumelimit',
  //         'match.MstDate',
  //         'match.has_bookmaker',
  //         'match.country_code',
  //         'market.id AS marketid',
  //         'market.market_runner_json AS runner_json',
  //         'market.isbetallowedonmanualmatchodds',
  //         'sport.NAME AS sportname',
  //         'sport.id AS sportid',
  //         'series.NAME AS series_name',
  //         'series.seriesid AS seriesid',
  //         Database.from('matchfancy')
  //           .countDistinct('matchid')
  //           .whereColumn('matchfancy.matchid', 'match.MstCode')
  //           .orderBy('id', 'desc')
  //           .as('isfancy'),
  //         Database.from('tblbets')
  //           .count('*')
  //           .whereColumn('tblbets.MatchId', 'match.MstCode')
  //           .if(authUser?.mstrid, (q) => {
  //             q.where('UserId', authUser.mstrid)
  //           })
  //           .as('match_bets_count'),
  //         Database.from('bet_entry')
  //           .count('*')
  //           .whereColumn('bet_entry.MatchId', 'match.MstCode')
  //           .if(authUser?.mstrid, (q) => {
  //             q.where('UserId', authUser.mstrid)
  //           })
  //           .as('session_bets_count')
  //       )
  //       .groupBy('matchid')
  //       .orderBy('match.MstDate', 'asc')
  //       .orderBy('match.matchname', 'asc')

  //     return matches || []
  //   })

  //   // ----------------------------------------------
  //   //  FETCH INPLAY DIRECTLY (NO REDIS)
  //   // ----------------------------------------------

  //   const marketIds = data.map((d) => d.marketid)
  //   let inplayMap: Record<string, boolean> = {}

  //   console.log('Fetching inplay status for market IDs:', marketIds)

  //   if (marketIds.length) {
  //     try {
  //       const API_URL = ThirdParty.martetURL
  //       const res = await axios.get(`${API_URL}${marketIds.join(',')}`)

  //       const marketsData = res.data?.data
  //       if (marketsData && typeof marketsData === 'object') {
  //         for (const [marketId, market] of Object.entries(marketsData) as any) {
  //           inplayMap[String(marketId)] = market.ip === true
  //         }
  //       }
  //     } catch (err) {
  //       console.log('Inplay API error:', err.message)
  //     }
  //   }

  //   // ----------------------------------------------
  //   //  ASSIGN INPLAY + OTHER FIELDS
  //   // ----------------------------------------------

  //   for (const d of data) {
  //     d.data = await Cache.get('dashboard_market:' + d.marketid)

  //     // inplay from API only
  //     d.inPlay = inplayMap[String(d.marketid)] || false

  //     if (authUser) {
  //       d.isFav = await Redis.sismember('favorite_by_users:' + d.matchid, authUser.mstrid)
  //     }
  //   }

  //   return response.json({
  //     status: true,
  //     message: null,
  //     data: data,
  //   })
  // }
  // public async index({ request, authUser, response }: HttpContextContract) {

  //   let sportId = request.input('sport_id', 0)

  //   const key = 'dashboard:' + authUser?.mstrid + ':' + sportId

  //   const REDIS_TTL = 2 // seconds

  //   // const MONGO_TTL_SECONDS = 30

  //   // ----------------------------------------------

  //   // 1. REDIS (L1 CACHE)

  //   // ----------------------------------------------

  //   let data = await Cache.get(key)

  //   if (!data) {

  //     // ----------------------------------------------

  //     // 2. MONGO (L2 CACHE)

  //     // ----------------------------------------------

  //     const mongoDoc = await Mongo.collection('dashboard').findOne({ key })

  //     if (mongoDoc?.value) {

  //       data = mongoDoc.value

  //       // hydrate Redis

  //       await Cache.put(key, data, REDIS_TTL)

  //     } else {

  //       // ----------------------------------------------

  //       // 3. MYSQL (ORIGINAL QUERY - SAME)

  //       // ----------------------------------------------

  //       const matches: any = await Database.query()

  //         .from('matchmst as match')

  //         .leftJoin('market', (builder) => {

  //           builder

  //             .andOnVal('market.Name', '=', 'Match Odds')

  //             .andOn('market.matchid', 'match.mstcode')

  //         })

  //         .innerJoin('seriesmst as series', 'series.seriesid', 'match.seriesid')

  //         .innerJoin('sportmst as sport', 'match.sportid', 'sport.id')

  //         .where('sport.active', 1)

  //         .where('match.completed', 0)

  //         .where('match.active', 1)

  //         .if(sportId != 0, (query) => {

  //           query.where('sport.id', sportId)

  //         })

  //         .whereNotIn('match.SportID', [1233, 1234, 1235, 1236, 7, 4339])

  //         .where((q) => {

  //           q.whereExists((query: any) => {

  //             query

  //               .from('market')

  //               .whereColumn('match.MstCode', 'market.matchId')

  //               .where('active', 1)

  //               .limit(1)

  //           }).orWhereExists((query: any) => {

  //             query

  //               .from('matchfancy')

  //               .whereColumn('match.MstCode', 'matchfancy.MatchID')

  //               .whereNull('matchfancy.result')

  //               .limit(1)

  //           })

  //         })

  //         .if(authUser, (q) => {

  //           q.whereNotIn('match.mstcode', (query: any) => {

  //             query

  //               .select('match_id')

  //               .from('user_deactive_match')

  //               .whereIn('user_id', authUser.parentIds)

  //           }).whereNotIn('match.SportID', (query: any) => {

  //             query

  //               .select('sport_id')

  //               .from('blocked_sports')

  //               .whereIn('user_id', authUser.parentIds)

  //           })

  //         })

  //         .select(

  //           'match.matchName',

  //           'match.mstcode AS matchid',

  //           'match.oddslimit',

  //           'match.volumelimit',

  //           'match.MstDate',

  //           'match.has_bookmaker',

  //           'match.country_code',

  //           'market.id AS marketid',

  //           'market.market_runner_json AS runner_json',

  //           'market.isbetallowedonmanualmatchodds',

  //           'sport.NAME AS sportname',

  //           'sport.id AS sportid',

  //           'series.NAME AS series_name',

  //           'series.seriesid AS seriesid',

  //           Database.from('matchfancy')

  //             .countDistinct('matchid')

  //             .whereColumn('matchfancy.matchid', 'match.MstCode')

  //             .orderBy('id', 'desc')

  //             .as('isfancy'),

  //           Database.from('tblbets')

  //             .count('*')

  //             .whereColumn('tblbets.MatchId', 'match.MstCode')

  //             .if(authUser?.mstrid, (q) => {

  //               q.where('UserId', authUser.mstrid)

  //             })

  //             .as('match_bets_count'),

  //           Database.from('bet_entry')

  //             .count('*')

  //             .whereColumn('bet_entry.MatchId', 'match.MstCode')

  //             .if(authUser?.mstrid, (q) => {

  //               q.where('UserId', authUser.mstrid)

  //             })

  //             .as('session_bets_count')

  //         )

  //         .groupBy('matchid')

  //         .orderBy('match.MstDate', 'asc')

  //         .orderBy('match.matchname', 'asc')

  //       data = matches || []

  //       // ----------------------------------------------

  //       // SAVE TO MONGO (L2 CACHE)

  //       // ----------------------------------------------

  //       await Mongo.collection('dashboard').updateOne(

  //         { key },

  //         {

  //           $set: {

  //             key,

  //             value: data,

  //             createdAt: new Date(),

  //           },

  //         },

  //         { upsert: true }

  //       )

  //       // ----------------------------------------------

  //       // SAVE TO REDIS (L1 CACHE)

  //       // ----------------------------------------------

  //       await Cache.put(key, data, REDIS_TTL)

  //     }

  //   }

  //   // ----------------------------------------------

  //   // 4. PARALLEL FETCH (NO N+1)

  //   // ----------------------------------------------

  //   const marketIds = data.map((d: any) => d.marketid).filter(Boolean)

  //   // const matchIds = data.map((d) => d.matchid)

  //   const [apiRes, redisMarkets, userFavs] = await Promise.all([

  //     marketIds.length

  //       ? axios.get(`${ThirdParty.martetURL}${marketIds.join(',')}`).catch(() => null)

  //       : null,

  //     marketIds.length

  //       ? Redis.mget(...marketIds.map((id: any) => `dashboard_market:${id}`))

  //       : [],

  //     authUser ? Redis.smembers(`favorite_by_users:${authUser.mstrid}`) : [],

  //   ])

  //   // ----------------------------------------------

  //   // 5. PROCESS API

  //   // ----------------------------------------------

  //   let inplayMap: Record<string, boolean> = {}

  //   const marketsData = apiRes?.data?.data

  //   if (marketsData) {

  //     for (const [marketId, market] of Object.entries(marketsData) as any) {

  //       inplayMap[String(marketId)] = market.ip === true

  //     }

  //   }

  //   const favSet = new Set(userFavs || [])

  //   // ----------------------------------------------

  //   // 6. FINAL MAPPING (NO AWAIT INSIDE LOOP)

  //   // ----------------------------------------------

  //   data.forEach((d: any, i: any) => {

  //     d.data = redisMarkets[i] || null

  //     d.inPlay = inplayMap[String(d.marketid)] || false

  //     d.isFav = favSet.has(String(d.matchid))

  //   })

  //   return response.json({

  //     status: true,

  //     message: null,

  //     data: data,

  //   })

  // }
  public async index({ request, authUser, response }: HttpContextContract) {

    let sportId = request.input('sport_id', 0)

    const key = 'dashboard:' + authUser?.mstrid + ':' + sportId

    const REDIS_TTL = 2 // seconds

    const MONGO_TTL_SECONDS = 100

    // ----------------------------------------------

    // 1. REDIS (L1 CACHE)

    // ----------------------------------------------

    let data = await Cache.get(key)

    if (!data) {

      // ----------------------------------------------

      // 2. MONGO (L2 CACHE)

      // ----------------------------------------------

      const mongoDoc = await Mongo.collection('dashboard').findOne({ key })

      // Check expiry manually (for safety)

      if (mongoDoc?.value && mongoDoc?.expiresAt > new Date()) {

        data = mongoDoc.value

        // hydrate Redis

        await Cache.put(key, data, REDIS_TTL)

      } else {

        // ----------------------------------------------

        // 3. MYSQL (ORIGINAL QUERY)

        // ----------------------------------------------

        const matches: any = await Database.query()

          .from('matchmst as match')

          .leftJoin('market', (builder) => {

            builder

              .andOnVal('market.Name', '=', 'Match Odds')

              .andOn('market.matchid', 'match.mstcode')

          })

          .innerJoin('seriesmst as series', 'series.seriesid', 'match.seriesid')

          .innerJoin('sportmst as sport', 'match.sportid', 'sport.id')

          .where('sport.active', 1)

          .where('match.completed', 0)

          .where('match.active', 1)

          .if(sportId != 0, (query) => {

            query.where('sport.id', sportId)

          })

          .whereNotIn('match.SportID', [1233, 1234, 1235, 1236, 7, 4339])

          .where((q) => {

            q.whereExists((query) => {

              query

                .from('market')

                .whereColumn('match.MstCode', 'market.matchId')

                .where('active', 1)

                .limit(1)

            }).orWhereExists((query) => {

              query

                .from('matchfancy')

                .whereColumn('match.MstCode', 'matchfancy.MatchID')

                .whereNull('matchfancy.result')

                .limit(1)

            })

          })

          .if(authUser, (q) => {

            q.whereNotIn('match.mstcode', (query) => {

              query

                .select('match_id')

                .from('user_deactive_match')

                .whereIn('user_id', authUser.parentIds)

            }).whereNotIn('match.SportID', (query) => {

              query

                .select('sport_id')

                .from('blocked_sports')

                .whereIn('user_id', authUser.parentIds)

            })

          })

          .select(

            'match.matchName',

            'match.mstcode AS matchid',

            'match.oddslimit',

            'match.volumelimit',

            'match.MstDate',

            'match.has_bookmaker',

            'match.country_code',

            'market.id AS marketid',

            'market.market_runner_json AS runner_json',

            'market.isbetallowedonmanualmatchodds',

            'sport.NAME AS sportname',

            'sport.id AS sportid',

            'series.NAME AS series_name',

            'series.seriesid AS seriesid',

            Database.from('matchfancy')

              .countDistinct('matchid')

              .whereColumn('matchfancy.matchid', 'match.MstCode')

              .orderBy('id', 'desc')

              .as('isfancy'),

            Database.from('tblbets')

              .count('*')

              .whereColumn('tblbets.MatchId', 'match.MstCode')

              .if(authUser?.mstrid, (q) => {

                q.where('UserId', authUser.mstrid)

              })

              .as('match_bets_count'),

            Database.from('bet_entry')

              .count('*')

              .whereColumn('bet_entry.MatchId', 'match.MstCode')

              .if(authUser?.mstrid, (q) => {

                q.where('UserId', authUser.mstrid)

              })

              .as('session_bets_count')

          )

          .groupBy('matchid')

          .orderBy('match.MstDate', 'asc')

          .orderBy('match.matchname', 'asc')

        data = matches || []

        // ----------------------------------------------

        // SAVE TO MONGO (L2 CACHE with TTL)

        // ----------------------------------------------

        await Mongo.collection('dashboard').updateOne(

          { key },

          {

            $set: {

              key,

              value: data,

              createdAt: new Date(),

              expiresAt: new Date(Date.now() + MONGO_TTL_SECONDS * 1000),

            },

          },

          { upsert: true }

        )

        // ----------------------------------------------

        // SAVE TO REDIS (L1 CACHE)

        // ----------------------------------------------

        await Cache.put(key, data, REDIS_TTL)

      }

    }

    // ----------------------------------------------

    // 4. PARALLEL FETCH (NO N+1)

    // ----------------------------------------------

    const marketIds = data.map((d) => d.marketid).filter(Boolean)

    const [apiRes, redisMarkets, userFavs] = await Promise.all([

      marketIds.length

        ? axios.get(`${ThirdParty.martetURL}${marketIds.join(',')}`).catch(() => null)

        : null,

      marketIds.length

        ? Redis.mget(...marketIds.map((id) => `dashboard_market:${id}`))

        : [],

      authUser ? Redis.smembers(`favorite_by_users:${authUser.mstrid}`) : [],

    ])

    // ----------------------------------------------

    // 5. PROCESS API

    // ----------------------------------------------

    let inplayMap: Record<string, boolean> = {}

    const marketsData = apiRes?.data?.data

    if (marketsData) {

      for (const [marketId, market] of Object.entries(marketsData) as any) {

        inplayMap[String(marketId)] = market.ip === true

      }

    }

    const favSet = new Set(userFavs || [])

    // ----------------------------------------------

    // 6. FINAL MAPPING

    // ----------------------------------------------

    data.forEach((d, i) => {

      d.data = redisMarkets[i] || null

      d.inPlay = inplayMap[String(d.marketid)] || false

      d.isFav = favSet.has(String(d.matchid))

    })

    return response.json({

      status: true,

      message: null,

      data: data,

    })

  }


  public async horse({ request, authUser, response }: HttpContextContract) {
    const key = 'dashboard:' + authUser?.mstrid + ':horse'
    let sportId = request.input('sport_id')
    let data = await Cache.remember(key, 15, async () => {
      const matches: any = await Database.query()
        .from('matchmst as match')
        .leftJoin('market', (builder) => {
          builder.andOnVal('market.active', 1).andOn('market.matchid', 'match.mstcode')
        })
        .innerJoin('seriesmst as series', 'series.seriesid', 'match.seriesid')
        .innerJoin('sportmst as sport', 'match.sportid', 'sport.id')
        .where('sport.active', 1)
        .where('match.completed', 0)
        .where('match.active', 1)
        .whereExists((query) => {
          query
            .from('market')
            .whereColumn('match.MstCode', 'market.matchId')
            .where('active', 1)
            .limit(1)
        })
        .if(
          sportId,
          (query) => {
            query.where('sport.id', sportId)
          },
          (query) => {
            query.whereIn('sport.id', [7, 4339])
          }
        )
        .if(authUser, (q) => {
          q.whereNotIn('match.mstcode', (query) => {
            query
              .select('match_id')
              .from('user_deactive_match')
              .whereIn('user_id', authUser.parentIds)
          }).whereNotIn('match.SportID', (query) => {
            query.select('sport_id').from('blocked_sports').whereIn('user_id', authUser.parentIds)
          })
        })
        .select(
          'match.matchName',
          'match.mstcode AS matchid',
          'match.oddslimit',
          'match.volumelimit',
          'match.MstDate',
          'match.has_bookmaker',
          'match.country_code',
          'market.id AS marketid',
          'market.market_runner_json AS runner_json',
          'market.isbetallowedonmanualmatchodds',
          'sport.NAME AS sportname',
          'sport.id AS sportid',
          'series.NAME AS series_name',
          'series.seriesid AS seriesid',
          Database.from('matchfancy')
            .countDistinct('matchid')
            .whereColumn('matchfancy.matchid', 'match.MstCode')
            .orderBy('id', 'desc')
            .as('isfancy'),
          Database.raw(
            "GROUP_CONCAT(market.Id,'|',market.start_time,'|',(SELECT COUNT(*) FROM tblbets WHERE MarketId = market.Id) ORDER BY market.start_time ASC SEPARATOR ', ') as start_times"
          )
        )
        .groupBy('matchid')
        .orderBy('match.MstDate', 'asc')
        .orderBy('match.matchname', 'asc')

      return matches || []
    })

    return response.json({
      status: true,
      message: null,
      data: data,
    })
  }
}
