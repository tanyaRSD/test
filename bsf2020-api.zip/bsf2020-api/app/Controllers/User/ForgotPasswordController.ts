import Cache from '@ioc:Adonis/Addons/Cache'
import Env from '@ioc:Adonis/Core/Env'
import { HttpContextContract } from '@ioc:Adonis/Core/HttpContext'
import Logger from '@ioc:Adonis/Core/Logger'
import { rules, schema } from '@ioc:Adonis/Core/Validator'
import Database from '@ioc:Adonis/Lucid/Database'
import User from 'App/Models/User'
import UserService from 'App/Services/UserService'

const phoneLimit = Env.get('PHONE_LIMIT', 10)

export default class ForgotPasswordController {
  public async passwordOtp({ request, response }: HttpContextContract) {
    const data = await request.validate({
      schema: schema.create({
        phone: schema.string([rules.mobile()]),
        // email: schema.string(),
      }),
    })

    if (data.phone.toString().length != phoneLimit) {
      return response.badRequest({
        message: `Phone no must be ${phoneLimit} digits.`,
        status: false,
      })
    }

    const dealer = await this.getDealer(request)

    if (!dealer) {
      return response.badRequest({
        message: 'Invalid request. Company not found.',
        status: false,
      })
    }

    response.abortIf(!dealer.show_register, {
      message: 'Invalid request.',
      status: false,
    })

    const user = await Database.query()
      .from('createmaster')
      .where('phone', data.phone)
      .where('domain', dealer.domain)
      .first()

    if (!user) {
      return response.badRequest({
        message: 'User does not exists.',
        status: false,
      })
    }

    const otp = this.generateOTP()
    try {
      // const forgotKey = 'otp:' + data.email
      // await new ForgotPassword(data.email, otp).send()
      // await Cache.put(forgotKey, otp, 600)
      // return response.json({
      //   message: 'OTP has been sent your email.',
      //   status: true,
      // })
      // const res = await UserService.sendOtp(data.phone, otp)
      // if (res.status === 200) {
      //   if (res.data.Status === 'Success') {
      //     await Cache.put('otp:' + data.phone, otp, 600)
      //     return response.json({
      //       message: 'OTP has been sent your mobile no.',
      //       status: true,
      //     })
      //   }
      // }
      // return response.badRequest({
      //   message: 'OTP service issue.',
      //   status: false,
      // })

      if (Env.get('SMS') == 'portal.sms.net') {
        const res = await UserService.sendOtpSmsNet(data.phone, otp)
        if (res.status === 200) {
          const r = res.data

          if (r.error == 0) {
            await Cache.put('forgotPassword:' + data.phone, otp, 600)
            return response.json({
              message: 'OTP has been sent your mobile no.',
              status: true,
            })
          } else {
            return response.badRequest({
              message: res.data.msg,
              status: false,
            })
          }
        }
      } else if (Env.get('SMS') == 'onbuka') {
        const res = await UserService.sendOtpOnbuka(data.phone, otp)
        if (res.status === 200) {
          const r = res.data
          if (r.status == 0) {
            await Cache.put('forgotPassword:' + data.phone, otp, 600)
            return response.json({
              message: 'OTP has been sent your mobile no.',
              status: true,
            })
          } else {
            return response.badRequest({
              message: r.reason,
              status: false,
            })
          }
        }
      } else if (Env.get('SMS') == 'greenweb') {
        const res = await UserService.sendOtpGreenWeb(data.phone, otp)
        if (res.status === 200) {
          const r = res.data
          if (typeof r == 'string' && r.toLowerCase().startsWith('ok')) {
            await Cache.put('forgotPassword:' + data.phone, otp, 600)
            return response.json({
              message: 'OTP has been sent your mobile no.',
              status: true,
            })
          } else {
            return response.badRequest({
              message: 'Server error.',
              status: false,
            })
          }
        }
      } else {
        const res = await UserService.sendOtp(data.phone, otp)

        if (res.status === 200) {
          const r = res.data?.smslist?.sms?.code

          if (r == '000') {
            await Cache.put('forgotPassword:' + data.phone, otp, 600)
            return response.json({
              message: 'OTP has been sent your mobile no.',
              status: true,
            })
          }
        }
      }

      return response.badRequest({
        message: 'OTP service issue.',
        status: false,
      })
    } catch (e) {
      Logger.error('FORGOT PASSWORD OTP %o', e)
      return response.badRequest({
        message: e.message,
        status: false,
      })
    }
  }

  public async checkForgetOtp({ request, response }: HttpContextContract) {
    const data = await request.validate({
      schema: schema.create({
        phone: schema.string([rules.mobile()]),
        otp: schema.number(),
      }),
    })

    if (data.phone.toString().length != phoneLimit) {
      return response.badRequest({
        message: `Phone no must be ${phoneLimit} digits.`,
        status: false,
      })
    }

    const dealer = await this.getDealer(request)

    response.abortIf(!dealer.show_register, {
      message: 'Invalid request.',
      status: false,
    })

    const otpKey = 'forgotPassword:' + data.phone

    const otpValue: any = await Cache.get(otpKey)

    response.abortIf(otpValue != data.otp, {
      message: 'OTP for phone no is wrong.',
    })

    return response.json({
      status: true,
    })
  }

  public async updatePassword({ request, response }: HttpContextContract) {
    const data = await request.validate({
      schema: schema.create({
        phone: schema.string([rules.mobile()]),
        otp: schema.number(),
        password: schema.string({}, [
          rules.confirmed('confirmPassword'),
          // rules.minLength(6),
          // rules.regex(/[A-Z]/),
        ]),
      }),
      messages: {
        'password.minLength': 'Password must be at least {{ options.minLength }} characters.',
        'password.regex': 'Password must contain at least one uppercase letter.',
      },
    })

    if (data.phone.toString().length != phoneLimit) {
      return response.badRequest({
        message: `Phone no must be ${phoneLimit} digits.`,
        status: false,
      })
    }

    const dealer = await this.getDealer(request)

    response.abortIf(!dealer.show_register, {
      message: 'Invalid request.',
      status: false,
    })

    const otpKey = 'forgotPassword:' + data.phone

    const otpValue: any = await Cache.get(otpKey)

    response.abortIf(otpValue != data.otp, {
      message: 'OTP for phone no is wrong.',
    })

    const user = await User.query()
      .where('phone', data.phone)
      .andWhere('domain', dealer.domain)
      .first()

    if (user) {
      await UserService.changePassword(user.mstrid, data.password)

      const passwordHistory = {
        user_id: user.mstrid,
        changer_id: user.mstrid,
        ip: request.ip(),
        created_at: new Date(),
      }

      await Database.table('password_history').insert(passwordHistory)
    }
    return response.json({
      message: 'Password changed.',
      status: true,
    })
  }

  private generateOTP() {
    const digits = '0123456789'
    let OTP = ''
    for (let i = 0; i < 4; i++) {
      OTP += digits[Math.floor(Math.random() * 10)]
    }
    return OTP
  }

  private async getDealer(request) {
    const origin: any = request.input('origin', request.header('origin'))
    const url = origin ? origin.replace('www.', '') : null
    if (!url) {
      return null
    }

    let domain: any
    if (url?.startsWith('http://localhost')) {
      domain = await Database.from('domains').first()
    }
    return await Database.query()
      .from('createmaster')
      .leftJoin('domains', 'domains.value', '=', 'createmaster.domain')
      .if(
        !url?.startsWith('http://localhost'),
        (q) => {
          q.where('domain', url)
          q.where('useType', 2)
        },
        (q) => {
          q.where('domain', domain.value)
        }
      )
      .select('createmaster.*', 'domains.show_register')
      .first()
  }
}
