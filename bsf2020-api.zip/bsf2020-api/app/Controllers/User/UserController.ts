import Cache from '@ioc:Adonis/Addons/Cache'
import Redis from '@ioc:Adonis/Addons/Redis'
import { HttpContextContract } from '@ioc:Adonis/Core/HttpContext'
import { rules, schema } from '@ioc:Adonis/Core/Validator'
import Database from '@ioc:Adonis/Lucid/Database'
import UserService from 'App/Services/UserService'

export default class UserController {
  public async update({ request, authUser, response }: HttpContextContract) {
    const data = await request.validate({
      schema: schema.create({
        phone1: schema.string.optional([rules.mobile()]),
        phone2: schema.string.optional([rules.mobile()]),
        dob: schema.string.optional(),
      }),
    })

    if (authUser.usetype == 3) {
      const user = await Database.from('createmaster')
        .where('mstrid', authUser.mstrid)
        .firstOrFail()

      if (data.dob && user.DOB) {
        return response.abort({
          message: 'You cannot change date of birth',
          status: false,
        })
      } else {
        if (data.dob) {
          await Database.from('createmaster').where('mstrid', authUser.mstrid).update({
            DOB: data.dob,
          })
        }
      }

      if (data.phone1 || data.phone2) {
        await Database.from('createmaster').where('mstrid', authUser.mstrid).update({
          phone_1: data.phone1,
          phone_2: data.phone2,
        })
      }

      const keys = await Redis.keys('auth:' + authUser.mstrid + '|*')

      for (const key of keys) {
        let user: any = await Cache.get(key)
        if (user) {
          if (data.phone1) {
            user.phone_1 = data.phone1
          }

          if (data.phone2) {
            user.phone_2 = data.phone2
          }

          if (!user.DOB && data.dob) {
            user.DOB = data.dob
          }
          await Cache.put(key, user, 3600)
        }
      }

      return response.ok({
        message: 'Details changed successfully',
        status: true,
      })
    }

    return response.badRequest({
      message: `You don't have permission to`,
      status: false,
    })
  }

  // tanya start changes
  public async clearLiability({ request, response, authUser }: HttpContextContract) {
    const data = await request.validate({
      schema: schema.create({
        userId: schema.string(),
      }),
    })

    if (authUser.usetype != 3) {
      return response.status(403).send({
        status: false,
        message: 'You do not have permission to clear liability',
      })
    }

    if (authUser.mstrid != data.userId) {
      return response.status(403).send({
        status: false,
        message: 'Permission denied: You can only clear liability for your own account',
      })
    }

    try {
      const mongoData = {
        userId: authUser.mstrid,
        type: 'clear_liability',
        ip: request.ip(),
      }

      await UserService.clearLiability(authUser.mstrid, mongoData)

      return response.send({
        status: true,
        message: 'Liability cleared successfully',
      })
    } catch (error) {
      console.log('ClearLiability Controller Error:', error)

      return response.status(500).send({
        status: false,
        message: 'Failed to clear liability',
      })
    }
  }
  //tanya end changes
}
