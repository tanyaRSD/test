import Cache from '@ioc:Adonis/Addons/Cache'
import Redis from '@ioc:Adonis/Addons/Redis'
import { HttpContextContract } from '@ioc:Adonis/Core/HttpContext'
import { rules, schema } from '@ioc:Adonis/Core/Validator'
import Database from '@ioc:Adonis/Lucid/Database'

export default class StakesController {
  public async store({ request, authUser, response }: HttpContextContract) {
    const data = await request.validate({
      schema: schema.create({
        stakes: schema
          .array([rules.distinct('*')])
          .members(schema.number([rules.range(1, 10000000)])),
      }),
      messages: {
        'stakes.*.range': 'Stake must be between {{ options.start }} and {{ options.stop }}',
        'stakes.*.number': 'Stake must be a number',
        'stakes.distinct': 'Stake must be unique',
      },
    })
    try {
      const stake = data.stakes

      //get Auth User
      let userId: any = authUser?.mstrid

      const keys = await Redis.keys('auth:' + userId + '|*')

      for (const key of [...keys]) {
        let user: any = await Cache.get(key)
        if (user) {
          user.stakes = stake
          await Cache.put(key, user, 3600)
        }
      }

      await Database.from('createmaster')
        .where('mstrid', userId)
        .update({
          match_stake: JSON.stringify(stake),
        })

      return response.json({
        status: true,
        message: 'Stack updated succefully.',
        data: [],
      })
    } catch {
      return response.badRequest('Invalid credentials')
    }
  }
}
