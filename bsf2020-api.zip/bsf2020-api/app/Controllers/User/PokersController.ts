import Cache from '@ioc:Adonis/Addons/Cache'
import Redis from '@ioc:Adonis/Addons/Redis'
import Env from '@ioc:Adonis/Core/Env'
import { HttpContextContract } from '@ioc:Adonis/Core/HttpContext'
import Logger from '@ioc:Adonis/Core/Logger'
import { RequestContract } from '@ioc:Adonis/Core/Request'
import { schema } from '@ioc:Adonis/Core/Validator'
import Database from '@ioc:Adonis/Lucid/Database'
import Bull from '@ioc:Rocketseat/Bull'
import UpdateLiability from 'App/Jobs/UpdateLiability'
import { Mongo } from 'App/Services/Mongo'
import Poker from 'App/Services/Poker'
import Sp from 'App/Services/Sp'
import ThirdParty from 'App/Services/ThirdParty'
import UserService from 'App/Services/UserService'
import axios from 'axios'

// let code = Env.get('POKER_PARTNER_ID')
let code = '9767' // dev
if (Env.get('NODE_ENV') === 'production') {
  code = '9768' // prod
}
const sportId = '1233'
const seriesId = sportId + '1'

const whitelistIps = ['52.66.120.45', '172.68.79.152']

export default class PokersController {
  public async auth({ request, response }: HttpContextContract) {
    if (!this.hasWhiteListed(request)) {
      return response.forbidden()
    }

    const data = await request.validate({
      schema: schema.create({
        token: schema.string(),
        operatorId: schema.string(),
      }),
    })

    if (code != data.operatorId) {
      return response.json({
        ErrorCode: 1,
        message: 'User is not Login !',
      })
    }

    const user = await Cache.get(data.token)
    if (user) {
      if (user.bet_lock == 0) {
        return response.json({
          ErrorCode: 1,
          message: 'Betting is locked, contact upline.',
        })
      }

      if (user.usetype != 3) {
        return response.json({
          ErrorCode: 1,
          message: 'You are not authorized.',
        })
      }

      // if (user.mstrid != 5) {
      //   return response.json({
      //     ErrorCode: 1,
      //     message: 'You are not authorized.',
      //   })
      // }

      const parentData: any = await UserService.parents(user.mstrid)
      const parentIds = parentData.map((i: any) => i.mstrid)

      const sport = await Database.from('blocked_sports')
        .select('sport_id')
        .where('sport_id', sportId)
        .whereIn('user_id', parentIds)
        .first()

      if (sport) {
        return response.json({
          status: false,
          message: 'Casino is blocked.',
        })
      }

      const host = user.domain.substring(8).split('.')[0]
      const resData = {
        operatorId: code,
        userId: user.mstrid + '|' + host,
        username: user.mstrname,
        playerTokenAtLaunch: data.token,
        token: data.token,
        balance: user.balance,
        exposure: parseFloat(user.liability),
        currency: 'INR',
        language: 'en',
        timestamp: new Date().getTime(),
        clientIP: [user.ipadress],
        VIP: '3',
        errorCode: 0,
        errorDescription: 'ok',
      }

      await Redis.expire(data.token, 3600)
      Logger.info('📢POKER BALANCE RESPONSE: %o', resData)
      return response.json(resData)
    } else {
      const res = {
        ErrorCode: 1,
        message: 'Account Inactive, contact upline.',
      }
      Logger.info('📢POKER BALANCE RESPONSE: %o', res)
      return response.json(res)
    }
  }

  public async exposure({ request, response }: HttpContextContract) {
    if (!this.hasWhiteListed(request)) {
      return response.forbidden()
    }

    Logger.info('📢POKER BET: %o', request.all())
    const data = await request.validate({
      schema: schema.create({
        token: schema.string(),
        gameId: schema.number(),
        matchName: schema.string(),
        roundId: schema.number(),
        marketId: schema.string(),
        marketType: schema.string(),
        userId: schema.string(),
        calculateExposure: schema.number(),
        betInfo: schema.object().members({
          gameId: schema.number(),
          marketId: schema.string(),
          runnerId: schema.number(),
          runnerName: schema.string(),
          reqStake: schema.number(),
          requestedOdds: schema.number(),
          pnl: schema.number(),
          liability: schema.number(),
          isBack: schema.boolean(),
          roundId: schema.string(),
          pl: schema.number(),
          orderId: schema.string(),
        }),
        runners: schema.array().anyMembers(),
      }),
    })

    const ids = [...Poker.liveGames.map((el) => el.id), ...Poker.virtualGames.map((el) => el.id)]
    if (ids.indexOf(data.gameId.toString()) < 0) {
      return response.json({ status: 1, message: 'Game is not live.' })
    }

    const sportId = 1233

    const usl = await Database.from('user_sport_limit')
      .where('sport_id', sportId)
      .where('type', 'market')
      .where('user_id', 1)
      .select('min_stake', 'max_stake')
      .first()

    const minStakes: any = usl?.min_stake || 0
    const maxStakes: any = usl?.max_stake || 0

    //poker market validations
    if (maxStakes > 0 && data.betInfo.reqStake > maxStakes) {
      return response.json({
        status: 1,
        message: 'Check max stake :' + maxStakes,
      })
    } else if (minStakes > 0 && data.betInfo.reqStake < minStakes) {
      return response.json({
        status: 1,
        message: 'Check min stake :' + minStakes,
      })
    }

    const multiplier = Env.get('project') == 1 ? 1 : 10
    data.calculateExposure = data.calculateExposure * multiplier
    data.betInfo.reqStake = data.betInfo.reqStake * multiplier

    let parents: any = await UserService.parents(data.userId)

    for (const parent of parents) {
      if (await Redis.sismember('pokerBlocked:' + parent.mstrid, data.gameId)) {
        return response.json({ status: 1, message: 'Game is blocked.' })
      }
    }

    if (data.betInfo.reqStake <= 0) {
      return response.json({ status: 1, message: 'Stake must be greather than 0.' })
    }

    const user = await Cache.get(data.token)
    if (!user) {
      const res = { status: 1, message: 'Session expired.', wallet: 0, exposure: 0 }
      return response.json(res)
    }

    if (user.bet_lock == 0) {
      return response.json({
        ErrorCode: 1,
        message: 'Betting is locked, contact upline.',
      })
    }

    if (user.usetype != 3) {
      return response.json({
        ErrorCode: 1,
        message: 'You are not authorized.',
      })
    }

    await Redis.expire(data.token, 3600)

    const liabilityKey = `poker:${user.mstrid}:${data.marketId}`
    let getMarketLiability: any = await UserService.getPokerLiability(user.mstrid, data.marketId)

    try {
      let userKey = 'USER_BET:' + user?.mstrid

      if (await Cache.has(userKey)) {
        return response.json({ status: 1, message: 'Previous bet is in process.' })
      }

      await Redis.expire(data.token, 3600)

      await Cache.put(userKey, '', 120)

      const calculateExposure = Math.abs(data.calculateExposure)

      let betExposure = Math.min(...data.runners.map((el: any) => el.pl))
      if (!isFinite(betExposure)) {
        betExposure = 0
      }

      const b = user.balance + getMarketLiability
      if (calculateExposure == 0 && betExposure >= 0) {
        if (b + Math.max(...data.runners.map((el: any) => el.pl)) < calculateExposure) {
          await Redis.del(userKey)
          return response.json({ status: 1, message: 'Insufficient balance.' })
        }
      } else {
        if (b < calculateExposure) {
          await Redis.del(userKey)
          return response.json({ status: 1, message: 'Insufficient balance.' })
        }
      }

      await this.match(data)
      await this.market(data)

      let exposure = (data.betInfo.requestedOdds - 1) * data.betInfo.reqStake

      const parentData: any = await UserService.parents(user.mstrid)

      const defaultValue = { mstrid: 0, mstruserid: '' }

      let { mstrid: superDuperAdminId, mstruserid: superDuperAdminName } =
        parentData.find((el: any) => el.usetype == 0) ?? defaultValue

      let { mstrid: companyId, mstruserid: companyName } =
        parentData.find((el: any) => el.usetype == 11) ?? defaultValue

      let { mstrid: superAdminId, mstruserid: superAdminName } =
        parentData.find((el: any) => el.usetype == 10) ?? defaultValue

      let { mstrid: subAdminId, mstruserid: subAdminName } =
        parentData.find((el: any) => el.usetype == 9) ?? defaultValue

      let { mstrid: superMasterId, mstruserid: superMasterName } =
        parentData.find((el: any) => el.usetype == 8) ?? defaultValue

      let { mstrid: masterId, mstruserid: masterName } =
        parentData.find((el: any) => el.usetype == 1) ?? defaultValue

      let { mstrid: dealerId, mstruserid: dealerName } =
        parentData.find((el: any) => el.usetype == 2) ?? defaultValue

      let { mstruserid: userName } = parentData.find((el: any) => el.usetype == 3) ?? {
        mstruserid: '',
      }

      let userId = user?.mstrid

      const partnershipData: any = await Cache.rememberForever(
        'partnership:' + userId,
        async () => {
          return await Database.from('tblpartner').where('UserID', userId).firstOrFail()
        }
      )

      const superDuperAdminPartnership = partnershipData['super_duper_admin_casino']
      const companyPartnership = partnershipData['company_casino']
      const superAdminPartnership = partnershipData['super_admin_casino']
      const subAdminPartnership = partnershipData['sub_admin_casino']
      const superMasterPartnership = partnershipData['super_master_casino']
      const masterPartnership = partnershipData['master_casino']
      const dealerPartnership = partnershipData['dealer_casino']

      // call sp teen place bet
      let betPlaceVal = await Sp.call(
        '_bet_place_poker(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,1,"auto",?,?,?,?)',
        [
          userId,
          userId,
          user?.parentId,
          dealerId,
          masterId,
          superMasterId,
          subAdminId,
          superAdminId,
          companyId,
          superDuperAdminId,
          userName,
          dealerName,
          masterName,
          superMasterName,
          subAdminName,
          superAdminName,
          companyName,
          superDuperAdminName,
          superDuperAdminPartnership,
          companyPartnership,
          superAdminPartnership,
          subAdminPartnership,
          superMasterPartnership,
          masterPartnership,
          dealerPartnership,
          data.gameId,
          data.betInfo.runnerId,
          data.betInfo.reqStake,
          data.marketId,
          data.betInfo.runnerName, // runner name
          new Date(),
          data.betInfo.requestedOdds,
          exposure,
          data.betInfo.isBack ? 0 : 1, // isback
          1,
          'Chip Deducted From Betting >> ' + data.matchName,
          'chrome',
          request.ip(),
          1,
          data.betInfo.orderId,
          data.betInfo.roundId,
          data.marketType == 'plus' ? 'plus' : null,
          betExposure,
        ]
      )

      Logger.info('📢BET PLACE: %o', betPlaceVal)

      if (betPlaceVal[0].resultV == 0) {
        // await UserService.saveOddsProfitLoss(user?.mstrid, betPlaceVal[0].LID, data.marketId)
        if (user.balance + data.calculateExposure < 0) {
          await Database.from('tblbets').where('MstCode', betPlaceVal[0].LID).delete()

          await Redis.del(userKey)
          const res = {
            status: 1,
            message: 'Bet not placed',
            wallet: user.balance / multiplier,
            exposure: parseFloat(user.liability) / multiplier,
          }

          Logger.info('📢POKER BET RESPONSE 1: %o', res)
          return response.json(res)
        }

        await Cache.forever(liabilityKey, calculateExposure)

        const mongoData = {
          type: `BET PLACE for ${data.betInfo.reqStake}`,
          category: 'POKER',
          userId: user.mstrid,
          username: user.mstruserid,
          betId: betPlaceVal[0].LID,
          beforeBalance: user.balance,
          beforeLiability: user.liability,
          matchName: data.matchName,
          selectionName: data.betInfo.runnerName,
          marketId: data.betInfo.marketId,
          betType: data.betInfo.isBack ? 'LAY' : 'BACK', // BACK_LAY_TYPE 
          matchId: data.gameId || 0,
        }

        const newData = await UserService.updateLiability([{ id: user?.mstrid }], mongoData, 'add')

        await Redis.del(userKey)

        const res = {
          status: 0,
          Message: 'Exposure insert Successfully.',
          wallet: newData.balance / multiplier,
          exposure: newData.liability / multiplier,
        }

        Logger.info('📢POKER BET RESPONSE: %o', res)

        return response.json(res)
      } else {
        await Database.from('tblbets').where('MstCode', betPlaceVal[0].LID).delete()

        await Redis.del(userKey)
        const res = {
          status: 1,
          message: 'Bet not placed',
          wallet: user.balance / multiplier,
          exposure: parseFloat(user.liability) / multiplier,
        }

        Logger.info('📢POKER BET RESPONSE 1: %o', res)

        return response.json(res)
      }
      // } else {
      //   const res = {
      //     status: 1,
      //     message: 'Insufficient Balance',
      //     wallet: user.balance,
      //     exposure: parseFloat(user.liability),
      //   }
      //   Logger.info('📢POKER BET RESPONSE 2', res)
      //   return response.json(res)
      // }
    } catch (e) {
      Logger.error('POKER BET %o', e)
      const pokerLiability: any = await UserService.getPokerLiability(user.mstrid)
      const balance = parseFloat(user.Balance) - pokerLiability
      const liability = parseFloat(user.Liability) - pokerLiability
      const res = {
        status: 1,
        message: 'Bet not placed',
        wallet: balance / multiplier,
        exposure: liability / multiplier,
      }
      return response.json(res)
    }
  }

  public async getUrl({ authUser, response }: HttpContextContract) {
    const mobileUrl = 'https://m2.fawk.app/#/splash-screen/' + authUser.TokenId + '/' + code
    const desktopUrl = 'https://d2.fawk.app/#/splash-screen/' + authUser.TokenId + '/' + code

    return response.json({
      status: true,
      mobileUrl: mobileUrl,
      desktopUrl: desktopUrl,
    })
  }

  public async getGameUrl({ authUser, response, request }: HttpContextContract) {
    const gameId = request.input('gameCode')
    const ids = [...Poker.liveGames.map((el) => el.id), ...Poker.virtualGames.map((el) => el.id)]
    if (ids.indexOf(gameId.toString()) < 0) {
      return response.json({
        status: false,
        message: 'Game is not live.',
      })
    }

    const mobileUrl =
      'https://m.fawk.app/#/splash-screen/' + authUser.TokenId + '/' + code + '?opentable=' + gameId
    const desktopUrl =
      'https://d.fawk.app/#/splash-screen/' + authUser.TokenId + '/' + code + '?opentable=' + gameId

    return response.json({
      status: true,
      mobileUrl: mobileUrl,
      desktopUrl: desktopUrl,
    })
  }

  public async getPokerGameList({ response }: HttpContextContract) {
    try {
      let virtualGames: any = []
      if (Env.get('project') != 2) {
        virtualGames = Poker.virtualGames
      }
      const data = [...Poker.liveGames, ...virtualGames]

      return response.json({
        data: data,
      })
    } catch (err) {
      return response.badRequest({
        message: err,
        data: [],
      })
    }
  }

  public async result({ request, response }: HttpContextContract) {
    let resultProcessed = false
    try {
      Logger.info('📢POKER RESULT: %o', request.all())
      if (!this.hasWhiteListed(request)) {
        return response.forbidden()
      }
      let data
      try {
        console.log('POKER RESULT TRYING TO VALIDATE REQUEST BODY')
        data = await request.validate({
          schema: schema.create({
            result: schema.array().members(
              schema.object().members({
                _id: schema.string(),
                userId: schema.string(),
                gameId: schema.string(),
                winnerId: schema.number(),
                marketId: schema.string(),
                orders: schema.array().members(
                  schema.object().members({
                    orderId: schema.string(),
                    status: schema.string(),
                    downPl: schema.number(),
                  })
                ),
              })
            ),
            market: schema.object().members({
              marketHeader: schema.string(),
              gameType: schema.string(),
              _id: schema.string(),
              marketRunner: schema.array.optional().members(schema.object().anyMembers()),
              gameId: schema.string(),
              roundId: schema.string(),
              runnerType: schema.string(),
            }),
            runners: schema.array.optional().members(schema.object().anyMembers()), // ✅ FIXED
          }),
        })
      } catch (error) {
        Logger.error('📛 [VALIDATION FAILED]')
        Logger.error('🔢 Status: 422')
        Logger.error('📬 Request Body: %o', request.all())
        Logger.error('❗ Error Messages: %o', error.messages)

        return response.status(422).send({
          error: 'Validation failed',
          details: error.messages,
        })
      }

      const resultKey = 'poker_result:' + data.market._id
      const resultJson = JSON.stringify(request.body())

      Mongo.collection('poker_results').insertOne({
        redis_key: resultKey,
        body: resultJson,
        marketId: data.market._id,
        createdAt: new Date(),
      })

      // Try to set the key only if it doesn't exist
      const isFirst = await Redis.set(
        resultKey,
        resultJson,
        'EX',
        3 * 24 * 60 * 60,
        'NX'
      ) // 3 days expiry

      if (!isFirst) {
        const res = {
          Error: '1',
          result: [],
          message: 'Result already declared.',
        }

        return response.json(res)
      }
      console.log('POKER RESULT DECLARATION STARTED FOR MARKET ID:')
      const runners = [{ id: 0, name: 'N/A' }, ...(data.market.marketRunner || [])]
      let winner: any = null
      let count = 0
      let isProcessed = false
      const trx = await Database.transaction()
      const multiplier = Env.get('project') == 1 ? 1 : 10
      while (count < 3) {
        try {
          console.log('POKER RESULT PROCESSING ATTEMPT:', count + 1)
          for (const r of data.result) {
            winner = runners.find((x) => x.id == r.winnerId)
            for (const order of r.orders) {
              await trx
                .from('tblbets')
                .where('IsMatched', 1)
                .where('MatchId', data.market.gameId)
                .where('MarketId', r.marketId)
                .where('transaction_uuid', order.orderId)
                .update({
                  Chips: order.downPl * multiplier,
                })
            }
          }

          await trx.commit()
          count++
          isProcessed = true
          break
        } catch (error) {
          console.log('POKER RESULT PROCESSING ERROR:', error)
          await trx.rollback()
          await Redis.sadd(
            'errors',
            JSON.stringify({
              time: new Date().toISOString(),
              user: 0,
              error,
            })
          )
          count++
          await this.sleep(1000)
        }
      }

      if (!isProcessed) {
        const res = {
          Error: '1',
          result: [],
          message: 'Error in result declaration',
        }
        await Redis.del(resultKey)
        console.log('POKER RESULT DECLARATION FAILED AFTER 3 ATTEMPTS')
        return response.json(res)
      }

      const resVal = await Sp.call(
        '_result_poker(:sportId,:matchId,:marketId,:selectionId,:fancyId,:resultId,:sportNM,:matchNM, :marketNM, :selectionNM)',
        {
          sportId: sportId,
          matchId: data.market.gameId,
          marketId: data.market._id,
          selectionId: winner.id,
          fancyId: 0,
          resultId: '1',
          sportNM: 'Poker Casino',
          matchNM: data.market.gameType,
          marketNM: data.market.marketHeader,
          selectionNM: winner.name,
        }
      )

      if (resVal[0].resultV == 0) {
        const tableUpdates: any = []
        let result: any = []

        for (const r of data.result) {
          const [rawUserId, domain] = r.userId.split('|') // ✅ Extract domain
          const user = await Database.from('createmaster').where('mstrid', rawUserId).first()
          if (user) {
            const mongoData = {
              type: 'RESULT',
              category: 'POKER',
              userId: user.mstrid,
              username: user.mstruserid,
              betId: null,
              beforeBalance: user.balance,
              beforeLiability: user.liability,
              matchName: data.market.gameType,
              selectionName: winner.name,
              marketId: data.market._id,
            }

            const rs = await this.updateLiability([{ id: user?.mstrid }], r, mongoData, 'add', domain)

            result.push(...rs)

            tableUpdates.push({
              id: r._id,
              market_id: r.marketId,
              user_id: user?.mstrid,
              log_data: JSON.stringify(request.body()),
            })
          }
        }

        // try {
        //   if (tableUpdates.length > 0) {
        //     await Database.table('ez_casino').multiInsert(tableUpdates)
        //   }
        // } catch (e) {
        //   Logger.error('ez_casino %o', e)
        // }

        const res = {
          Error: '0',
          result: result,
          message: 'users profit/loss updated',
        }

        Logger.info('📢POKER RESULT RESPONSE: %o', res)

        resultProcessed = true

        return response.json(res)
      } else {
        const res = {
          Error: '1',
          result: [],
          message: 'Result already declared.',
        }
        console.log('POKER RESULT Already DECLARATION')
        return response.json(res)
      }
    } finally {
      if (resultProcessed) {
        void this.saveCasinoLimitForCompanyAfterPokerResultDeclared()
      }
    }
  }

  public async fixPoker({ response }: HttpContextContract) {
    const keys = await UserService.scanKeys('poker:*')
    for (const key of keys) {
      const marketId = key.split(':')[2]
      const userId = key.split(':')[1]
      const bets = await Database.from('tblbets').where('MarketId', marketId).whereNull('ResultID')
      const deletedBets = await Database.from('tblbets_bak')
        .where('MarketId', marketId)
        .whereNull('ResultID')
      if (bets.length == 0 && deletedBets) {
        await Redis.del(key)
        await Bull.add(new UpdateLiability().key, [{ id: userId }], { removeOnComplete: true })
      }
    }
    return response.json({ status: 'success' })
  }

  public async getResults(ctx: HttpContextContract) {
    const { request, response } = ctx
    const data = await request.validate({
      schema: schema.create({
        betId: schema.string(),
      }),
    })

    const bet: any = await Database.from('tblbets').where('MstCode', data.betId).firstOrFail()
    try {
      const res = await axios.post(ThirdParty.pokerResults, {
        operatorId: code,
        markets: [bet.MarketId],
      })

      if (res.data) {
        request.updateBody(res.data.result)
        return await this.result(ctx)
      }
    } catch (e) {
      return response.badRequest({
        message: 'Error in third party api.',
      })
    }
  }

  private sleep(ms: number) {
    return new Promise((resolve) => setTimeout(resolve, ms))
  }

  private async updateLiability(
    data: any[],
    r: any,
    mongoData?: any,
    type?: 'add' | 'delete',
    domain?: any
  ) {
    const result: any = []
    for (const user of data) {
      const liabilityKey: any = `poker:${user.id}:${r.marketId}`
      await Redis.del(liabilityKey)

      // await Mongo.collection('logs').insertOne({
      //   ...mongoData,
      //   logType: 'Update Liability Started',
      //   createdAt: new Date(),
      // })

      if (user.hasOwnProperty('id')) {
        const rows: any = await UserService.getLiability(user.id, mongoData?.type || '', mongoData)
        if (rows.length > 0) {
          const uData = rows[0]
          const pokerLiability: any = await UserService.getPokerLiability(user.id)
          const balance = parseFloat(uData.Balance) - pokerLiability
          const liability = parseFloat(uData.Liability) - pokerLiability
          const profitLoss = await UserService.getProfitLoss(user.id)

          const finalData = {
            liability: liability,
            balance: balance,
            p_l: uData.chipspnl,
            freechips: uData.FreeChip,
            chip: uData.Chip,
            sessionLiability: uData.sessionLiability,
            unmatchliability: uData.unmatchliability,
            profit_loss: profitLoss.total,
          }
          await Database.query().from('createmaster').where('mstrid', user.id).update(finalData)
          const multiplier = Env.get('project') == 1 ? 1 : 10
          let userData = {
            user_id: user.id,
            data: {
              type: 'balance',
              data: finalData,
            },
          }

          try {
            if (mongoData && mongoData.userId == user.id) {
              if (type == 'add') {
                Mongo.collection('logs').insertOne({
                  ...mongoData,
                  logType: 'Update Liability Ended',
                  afterBalance: balance,
                  afterLiability: liability,
                  createdAt: new Date(),
                })
              } else {
                Mongo.collection('logs').deleteOne(mongoData)
              }
            }
          } catch (e) {
            console.error(e)
          }

          result.push({
            wallet: balance / multiplier,
            exposure: liability / multiplier,
            userId: domain ? `${user.id}|${domain}` : user.id,
          })

          await Redis.publish('USER_UPDATE_DATA', JSON.stringify(userData))

          const keys = await Redis.keys('auth:' + user.id + '|*')

          for (const key of keys) {
            let user: any = await Cache.get(key)
            if (user) {
              user.liability = liability
              user.balance = balance
              user.p_l = uData.chipspnl
              user.freechips = uData.FreeChip
              user.chip = uData.Chip
              user.profit_loss = profitLoss.total
              await Cache.put(key, user, 3600)
            }
          }
        }
      }
    }

    return result
  }

  private async match(data: any) {
    const runners = []
    const key = 'POKER_MATCH'
    if (!(await Redis.sismember(key, data.gameId))) {
      const match = await Database.query().from('matchmst').where('MstCode', data.gameId).first()
      if (!match) {
        await Database.insertQuery()
          .table('matchmst')
          .insert({
            MstCode: data.gameId,
            mstDate: new Date(),
            matchName: data.matchName,
            seriesId: seriesId,
            SportID: sportId,
            marketCount: 0,
            createdOn: new Date(),
            active: 1,
            runner_json: JSON.stringify(runners),
            tvUrl: '',
            score_board_json: '',
          })

        await Redis.sadd(key, data.matchId)
      }
    }
  }

  private async market(data: any) {
    const key = 'POKER_MARKET'

    if (!(await Redis.sismember(key, data.marketId))) {
      const market = await Database.query().from('market').where('Id', data.marketId).first()
      if (!market) {
        const runnersJson: any = []
        const runners: any = []

        for (const r of data.runners) {
          const backLay: any = []

          for (const { } of [1, 2, 3]) {
            backLay.push({ size: '--', price: '--' })
          }

          runnersJson.push({
            id: parseInt(r.id),
            name: r.name,
            back: backLay,
            lay: backLay,
          })

          runners.push({
            selectionId: r.id,
            runnerName: r.name,
          })
        }
        await Database.insertQuery()
          .table('market')
          .insert({
            Id: data.marketId,
            Name: data.matchName,
            sportsId: sportId,
            seriesId: seriesId,
            matchId: data.gameId,
            totalMatched: 0,
            createdOn: new Date(),
            active: 1,
            market_runner_json: JSON.stringify(runnersJson),
          })
        let index = 1
        for (let runner of data.runners) {
          await Database.insertQuery().table('tblselection').insert({
            sportId: sportId,
            matchId: data.gameId,
            selectionId: runner.id,
            selectionName: runner.name,
            marketId: data.marketId,
            teamType: index,
          })

          index++
        }
        await Redis.sadd(key, data.marketId)
      }
    }
  }

  public async refund({ request, response }: HttpContextContract) {
    if (!this.hasWhiteListed(request)) {
      return response.forbidden()
    }

    Logger.info('📢POKER REFUND: ', request.all())

    const data = await request.validate({
      schema: schema.create({
        token: schema.string(),
        gameId: schema.number(),
        matchName: schema.string(),
        roundId: schema.number(),
        marketId: schema.string(),
        marketType: schema.string(),
        userId: schema.string(),
        calculateExposure: schema.number(),
        exposureTime: schema.number(),
        betInfo: schema.object().members({
          gameId: schema.number(),
          marketId: schema.string(),
          runnerId: schema.number(),
          runnerName: schema.string(),
          reqStake: schema.number(),
          requestedOdds: schema.number(),
          pnl: schema.number(),
          liability: schema.number(),
          isBack: schema.boolean(),
          roundId: schema.string(),
          pl: schema.number(),
          orderId: schema.string(),
        }),
        runners: schema.array.optional().anyMembers(),
      }),
    })

    const bet = await Database.from('tblbets')
      .where('MatchId', data.gameId)
      .where('MarketId', data.marketId)
      .where('transaction_uuid', data.betInfo.orderId)
      .first()

    if (new Date(bet?.MstDate) < new Date(data?.exposureTime)) {
      const liabilityKey = `poker:${bet.UserId}:${data.marketId}`
      await Redis.del(liabilityKey)
    }

    const mongoData = {
      type: `REFUND Of BET PLACE for ${bet.stake}`,
      category: 'REFUND',
      userId: bet.UserId,
      username: bet.mstruserid,
      betId: bet[0].LID,
      // beforeBalance: user.balance,
      // beforeLiability: user.liability,
      matchName: data.matchName,
      selectionName: data.betInfo.runnerName,
    }

    const newData = await UserService.updateLiability([{ id: bet.UserId }], mongoData, 'add')

    const res = {
      status: 0,
      Message: 'success',
      wallet: newData.balance,
      exposure: newData.liability,
    }

    Logger.info('📢POKER REFUND RESPONSE: %o', res)

    return response.json(res)
  }

  private hasWhiteListed(request: RequestContract) {
    console.log('POKER REQUEST IP:', request, request.header('x-forwarded-for'))
    const ips = request.header('x-forwarded-for')
    let ipsArray: string[] = []
    if (ips) {
      ipsArray = ips.split(',')
    } else {
      ipsArray = request.ips()
    }

    return ipsArray.some((ip) => whitelistIps.includes(ip))
  }

  private async saveCasinoLimitForCompanyAfterPokerResultDeclared() {
    try {
      const companies = await Database.from('createmaster').where('Usetype', '11')

      for (const company of companies) {
        const spResult = await Sp.call('_casino_setLimit(:pUserID)', {
          pUserID: company.mstrid,
        })

        if (spResult && spResult.length) {
          await Mongo.collection('casino_limit_logs').updateOne(
            {
              $or: [{ userId: company.mstrid }, { companyName: company.mstrname }],
            },
            {
              $set: {
                // userId: company.mstrid,
                // companyName: company.mstrname || '',
                // casino_limit: company.casino_limit || 0,
                data: spResult,
                updatedAt: new Date(),
              },
              $setOnInsert: {
                createdAt: new Date(), // Only set once if new
              },
            },
            { upsert: true }
          )
        }
      }
    } catch (error) {
      Logger.error('❌ Error in saveCasinoLimitForCompanyAfterPokerResultDeclared:', error)
    }
  }

  public async getLimitByUserId({ authUser, response }: HttpContextContract) {
    try {
      let companyId = authUser.mstrid
      let parents = await UserService.parents(authUser.mstrid)
      parents = Array.isArray(parents) ? parents : []
      const company = parents.find((p: any) => p.usetype === 11)
      if (company) {
        companyId = company.mstrid
      }

      if (!companyId) {
        return response.status(400).send({ error: 'userId is required' })
      }

      const record = await Mongo.collection('casino_limit_logs').findOne({
        $or: [{ userId: companyId }, { companyName: company.mstrname }],
      })

      if (!record) {
        return response.status(404).send({ message: 'No record found for this userId' })
      }

      return response.ok({ data: record })
    } catch (error) {
      return response.status(500).send({
        message: 'Error fetching data',
        error: error.message,
      })
    }
  }
}
