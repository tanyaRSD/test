import Cache from '@ioc:Adonis/Addons/Cache'
import Redis from '@ioc:Adonis/Addons/Redis'
import Application from '@ioc:Adonis/Core/Application'
import Encryption from '@ioc:Adonis/Core/Encryption'
import Env from '@ioc:Adonis/Core/Env'
import { HttpContextContract } from '@ioc:Adonis/Core/HttpContext'
import Logger from '@ioc:Adonis/Core/Logger'
import { schema } from '@ioc:Adonis/Core/Validator'
import Database from '@ioc:Adonis/Lucid/Database'
import GameHub from 'App/Services/GameHub'
import Sp from 'App/Services/Sp'
import UserService from 'App/Services/UserService'
import axios from 'axios'

const sportId = '1236'
const username = Env.get('GAMEHUB_USERNAME')
const password = Env.get('GAMEHUB_PASSWORD')
const currency = Env.get('GAMEHUB_CURRENCY')
const betKey = 'gh_bet'
const resultKey = 'gh_result'
const rollbackKey = 'gh_rollback'

let base = 'https://stage.game-program.com/api/seamless/provider'
if (Application.inProduction) {
  base = 'https://em-api.thegameprovider.com/api/seamless/provider'
}

export default class GameHubController {
  public async gameList({ request, response, authUser }: HttpContextContract) {
    let page = request.input('page', 1)
    let limit = request.input('limit', 100)
    let type = request.input('type')
    let category = request.input('category')
    let mobile = request.input('mobile', 0)

    try {
      const sport = await Database.from('blocked_sports')
        .select('sport_id')
        .where('sport_id', sportId)
        .whereIn('user_id', authUser.parentIds)
        .first()

      if (sport) {
        return response.json({
          status: false,
          message: 'Casino is blocked.',
        })
      }

      const data = await Database.from('gamehub_games')
        .if(type, (q) => {
          q.where('type', type)
        })
        .if(category, (q) => {
          q.where('category', category)
        })
        .where('mobile', mobile)
        .paginate(page, limit)

      const categories = await Database.from('gamehub_games')
        .distinct('category')
        .select('category')
      const types = await Database.from('gamehub_games').distinct('type').select('type')

      return response.json({
        data: data,
        categories,
        types,
      })
    } catch (err) {
      console.error('👑 gameList: ', err)
      return response.badRequest({
        message: err,
      })
    }
  }

  public async vendorList({ request, response, authUser }: HttpContextContract) {
    let type = request.input('type')

    const sport = await Database.from('blocked_sports')
      .select('sport_id')
      .where('sport_id', sportId)
      .whereIn('user_id', authUser.parentIds)
      .first()

    if (sport) {
      return response.json({
        status: false,
        message: 'Casino is blocked.',
      })
    }

    const categories = await Database.from('gamehub_games')
      .if(type, (q) => {
        q.where('type', type)
      })
      .distinct('category')
      .select('category')

    return response.json({
      data: categories,
    })
  }

  public async gameUrl({ request, response, authUser }: HttpContextContract) {
    const sport = await Database.from('blocked_sports')
      .select('sport_id')
      .where('sport_id', sportId)
      .whereIn('user_id', authUser.parentIds)
      .first()

    if (sport) {
      return response.json({
        status: false,
        message: 'Casino is blocked.',
      })
    }

    const requestData = await request.validate({
      schema: schema.create({
        gameId: schema.string(),
      }),
    })

    const game = await Database.from('gamehub_games').where('id', requestData.gameId).first()
    if (!game) {
      return response.json({
        status: false,
        message: 'Game not found.',
      })
    }

    try {
      // check player exist on gamehub server
      const { data: playerRes } = await axios.post(base, {
        api_password: password,
        api_login: username,
        method: 'playerExists',
        user_username: authUser.mstruserid + '_' + authUser.mstrid,
        currency: currency,
      })

      if (!playerRes.response) {
        // create player
        await axios.post(base, {
          api_password: password,
          api_login: username,
          method: 'createPlayer',
          user_username: authUser.mstruserid + '_' + authUser.mstrid,
          user_password: Encryption.decrypt(authUser.gamehub_password),
          user_nickname: authUser.mstruserid + '_' + authUser.mstrid,
          currency: currency,
        })
      }

      // sportsbook
      const { data } = await axios.post(base, {
        api_password: password,
        api_login: username,
        method: game.type == 'sportsbook' ? 'getGameDirect' : 'getGame',
        lang: 'en',
        user_username: authUser.mstruserid + '_' + authUser.mstrid,
        user_password: Encryption.encrypt(authUser.mstruserid),
        gameid: requestData.gameId,
        play_for_fun: 0,
        currency: currency,
        homeurl: authUser.domain + '/gamehubCasino',
      })

      return response.json({
        data: data.response.url || data.response,
        embedCode: data.response.embed_code,
      })
    } catch (err) {
      console.log('👑 gameUrl: ', err)
      return response.badRequest({
        message: err.response.status,
      })
    }
  }

  public async wallet(ctx: HttpContextContract) {
    const { request, response } = ctx
    const isVerified = await GameHub.verifyHash(request.qs())

    if (!isVerified) {
      return response.json({
        status: 403,
        msg: 'INCORRECT_KEY_VALIDATION',
      })
    }

    const data = await request.validate({
      schema: schema.create({
        action: schema.string(),
        transaction_id: schema.string.optional(),
        username: schema.string(),
      }),
    })

    const lockKey = `gh_lock`

    // remove this condition when testing only condition not code.
    if (['debit', 'credit', 'rollback'].indexOf(data.action) > -1) {
      const processId = request.id() + (Math.floor(Math.random() * 90000) + 10000).toString()
      const isLocked = await Redis.rpush(lockKey, processId)

      if (isLocked > 1) {
        // If the transaction is already being processed, wait for it to complete
        await new Promise((resolve) => {
          const intervalId = setInterval(async () => {
            const checkLock = await Redis.lindex(lockKey, 0)
            // @ts-ignore
            if (checkLock == processId) {
              clearInterval(intervalId)
              console.log('👑 ' + data.action.toUpperCase(), request.all())
              resolve(true)
            }
          }, 200)
        })
      }
    }

    if (data.action == 'balance') {
      const res = await this.balance(ctx)
      await Redis.lpop(lockKey)
      return response.json(res)
    } else if (data.action == 'debit') {
      const res = await this.bet(ctx)
      await Redis.lpop(lockKey)
      return response.json(res)
    } else if (data.action == 'credit') {
      const res = await this.result(ctx)
      await Redis.lpop(lockKey)
      return response.json(res)
    } else if (data.action == 'rollback') {
      const res = await this.rollback(ctx)
      await Redis.lpop(lockKey)
      return response.json(res)
    } else {
      await Redis.lpop(lockKey)

      return response.json({
        status: 500,
        msg: 'Invalid action.',
      })
    }
  }

  public async balance({ request }: HttpContextContract) {
    const data = await request.validate({
      schema: schema.create({
        callerId: schema.string(),
        callerPassword: schema.string(),
        username: schema.string(),
        action: schema.string(),
        remote_id: schema.string(),
        game_id: schema.string.optional(),
        session_id: schema.string(),
        key: schema.string(),
      }),
    })

    let user = await Database.from('createmaster')
      .where('mstruserid', data.username.split('_')[0])
      .first()

    if (user) {
      const keys = Redis.keys('auth:' + user.mstrid)
      const token = keys[0]

      if (user.bet_lock == 0) {
        return {
          balance: parseInt(user.balance),
          status: 500,
          msg: 'Betting locked',
        }
      }

      await Redis.expire(token, 3600)

      const res = {
        status: 200,
        balance: parseInt(user.balance),
      }

      console.log('👑 BALANCE ', res)
      return res
    } else {
      return {
        status: 500,
        msg: 'User not found.',
      }
    }
  }

  public async bet({ request }: HttpContextContract) {
    // try {
    const data = await request.validate({
      schema: schema.create({
        callerId: schema.string(),
        callerPassword: schema.string(),
        username: schema.string(),
        action: schema.string(),
        remote_id: schema.string(),
        amount: schema.number(),
        provider: schema.string(),
        game_id: schema.string(),
        transaction_id: schema.string(),
        gameplay_final: schema.number(),
        round_id: schema.string(),
        session_id: schema.string(),
        key: schema.string(),
        // gamesession_id: schema.string(),
      }),
    })

    let user = await Database.from('createmaster')
      .where('mstruserid', data.username.split('_')[0])
      .first()

    if (user) {
      const keys = Redis.keys('auth:' + user.mstrid)
      const token = keys[0]
      if (user.bet_lock == 0) {
        return {
          balance: parseInt(user.balance),
          status: 500,
          msg: 'Betting locked',
        }
      }

      await Redis.expire(token, 3600)

      if (data.amount < 0) {
        const res = {
          balance: parseInt(user.balance),
          status: 403,
          msg: 'Amount can not be nagative.',
        }

        console.log('👑 BET1 ', res)
        return res
      }

      if (data.amount == 0) {
        const res = {
          balance: parseInt(user.balance),
          status: 200,
        }
        console.log('👑 BET2 ', res)
        return res
      }

      // check for duplicate request
      if (await Redis.sismember(betKey + user.mstrid, data.transaction_id)) {
        const bet = await Database.from('tblbets')
          .where('MarketId', data.round_id)
          .where('transaction_uuid', data.transaction_id)
          .where('Stack', data.amount)
          .first()

        const res = {
          balance: parseInt(user.balance),
          status: bet ? 200 : 403,
        }

        console.log('👑 BET3 ', res)
        return res
      }

      // check user have sufficient balance or not
      if (user.balance >= data.amount) {
        return await this.placeBet(user, data, false)
      } else {
        const res = {
          balance: parseInt(user.balance),
          status: 403,
          msg: 'Insufficient balance!',
        }

        console.log('👑 BET4 ', res)
        return res
      }
    } else {
      const res = {
        status: 500,
        msg: 'Token expired!',
      }

      console.log('👑 BET5', res)
      return res
    }
    // } catch (e) {
    //   Logger.error('BET PLACE %o', e)
    //   return {
    //     status: 500,
    //     msg: 'Error occured!',
    //   }
    // }
  }

  public async result({ request }: HttpContextContract) {
    try {
      const data = await request.validate({
        schema: schema.create({
          callerId: schema.string(),
          callerPassword: schema.string(),
          username: schema.string(),
          action: schema.string(),
          remote_id: schema.string(),
          amount: schema.string(),
          // provider: schema.string(),
          game_id: schema.string(),
          transaction_id: schema.string(),
          gameplay_final: schema.string(),
          round_id: schema.string(),
          session_id: schema.string(),
          key: schema.string(),
          // gamesession_id: schema.string(),
        }),
      })

      if (parseFloat(data.amount) < 0) {
        const res = {
          status: 403,
          msg: 'Amount can not be nagative.',
        }
        console.log('👑 RESULT1 ', res)
        return res
      }

      let user = await Database.from('createmaster')
        .where('mstruserid', data.username.split('_')[0])
        .first()

      if (!user) {
        return {
          status: 500,
          msg: 'User not found.',
        }
      }

      await Redis.sadd(resultKey + ':' + data.transaction_id, JSON.stringify(request.body()))

      if (await Redis.sismember(resultKey + user.mstrid, data.transaction_id)) {
        const res = {
          balance: parseInt(user.balance),
          status: 200,
        }

        console.log('👑 RESULT2 ', res)
        return res
      }

      await this.placeBet(user, data)

      return await this.rollbackAndDeclare(user, data)
    } catch (e) {
      console.log('👑 RESULT3', e)
      return {
        balance: 0,
        status: 200,
        mdg: 'RS_ERROR_WRONG_SYNTAX',
      }
    }
  }

  public async rollback({ request }: HttpContextContract) {
    // try {
    const data = await request.validate({
      schema: schema.create({
        callerId: schema.string(),
        callerPassword: schema.string(),
        username: schema.string(),
        action: schema.string(),
        remote_id: schema.string(),
        amount: schema.number.optional(),
        provider: schema.string(),
        game_id: schema.string.optional(),
        transaction_id: schema.string(),
        gameplay_final: schema.number(),
        round_id: schema.string.optional(),
        session_id: schema.string(),
        key: schema.string(),
        // gamesession_id: schema.string(),
      }),
    })

    // const matchId: any = data.game_id

    let user = await Database.from('createmaster')
      .where('mstruserid', data.username.split('_')[0])
      .first()

    if (await Redis.sismember(rollbackKey, data.transaction_id)) {
      const res = {
        balance: parseInt(user.balance),
        status: 200,
      }

      console.log('👑 ROLLBACK1', res)
      return res
    }

    const bet = await Database.from('tblbets')
      .where('transaction_uuid', data.transaction_id)
      .first()

    if (bet) {
      await Redis.sadd(rollbackKey, data.transaction_id)

      if (!data.round_id) {
        data.round_id = bet.MarketId
      }

      if (!data.game_id) {
        data.game_id = bet.MatchId
      }
    } else {
      const res = {
        msg: 'TRANSACTION_NOT_FOUND',
        status: 404,
      }

      console.log('👑 ROLLBACK2', res)
      return res
    }

    await Database.from('tblbets').where('transaction_uuid', data.transaction_id).delete()

    return await this.rollbackAndDeclare(user, data)
    // } catch (e) {
    //   Logger.error('ROLLBACK %o', e)
    //   return {
    //     balance: 0,
    //     msg: 'Server error',
    //     status: 200,
    //   }
    // }
  }

  private async placeBet(user: any, data: any, isResult = true) {
    const selectionId = this.grabNumber(data.round_id)
    await Redis.sadd(betKey + user.mstrid, data.transaction_id)

    await this.match(data)
    await this.market(data, selectionId)

    let exposure = data.amount

    const parentData: any = await UserService.parents(user.mstrid)

    const defaultValue = { mstrid: 0, mstruserid: '' }

    let { mstrid: superDuperAdminId, mstruserid: superDuperAdminName } =
      parentData.find((el: any) => el.usetype == 0) ?? defaultValue

    let { mstrid: companyId, mstruserid: companyName } =
      parentData.find((el: any) => el.usetype == 11) ?? defaultValue

    let { mstrid: superAdminId, mstruserid: superAdminName } =
      parentData.find((el: any) => el.usetype == 10) ?? defaultValue

    let { mstrid: subAdminId, mstruserid: subAdminName } =
      parentData.find((el: any) => el.usetype == 9) ?? defaultValue

    let { mstrid: superMasterId, mstruserid: superMasterName } =
      parentData.find((el: any) => el.usetype == 8) ?? defaultValue

    let { mstrid: masterId, mstruserid: masterName } =
      parentData.find((el: any) => el.usetype == 1) ?? defaultValue

    let { mstrid: dealerId, mstruserid: dealerName } =
      parentData.find((el: any) => el.usetype == 2) ?? defaultValue

    let { mstruserid: userName } = parentData.find((el: any) => el.usetype == 3) ?? {
      mstruserid: '',
    }

    let userId = user?.mstrid

    const partnershipData: any = await Cache.rememberForever('partnership:' + userId, async () => {
      return await Database.from('tblpartner').where('UserID', userId).firstOrFail()
    })

    const superDuperAdminPartnership = partnershipData['super_duper_admin_casino']
    const companyPartnership = partnershipData['company_casino']
    const superAdminPartnership = partnershipData['super_admin_casino']
    const subAdminPartnership = partnershipData['sub_admin_casino']
    const superMasterPartnership = partnershipData['super_master_casino']
    const masterPartnership = partnershipData['master_casino']
    const dealerPartnership = partnershipData['dealer_casino']

    // call sp teen place bet
    let betPlaceVal = await Sp.call(
      '_bet_place_gamehub(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,1,"auto",?)',
      [
        userId,
        userId,
        user?.parentId,
        dealerId,
        masterId,
        superMasterId,
        subAdminId,
        superAdminId,
        companyId,
        superDuperAdminId,
        userName,
        dealerName,
        masterName,
        superMasterName,
        subAdminName,
        superAdminName,
        companyName,
        superDuperAdminName,
        superDuperAdminPartnership,
        companyPartnership,
        superAdminPartnership,
        subAdminPartnership,
        superMasterPartnership,
        masterPartnership,
        dealerPartnership,
        data.game_id,
        selectionId,
        isResult ? 0 : exposure,
        data.round_id,
        selectionId.toString(), // runner name
        new Date(),
        1,
        isResult ? exposure : -exposure,
        0, // isback
        1,
        'Chip Deducted From Betting >> ',
        'chrome',
        user.ipadress,
        1,
        data.transaction_id,
      ]
    )

    if (betPlaceVal[0].resultV == 0) {
      const d: any = await this.updateLiability(user.mstrid)

      const balance: any = d.balance
      if (balance < 0) {
        await Database.from('tblbets').where('MstCode', betPlaceVal[0].LID).delete()
        await Redis.srem(betKey + user.mstrid, data.transaction_id)
        await this.updateLiability([{ id: user?.mstrid }])
        return {
          status: 403,
          msg: 'Insufficient balance!',
        }
      }

      return {
        balance: balance,
        status: 200,
      }
    } else {
      await Database.from('tblbets').where('MstCode', betPlaceVal[0].LID).delete()

      await Redis.srem(betKey + user.mstrid, data.transaction_id)

      const res = {
        balance: parseInt(user.balance),
        msg: 'Server error',
        status: 403,
      }

      console.log('👑 PBET1 ', res)
      return res
    }
  }

  private async rollbackAndDeclare(user, data) {
    const selectionId = this.grabNumber(data.round_id)
    const winner = { id: selectionId, name: selectionId.toString() }

    let marketId = data.round_id

    const result = await Database.from('tblresult').where('marketId', marketId).first()

    if (result) {
      const trx = await Database.transaction()
      try {
        await trx.from('market').where({ Id: marketId }).update({ active: 1 })
        await trx.from('tblchipdet').where('ResultID', result.resId).delete()
        await trx.from('tblresult').where('marketId', marketId).delete()

        await trx.commit()
      } catch (e) {
        Logger.error('GAMEHUB RESULT %o', e)
        await trx.rollback()

        const res = {
          balance: parseInt(user.balance),
          status: 500,
          msg: 'Error occured',
        }

        console.log('==========================================')
        console.log(e)
        console.log('==========================================')
        console.log('👑 ROLLBACKRESULT1', res)
        return res
      }
    } else {
      console.log('👑 NO RESULT')
      // await Database.rawQuery(
      //   'UPDATE tblbets SET Chips = Chips - Stack WHERE MarketId = :marketId AND UserId = :userId',
      //   {
      //     marketId: marketId,
      //     userId: user.mstrid,
      //   }
      // )
    }

    await Redis.sadd(resultKey + user.mstrid, data.transaction_id)

    const resVal = await Sp.call(
      '_result_gamehub(:sportId,:matchId,:marketId,:selectionId,:resultId,:sportNM,:matchNM, :marketNM, :selectionNM,:pl)',
      {
        sportId: sportId,
        matchId: data.game_id,
        marketId: marketId,
        selectionId: winner.id,
        resultId: '1',
        sportNM: 'Gamehub Casino',
        matchNM: data.game_id,
        marketNM: data.game_id,
        selectionNM: winner.name,
        pl: data.amount ?? 0,
      }
    )

    // console.log('👑 ROLLBACKRESULT2 ', resVal)

    if (resVal[0].resultV == 0) {
      const d: any = await this.updateLiability(user.mstrid)

      const res = {
        balance: d.balance,
        status: 200,
      }

      console.log('👑 ROLLBACKRESULT3', res)
      return res
    } else {
      const res = {
        balance: parseInt(user.balance),
        status: 200,
      }

      console.log('👑 ROLLBACKRESULT4', res)

      return res
    }
  }

  private async updateLiability(id: any) {
    const rows: any = await UserService.getLiability(id)

    const data = rows[0]

    const pokerLiability: any = await UserService.getPokerLiability(id)
    const kingLiability: any = await UserService.getKingLiability(id)
    const balance: any = parseInt(data.Balance) - pokerLiability - kingLiability
    const liability = parseInt(data.Liability) - pokerLiability - kingLiability
    const profitLoss = await UserService.getProfitLoss(id)

    const finalData = {
      liability: liability,
      balance: parseInt(balance),
      p_l: data.chipspnl,
      freechips: data.FreeChip,
      chip: data.Chip,
      sessionLiability: data.sessionLiability,
      unmatchliability: data.unmatchliability,
      profit_loss: profitLoss.total,
    }
    await Database.query().from('createmaster').where('mstrid', id).update(finalData)

    let userData = {
      user_id: id,
      data: {
        type: 'balance',
        data: finalData,
      },
    }

    await Redis.publish('USER_UPDATE_DATA', JSON.stringify(userData))

    const keys = await Redis.keys('auth:' + id + '|*')

    for (const key of keys) {
      let user: any = await Cache.get(key)
      if (user) {
        user.liability = liability
        user.balance = balance
        user.p_l = data.chipspnl
        user.freechips = data.FreeChip
        user.chip = data.Chip
        user.profit_loss = profitLoss.total
        await Cache.put(key, user, 3600)
      }
    }

    return finalData
  }

  private async match(data: any) {
    const seriesId = sportId + '3'
    const runners = []
    const key = 'GH_MATCH'
    if (!(await Redis.sismember(key, data.game_id))) {
      const match = await Database.query().from('matchmst').where('MstCode', data.game_id).first()
      if (!match) {
        await Database.insertQuery()
          .table('matchmst')
          .insert({
            MstCode: data.game_id,
            mstDate: new Date(),
            matchName: data.game_id_hash,
            seriesId: seriesId,
            SportID: sportId,
            marketCount: 0,
            createdOn: new Date(),
            active: 1,
            runner_json: JSON.stringify(runners),
            tvUrl: '',
            score_board_json: '',
          })

        await Redis.sadd(key, data.game_id)
      }
    }
  }

  private async market(data: any, selectionId: any) {
    const seriesId = sportId + '3'
    const key = 'GH_MARKET'

    if (!(await Redis.sismember(key, data.round_id))) {
      const market = await Database.query().from('market').where('Id', data.round_id).first()
      if (!market) {
        const runnersJson: any = []
        const runners: any = []

        for (const r of [
          { id: selectionId, name: selectionId.toString() },
          { id: 2, name: 'B' },
        ]) {
          const backLay: any = []

          // @ts-ignore
          for (const i of [1, 2, 3]) {
            backLay.push({ size: '--', price: '--' })
          }

          runnersJson.push({
            id: r.id,
            name: r.name,
            back: backLay,
            lay: backLay,
          })

          runners.push({
            selectionId: r.id,
            runnerName: r.name,
          })
        }

        await Database.insertQuery()
          .table('market')
          .insert({
            Id: data.round_id,
            Name: data.game_id_hash,
            sportsId: sportId,
            seriesId: seriesId,
            matchId: data.game_id,
            totalMatched: 0,
            createdOn: new Date(),
            active: 1,
            market_runner_json: JSON.stringify(runnersJson),
          })

        let index = 1

        for (let runner of [
          { id: selectionId, name: selectionId.toString() },
          { id: 2, name: 'B' },
        ]) {
          await Database.insertQuery().table('tblselection').insert({
            sportId: sportId,
            matchId: data.game_id,
            selectionId: runner.id,
            selectionName: runner.name,
            marketId: data.round_id,
            teamType: index,
          })

          index++
        }
        await Redis.sadd(key, data.round_id)
      }
    }
  }

  // private convertToNumber(str: string) {
  //   str = str.toUpperCase();
  //   let len = str.length;
  //   str = str.substring(0, 4) + str.substring(len - 4);
  //   len = str.length;

  //   let out = 0;
  //   for (let pos = 0; pos < len; pos++) {
  //     out += (str.charCodeAt(pos) - 64) * Math.pow(26, len - pos - 1);
  //   }

  //   const outputLength = out.toString().length;

  //   if (outputLength > 10) {
  //     out = Math.round(out / (outputLength * 100))
  //   }

  //   return out;
  // }

  private grabNumber(str: string) {
    let out = str.replace(/\D/g, '').substring(0, 6)
    if (out.length === 0) {
      out = '123'
    }
    return out
  }
}
