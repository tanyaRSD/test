import { HttpContextContract } from '@ioc:Adonis/Core/HttpContext'
import { schema } from '@ioc:Adonis/Core/Validator'
import Database from '@ioc:Adonis/Lucid/Database'

export default class UserBanksController {
  public async index({ response, authUser }: HttpContextContract) {
    const banks = await Database.query().from('user_banks').where('user_id', authUser.mstrid)

    return response.json({
      status: true,
      data: banks,
    })
  }

  public async store({ request, response, authUser }: HttpContextContract) {
    const data = await request.validate({
      schema: schema.create({
        account_name: schema.string(),
        account_number: schema.string(),
        ifsc_code: schema.string(),
        bank_name: schema.string(),
        is_default: schema.boolean(),
        user_id: schema.number.optional(),
      }),
    })

    const bank = await Database.query()
      .from('user_banks')
      .where('user_id', authUser.mstrid)
      .where('account_number', data.account_number)
      .first()

    if (bank) {
      return response.json({
        status: true,
        message: 'Bank already exists.',
      })
    }

    data.user_id = authUser.mstrid

    if (data.is_default) {
      await Database.from('user_banks')
        .where('user_id', authUser.mstrid)
        .update({ is_default: false })
    }

    await Database.table('user_banks').insert(data)

    return response.json({
      status: true,
      message: 'Bank added successfully.',
    })
  }

  public async update({ request, params, response, authUser }: HttpContextContract) {
    const data = await request.validate({
      schema: schema.create({
        account_name: schema.string(),
        account_number: schema.string(),
        ifsc_code: schema.string(),
        bank_name: schema.string(),
        is_default: schema.boolean(),
      }),
    })

    const bank = await Database.query()
      .from('user_banks')
      .whereNot('id', params.id)
      .where('user_id', authUser.mstrid)
      .where('account_number', data.account_number)
      .first()

    if (bank) {
      return response.json({
        status: true,
        message: 'Bank already exists.',
      })
    }

    if (data.is_default) {
      await Database.from('user_banks')
        .where('user_id', authUser.mstrid)
        .update({ is_default: false })
    }

    await Database.from('user_banks')
      .where('id', params.id)
      .where('user_id', authUser.mstrid)
      .update(data)

    return response.json({
      status: true,
      message: 'Bank updated successfully.',
    })
  }

  public async destroy({ params, response, authUser }: HttpContextContract) {
    await Database.query()
      .from('user_banks')
      .where('id', params.id)
      .where('user_id', authUser.mstrid)
      .delete()

    return response.json({
      status: true,
      message: 'Bank removed successfully.',
    })
  }
}
