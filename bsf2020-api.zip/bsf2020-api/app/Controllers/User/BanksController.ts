import Cache from '@ioc:Adonis/Addons/Cache'
import Redis from '@ioc:Adonis/Addons/Redis'
import Env from '@ioc:Adonis/Core/Env'
import { string } from '@ioc:Adonis/Core/Helpers'
import { HttpContextContract } from '@ioc:Adonis/Core/HttpContext'
import { rules, schema } from '@ioc:Adonis/Core/Validator'
import Database from '@ioc:Adonis/Lucid/Database'
import Bull from '@ioc:Rocketseat/Bull'
import UpdateLiability from 'App/Jobs/UpdateLiability'
import Payment from 'App/Services/Payment'
import ThirdParty from 'App/Services/ThirdParty'
import UserService from 'App/Services/UserService'
import axios from 'axios'
import { DateTime } from 'luxon'
import moment from 'moment/moment'

const depositLimit = JSON.parse(Env.get('DEPOSIT_LIMIT', 'false'))

export default class BanksController {
  public async index({ request, response, authUser }: HttpContextContract) {
    const data = await request.validate({
      schema: schema.create({
        parentId: schema.number(),
        type: schema.number(),
      }),
    })

    let parents: any = await UserService.parents(authUser.mstrid)
    const parent = parents.find((p) => p.usetype == 1)
    const banks = await Database.query()
      .from('bank_details')
      .where('mstrid', parent.mstrid || data.parentId)
      .where('status', true)
      .where(data.type == 0 ? 'cd' : 'cw', true)

    return response.json({
      status: true,
      data: banks,
    })
  }

  public async deposit({ request, authUser, response }: HttpContextContract) {
    let data: any

    data = await request.validate({
      schema: schema.create({
        is_utr: schema.boolean(),
        amount: schema.number([rules.range(0, 100000000001)]),
        acc_type: schema.number(),
        screenShotsFile: schema.file({
          size: '5mb',
          extnames: ['jpg', 'png', 'jpeg', 'JPEG'],
        }),
        utr_no: schema.string.optional(),
      }),
    })

    let parents: any = await UserService.parents(authUser.mstrid)
    const parent = parents.find((p) => p.usetype == 1)

    if (!parent) {
      return response.badRequest({
        message: 'Please contact upline.',
      })
    }

    const dealer: any = await Database.from('createmaster')
      .where('mstrid', authUser.parentId)
      .select('*')
      .firstOrFail()

    if (data.CrDr == 1 && Math.abs(data.Chips) > parseFloat(dealer.freechips)) {
      return response.badRequest({
        message: 'Your dealer has insufficient balance.',
      })
    }

    const pendingRequests = await this.getUserPendingRequests(authUser.mstrid)

    if (pendingRequests) {
      return response.badRequest({
        message: 'Previous requests are pending.',
      })
    }

    if (depositLimit) {
      const reqPerDay = await Database.from('bank_entry')
        .where('user_id', authUser.mstrid)
        .where('req_date', '>=', DateTime.now().toFormat('yyyy-MM-dd') + 'T00:00:00')
        .where('req_date', '<=', DateTime.now().toFormat('yyyy-MM-dd') + 'T23:59:59')
        .where('type', '1')
        .where('status', 'COMPLETE')
        .count('* as total')
        .first()

      if (reqPerDay.total >= 3) {
        return response.badRequest({
          message: 'Maximum deposit request per day exceeded!',
        })
      }
    }

    const parentSettings = await Cache.rememberForever(
      'dealer_setting:' + parent.mstrid,
      async () => {
        return {
          fast_withdraw: 0,
          min_deposit: 10,
          max_deposit: 1000000,
          min_withdraw: 10,
          max_withdraw: 1000000,
          deposit_bonus: 0,
        }
      }
    )

    if (parentSettings) {
      const minDeposit = parentSettings.min_deposit
      const maxDeposit = parentSettings.max_deposit
      if (minDeposit > 0 && data.amount < minDeposit) {
        return response.badRequest({
          message: 'Minimum deposit value is.' + minDeposit,
        })
      } else if (maxDeposit > 0 && data.amount > maxDeposit) {
        return response.badRequest({
          message: 'Maximun deposit value is.' + maxDeposit,
        })
      }
    }

    data['type'] = 1
    data['status'] = 'PENDING'

    const bank = await Database.from('bank_details')
      .where('id', data.acc_type)
      .where('mstrid', parent.mstrid)
      .firstOrFail()

    const payment: any = Payment.list.find((el: any) => el.id == bank.payment)

    if (!payment) {
      return response.badRequest({
        message: 'Please add this payment method.',
      })
    }

    bank.paymentName = payment.name

    let insertData: any = {
      user_id: authUser.mstrid,
      dealer_id: parent.mstrid,
      status: 'PENDING',
      type: 1,
      req_date: moment().format('YYYY-MM-DD HH:mm:ss'),
      req_amount: data.amount,
      acc_type: data.acc_type,
      bank_details: JSON.stringify(bank),
      username: authUser.mstruserid,
      desc: `${payment.name || ''} -> Deposit`,
      fast_withdraw: 0,
      req_method: 0,
    }

    // In baziwala, is_utr is always 1 and user side transaction Id is utr_no
    // Also the agent cashout number stored as upi in deposit

    if (data.is_utr) {
      insertData.utr = data.utr_no
      const entry = await Database.from('bank_entry').where('utr', insertData.utr).first()

      if (entry) {
        return response.badRequest({
          message: 'UTR number already exists.',
          status: false,
        })
      }
    }

    if (data.screenShotsFile) {
      await data.screenShotsFile.moveToDisk('deposit', {}, 's3')
      // @ts-ignore
      insertData.screen_shots = data.screenShotsFile.filePath
    }

    await Database.table('bank_entry').insert(insertData)

    const dataToPublish = {
      userId: parent.mstrid,
      type: 'notification',
      message: 'User sent request for deposit.',
      reqType: 1,
    }

    await Redis.publish('notification', JSON.stringify(dataToPublish))

    return response.json({
      status: true,
      message: 'Request received successfully.',
    })
  }

  public async depositNew({ request, authUser, response }: HttpContextContract) {
    const data: any = await request.validate({
      schema: schema.create({
        amount: schema.number([rules.range(1, 1000000)]),
        isMobile: schema.boolean(),
      }),
    })

    const dealer: any = await Database.from('createmaster')
      .where('mstrid', authUser.parentId)
      .select('*')
      .firstOrFail()

    if (dealer.payment_type == 1) {
      return response.badRequest({
        message: 'Only automatic payments are allowed',
      })
    }

    await this.updateUserPendingRequests(authUser.mstrid)

    const parentSettings = await Cache.rememberForever(
      'dealer_setting:' + authUser.parentId,
      async () => {
        return {
          fast_withdraw: 0,
          min_deposit: 10,
          max_deposit: 1000000,
          min_withdraw: 10,
          max_withdraw: 1000000,
          deposit_bonus: 0,
        }
      }
    )
    if (parentSettings) {
      const minDeposit = parentSettings.min_deposit
      const maxDeposit = parentSettings.max_deposit
      if (minDeposit > 0 && data.amount < minDeposit) {
        return response.badRequest({
          message: 'Minimum deposit value is.' + minDeposit,
        })
      } else if (maxDeposit > 0 && data.amount > maxDeposit) {
        return response.badRequest({
          message: 'Maximun deposit value is.' + maxDeposit,
        })
      }
    }

    const parentId = authUser.parentId
    const liability = await UserService.getLiability(parentId)

    if (liability[0].Balance < data.amount) {
      return response.json({
        status: false,
        message: 'Balance insufficient parent A/C',
      })
    }

    let insertData: any = {
      sender_name: authUser.mstruserid,
      user_id: authUser.mstrid,
      dealer_id: authUser.parentId,
      type: 1,
      req_date: moment().format('YYYY-MM-DD HH:mm:ss'),
      req_amount: data.amount,
      username: authUser.mstruserid,
      fast_withdraw: 0,
      req_method: 0,
      status: 'PENDING',
      desc: `UPI -> Deposit`,
      transaction_id: string.generateRandom(50),
    }

    let depositeId = await Database.table('bank_entry').returning('id').insert(insertData)
    depositeId = depositeId[0]

    const dataToPublish = {
      userId: authUser.parentId,
      type: 'notification',
      message: 'User sent request for deposit.',
      reqType: 1,
    }

    await Redis.publish('notification', JSON.stringify(dataToPublish))

    let paymentToken = await Cache.get(`dealer_deposit_token:${dealer.mstrid}`)

    if (!paymentToken) {
      try {
        const key = 'dealer_setting:' + dealer.mstrid
        const dealerSettings = await Cache.get(key)

        if (!dealerSettings.deposit_email || !dealerSettings.deposit_password) {
          return response.badRequest({
            message: 'Payment gateway is not active. please contact upline.',
          })
        }

        const creds = {
          email: dealerSettings.deposit_email,
          password: dealerSettings.deposit_password,
        }

        const paymentUser: any = await axios.post(ThirdParty.paymentLoginUrl, creds, {
          headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
        })
        const now = Math.floor(Date.now() / 1000) // Divide by 1000 to convert milliseconds to seconds
        const timestamp = paymentUser.data.expires_in

        // Calculate the difference in seconds
        const differenceInSeconds = now - timestamp

        await Cache.put(
          `dealer_deposit_token:${dealer.mstrid}`,
          paymentUser.data.access_token,
          differenceInSeconds
        )
        paymentToken = paymentUser.data.access_token
      } catch (err) {
        console.log(err)
        return response.badRequest({
          status: false,
          message: 'Error in payment api',
        })
      }
    }

    const orderDetails = {
      billing_person_name: 'Demo',
      fulfillment_status: '1',
      payment_status: '1',
      order_number: insertData.transaction_id,
      tax: 0,
      type: 3,
      total: data.amount,
      phone: '6291459372',
      subtotal: data.amount,
      platform_id: '0',
      return_url: authUser.domain,
      currency: 'INR',
      email: authUser.email || 'test@gmail.com',
    }

    try {
      const paymentOrder = await axios.post(ThirdParty.paymentUrl, orderDetails, {
        headers: {
          'Accept': 'application/json',
          'Authorization': 'Bearer ' + paymentToken,
          'Content-Type': 'application/json',
        },
      })

      await Cache.forever(`payment_${depositeId}`, paymentOrder.data)

      let checkOutUrl = `https://api.step2pay.online/payment/checkout/general?order_id=${paymentOrder.data.id}`

      if (data.isMobile) {
        checkOutUrl = paymentOrder.data.upi_url
      }

      return response.json({
        status: true,
        data: checkOutUrl,
      })
    } catch (err) {
      console.log(err)

      await Database.from('bank_entry').where('id', depositeId).delete()

      return response.badRequest({
        status: false,
        message: 'Error in payment order',
      })
    }
  }

  public async withdraw({ request, authUser, response }: HttpContextContract) {
    const project = Env.get('project')
    let data: any
    if (project == 1) {
      data = await request.validate({
        schema: schema.create({
          acc_type: schema.string(),
          payment: schema.string(),
          acc_name: schema.string(),
          acc_num: schema.string.optional([rules.requiredWhen('payment', '=', 4)]),
          ifsc_code: schema.string.optional([rules.requiredWhen('payment', '=', 4)]),
          upi: schema.string.optional([rules.requiredWhen('payment', 'notIn', ['4', '9'])]),
          bank_name: schema.string.optional([rules.requiredWhen('payment', 'in', ['4', '9'])]),
          branch_name: schema.string.optional([rules.requiredWhen('payment', '=', 9)]),
          amount: schema.number([rules.range(0, 100000000001)]),
          fast_withdraw: schema.number(),
          req_method: schema.number(),
        }),
      })
    } else {
      data = await request.validate({
        schema: schema.create({
          // acc_type: schema.string(),
          payment: schema.string(),
          acc_name: schema.string(),
          acc_num: schema.string.optional([rules.requiredWhen('payment', 'in', ['1', '4', '9'])]),
          ifsc_code: schema.string.optional([rules.requiredWhen('payment', '=', 4)]),
          // upi: schema.string.optional([rules.requiredWhen('payment', 'notIn', ['4', '9'])]),
          bank_name: schema.string.optional([rules.requiredWhen('payment', 'in', ['9'])]),
          branch_name: schema.string.optional([rules.requiredWhen('payment', '=', 9)]),
          amount: schema.number([rules.range(0, 100000000001)]),
          fast_withdraw: schema.number(),
          req_method: schema.number(),
        }),
      })
    }

    let parents: any = await UserService.parents(authUser.mstrid)
    const parent = parents.find((p) => p.usetype == 1)

    const dealer: any = await Database.from('createmaster')
      .where('mstrid', parent.mstrid)
      .select('*')
      .firstOrFail()

    if (dealer.payment_type == 0) {
      if (data.payment != 4)
        return response.badRequest({
          message: 'Only IMPS allowed',
        })
    }

    const pendingRequests = await this.getUserPendingRequests(authUser.mstrid)

    if (pendingRequests) {
      return response.badRequest({
        message: 'Previous requests are pending.',
      })
    }

    const reqPerDay = await Database.from('bank_entry')
      .where('user_id', authUser.mstrid)
      .where('req_date', '>=', DateTime.now().toFormat('yyyy-MM-dd') + 'T00:00:00')
      .where('req_date', '<=', DateTime.now().toFormat('yyyy-MM-dd') + 'T23:59:59')
      .where('type', '2')
      .where('status', 'COMPLETE')
      .count('* as total')
      .first()

    if (reqPerDay.total >= 5) {
      return response.badRequest({
        message: 'Maximum withdraw request per day exceeded!',
      })
    }

    const parentSettings = await Cache.rememberForever(
      'dealer_setting:' + parent.mstrid,
      async () => {
        return {
          fast_withdraw: 0,
          min_deposit: 10,
          max_deposit: 1000000,
          min_withdraw: 10,
          max_withdraw: 1000000,
          deposit_bonus: 0,
        }
      }
    )
    if (parentSettings) {
      const minWithdraw = parentSettings.min_withdraw
      const maxWithdraw = parentSettings.max_withdraw
      if (minWithdraw > 0 && data.amount < minWithdraw) {
        return response.badRequest({
          message: 'Minimum withdraw value is ' + minWithdraw,
        })
      } else if (maxWithdraw > 0 && data.amount > maxWithdraw) {
        return response.badRequest({
          message: 'Maximun withdraw value is ' + maxWithdraw,
        })
      }
    }

    const userLiability = await UserService.getLiability(authUser.mstrid)
    const pokerLiability: any = await UserService.getPokerLiability(authUser.mstrid)
    const kingLiability: any = await UserService.getKingLiability(authUser.mstrid)
    if (data.amount > userLiability[0].Balance - pokerLiability - kingLiability) {
      return response.badRequest({
        message: 'Insufficient balance',
      })
    }

    const bank = await Database.from('bank_details')
      .if(project == 1, (q) => {
        q.where('id', data.acc_type)
      })
      .where('cw', 1)
      .where('mstrid', parent.mstrid)
      .first()

    if (!bank) {
      return response.badRequest({
        message: 'Please add bank details first.',
      })
    }

    const payment: any = Payment.list.find((el: any) => el.id == bank.payment)

    if (!payment) {
      return response.badRequest({
        message: 'Please add this payment method.',
      })
    }

    data.req_date = moment().format('YYYY-MM-DD HH:mm:ss')
    data.dealer_id = parent.mstrid
    data.user_id = authUser.mstrid
    data.status = 'PENDING'
    data.type = 2
    data.sender_name = authUser.mstruserid
    data.desc = `${payment.name || ''} -> Withdrawal`
    data.username = authUser.mstruserid
    data.req_amount = data.amount
    data.bank_details = JSON.stringify({
      payment: payment.id,
      paymentName: payment.name,
      acc_name: data.acc_name,
      acc_num: data.acc_num,
      upi: data.upi,
      bank_name: data.bank_name,
      branch_name: data.branch_name,
    })

    const chips = data.amount

    delete data.amount
    delete data.payment

    const [requestId] = await Database.table('bank_entry').returning('id').insert(data)

    const b = await Database.from('bank_entry').where('id', requestId).firstOrFail()

    const userdetails = await Database.query()
      .from('createmaster')
      .where('mstrid', b.user_id)
      .firstOrFail()

    data['UserName'] = userdetails.mstrname
    data['IsFree'] = 1
    data['RefID'] = data.remark

    await Database.table('tblchips').insert({
      MstDate: new Date(),
      UserID: b.user_id,
      RefID: data.RefID,
      LoginID: authUser.mstrid,
      CrDr: b.type,
      Chips: b.type == 2 ? -chips : chips,
      txnId: 0,
      //@ts-ignore
      IsFree: data.IsFree || '',
      //@ts-ignore
      Narration:
        data.IsFree == 1
          ? b.type == 1 // 1 deposit to user
            ? 'Chip deposit to ' + data.UserName
            : 'Chip withdraw from ' + data.UserName
          : b.type == 1
            ? 'Coins deposited to ' + data.UserName
            : 'Withdrawl coin from ' + data.UserName,
      HelperID: 0,
      withdrawId: requestId,
    })

    // const insId = insertId[0].insertId

    await Bull.add(new UpdateLiability().key, [{ id: b.user_id }, { id: authUser.parentId }], {
      removeOnComplete: true,
    })

    await Redis.publish(
      'notification',
      JSON.stringify({
        userId: parent.mstrid,
        type: 'notification',
        message: 'User send request for withdraw.',
        reqType: 2,
      })
    )

    return response.json({
      status: true,
      message: 'Request received successfully.',
    })
  }

  public async getRequest({ request, authUser, response }: HttpContextContract) {
    const data = await request.validate({
      schema: schema.create({
        from_date: schema.date({
          format: 'sql',
        }),
        to_date: schema.date({
          format: 'sql',
        }),
      }),
    })

    let page = request.input('page', 1)
    let limit = request.input('limit', 70)

    const reqData = await Database.query()
      .from('bank_entry')
      .where('user_id', authUser.mstrid)
      .whereBetween('req_date', [
        data.from_date.toSQLDate() + 'T00:00:00',
        data.to_date.toSQLDate() + 'T23:59:59',
      ])
      .orderBy('id', 'desc')
      .paginate(page, limit)

    return response.json({
      status: true,
      data: reqData,
    })
  }

  public async fastWithdrawShow({ authUser, response }: HttpContextContract) {
    let parents: any = await UserService.parents(authUser.mstrid)
    const parent = parents.find((p) => p.usetype == 1)

    const key = 'dealer_setting:' + parent.mstrid
    let result = await Cache.rememberForever(key, async () => {
      return {
        fast_withdraw: 0,
        min_deposit: 10,
        max_deposit: 1000000,
        min_withdraw: 10,
        max_withdraw: 1000000,
        deposit_bonus: 0,
      }
    })

    return response.json({
      status: true,
      data: result,
    })
  }

  private async updateUserPendingRequests(userId) {
    await Database.query()
      .from('bank_entry')
      .where('user_id', userId)
      .andWhere('status', 'PENDING')
      .update({ status: 'CANCEL' })
  }

  private async getUserPendingRequests(userId) {
    return await Database.query()
      .from('bank_entry')
      .where('user_id', userId)
      .andWhere('status', 'PENDING')
      .first()
  }

  public async cancelWithdraw({ request, authUser, response }: HttpContextContract) {
    const data: any = await request.validate({
      schema: schema.create({
        id: schema.number(),
      }),
    })

    if (authUser.usetype == '3') {
      const b = await Database.from('bank_entry').where('id', data.id).firstOrFail()

      if (b.user_id != authUser.mstrid) {
        return response.badRequest({
          message: 'You are not authorized',
        })
      }
      if (b.type != 2) {
        return response.badRequest({
          message: 'Cancel is only allowed for withdrawal',
        })
      }

      const key = 'approved_request:' + data.id
      const count = await Redis.incr(key)
      await Redis.expire(key, 50)

      const user = await Database.from('createmaster')
        .where('mstrid', b.user_id)
        .select('parentId')
        .first()

      response.abortIf(count > 1 || b.status !== 'PENDING', {
        message: 'This request has already been processed.',
      })

      await Database.query().from('tblchips').where('WithdrawId', data.id).delete()

      await Database.query().from('bank_entry').where('id', data.id).update({
        status: 'CANCELLED',
        remark: data.remark,
        approved_amount: 0,
      })

      await Bull.add(new UpdateLiability().key, [{ id: b.user_id }, { id: user.parentId }], {
        removeOnComplete: true,
      })

      return response.json({
        status: true,
        message: 'Withdraw request is cancelled successfully',
      })
    }

    return response.badRequest({
      message: "You don't have permission",
    })
  }
}
