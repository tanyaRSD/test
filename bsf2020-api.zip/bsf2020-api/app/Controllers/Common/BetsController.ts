import { HttpContextContract } from '@ioc:Adonis/Core/HttpContext'
import UserService from 'App/Services/UserService'

export default class BetsController {
  public async index({ request, authUser, response }: HttpContextContract) {
    const page: any = request.input('page', 1)
    const limit = request.input('limit', 50)
    const sportId = request.input('sportId')
    const matchId = request.input('matchId')
    const paginate = request.input('paginate', 'yes')
    const search = request.input('search')
    const fancyId = request.input('fancyId')
    const type = request.input('type', null)
    const marketId = request.input('marketId', null)
    const userId = request.input('userId', null)
    const afterResult = request.input('afterResult', null)

    if (authUser.usetype == '55') {
      return response.badRequest({
        message: "You don' have permission",
      })
    }

    let data: any
    if (paginate == 'yes') {
      data = await UserService.bets(authUser.mstrid, {
        matchId,
        sportId,
        search,
        needPagination: true,
        page,
        limit,
        type,
        fancyId,
        marketId,
        afterResult: afterResult,
        userId,
      })
    } else {
      data = {
        data: await UserService.bets(authUser.mstrid, {
          matchId,
          sportId,
          search,
          type,
          fancyId,
          marketId,
          afterResult,
          userId,
        }),
      }
    }

    return response.json(data)
  }

  public async fancyBets({ request, authUser, response }: HttpContextContract) {
    const page: any = request.input('page', 1)
    const limit = request.input('limit', 50)
    const sportId = request.input('sportId')
    const matchId = request.input('matchId')
    const paginate = request.input('paginate', 'yes')
    const search = request.input('search')
    const fancyId = request.input('fancyId')
    const type = request.input('type', null)
    const marketId = request.input('marketId', null)

    if (authUser.usetype == '55') {
      return response.badRequest({
        message: "You don' have permission",
      })
    }

    let data: any
    if (paginate == 'yes') {
      data = await UserService.fancyBets(authUser.mstrid, {
        matchId,
        sportId,
        search,
        needPagination: true,
        page,
        limit,
        type,
        fancyId,
        marketId,
      })
      // data = await UserService.getFancyBetsByUserAndMatchWithPagination(
      //   authUser.mstrid,
      //   matchId,
      //   page,
      //   limit,
      //   search
      // )
    } else {
      data = {
        data: await UserService.fancyBets(authUser.mstrid, {
          matchId,
          sportId,
          search,
          type,
          fancyId,
          marketId,
        }),
        // data: await UserService.fancyBetsMongoQuery(authUser.mstrid, matchId, fancyId),
      }
    }

    return response.json(data)
  }

  public async bookmakerBets({ request, authUser, response }: HttpContextContract) {
    const page: any = request.input('page', 1)
    const limit = request.input('limit', 50)
    const sportId = request.input('sportId')
    const matchId = request.input('matchId')
    const paginate = request.input('paginate', 'yes')
    const search = request.input('search')
    const fancyId = request.input('fancyId')
    const type = request.input('type', null)
    const marketId = request.input('marketId', null)

    if (authUser.usetype == '55') {
      return response.badRequest({
        message: "You don' have permission",
      })
    }

    let data: any
    if (paginate == 'yes') {
      data = await UserService.bookmakerBets(authUser.mstrid, {
        matchId,
        sportId,
        search,
        needPagination: true,
        page,
        limit,
        type,
        fancyId,
        marketId,
      })

      // data = await UserService.allMarketBetsMongoQueryWithPagination(
      //   authUser.mstrid,
      //   matchId,
      //   'Bookmaker',
      //   page,
      //   limit,
      //   search
      // )
    } else {
      data = {
        data: await UserService.bookmakerBets(authUser.mstrid, {
          matchId,
          sportId,
          search,
          type,
          fancyId,
          marketId,
        }),
        // data: await UserService.marketBetsMongoQuery(authUser.mstrid, matchId, 'Bookmaker'),
      }
    }

    return response.json(data)
  }

  public async winnerBets({ request, authUser, response }: HttpContextContract) {
    const page: any = request.input('page', 1)
    const limit = request.input('limit', 50)
    const sportId = request.input('sportId')
    const matchId = request.input('matchId')
    const paginate = request.input('paginate', 'yes')
    const search = request.input('search')
    const fancyId = request.input('fancyId')
    const type = request.input('type', null)
    const marketId = request.input('marketId', null)

    if (authUser.usetype == '55') {
      return response.badRequest({
        message: "You don' have permission",
      })
    }

    let data: any
    if (paginate == 'yes') {
      data = await UserService.winnerBets(authUser.mstrid, {
        matchId,
        sportId,
        search,
        needPagination: true,
        page,
        limit,
        type,
        fancyId,
        marketId,
      })

      // data = await UserService.allMarketBetsMongoQueryWithPagination(
      //   authUser.mstrid,
      //   matchId,
      //   'Winner',
      //   page,
      //   limit,
      //   search
      // )
    } else {
      data = {
        data: await UserService.winnerBets(authUser.mstrid, {
          matchId,
          sportId,
          search,
          type,
          fancyId,
          marketId,
        }),
        // data: await UserService.marketBetsMongoQuery(authUser.mstrid, matchId, 'Winner'),
      }
    }

    return response.json(data)
  }

  public async matchOddsBets({ request, authUser, response }: HttpContextContract) {
    const page: any = request.input('page', 1)
    const limit = request.input('limit', 50)
    const sportId = request.input('sportId')
    const matchId = request.input('matchId')
    const paginate = request.input('paginate', 'yes')
    const search = request.input('search')
    const fancyId = request.input('fancyId')
    const type = request.input('type', null)
    const marketId = request.input('marketId', null)

    if (authUser.usetype == '55') {
      return response.badRequest({
        message: "You don' have permission",
      })
    }

    let data: any
    if (paginate == 'yes') {
      data = await UserService.matchOddsBets(authUser.mstrid, {
        matchId,
        sportId,
        search,
        needPagination: true,
        page,
        limit,
        type,
        fancyId,
        marketId,
      })

      // data = await UserService.allMarketBetsMongoQueryWithPagination(
      //   authUser.mstrid,
      //   matchId,
      //   'Match Odds',
      //   page,
      //   limit,
      //   search
      // )
    } else {
      data = {
        data: await UserService.matchOddsBets(authUser.mstrid, {
          matchId,
          sportId,
          search,
          type,
          fancyId,
          marketId,
        }),
        // data: await UserService.marketBetsMongoQuery(authUser.mstrid, matchId, 'Match Odds'),
      }
    }

    return response.json(data)
  }

  public async tiedMatchBets({ request, authUser, response }: HttpContextContract) {
    const page: any = request.input('page', 1)
    const limit = request.input('limit', 50)
    const sportId = request.input('sportId')
    const matchId = request.input('matchId')
    const paginate = request.input('paginate', 'yes')
    const search = request.input('search')
    const fancyId = request.input('fancyId')
    const type = request.input('type', null)
    const marketId = request.input('marketId', null)

    if (authUser.usetype == '55') {
      return response.badRequest({
        message: "You don' have permission",
      })
    }

    let data: any
    if (paginate == 'yes') {
      data = await UserService.tiedMatchBets(authUser.mstrid, {
        matchId,
        sportId,
        search,
        needPagination: true,
        page,
        limit,
        type,
        fancyId,
        marketId,
      })

      // data = await UserService.allMarketBetsMongoQueryWithPagination(
      //   authUser.mstrid,
      //   matchId,
      //   'Tied',
      //   page,
      //   limit,
      //   search
      // )
    } else {
      data = {
        data: await UserService.tiedMatchBets(authUser.mstrid, {
          matchId,
          sportId,
          search,
          type,
          fancyId,
          marketId,
        }),
        // data: await UserService.marketBetsMongoQuery(authUser.mstrid, matchId, 'Tied'),
      }
    }

    return response.json(data)
  }

  public async tossBets({ request, authUser, response }: HttpContextContract) {
    const page: any = request.input('page', 1)
    const limit = request.input('limit', 50)
    const sportId = request.input('sportId')
    const matchId = request.input('matchId')
    const paginate = request.input('paginate', 'yes')
    const search = request.input('search')
    const fancyId = request.input('fancyId')
    const type = request.input('type', null)
    const marketId = request.input('marketId', null)

    if (authUser.usetype == '55') {
      return response.badRequest({
        message: "You don' have permission",
      })
    }

    let data: any
    if (paginate == 'yes') {
      data = await UserService.tossBets(authUser.mstrid, {
        matchId,
        sportId,
        search,
        needPagination: true,
        page,
        limit,
        type,
        fancyId,
        marketId,
      })

      // data = await UserService.allMarketBetsMongoQueryWithPagination(
      //   authUser.mstrid,
      //   matchId,
      //   'Toss',
      //   page,
      //   limit,
      //   search
      // )
    } else {
      data = {
        data: await UserService.tossBets(authUser.mstrid, {
          matchId,
          sportId,
          search,
          type,
          fancyId,
          marketId,
        }),
        // data: await UserService.marketBetsMongoQuery(authUser.mstrid, matchId, 'Toss'),
      }
    }

    return response.json(data)
  }

  public async goalsBets({ request, authUser, response }: HttpContextContract) {
    const page: any = request.input('page', 1)
    const limit = request.input('limit', 50)
    const sportId = request.input('sportId')
    const matchId = request.input('matchId')
    const paginate = request.input('paginate', 'yes')
    const search = request.input('search')
    const fancyId = request.input('fancyId')
    const type = request.input('type', null)
    const marketId = request.input('marketId', null)

    if (authUser.usetype == '55') {
      return response.badRequest({
        message: "You don' have permission",
      })
    }

    let data: any
    if (paginate == 'yes') {
      data = await UserService.goalsBets(authUser.mstrid, {
        matchId,
        sportId,
        search,
        needPagination: true,
        page,
        limit,
        type,
        fancyId,
        marketId,
      })

      // data = await UserService.allMarketBetsMongoQueryWithPagination(
      //   authUser.mstrid,
      //   matchId,
      //   'Goals',
      //   page,
      //   limit,
      //   search
      // )
    } else {
      data = {
        data: await UserService.goalsBets(authUser.mstrid, {
          matchId,
          sportId,
          search,
          type,
          fancyId,
          marketId,
        }),
        // data: await UserService.marketBetsMongoQuery(authUser.mstrid, matchId, 'Goals'),
      }
    }

    return response.json(data)
  }

  public async allBets({ request, authUser, response }: HttpContextContract) {
    const matchId = request.input('matchId')

    if (authUser.usetype == '55') {
      return response.badRequest({
        message: "You don' have permission",
      })
    }
    let data: any
    data = {
      data: await UserService.allMarketBetsMongoQuery(authUser.mstrid, matchId),
    }

    return response.json(data)
  }

  public async allMarketsBetsWithPagination({ request, authUser, response }: HttpContextContract) {
    const matchId = request.input('matchId')
    const marketName = request.input('marketName')
    const page = Number(request.input('page') || 1)
    const limit = Number(request.input('limit') || 50)
    const search = request.input('search')

    // Check for permission
    if (authUser.usetype === '55') {
      return response.badRequest({
        message: "You don't have permission",
      })
    }

    try {
      const result = await UserService.allMarketBetsMongoQueryWithPagination(
        authUser.mstrid,
        matchId,
        marketName,
        page,
        limit,
        search
      )

      return response.json(result)
    } catch (error) {
      console.error('Error fetching market bets:', error)
      return response.internalServerError({
        message: 'Failed to fetch market bets.',
      })
    }
  }

  // tanya bookmaker fancy Deteted Bets 
  public async bookmakerDeletedBets({ request, authUser, response }: HttpContextContract) {
    const page: any = request.input('page', 1)
    const limit = request.input('limit', 50)
    const sportId = request.input('sportId')
    const matchId = request.input('matchId')
    const paginate = request.input('paginate', 'yes')
    const search = request.input('search')
    const fancyId = request.input('fancyId')
    const type = request.input('type', null)
    const marketId = request.input('marketId', null)

    if (authUser.usetype == '55') {
      return response.badRequest({
        message: "You don' have permission",
      })
    }

    let data: any
    if (paginate == 'yes') {
      data = await UserService.bookmakerBets(authUser.mstrid, {
        matchId,
        sportId,
        search,
        needPagination: true,
        page,
        limit,
        type,
        fancyId,
        marketId,
        bet_deleted: true

      })

      // data = await UserService.allMarketBetsMongoQueryWithPagination(
      //   authUser.mstrid,
      //   matchId,
      //   'Bookmaker',
      //   page,
      //   limit,
      //   search
      // )
    } else {
      data = {
        data: await UserService.bookmakerBets(authUser.mstrid, {
          matchId,
          sportId,
          search,
          type,
          fancyId,
          marketId,
          bet_deleted: true

        }),
        // data: await UserService.marketBetsMongoQuery(authUser.mstrid, matchId, 'Bookmaker'),
      }
    }

    return response.json(data)
  }

  public async fancyDeletedBets({ request, authUser, response }: HttpContextContract) {
    const page: any = request.input('page', 1)
    const limit = request.input('limit', 50)
    const sportId = request.input('sportId')
    const matchId = request.input('matchId')
    const paginate = request.input('paginate', 'yes')
    const search = request.input('search')
    const fancyId = request.input('fancyId')
    const type = request.input('type', null)
    const marketId = request.input('marketId', null)

    if (authUser.usetype == '55') {
      return response.badRequest({
        message: "You don' have permission",
      })
    }

    let data: any
    if (paginate == 'yes') {
      data = await UserService.fancyDeletedBets({
        matchId,
        sportId,
        search,
        needPagination: true,
        page,
        limit,
        type,
        fancyId,
        marketId,
        bet_deleted: true
      })
      // data = await UserService.getFancyBetsByUserAndMatchWithPagination(
      //   authUser.mstrid,
      //   matchId,
      //   page,
      //   limit,
      //   search
      // )
    } else {
      data = {
        data: await UserService.fancyDeletedBets({
          matchId,
          sportId,
          search,
          type,
          fancyId,
          marketId,
          bet_deleted: true
        }),
        // data: await UserService.fancyBetsMongoQuery(authUser.mstrid, matchId, fancyId),
      }
    }

    return response.json(data)
  }


  // tanya bookmaker ,fancy Deteted Bets end



}
