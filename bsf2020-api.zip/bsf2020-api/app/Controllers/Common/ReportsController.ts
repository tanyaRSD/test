import { HttpContextContract } from '@ioc:Adonis/Core/HttpContext'
import { schema } from '@ioc:Adonis/Core/Validator'
import Database from '@ioc:Adonis/Lucid/Database'
import { Mongo } from 'App/Services/Mongo'
import Parent from 'App/Services/Parent'
import Sp from 'App/Services/Sp'
import UserService from 'App/Services/UserService'
import { DateTime } from 'luxon'
import Redis from '@ioc:Adonis/Addons/Redis'

export default class ReportsController {
  public async accountStatement({ request, authUser, response }: HttpContextContract) {
    let userId = request.input('user_id', authUser?.mstrid)
    let type = request.input('type', 'all')
    let tranType = request.input('transaction_type', 'all')
    let page = request.input('page', 1)
    let fromDate = request.input('from_date')
    let toDate = request.input('to_date')
    const limit = request.input('limit', 50)

    if (!(await Parent.validate(authUser, userId))) {
      return response.badRequest({
        message: 'Invalid request.',
      })
    }

    const result = await UserService.accountStatement(
      userId,
      fromDate,
      toDate,
      tranType,
      type,
      page,
      limit
    )

    return response.json({
      status: true,
      message: null,
      ...result,
    })
  }

  public async ledger({ request, authUser, response }: HttpContextContract) {
    let userId = request.input('user_id', authUser?.mstrid)
    let page = request.input('page', 1)
    const limit = request.input('limit', 100)

    if (!(await Parent.validate(authUser, userId))) {
      return response.badRequest({
        message: 'Invalid request.',
      })
    }

    const result = await UserService.ledger(userId, page, limit)

    return response.json({
      status: true,
      message: null,
      ...result,
    })
  }

  public async ledgerByMatch({ authUser, response, params }: HttpContextContract) {
    const matchId = params.matchId
    const userId = authUser?.mstrid

    const matchodds = await Database.query()
      .from(`tblbets as a`)
      .join('matchmst', 'matchmst.MstCode', '=', 'a.MatchId')
      .join('market as a1', 'a1.Id', 'a.marketId')
      .join('tblresult as a3', 'a3.resId', 'a.ResultId')
      .join('tblselection as a4', 'a4.selectionId', 'a3.selectionId')
      .distinct()
      .select(
        'a.UserId',
        'a.UserName',
        'a.MatchId',
        'a.SelectionId',
        'a.selectionName',
        'a.MstDate',
        'a.Odds',
        'a.Stack',
        'a.P_L',
        'a.isBack',
        'a4.selectionName as winner',
        'matchmst.matchName as matchName',
        Database.raw("CASE WHEN a.isBack = 1 THEN 'KHAI' ELSE 'LAGAI' END AS Type"),
        Database.raw(
          'CASE WHEN IFNULL(a.result, 0) = 1 THEN CASE WHEN IFNULL(a.isBack, 0) = 0 THEN a.P_L ELSE a.Stack END ELSE 0 END AS Profit'
        ), // 0
        Database.raw(
          'CASE WHEN IFNULL(a.result, 0) = 0 THEN CASE WHEN IFNULL(a.isBack, 0) = 0 THEN a.Stack ELSE a.P_L END ELSE 0 END AS Liability'
        ), // 0
        Database.raw("CASE WHEN a.ResultID IS NULL THEN 'Open' ELSE 'Settled' END AS STATUS") // 0
      )
      .where('a4.matchId', matchId)
      .where('a1.Name', 'Match Odds')
      .where((query) => {
        query
          .where('a.UserId', userId)
          .orWhere('a.ParantId', userId)
          .orWhere('a.DealerID', userId)
          .orWhere('a.MasterID', userId)
          .orWhere('a.SMasterID', userId)
          .orWhere('a.SAdminID', userId)
          .orWhere('a.AdminID', userId)
          .orWhere('a.CompanyID', userId)
          .orWhere('a.ParentExchCompanyID', userId)
      })
      .where('a.MatchId', matchId)

    const matchOddsFinalValue = matchodds.reduce((pre, curr) => {
      return pre + (parseFloat(curr.Profit) - parseFloat(curr.Liability))
    }, 0.0)

    const bookmakerodds = await Database.query()
      .from(`tblbets as a`)
      .join('matchmst', 'matchmst.MstCode', '=', 'a.MatchId')
      .join('market as a1', 'a1.Id', 'a.marketId')
      .join('tblresult as a3', 'a3.resId', 'a.ResultId')
      .join('tblselection as a4', 'a4.selectionId', 'a3.selectionId')
      .distinct()
      .select(
        'a.UserId',
        'a.UserName',
        'a.MatchId',
        'a.SelectionId',
        'a.selectionName',
        'a.MstDate',
        'a.Odds',
        'a.Stack',
        'a.P_L',
        'a.isBack',
        'a4.selectionName as winner',
        'matchmst.matchName as matchName',
        Database.raw("CASE WHEN a.isBack = 1 THEN 'KHAI' ELSE 'LAGAI' END AS Type"),
        Database.raw(
          'CASE WHEN IFNULL(a.result, 0) = 1 THEN CASE WHEN IFNULL(a.isBack, 0) = 0 THEN a.P_L ELSE a.Stack END ELSE 0 END AS Profit'
        ), // 0
        Database.raw(
          'CASE WHEN IFNULL(a.result, 0) = 0 THEN CASE WHEN IFNULL(a.isBack, 0) = 0 THEN a.Stack ELSE a.P_L END ELSE 0 END AS Liability'
        ), // 0
        Database.raw("CASE WHEN a.ResultID IS NULL THEN 'Open' ELSE 'Settled' END AS STATUS") // 0
      )
      .where('a4.matchId', matchId)
      .where('a1.Name', 'Bookmaker')
      .where((query) => {
        query
          .where('a.UserId', userId)
          .orWhere('a.ParantId', userId)
          .orWhere('a.DealerID', userId)
          .orWhere('a.MasterID', userId)
          .orWhere('a.SMasterID', userId)
          .orWhere('a.SAdminID', userId)
          .orWhere('a.AdminID', userId)
          .orWhere('a.CompanyID', userId)
          .orWhere('a.ParentExchCompanyID', userId)
      })
      .where('a.MatchId', matchId)

    const bookmakerOddsFinalValue = bookmakerodds.reduce((pre, curr) => {
      return pre + (parseFloat(curr.Profit) - parseFloat(curr.Liability))
    }, 0.0)

    const matchToss = await Database.query()
      .from(`tblbets as a`)
      .join('matchmst', 'matchmst.MstCode', '=', 'a.MatchId')
      .join('market as a1', 'a1.Id', 'a.marketId')
      .join('tblresult as a3', 'a3.resId', 'a.ResultId')
      .join('tblselection as a4', 'a4.selectionId', 'a3.selectionId')
      .distinct()
      .select(
        'a.UserId',
        'a.UserName',
        'a.MatchId',
        'a.SelectionId',
        'a.selectionName',
        'a.MstDate',
        'a.Odds',
        'a.Stack',
        'a.P_L',
        'a.isBack',
        'a4.selectionName as winner',
        'matchmst.matchName as matchName',
        Database.raw("CASE WHEN a.isBack = 1 THEN 'KHAI' ELSE 'LAGAI' END AS Type"),
        Database.raw(
          'CASE WHEN IFNULL(a.result, 0) = 1 THEN CASE WHEN IFNULL(a.isBack, 0) = 0 THEN a.P_L ELSE a.Stack END ELSE 0 END AS Profit'
        ), // 0
        Database.raw(
          'CASE WHEN IFNULL(a.result, 0) = 0 THEN CASE WHEN IFNULL(a.isBack, 0) = 0 THEN a.Stack ELSE a.P_L END ELSE 0 END AS Liability'
        ), // 0
        Database.raw("CASE WHEN a.ResultID IS NULL THEN 'Open' ELSE 'Settled' END AS STATUS") // 0
      )
      .where('a4.matchId', matchId)
      .whereIn('a1.Name', ['Toss', 'To Win the Toss'])
      .where((query) => {
        query
          .where('a.UserId', userId)
          .orWhere('a.ParantId', userId)
          .orWhere('a.DealerID', userId)
          .orWhere('a.MasterID', userId)
          .orWhere('a.SMasterID', userId)
          .orWhere('a.SAdminID', userId)
          .orWhere('a.AdminID', userId)
          .orWhere('a.CompanyID', userId)
          .orWhere('a.ParentExchCompanyID', userId)
      })
      .where('a.MatchId', matchId)

    const matchTossFinalValue = matchToss.reduce((pre, curr) => {
      return pre + (parseFloat(curr.Profit) - parseFloat(curr.Liability))
    }, 0.0)

    const tiedMatch = await Database.query()
      .from(`tblbets as a`)
      .join('matchmst', 'matchmst.MstCode', '=', 'a.MatchId')
      .join('market as a1', 'a1.Id', 'a.marketId')
      .join('tblresult as a3', 'a3.resId', 'a.ResultId')
      .join('tblselection as a4', 'a4.selectionId', 'a3.selectionId')
      .distinct()
      .select(
        'a.UserId',
        'a.UserName',
        'a.MatchId',
        'a.SelectionId',
        'a.selectionName',
        'a.MstDate',
        'a.Odds',
        'a.Stack',
        'a.P_L',
        'a.isBack',
        'a4.selectionName as winner',
        'matchmst.matchName as matchName',
        Database.raw("CASE WHEN a.isBack = 1 THEN 'KHAI' ELSE 'LAGAI' END AS Type"),
        Database.raw(
          'CASE WHEN IFNULL(a.result, 0) = 1 THEN CASE WHEN IFNULL(a.isBack, 0) = 0 THEN a.P_L ELSE a.Stack END ELSE 0 END AS Profit'
        ), // 0
        Database.raw(
          'CASE WHEN IFNULL(a.result, 0) = 0 THEN CASE WHEN IFNULL(a.isBack, 0) = 0 THEN a.Stack ELSE a.P_L END ELSE 0 END AS Liability'
        ), // 0
        Database.raw("CASE WHEN a.ResultID IS NULL THEN 'Open' ELSE 'Settled' END AS STATUS") // 0
      )
      .where('a4.matchId', matchId)
      .where('a1.Name', 'Tied Match')
      .where((query) => {
        query
          .where('a.UserId', userId)
          .orWhere('a.ParantId', userId)
          .orWhere('a.DealerID', userId)
          .orWhere('a.MasterID', userId)
          .orWhere('a.SMasterID', userId)
          .orWhere('a.SAdminID', userId)
          .orWhere('a.AdminID', userId)
          .orWhere('a.CompanyID', userId)
          .orWhere('a.ParentExchCompanyID', userId)
      })
      .where('a.MatchId', matchId)

    const tiedMatchFinalValue = tiedMatch.reduce((pre, curr) => {
      return pre + (parseFloat(curr.Profit) - parseFloat(curr.Liability))
    }, 0.0)

    const goalBets = await Database.query()
      .from(`tblbets as a`)
      .join('matchmst', 'matchmst.MstCode', '=', 'a.MatchId')
      .join('market as a1', 'a1.Id', 'a.marketId')
      .join('tblresult as a3', 'a3.resId', 'a.ResultId')
      .join('tblselection as a4', 'a4.selectionId', 'a3.selectionId')
      .distinct()
      .select(
        'a.UserId',
        'a.UserName',
        'a.MatchId',
        'a.SelectionId',
        'a.selectionName',
        'a.MstDate',
        'a.Odds',
        'a.Stack',
        'a.P_L',
        'a.isBack',
        'a4.selectionName as winner',
        'matchmst.matchName as matchName',
        Database.raw("CASE WHEN a.isBack = 1 THEN 'KHAI' ELSE 'LAGAI' END AS Type"),
        Database.raw(
          'CASE WHEN IFNULL(a.result, 0) = 1 THEN CASE WHEN IFNULL(a.isBack, 0) = 0 THEN a.P_L ELSE a.Stack END ELSE 0 END AS Profit'
        ), // 0
        Database.raw(
          'CASE WHEN IFNULL(a.result, 0) = 0 THEN CASE WHEN IFNULL(a.isBack, 0) = 0 THEN a.Stack ELSE a.P_L END ELSE 0 END AS Liability'
        ), // 0
        Database.raw("CASE WHEN a.ResultID IS NULL THEN 'Open' ELSE 'Settled' END AS STATUS") // 0
      )
      .where('a4.matchId', matchId)
      .whereILike('a1.Name', '%goal%')
      .where((query) => {
        query
          .where('a.UserId', userId)
          .orWhere('a.ParantId', userId)
          .orWhere('a.DealerID', userId)
          .orWhere('a.MasterID', userId)
          .orWhere('a.SMasterID', userId)
          .orWhere('a.SAdminID', userId)
          .orWhere('a.AdminID', userId)
          .orWhere('a.CompanyID', userId)
          .orWhere('a.ParentExchCompanyID', userId)
      })
      .where('a.MatchId', matchId)

    const goalFinalValue = goalBets.reduce((pre, curr) => {
      return pre + (parseFloat(curr.Profit) - parseFloat(curr.Liability))
    }, 0.0)

    const fancy = await Database.from(`bet_entry as b`)
      .join('tblresult as c', 'c.resId', '=', 'b.resultId')
      .select(
        'b.userId as UserId',
        'b.UserName',
        'b.matchId as MatchId',
        'b.fancyId as SelectionId',
        Database.raw(
          '(CASE WHEN OddValue = 1 THEN session_no_size ELSE session_yes_size END) as Rate'
        ),
        // 'b.OddsNumber as Rate',
        // Database.raw('(CASE WHEN OddValue = 1 THEN 0 ELSE 1 END) as Rate'),
        Database.raw("(CASE WHEN OddValue = 1 THEN 'NO' ELSE 'YES' END) as Mode"),
        Database.raw('FHeadName as Fancy'),
        'c.Result',
        'b.dateTime as MstDate',
        Database.raw('FORMAT(OddsNumber, 0) as Runs'),
        'b.bet_value as Amt',
        // Database.raw(
        //   'FORMAT((CASE WHEN OddValue = 1 THEN (bet_value * (session_no_size/100)) WHEN OddValue = 0 THEN (bet_value * (session_yes_size/100)) ELSE 0 END), 0) as P_L'
        // ),
        // Database.raw(
        //   '(CASE WHEN (b.TypeID = 5 OR b.TypeID = 2) AND OddValue = 0 THEN 0 ELSE 1 END) as isBack'
        // ),
        Database.raw('CASE WHEN IFNULL(b.Chips, 0) > 0 THEN Chips ELSE 0 END AS Profit'), // 0
        Database.raw('CASE WHEN IFNULL(b.Chips, 0) < 0 THEN Chips ELSE 0 END AS Liability'), //0
        Database.raw("CASE WHEN b.ResultID IS NULL THEN 'Open' ELSE 'Settled' END AS STATUS") // 0
      )
      .leftJoin('matchfancy AS m', 'b.fancyID', 'm.ID')
      .where((query) => {
        query
          .where('b.UserId', userId)
          .orWhere('b.ParantId', userId)
          .orWhere('b.DealerID', userId)
          .orWhere('b.MasterID', userId)
          .orWhere('b.SMasterID', userId)
          .orWhere('b.SAdminID', userId)
          .orWhere('b.AdminID', userId)
          .orWhere('b.CompanyID', userId)
          .orWhere('b.ParentExchCompanyID', userId)
      })
      .where('b.matchId', params.matchId)

    const fancyFinalValue = fancy.reduce((pre, curr) => {
      return pre + (parseFloat(curr.Profit) + parseFloat(curr.Liability))
    }, 0.0)

    const commissionResult = await Database.query()
      .from('tblchipdet')
      .where('levelV', 0)
      .whereIn('MstType', [6, 7, 9, 10])
      .where('matchId', matchId)
      .select(Database.raw('ROUND(SUM(ChipsCr - ChipsDr),2) as commission'))
      .where('userId', userId)
      .groupBy(['userId', 'matchId'])
      .first()

    const commission = commissionResult ? commissionResult.commission : 0

    return response.json({
      matchToss,
      matchTossFinalValue,
      matchodds,
      matchOddsFinalValue,
      tiedMatch,
      tiedMatchFinalValue,
      fancy,
      fancyFinalValue,
      bookmakerodds,
      bookmakerOddsFinalValue,
      goalBets,
      goalFinalValue,
      commission: parseFloat(commission || '0'),
    })
  }

  public async betHistory({ request, authUser, response }: HttpContextContract) {
    let data = await request.validate({
      schema: schema.create({
        bet_type: schema.string(),
        from_date: schema.string(),
        page_no: schema.number(),
        sport_id: schema.string(),
        to_date: schema.string(),
        type: schema.number(),
        user_id: schema.number.optional(),
        limit: schema.number.optional(),
      }),
    })

    if (data.user_id) {
      if (!(await Parent.validate(authUser, data.user_id))) {
        return response.badRequest({
          message: 'Invalid request.',
        })
      }
    } else {
      data.user_id = authUser?.mstrid
    }

    let fetchData = []
    if (data.type == 1) {
      const pageLimit = data.limit || 50
      fetchData = await UserService.bets(data.user_id, {
        needPagination: true,
        page: data.page_no,
        limit: pageLimit,
        bet_type: data.bet_type,
        fromDate: data.from_date + 'T00:00:00',
        toDate: data.to_date + 'T23:59:59',
        afterResult: data.bet_type == 'P',
      })
    } else if (data.type == 0) {
      const pageLimit = data.limit || 50
      fetchData = await UserService.bets(data.user_id, {
        needPagination: true,
        page: data.page_no,
        limit: pageLimit,
        bet_type: data.bet_type,
        fromDate: data.from_date + 'T00:00:00',
        toDate: data.to_date + 'T23:59:59',
        bet_deleted: true,
        afterResult: data.bet_type == 'P',
      })
    }

    return response.json({ data: fetchData })
  }

  public async betHistoryFilter({ request, authUser, response }: HttpContextContract) {
    const data = await request.validate({
      schema: schema.create({
        match_id: schema.string(),
        market_id: schema.string(),
        fancy_id: schema.number(),
      }),
    })

    let Record1 = await Sp.readCall('_bet_history_pl(:user_id,:matchId,:marketId,:fancyId)', {
      user_id: authUser?.mstrid,
      matchId: data.match_id,
      marketId: data.market_id,
      fancyId: data.fancy_id,
    })

    return response.json({
      data: { data: Record1 },
    })
  }

  public async profitLossBySport({ request, authUser, response }: HttpContextContract) {
    let validated = await request.validate({
      schema: schema.create({
        userId: schema.number.optional(),
        fromDate: schema.string(),
        toDate: schema.string(),
      }),
    })

    if (validated.userId) {
      if (!(await Parent.validate(authUser, validated.userId))) {
        return response.badRequest({
          message: 'Invalid request.',
        })
      }
    } else {
      validated.userId = authUser?.mstrid
    }

    const data = await Database.from('tblchipdet as a')
      .innerJoin('matchmst', 'a.MatchId', '=', 'matchmst.MstCode')
      .innerJoin('sportmst', 'matchmst.SportID', '=', 'sportmst.id')
      .where('a.is_deleted', 'N')
      .where('a.MstDate', '>=', validated.fromDate + 'T00:00:00')
      .where('a.MstDate', '<=', validated.toDate + 'T23:59:59')
      // @ts-ignore
      .where('a.UserId', validated.userId)
      // .whereNot('a.ChildID', 0)
      .whereRaw(
        'CASE WHEN a.is_partnership = 0 THEN CASE WHEN (a.LevelV != 0) THEN a.ChildID != 0 ELSE a.ChildID = 0 END ELSE 1 = 1 END'
      )
      .select(
        'a.UserID as UserId',
        'sportmst.id as sport_id',
        'sportmst.name as sport_name',
        Database.raw(
          'ROUND(SUM(CASE WHEN (a.MstType IN (5, 8)) THEN (a.ChipsCr - a.ChipsDr) ELSE 0 END),2) as PnL'
        ),
        Database.raw(
          'ROUND(SUM(CASE WHEN (a.MstType IN (6,7,9,10)) THEN (a.ChipsCr - a.ChipsDr) ELSE 0 END),2) as Comm'
        )
      )
      .groupBy('matchmst.SportID')

    return response.json(data)
  }

  // public async profitLoss({ request, authUser, response }: HttpContextContract) {
  //   let validated = await request.validate({
  //     schema: schema.create({
  //       userId: schema.number.optional(),
  //       fromDate: schema.string(),
  //       toDate: schema.string(),
  //       page: schema.number(),
  //       sportId: schema.number(),
  //       limit: schema.number.optional(),
  //     }),
  //   })

  //   if (validated.userId) {
  //     if (!(await Parent.validate(authUser, validated.userId))) {
  //       return response.badRequest({
  //         message: 'Invalid request.',
  //       })
  //     }
  //   } else {
  //     validated.userId = authUser?.mstrid
  //   }

  //   const limit = validated.limit || 50

  //   const data = await Database.from('tblchipdet as a')
  //     .innerJoin('matchmst as d', 'a.MatchId', '=', 'd.MstCode')
  //     .innerJoin('createmaster as M', 'a.UserId', '=', 'M.mstrid')
  //     .leftJoin('market as e', 'a.MarketId', '=', 'e.Id')
  //     .leftJoin('matchfancy as f', 'a.FancyId', '=', 'f.ID')
  //     .leftJoin('tblresult as g', 'a.ResultID', '=', 'g.resId')
  //     .leftJoin('tblselection as h', 'g.selectionId', '=', 'h.selectionId')
  //     .where('a.is_deleted', 'N')
  //     .if(validated.sportId, (q) => {
  //       q.where('d.SportID', validated.sportId)
  //     })
  //     .where('a.MstDate', '>=', validated.fromDate + 'T00:00:00')
  //     .where('a.MstDate', '<=', validated.toDate + 'T23:59:59')
  //     // @ts-ignore
  //     .where('a.UserId', validated.userId)
  //     // .whereNot('a.ChildID', 0)
  //     .whereRaw(
  //       'CASE WHEN a.is_partnership = 0 THEN CASE WHEN (a.LevelV != 0) THEN a.ChildID != 0 ELSE a.ChildID = 0 END ELSE 1 = 1 END'
  //     )
  //     .select(
  //       'a.UserID as UserId',
  //       'd.SportID as sport_id',
  //       'd.matchName as EventName',
  //       'h.selectionName as WinnerName',
  //       Database.raw(
  //         'ROUND(SUM(CASE WHEN (a.MstType IN (5, 8)) THEN (a.ChipsCr - a.ChipsDr) ELSE 0 END),2) as PnL'
  //       ),
  //       Database.raw(
  //         'ROUND(SUM(CASE WHEN (a.MstType IN (6,7,9,10)) THEN (a.ChipsCr - a.ChipsDr) ELSE 0 END),2) as Comm'
  //       ),
  //       'a.MatchId as matchId',
  //       Database.raw('IFNULL(a.MarketId, 0) as MarketId'),
  //       Database.raw('IFNULL(a.FancyId, 0) as fancyId'),
  //       Database.raw('MAX(a.MstDate) as settle_date')
  //     )
  //     .groupBy('a.UserID', 'a.MatchId')
  //     .orderBy('a.MstDate', 'desc')
  //     .paginate(validated.page, limit)

  //   return response.json(data)
  // }

  public async profitLoss({ request, authUser, response }: HttpContextContract) {
    const validated = await request.validate({
      schema: schema.create({
        userId: schema.number.optional(),
        fromDate: schema.string(),
        toDate: schema.string(),
        page: schema.number(),
        sportId: schema.number(),
        limit: schema.number.optional(),
      }),
    })

    if (validated.userId) {
      if (!(await Parent.validate(authUser, validated.userId))) {
        return response.badRequest({ message: 'Invalid request.' })
      }
    } else {
      validated.userId = authUser?.mstrid
    }

    // Call the stored procedure instead of the complex query
    const storedProcResult: any = await Sp.readCall(
      `Winner_ProfitLoss(:pFromDate, :pToDate, :pSportID, :pUserID)`,
      {
        pFromDate: validated.fromDate,
        pToDate: validated.toDate,
        pSportID: validated.sportId,
        pUserID: validated.userId,
      }
    )

    // Optional: Paginate manually if needed
    const page = validated.page
    const limit = validated.limit || 50
    const offset = (page - 1) * limit
    const paginatedData = storedProcResult.slice(offset, offset + limit)

    if (paginatedData.length) {
      const matchIds = [...new Set(paginatedData.map((r) => r.matchId))]

      // const declaredResults = await Mongo.collection('declared_results')
      //   .find({ matchId: { $in: matchIds } }, { projection: { _id: 0 } })
      //   .toArray()
      const declaredResults = await Mongo.collection('declared_results')
        .find(
          {
            matchId: { $in: matchIds },
            marketName: 'Bookmaker', // 👈 ONLY Bookmaker
          },
          { projection: { _id: 0 } }
        )
        .toArray()

      // Pick ONE result per match
      const declaredMap = new Map<number, any>()

      for (const dr of declaredResults) {
        if (!declaredMap.has(dr.matchId)) {
          declaredMap.set(dr.matchId, dr)
        }
      }

      for (const row of paginatedData) {
        row.declaredResult = declaredMap.get(row.matchId) || null
      }
    }

    return response.json({
      data: paginatedData,
      meta: {
        total: storedProcResult.length,
        page,
        perPage: limit,
        lastPage: Math.ceil(storedProcResult.length / limit),
      },
    })
  }

  // public async profitLossByMatch({ request, authUser, response }: HttpContextContract) {
  //   let validated = await request.validate({
  //     schema: schema.create({
  //       userId: schema.number(),
  //       fromDate: schema.string(),
  //       toDate: schema.string(),
  //       sportId: schema.number(),
  //       matchId: schema.number(),
  //     }),
  //   })

  //   if (validated.userId) {
  //     if (!(await Parent.validate(authUser, validated.userId))) {
  //       return response.badRequest({
  //         message: 'Invalid request.',
  //       })
  //     }
  //   } else {
  //     validated.userId = authUser?.mstrid
  //   }

  //   const data = await Database.from('tblchipdet')
  //     .select(
  //       'tblchipdet.is_deleted',
  //       'createmaster.mstruserid',
  //       'createmaster.usetype',
  //       'tblchipdet.UserID',
  //       'matchmst.bet_deleted',
  //       'matchmst.MatchName',
  //       Database.raw('IFNULL(market.Name, matchfancy.HeadName) as MarketName'),
  //       Database.raw(
  //         'ROUND(SUM((CASE WHEN (tblchipdet.MstType IN (5, 8)) THEN (tblchipdet.ChipsCr - tblchipdet.ChipsDr) ELSE 0 END)), 2) as PnL'
  //       ),
  //       Database.raw(
  //         'ROUND(SUM((CASE WHEN (tblchipdet.MstType IN (6,7,9,10)) THEN (tblchipdet.ChipsCr - tblchipdet.ChipsDr) ELSE 0 END)), 2) as Comm'
  //       ),
  //       Database.raw('MAX(tblchipdet.MstDate) as MstDate'),
  //       Database.raw('IFNULL(tblchipdet.MarketId,0) as MarketId'),
  //       Database.raw('IFNULL(tblchipdet.FancyId,0) as fancyId'),
  //       'tblchipdet.matchId',
  //       'matchfancy.result'
  //     )
  //     .innerJoin('matchmst', 'tblchipdet.MatchId', 'matchmst.MstCode')
  //     .innerJoin('createmaster', 'tblchipdet.UserId', 'createmaster.mstrid')
  //     .leftJoin('market', 'tblchipdet.MarketId', 'market.Id')
  //     .leftJoin('matchfancy', 'tblchipdet.FancyId', 'matchfancy.ID')
  //     .where('tblchipdet.is_deleted', 'N')
  //     .where('tblchipdet.UserId', validated.userId)
  //     .where('tblchipdet.MatchId', validated.matchId)
  //     .where('tblchipdet.MstDate', '>=', validated.fromDate + 'T00:00:00')
  //     .where('tblchipdet.MstDate', '<=', validated.toDate + 'T23:59:59')
  //     .whereRaw(
  //       'CASE WHEN tblchipdet.is_partnership = 0 THEN CASE WHEN (tblchipdet.LevelV != 0) THEN tblchipdet.ChildID != 0 ELSE tblchipdet.ChildID = 0 END ELSE 1 = 1 END'
  //     )
  //     .groupByRaw(
  //       Database.raw(
  //         'tblchipdet.UserID, tblchipdet.MatchId ,tblchipdet.MarketId, tblchipdet.FancyId, IFNULL(tblchipdet.MarketId,0),IFNULL(tblchipdet.FancyId,0)'
  //       )
  //     )
  //     .orderByRaw('MAX(tblchipdet.MstDate) desc')

  //   return response.json({ data })
  // }

  // public async profitLossByMatch({ request, authUser, response }: HttpContextContract) {

  //   const validated = await request.validate({

  //     schema: schema.create({

  //       userId: schema.number.optional(),

  //       fromDate: schema.string(),

  //       toDate: schema.string(),

  //       sportId: schema.number.optional(),

  //       matchId: schema.number(),

  //       page: schema.number.optional(),

  //       limit: schema.number.optional(),

  //     }),

  //   })

  //   // ✅ Resolve user

  //   if (validated.userId) {

  //     if (!(await Parent.validate(authUser, validated.userId))) {

  //       return response.badRequest({ message: 'Invalid request.' })

  //     }

  //   } else {

  //     validated.userId = authUser?.mstrid

  //   }

  //   const userId = validated.userId as number

  //   const page = validated.page || 1

  //   const limit = validated.limit || 50
  //   const needPagination = true

  //   // ✅ Base query (FILTER FIRST 🚀)

  //   const baseQuery = Database.from('tblchipdet')

  //     .where('tblchipdet.is_deleted', 'N')

  //     .where('tblchipdet.UserId', userId)

  //     .where('tblchipdet.MatchId', validated.matchId)

  //     .whereBetween('tblchipdet.MstDate', [

  //       validated.fromDate + 'T00:00:00',

  //       validated.toDate + 'T23:59:59',

  //     ])

  //   // ✅ Replace expensive CASE with simpler logic

  //   baseQuery.where((q) => {

  //     q.where('tblchipdet.is_partnership', 1)

  //       .orWhere((sub) => {

  //         sub.where('tblchipdet.is_partnership', 0)

  //         sub.where((inner) => {

  //           inner

  //             .where((x) => {

  //               x.where('tblchipdet.LevelV', '!=', 0)

  //               x.where('tblchipdet.ChildID', '!=', 0)

  //             })

  //             .orWhere((x) => {

  //               x.where('tblchipdet.LevelV', 0)

  //               x.where('tblchipdet.ChildID', 0)

  //             })

  //         })

  //       })

  //   })

  //   // ✅ Aggregation query
  //   const aggregatedQuery = baseQuery
  //     .clone()

  //     .select(

  //       'tblchipdet.UserID',

  //       'tblchipdet.matchId',

  //       Database.raw('COALESCE(tblchipdet.MarketId,0) as MarketId'),

  //       Database.raw('COALESCE(tblchipdet.FancyId,0) as FancyId'),

  //       Database.raw(`

  //       ROUND(SUM(

  //         CASE WHEN tblchipdet.MstType IN (5,8)

  //         THEN (tblchipdet.ChipsCr - tblchipdet.ChipsDr)

  //         ELSE 0 END

  //       ),2) as PnL

  //     `),

  //       Database.raw(`

  //       ROUND(SUM(

  //         CASE WHEN tblchipdet.MstType IN (6,7,9,10)

  //         THEN (tblchipdet.ChipsCr - tblchipdet.ChipsDr)

  //         ELSE 0 END

  //       ),2) as Comm

  //     `),

  //       Database.raw('MAX(tblchipdet.MstDate) as MstDate')

  //     )

  //     .groupBy(

  //       'tblchipdet.UserID',

  //       'tblchipdet.matchId',

  //       'tblchipdet.MarketId',

  //       'tblchipdet.FancyId'

  //     )

  //     .orderBy('MstDate', 'desc')

  //   // ✅ Join AFTER aggregation (🚀 performance boost)
  //   const finalQuery = Database.from(aggregatedQuery.as('t'))
  //     .leftJoin('matchmst', 't.matchId', 'matchmst.MstCode')

  //     .leftJoin('createmaster', 't.UserID', 'createmaster.mstrid')

  //     .leftJoin('market', 't.MarketId', 'market.Id')

  //     .leftJoin('matchfancy', 't.FancyId', 'matchfancy.ID')

  //     .select(

  //       't.*',

  //       'matchmst.MatchName',

  //       'matchmst.bet_deleted',

  //       'createmaster.mstruserid',

  //       'createmaster.usetype',

  //       Database.raw('COALESCE(market.Name, matchfancy.HeadName) as MarketName'),

  //       'matchfancy.result'
  //     )

  //   // ✅ Counts (optional, like bets)
  //   const getCounts = async () => {
  //     const result = await baseQuery
  //       .clone()
  //       .count('* as total')
  //       .first()

  //     return {
  //       total: Number(result?.total || 0),
  //     }
  //   }

  //   const tossQuery = finalQuery
  //     .clone()
  //     .where((q) => {
  //       q.where('market.Name', 'Toss')
  //         .orWhere('matchfancy.HeadName', 'Toss')
  //     })
  //     .limit(1) // only 1 record

  //   // ✅ Pagination (same as bets API)
  //   if (needPagination) {
  //     const result = await finalQuery.paginate(page, limit)
  //     const counts = await getCounts()

  //     return response.json({
  //       data: result.all(),
  //       meta: result.getMeta(),
  //       counts,
  //     })
  //   }

  //   // ✅ Without pagination
  //   const data = await finalQuery
  //   const counts: any = await getCounts()

  //   return response.json({
  //     data,
  //     counts
  //   })
  // }
  // public async profitLossByMatch({

  //   request,

  //   authUser,

  //   response,

  // }: HttpContextContract) {

  //   const validated = await request.validate({

  //     schema: schema.create({

  //       userId: schema.number.optional(),

  //       fromDate: schema.string(),

  //       toDate: schema.string(),

  //       sportId: schema.number.optional(),

  //       matchId: schema.number(),

  //       page: schema.number.optional(),

  //       limit: schema.number.optional(),

  //     }),

  //   })

  //   // ✅ Resolve user

  //   if (validated.userId) {

  //     if (!(await Parent.validate(authUser, validated.userId))) {

  //       return response.badRequest({ message: 'Invalid request.' })

  //     }

  //   } else {

  //     validated.userId = authUser?.mstrid

  //   }

  //   const userId = validated.userId as number

  //   const page = validated.page || 1

  //   const limit = validated.limit || 50

  //   const baseQuery = Database.from('tblchipdet')

  //     .where('tblchipdet.is_deleted', 'N')

  //     .where('tblchipdet.UserId', userId)

  //     .where('tblchipdet.MatchId', validated.matchId)

  //     .whereBetween('tblchipdet.MstDate', [

  //       validated.fromDate + 'T00:00:00',

  //       validated.toDate + 'T23:59:59',

  //     ])

  //     // your existing filter logic

  //     .where((q) => {

  //       q.where('tblchipdet.is_partnership', 1).orWhere((sub) => {

  //         sub.where('tblchipdet.is_partnership', 0)

  //         sub.where((inner) => {

  //           inner

  //             .where((x) => {

  //               x.where('tblchipdet.LevelV', '!=', 0)

  //               x.where('tblchipdet.ChildID', '!=', 0)

  //             })

  //             .orWhere((x) => {

  //               x.where('tblchipdet.LevelV', 0)

  //               x.where('tblchipdet.ChildID', 0)

  //             })

  //         })

  //       })

  //     })

  //   // ✅ Aggregation

  //   const aggregatedQuery = baseQuery

  //     .clone()

  //     .select(

  //       'tblchipdet.UserID',

  //       'tblchipdet.matchId',

  //       Database.raw('COALESCE(tblchipdet.MarketId,0) as MarketId'),

  //       Database.raw('COALESCE(tblchipdet.FancyId,0) as FancyId'),

  //       Database.raw(`

  //       ROUND(SUM(

  //         CASE WHEN tblchipdet.MstType IN (5,8)

  //         THEN (tblchipdet.ChipsCr - tblchipdet.ChipsDr)

  //         ELSE 0 END

  //       ),2) as PnL

  //     `),

  //       Database.raw(`

  //       ROUND(SUM(

  //         CASE WHEN tblchipdet.MstType IN (6,7,9,10)

  //         THEN (tblchipdet.ChipsCr - tblchipdet.ChipsDr)

  //         ELSE 0 END

  //       ),2) as Comm

  //     `),

  //       Database.raw('MAX(tblchipdet.MstDate) as MstDate')

  //     )

  //     .groupBy(

  //       'tblchipdet.UserID',

  //       'tblchipdet.matchId',

  //       'tblchipdet.MarketId',

  //       'tblchipdet.FancyId'

  //     )

  //     .orderBy('MstDate', 'desc')

  //   // ✅ Final Join

  //   const finalQuery = Database.from(aggregatedQuery.as('t'))

  //     .leftJoin('matchmst', 't.matchId', 'matchmst.MstCode')

  //     .leftJoin('createmaster', 't.UserID', 'createmaster.mstrid')

  //     .leftJoin('market', 't.MarketId', 'market.Id')

  //     .leftJoin('matchfancy', 't.FancyId', 'matchfancy.ID')

  //     .select(

  //       't.*',

  //       'matchmst.MatchName',

  //       'matchmst.bet_deleted',

  //       'createmaster.mstruserid',

  //       'createmaster.usetype',

  //       Database.raw(

  //         'COALESCE(market.Name, matchfancy.HeadName) as MarketName'

  //       ),

  //       'matchfancy.result'

  //     )

  //   // ✅ Count

  //   const getCounts = async () => {

  //     const result = await baseQuery.clone().count('* as total').first()

  //     return { total: Number(result?.total || 0) }

  //   }

  //   // ✅ Execute

  //   const result = await finalQuery.paginate(page, limit)

  //   const counts = await getCounts()

  //   const allData = result.all()

  //   // 🔥 SPLIT LOGIC

  //   const tossData = allData.filter(

  //     (item) => item.MarketName === 'Toss'

  //   )

  //   const fancyData = allData.filter(

  //     (item) =>

  //       item.FancyId !== 0 &&

  //       item.MarketName !== 'Toss'

  //   )

  //   const normalData = allData.filter(
  //     (item) =>
  //       item.FancyId === 0 &&
  //       item.MarketName !== 'Toss'
  //   )

  //   return response.json({
  //     data: {
  //       toss: tossData,
  //       fancy: fancyData,
  //       market: normalData,

  //     },

  //     meta: result.getMeta(),

  //     counts,

  //   })

  // }
  public async profitLossByMatch({
    request,
    authUser,
    response,
  }: HttpContextContract) {
    const validated = await request.validate({
      schema: schema.create({
        userId: schema.number.optional(),
        fromDate: schema.string(),
        toDate: schema.string(),
        sportId: schema.number.optional(),
        matchId: schema.number(),
        page: schema.number.optional(),
        limit: schema.number.optional(),
      }),
    })


    // ✅ Resolve user
    if (validated.userId) {
      if (!(await Parent.validate(authUser, validated.userId))) {
        return response.badRequest({ message: 'Invalid request.' })
      }
    } else {
      validated.userId = authUser?.mstrid
    }

    const userId = validated.userId as number
    const page = validated.page || 1
    const limit = validated.limit || 50

    const baseQuery = Database.from('tblchipdet')
      .where('tblchipdet.is_deleted', 'N')
      .where('tblchipdet.UserId', userId)
      .where('tblchipdet.MatchId', validated.matchId)
      .whereBetween('tblchipdet.MstDate', [
        validated.fromDate + 'T00:00:00',
        validated.toDate + 'T23:59:59',
      ])

      // your existing filter logic
      .where((q) => {
        q.where('tblchipdet.is_partnership', 1).orWhere((sub) => {
          sub.where('tblchipdet.is_partnership', 0)
          sub.where((inner) => {
            inner
              .where((x) => {
                x.where('tblchipdet.LevelV', '!=', 0)
                x.where('tblchipdet.ChildID', '!=', 0)
              })
              .orWhere((x) => {
                x.where('tblchipdet.LevelV', 0)
                x.where('tblchipdet.ChildID', 0)
              })
          })
        })
      })

    // ✅ Aggregation
    const aggregatedQuery = baseQuery
      .clone()
      .select(
        'tblchipdet.UserID',
        'tblchipdet.matchId',
        Database.raw('COALESCE(tblchipdet.MarketId,0) as MarketId'),
        Database.raw('COALESCE(tblchipdet.FancyId,0) as FancyId'),

        Database.raw(`
        ROUND(SUM(
          CASE WHEN tblchipdet.MstType IN (5,8)
          THEN (tblchipdet.ChipsCr - tblchipdet.ChipsDr)
          ELSE 0 END
        ),2) as PnL
      `),

        Database.raw(`
        ROUND(SUM(
          CASE WHEN tblchipdet.MstType IN (6,7,9,10)
          THEN (tblchipdet.ChipsCr - tblchipdet.ChipsDr)
          ELSE 0 END
        ),2) as Comm
      `),

        Database.raw('MAX(tblchipdet.MstDate) as MstDate')
      )
      .groupBy(
        'tblchipdet.UserID',
        'tblchipdet.matchId',
        'tblchipdet.MarketId',
        'tblchipdet.FancyId'
      )
      .orderBy('MstDate', 'desc')

    // ✅ Final Join
    const finalQuery = Database.from(aggregatedQuery.as('t'))
      .leftJoin('matchmst', 't.matchId', 'matchmst.MstCode')
      .leftJoin('createmaster', 't.UserID', 'createmaster.mstrid')
      .leftJoin('market', 't.MarketId', 'market.Id')
      .leftJoin('matchfancy', 't.FancyId', 'matchfancy.ID')
      .select(
        't.*',
        'matchmst.MatchName',
        'matchmst.bet_deleted',
        'createmaster.mstruserid',
        'createmaster.usetype',
        Database.raw(
          'COALESCE(market.Name, matchfancy.HeadName) as MarketName'
        ),
        'matchfancy.result'
      )

    const totalFancyPLResult = await Database.from(aggregatedQuery.clone().as('t'))
      .where('t.FancyId', '!=', 0) // ✅ only fancy
      .sum('t.PnL as totalFancyPL')
      .first()
    const totalFancyPL = Number(totalFancyPLResult?.totalFancyPL || 0)
    // ✅ Count
    // const getCounts = async () => {
    //   const result = await baseQuery.clone().count('* as total').first()
    //   return { total: Number(result?.total || 0) }
    // }

    // ✅ Execute
    const tossData = (await finalQuery).filter(
      (item) => item.MarketName === 'Toss'
    )

    const result = await finalQuery.paginate(page, limit);

    // const counts = await getCounts()
    const allData = result.all()

    // 🔥 SPLIT LOGIC


    const fancyData = allData.filter(
      (item) =>
        item.FancyId !== 0 &&
        item.MarketName !== 'Toss'
    )

    const normalData = allData.filter(
      (item) =>
        item.MarketName === 'Bookmaker' ||
        item.MarketName === 'Match Odds'
    )

    return response.json({
      data: {
        toss: tossData,
        fancy: fancyData,
        market: normalData,
        totalFancyPL, // ✅ total fancy P&L
      },
      meta: result.getMeta(),
    })
  }


  public async loginHistory({ request, authUser, response }: HttpContextContract) {
    const limit = request.input('limit', 50)
    const page = request.input('page', 1)
    const userId = request.input('userId', authUser.mstrid)
    const fromDate = request.input('from_date')
    const toDate = request.input('to_date')

    if (!(await Parent.validate(authUser, userId))) {
      return response.badRequest({
        message: 'Invalid request.',
      })
    }

    const result = await Database.from('userlogged')
      .select('userlogged.*', 'createmaster.mstruserid')
      .leftJoin('createmaster', 'userlogged.loguser', 'createmaster.mstrid')
      .where('userlogged.loguser', userId)
      .if(fromDate, (q) => {
        q.where('userlogged.logstdt', '>=', fromDate + 'T00:00:00')
      })
      .if(toDate, (q) => {
        q.where('userlogged.logstdt', '<=', toDate + 'T23:59:59')
      })
      .orderBy('userlogged.logstdt', 'desc')
      .paginate(page, limit)

    return response.json(result)
  }

  public async passwordHistory({ request, authUser, response }: HttpContextContract) {
    const limit = request.input('limit', 50)
    const page = request.input('page', 1)
    const userId = request.input('userId', authUser.mstrid)
    const fromDate = request.input('from_date')
    const toDate = request.input('to_date')

    if (userId) {
      if (!(await Parent.validate(authUser, userId))) {
        return response.badRequest({
          message: 'Invalid request.',
        })
      }
    }

    const data = await Database.query()
      .from('password_history')
      .join('createmaster', 'createmaster.mstrid', '=', 'password_history.user_id')
      .join('createmaster as changer', 'changer.mstrid', '=', 'password_history.changer_id')
      .select(
        'password_history.*',
        'createmaster.mstruserid as username',
        'changer.mstruserid as changername'
      )
      .if(userId, (q) => {
        q.where('password_history.user_id', userId)
      })
      .if(fromDate && toDate, (q) => {
        q.where('password_history.created_at', '>=', fromDate + 'T00:00:00')
        q.where('password_history.created_at', '<=', toDate + 'T23:59:59')
      })
      .orderBy('password_history.created_at', 'desc')
      .paginate(page, limit)

    return response.json({
      data: data,
    })
  }

  public async plByMarket({ request, authUser, response }: HttpContextContract) {
    const data = await request.validate({
      schema: schema.create({
        matchId: schema.number(),
        MarketId: schema.array().members(schema.string()),
      }),
    })

    let PLData: any = []

    for (const d of data.MarketId) {
      const rows: any = await Sp.readCall(
        '_get_odds_profit_loss(:userId,:userType,:match_Id,:marketId)',
        {
          userId: authUser.mstrid,
          match_Id: data.matchId,
          marketId: d,
          userType: authUser.usetype,
        }
      )

      PLData.push(...rows)
    }

    return response.json({
      data: PLData,
    })
  }

  public async companyReport({ request, authUser, response }: HttpContextContract) {
    const v = await request.validate({
      schema: schema.create({
        userId: schema.string(),
        useType: schema.string(),
        matchId: schema.string(),
      }),
    })

    if (!(await Parent.validate(authUser, v.userId))) {
      return response.badRequest({
        message: 'Invalid request.',
      })
    }

    const data: any = await Sp.readCall('_company_report(:userId,:userType,:matchId)', {
      userId: v.userId,
      userType: v.useType,
      matchId: v.matchId,
    })

    return response.json({
      status: true,
      message: null,
      data: data,
    })
  }

  public async agentReport({ request, authUser, response }: HttpContextContract) {
    const v = await request.validate({
      schema: schema.create({
        userId: schema.string(),
        // useType: schema.string(),
        matchId: schema.string(),
      }),
    })

    if (!(await Parent.validate(authUser, v.userId))) {
      return response.badRequest({
        message: 'Invalid request.',
      })
    }

    const agentData: any = await Sp.readCall('_agent_report(:userId,:matchId)', {
      userId: v.userId,
      // userType: v.useType,
      matchId: v.matchId,
    })

    // const clientData: any = await Sp.call('_client_report(:userId,:matchId)', {
    //   userId: v.userId,
    //   // userType: v.useType,
    //   matchId: v.matchId,
    // })

    return response.json({
      status: true,
      message: null,
      agentData,
      // clientData,
    })
  }

  public async sessionEarningReport({ request, response }: HttpContextContract) {
    const v = await request.validate({
      schema: schema.create({
        userId: schema.string(),
        matchId: schema.string(),
      }),
    })

    // if (!(await Parent.validate(authUser, v.userId))) {
    //   return response.badRequest({
    //     message: 'Invalid request.',
    //   })
    // }

    const sessionEarningData: any = await Sp.readCall('_session_earning_report(:userId,:matchId)', {
      userId: v.userId,
      matchId: v.matchId,
    })

    return response.json({
      status: true,
      message: null,
      sessionEarningData,
    })
  }

  public async agentCommissionUserwiseReport({ request, response }: HttpContextContract) {
    const v = await request.validate({
      schema: schema.create({
        userId: schema.string(),
        matchId: schema.string.optional(),
        fromDate: schema.date.optional({ format: 'yyyy-MM-dd' }),
        toDate: schema.date.optional({ format: 'yyyy-MM-dd' }),
      }),
    })

    const agentCommissionUserwiseData: any = await Sp.call(
      '_agent_commission_userwise(:pUserID,:pMatchID,:pFromDate,:pToDate)',
      {
        pUserID: v.userId,
        pMatchID: v.matchId ? v.matchId : '',
        pFromDate: v.fromDate ? v.fromDate.toJSDate() : '',
        pToDate: v.toDate ? v.toDate.toJSDate() : '',
      }
    )

    const agentMarketRollingCommissionData: any = await Sp.readCall(
      '_agent_market_rolling_commission(:pUserID,:pMatchID,:pFromDate,:pToDate)',
      {
        pUserID: v.userId,
        pMatchID: v.matchId ? v.matchId : '',
        pFromDate: v.fromDate ? v.fromDate.toJSDate() : null,
        pToDate: v.toDate ? v.toDate.toJSDate() : null,
      }
    )

    return response.json({
      status: true,
      message: null,
      agentCommissionUserwiseData,
      agentMarketRollingCommissionData,
    })
  }

  public async getDeclaredMatches({ response }: HttpContextContract) {
    const startDate = DateTime.now() // 14 days ago (inclusive today = 15 days)
      .minus({ days: 14 })
      .startOf('day')
      .toSQL({ includeOffset: false }) // <-- important: no timezone offset

    const endDate = DateTime.now().endOf('day').toSQL({ includeOffset: false })

    const matches = await Database.query()
      .from('matchmst')
      .select('MstCode', 'matchName')
      .where('active', 0)
      .where('SportID', 4)
      .whereBetween('MstDate', [startDate, endDate])
      .orderBy('MstDate', 'desc')

    return response.json({
      status: true,
      message: null,
      data: matches,
    })
  }

  public async royalCasinoReport({ request, authUser, response }: HttpContextContract) {
    const v = await request.validate({
      schema: schema.create({
        fromDate: schema.date.optional({ format: 'yyyy-MM-dd' }),
        toDate: schema.date.optional({ format: 'yyyy-MM-dd' }),
      }),
    })

    let royalCasinoReportData: any = []
    if (authUser.usetype == 11) {
      royalCasinoReportData = await Sp.readCall(
        'GetChipSummaryByCompany(:pUserID,:pFromDate,:pToDate)',
        {
          pUserID: authUser.mstrid,
          pFromDate: v.fromDate ? v.fromDate.toJSDate() : '',
          pToDate: v.toDate ? v.toDate.toJSDate() : '',
        }
      )
    } else {
      royalCasinoReportData = await Sp.readCall('GetChipSummaryByDate(:pFromDate,:pToDate)', {
        pFromDate: v.fromDate ? v.fromDate.toJSDate() : '',
        pToDate: v.toDate ? v.toDate.toJSDate() : '',
      })
    }

    return response.json({
      status: true,
      message: null,
      royalCasinoReportData,
    })
  }

  public async getTossResults({ request, response }: HttpContextContract) {
    const matchId = request.input('matchId') // optional

    const query: any = { marketName: 'Toss' }

    // Optional matchId filter
    if (matchId) {
      query.matchId = Number(matchId)
    }

    const results = await Mongo.collection('declared_results')
      .find(query)
      .sort({ createdAt: -1 }) // newest first
      .toArray()

    return response.json({
      data: results,
    })
  }

  public async getTodayLoginLogs({ request, response }: HttpContextContract) {
    try {
      const userId = request.input('userId') // optional filter

      // Get start and end of current day in UTC
      const startOfDay = DateTime.now().startOf('day').toJSDate()
      const endOfDay = DateTime.now().endOf('day').toJSDate()

      const query: any = {
        loginTime: { $gte: startOfDay, $lte: endOfDay }, // today's logins
      }

      if (userId) {
        query.userId = Number(userId)
      }

      const logs = await Mongo.collection('login_logs')
        .find(query)
        .sort({ loginTime: -1 }) // newest first
        .toArray()

      return response.json({
        status: true,
        data: logs,
      })
    } catch (err) {
      console.error('Error fetching today login logs:', err)
      return response.status(500).json({
        status: false,
        message: 'Failed to fetch today login logs',
      })
    }
  }

  public async getBetsCountPerUserForOnlyToday({ request, response }: HttpContextContract) {
    try {
      const matchId = request.input('matchId') // optional filter

      // Get start and end of current day in UTC
      const startOfDay = DateTime.now().startOf('day').toJSDate()
      const endOfDay = DateTime.now().endOf('day').toJSDate()

      const matchFilter: any = {
        MstDate: { $gte: startOfDay, $lte: endOfDay },
      }

      if (matchId) {
        matchFilter.MatchId = Number(matchId)
      }

      const results = await Mongo.collection('bets')
        .aggregate([
          { $match: matchFilter },
          {
            $group: {
              _id: '$UserId',
              username: { $first: '$Username' },
              totalBets: { $sum: 1 },
            },
          },
          { $sort: { totalBets: -1 } },
        ])
        .toArray()

      return response.json({ data: results })
    } catch (error) {
      return response.status(500).json({ message: 'Something went wrong', error })
    }
  }

  // public async getBetsCountPerUser({ request, authUser, response }: HttpContextContract) {
  //   try {
  //     const matchId = request.input('matchId') // optional
  //     const companyId = authUser?.mstrid  // or however you store it

  //     /* ---------------- NORMAL BETS ---------------- */
  //     const betsFilter: any = {}

  //     if (companyId != 1) {
  //       betsFilter.companyId = companyId   // ✅ IMPORTANT
  //     }
  //     if (matchId) {
  //       betsFilter.MatchId = Number(matchId)
  //     }
  //     console.log('Normal Bets Filter:', betsFilter) // Debug log to verify filter
  //     const normalBets = await Mongo.collection('bets')
  //       .aggregate([
  //         { $match: betsFilter },
  //         {
  //           $group: {
  //             _id: '$UserId',
  //             username: { $first: '$Username' },
  //             totalBets: { $sum: 1 },
  //           },
  //         },
  //         { $sort: { totalBets: -1 } },
  //       ])
  //       .toArray()

  //     /* ---------------- FANCY BETS ---------------- */
  //     const fancyFilter: any = {}
  //     if (companyId != 1) {
  //       fancyFilter.companyId = companyId   // ✅ IMPORTANT
  //     }
  //     if (matchId) {
  //       fancyFilter.MatchId = Number(matchId) // ✅ correct case
  //     }
  //     console.log('Fancy Bets Filter:', fancyFilter) // Debug log to verify filter
  //     const fancyBets = await Mongo.collection('fancy_bets')
  //       .aggregate([
  //         { $match: fancyFilter },
  //         {
  //           $group: {
  //             _id: '$UserId', // ✅ correct case
  //             username: { $first: '$UserName' }, // ✅ correct
  //             totalBets: { $sum: 1 },
  //           },
  //         },
  //         { $sort: { totalBets: -1 } },
  //       ])
  //       .toArray()

  //     /* ---------------- RESPONSE ---------------- */
  //     return response.json({
  //       status: true,
  //       data: {
  //         normalBets,
  //         fancyBets,
  //       },
  //     })
  //   } catch (error) {
  //     return response.status(500).json({
  //       status: false,
  //       message: 'Something went wrong',
  //       error,
  //     })
  //   }
  // }
  public async getBetsCountPerUser({ request, authUser, response }: HttpContextContract) {
    try {
      const matchId = request.input('matchId') || null
      const companyID = authUser?.mstrid || 1
      /* ---------------- NORMAL BETS ---------------- */
      const normalBetsQuery = await Database.rawQuery(
        `
      SELECT 
        UserId AS _id,
        Username AS username,
        COUNT(*) AS totalBets
      FROM tblbets
      WHERE 
        (? = 1 OR companyID = ?)
        AND (? IS NULL OR matchid = ?)
      GROUP BY UserId, Username
      ORDER BY totalBets DESC
      `,
        [companyID, companyID, matchId, matchId]
      )

      /* ---------------- FANCY BETS ---------------- */
      const fancyBetsQuery = await Database.rawQuery(
        `
      SELECT 
        UserId AS _id,
        UserName AS username,
        COUNT(*) AS totalBets
      FROM bet_entry
      WHERE 
        (? = 1 OR companyID = ?)
        AND (? IS NULL OR matchid = ?)
      GROUP BY UserId, UserName
      ORDER BY totalBets DESC
      `,
        [companyID, companyID, matchId, matchId]
      )

      // Handle DB driver difference
      const normalBets = normalBetsQuery.rows || normalBetsQuery[0]
      const fancyBets = fancyBetsQuery.rows || fancyBetsQuery[0]

      return response.json({
        status: true,
        data: {
          normalBets,
          fancyBets,
        },
      })

    } catch (error: any) {
      console.error(error)

      return response.status(500).json({
        status: false,
        message: 'Something went wrong',
        error: error.message,
      })
    }

  }

  public async getMatchStateCounts({ request, authUser, response }: HttpContextContract) {
    try {
      const matchId = request.input('matchId')
      const companyId = authUser?.mstrid

      /* ---------------- NORMAL BETS ---------------- */
      const betsFilter: any = {}

      if (companyId != 1) {
        betsFilter.companyId = companyId
      }
      if (matchId) {
        betsFilter.MatchId = Number(matchId)
      }

      const normalCountResult = await Mongo.collection('bets')
        .aggregate([
          { $match: betsFilter },
          {
            $group: {
              _id: null,
              totalBets: { $sum: 1 },
            },
          },
        ])
        .toArray()

      /* ---------------- FANCY BETS ---------------- */
      const fancyFilter: any = {}

      if (companyId != 1) {
        fancyFilter.companyId = companyId
      }
      if (matchId) {
        fancyFilter.MatchId = Number(matchId)
      }

      const fancyCountResult = await Mongo.collection('fancy_bets')
        .aggregate([
          { $match: fancyFilter },
          {
            $group: {
              _id: null,
              totalBets: { $sum: 1 },
            },
          },
        ])
        .toArray()

      /* ---------------- REDIS COUNTS + FAILED DATA ---------------- */
      let successCount = 0
      let failCount = 0
      let failedData: any[] = []

      let glSuccessCount = 0
      let glFailCount = 0
      let glFailedData: any[] = []

      if (matchId) {
        const successKey = `MATCH:${matchId}:SUCCESS_COUNT`
        const failKey = `MATCH:${matchId}:FAIL_COUNT`
        const failDataKey = `MATCH:${matchId}:FAIL_DATA`

        const glSuccessKey = `MATCH:${matchId}:GL_SUCCESS_COUNT`
        const glFailKey = `MATCH:${matchId}:GL_FAIL_COUNT`
        const glFailDataKey = `MATCH:${matchId}:GL_FAIL_DATA`

        const [
          success,
          fail,
          failList,
          glSuccess,
          glFail,
          glFailList
        ] = await Promise.all([
          Redis.get(successKey),
          Redis.get(failKey),
          Redis.lrange(failDataKey, 0, -1),

          Redis.get(glSuccessKey),
          Redis.get(glFailKey),
          Redis.lrange(glFailDataKey, 0, -1),
        ])

        successCount = Number(success) || 0
        failCount = Number(fail) || 0

        glSuccessCount = Number(glSuccess) || 0
        glFailCount = Number(glFail) || 0

        // ✅ parse updateLiability failed data
        if (failList?.length) {
          failedData = failList.map((item: string) => {
            try {
              return JSON.parse(item)
            } catch {
              return item
            }
          })
        }

        // ✅ parse getLiability failed data
        if (glFailList?.length) {
          glFailedData = glFailList.map((item: string) => {
            try {
              return JSON.parse(item)
            } catch {
              return item
            }
          })
        }
      }

      /* ---------------- RESPONSE ---------------- */
      return response.json({
        status: true,
        data: {
          normalBetsCount: normalCountResult[0]?.totalBets || 0,
          fancyBetsCount: fancyCountResult[0]?.totalBets || 0,

          // updateLiability tracking
          liabilitySuccessCount: successCount,
          liabilityFailCount: failCount,
          liabilityFailedData: failedData,

          // getLiability tracking
          getLiabilitySuccessCount: glSuccessCount,
          getLiabilityFailCount: glFailCount,
          getLiabilityFailedData: glFailedData,
        },
      })
    } catch (error) {
      return response.status(500).json({
        status: false,
        message: 'Something went wrong',
        error,
      })
    }
  }
}
