import { HttpContextContract } from '@ioc:Adonis/Core/HttpContext'
import { rules, schema } from '@ioc:Adonis/Core/Validator'
import Database from '@ioc:Adonis/Lucid/Database'

export default class QueryController {
  public async index({ request, authUser, response }: HttpContextContract) {
    const status = request.input('status', null)
    const limit = request.input('limit', 50)
    const page = request.input('page', 1)

    if (authUser.usetype == 0) {
      const queries = await Database.from('queries')
        .select('*')
        .where('status', status)
        .orderBy('issue_date', 'desc')
        .paginate(page, limit)

      return response.json({
        status: true,
        data: queries,
      })
    } else {
      return response.badRequest({
        message: "You don't have permission.",
      })
    }
  }
  public async store({ request, authUser, response }: HttpContextContract) {
    const data = await request.validate({
      schema: schema.create({
        mobile: schema.string([rules.mobile()]),
        query: schema.string(),
        category: schema.string(),
      }),
    })

    const query = await Database.from('queries')
      .where('user_id', authUser.mstrid)
      .where('status', 'PENDING')
      .first()

    if (query) {
      return response.badRequest({
        message: 'Previous query is not resolved yet!',
      })
    }

    await Database.table('queries').insert({
      status: 'PENDING',
      user_id: authUser.mstrid,
      issue_date: new Date(),
      ...data,
    })

    return response.json({
      status: true,
      message: 'Query is successfully sent.',
    })
  }

  public async update({ request, authUser, response, params }: HttpContextContract) {
    const data = await request.validate({
      schema: schema.create({
        status: schema.string(),
      }),
    })

    if (authUser.usetype == 0) {
      await Database.from('queries').where('id', params.id).firstOrFail()

      await Database.from('queries').where('id', params.id).update({
        status: data.status,
        resolve_date: new Date(),
      })

      return response.json({
        status: true,
        message: 'Marked As Resolved Successfully.',
      })
    } else {
      return response.badRequest({
        message: "You don't have permission.",
      })
    }
  }
}
