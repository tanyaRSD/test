import Drive from '@ioc:Adonis/Core/Drive'
import Env from '@ioc:Adonis/Core/Env'
import { HttpContextContract } from '@ioc:Adonis/Core/HttpContext'
import { schema } from '@ioc:Adonis/Core/Validator'
import Database from '@ioc:Adonis/Lucid/Database'

export default class QueryController {
  public async index({ request, response }: HttpContextContract) {
    const limit = request.input('limit', 50)
    const page = request.input('page', 1)

    // if (authUser.usetype == 0) {
    const blogs = await Database.from('blogs')
      .select('*')
      .orderBy('createdOn', 'desc')
      .paginate(page, limit)

    return response.json({
      status: true,
      data: blogs,
    })
    // }

    // return response.badRequest({
    //   message: "You don't have permission.",
    // })
  }

  public async getBlog({ request, response }: HttpContextContract) {
    const id = request.input('id', -1)

    // if (authUser.usetype == 0) {
    const blogs = await Database.from('blogs').where('id', id).firstOrFail()

    return response.json({
      status: true,
      data: blogs,
    })
    // }

    // return response.badRequest({
    //   message: "You don't have permission.",
    // })
  }

  public async store({ request, authUser, response }: HttpContextContract) {
    const data = await request.validate({
      schema: schema.create({
        content: schema.string(),
        slug: schema.string(),
        description: schema.string(),
        image: schema.file.optional({
          size: '3mb',
          extnames: ['jpg', 'png', 'jpeg'],
        }),
      }),
    })

    if (authUser.usetype == 0) {
      const blog = await Database.from('blogs').where('slug', data.slug).first()

      if (blog) {
        return response.badRequest({
          message: 'Please provide an unique slug',
        })
      }

      let imgUrl: any
      if (data.image) {
        await data.image.moveToDisk('blogs', {}, 's3')
        // @ts-ignore
        imgUrl = data.image.filePath
      }

      await Database.table('blogs').insert({
        createdOn: new Date(),
        content: data.content,
        slug: data.slug,
        description: data.description,
        image: imgUrl,
      })

      return response.json({
        status: true,
        message: 'Blog is successfully posted.',
      })
    }

    return response.badRequest({
      message: 'You do not have permission to.',
    })
  }

  public async update({ request, authUser, response, params }: HttpContextContract) {
    const data = await request.validate({
      schema: schema.create({
        content: schema.string(),
        slug: schema.string(),
        description: schema.string(),
        image: schema.file.optional({
          size: '3mb',
          extnames: ['jpg', 'png', 'jpeg'],
        }),
      }),
    })

    if (authUser.usetype == 0) {
      const isBlogExist = await Database.from('blogs')
        .whereNot('id', params.id)
        .where('slug', data.slug)
        .first()

      if (isBlogExist) {
        return response.badRequest({
          message: 'Please provide an unique slug',
        })
      }

      const blog = await Database.from('blogs').where('id', params.id).firstOrFail()

      if (data.image) {
        await data.image.moveToDisk('blogs', {}, 's3')
        // @ts-ignore
        const imgUrl: any = data.image.filePath

        if (blog.image) {
          const host = Env.get('S3_ENDPOINT')
          const bucket = Env.get('S3_BUCKET')
          await Drive.use('s3').delete(blog.image.replace(host + '/' + bucket + '/', ''))
        }

        await Database.from('blogs').where('id', blog.id).update('image', imgUrl)
      }

      await Database.from('blogs').where('id', params.id).update({
        content: data.content,
        slug: data.slug,
        description: data.description,
      })

      return response.json({
        status: true,
        message: 'Blog is Updated.',
      })
    }

    return response.badRequest({
      message: "You don't have permission.",
    })
  }

  public async blogImage({ request, authUser, response }: HttpContextContract) {
    if (authUser.usetype == 0) {
      const data = await request.validate({
        schema: schema.create({
          file: schema.file(),
        }),
      })

      await data.file.moveToDisk('blogs', {}, 's3')
      // @ts-ignore
      const imgUrl: any = data.file.filePath

      return response.json({
        imageUrl: imgUrl,
      })
    }
    return response.badRequest({
      message: 'You do not have permission to.',
    })
  }

  public async delete({ authUser, response, params }: HttpContextContract) {
    if (authUser.usetype == 0) {
      await Database.from('blogs').where('id', params.id).delete()

      return response.json({
        status: true,
        message: 'Blog is deleted.',
      })
    }

    return response.badRequest({
      message: "You don't have permission.",
    })
  }
}
