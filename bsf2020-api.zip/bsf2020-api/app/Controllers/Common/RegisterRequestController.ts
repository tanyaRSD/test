import { HttpContextContract } from '@ioc:Adonis/Core/HttpContext'
import Database from '@ioc:Adonis/Lucid/Database'

export default class RegisterRequest {
  public async getRegisterRequests({ request, authUser, response }: HttpContextContract) {
    const limit = request.input('limit', 50)
    const page = request.input('page', 1)
    const userId = request.input('user_id', null)

    if (authUser) {
      const registerRequests = await Database.from('register_requests')
        .select('*')
        .where('user_id', userId)
        .orderBy('date', 'desc')
        .paginate(page, limit)

      return response.json({
        status: true,
        data: registerRequests,
      })
    }
  }
}
