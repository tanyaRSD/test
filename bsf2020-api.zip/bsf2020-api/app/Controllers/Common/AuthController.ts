import Cache from '@ioc:Adonis/Addons/Cache'
import Redis from '@ioc:Adonis/Addons/Redis'
import Env from '@ioc:Adonis/Core/Env'
import { cuid } from '@ioc:Adonis/Core/Helpers'
import { HttpContextContract } from '@ioc:Adonis/Core/HttpContext'
import { rules, schema } from '@ioc:Adonis/Core/Validator'
import Database from '@ioc:Adonis/Lucid/Database'
import Bull from '@ioc:Rocketseat/Bull'
import UserLog from 'App/Jobs/UserLog'
import { Mongo } from 'App/Services/Mongo'
import UserService from 'App/Services/UserService'
import { DateTime } from 'luxon'

export default class AuthController {
  public async login({ request, response }: HttpContextContract) {
    const data = await request.validate({
      schema: schema.create({
        username: schema.string({ trim: true }),
        password: schema.string(),
        browser_info: schema.string(),
        device_info: schema.string(),
        dom: schema.string(),
        captcha: schema.string.optional(),
        captcha_numbers: schema.string.optional(),
        captcha_time: schema.number.optional(),
        city: schema.string.nullableAndOptional(),
        region: schema.string.nullableAndOptional(),
        org: schema.string.nullableAndOptional(),
      }),
      messages: {
        'username.alphaNum': 'The username can only include letters, numbers, and underscores.',
      },
    })

    let unix = Math.floor(Date.now() / 1000)
    let origin: any = request.input('origin', request.header('origin'))
    origin = origin ? origin.replace('www.', '') : null

    response.abortIf(request.input('captcha') != request.input('captcha_numbers'), {
      message: 'Captcha does not match.',
      status: false,
    })
    response.abortIf(request.input('captcha_time') + 60 * 60 < unix, {
      message: 'Invalid captcha, please refresh.',
      status: false,
    })

    response.abortIf(!origin, { message: 'Invalid domain.', status: false })

    const user = await Database.from('createmaster')
      .select(
        'mstrid',
        'mstrname',
        'mstruserid',
        'domain',
        'mstrremarks',
        'usetype',
        'loginid',
        'match_stake',
        'balance',
        'liability',
        'p_l',
        'freechips',
        'chip',
        'ipadress',
        'usecrdt',
        'parentId',
        'mstrlock',
        'partner',
        'partner_cricket',
        'partner_soccer',
        'partner_tennis',
        'partner_casino',
        'bet_lock',
        'domain',
        'isPartnership',
        'account_closed',
        'stakeLimit',
        'Commission',
        'SessionComm',
        'rolling_commission',
        'fancy_rolling_commission',
        'OtherComm',
        'active',
        'password_changed',
        'allow_deposit_withdraw',
        'domain',
        'allow_bet_delete',
        'allow_result_declare',
        'allow_result_revoke',
        'profit_loss',
        'payment_type',
        'permissions',
        'question',
        'gamehub_password',
        'phone',
        'phone_1',
        'phone_2',
        'DOB'
      )
      .where('mstruserid', data.username)
      .if(
        request.url().includes('admin'),
        (q) => {
          q.whereNot('usetype', 3)
        },
        (q) => {
          q.where('usetype', 3)
        }
      )
      .where('mstrpassword', Database.raw('SHA1(:password)', { password: data.password }))
      .first()

    response.abortIf(!user, {
      status: false,
      message: 'Invalid username or password',
    })

    response.abortIf(user.account_closed == 0, { status: false, message: 'User account closed.' })

    response.abortIf(user.mstrlock == 0, { status: false, message: 'User is locked.' })

    response.abortIf(user.active == 0, { status: false, message: 'Login failed.' })

    const parentData: any = await UserService.parents(user.mstrid)
    const parentIds = parentData.map((i: any) => i.mstrid)
    const parentLocked = await Database.from('createmaster')
      .where('mstrlock', 0)
      .whereIn('mstrid', parentIds)
      .first()

    response.abortIf(parentLocked, { status: false, message: 'User is locked.' })

    let domain = await Database.from('domains')
      .if(
        user.usetype != 3,
        (q) => {
          q.where('value', user.domain)
        },
        (q) => {
          q.where('alternate_url', user.domain)
        }
      )
      .first()

    if (Env.get('NODE_ENV') === 'production') {
      response.abortIf(!domain, {
        status: false,
        message: 'Please contact upline.',
      })

      response.abortIf(
        !origin?.startsWith('http://localhost') &&
        [domain.value, domain.alternate_url].indexOf(origin) == -1,
        {
          status: false,
          message: 'Invalid username or password.',
        }
      )
    } else {
      domain = await Database.from('domains').first()
    }

    if (user.usetype != 3) {
      if (domain) {
        user.domainId = domain.id
      }

      if (user.usetype == 2) {
        const rows = await Database.from('createmaster')
          .where('mstrid', user.parentId)
          .select(['mstrid', 'usetype'])
        await Cache.forever('parentUseType:' + user.mstrid, rows[0].usetype)
      }
    } else {
      user.iType = 0

      let username = user.mstruserid
      let checkDemoUser = username.replace(/[0-9]+$/, '')
      if (checkDemoUser !== 'user') {
        UserService.deleteKeys(await Redis.keys('auth:' + user.mstrid + '|*')).then()
      }

      user.stakes = JSON.parse(user.match_stake)

      await Cache.rememberForever('partnership:' + user.mstrid, async () => {
        return await Database.from('tblpartner').where('UserID', user.mstrid).firstOrFail()
      })

      await Redis.publish('ACTIVE_USERS', '')
    }

    user.TokenId = 'auth:' + user.mstrid + '|' + cuid().toLowerCase()
    user.parentIds = parentIds
    user.singleDealer = JSON.parse(Env.get('SINGLE_DEALER', 'true'))

    await Cache.put(user.TokenId, user, 3600)

    if (!data.city) {
      data.city = null
    }

    if (!data.region) {
      data.region = null
    }

    if (!data.org) {
      data.org = null
    }

    //update User Log
    await Bull.add(
      new UserLog().key,
      {
        userId: user.mstrid,
        date: DateTime.now(),
        browser_info: data.browser_info,
        device_info: data.device_info,
        logcode: user.iType,
        ip: request.ip(),
        city: data.city,
        region: data.region,
        org: data.org,
      },
      { removeOnComplete: true }
    )

    try {
      await Mongo.collection('login_logs').insertOne({
        userId: user?.mstruserid,
        username: user?.mstrname,
        usetype: user?.usetype,
        loginTime: new Date(), // current timestamp
        ip: request.ip(),
        browser_info: data.browser_info,
        device_info: data.device_info,
        city: data?.city || null,
        region: data?.region || null,
        org: data?.org || null,
      })
    } catch (err) {
      console.error('Mongo login log error:', err)
      // optionally continue without failing login
    }

    return response.json({
      token: user.TokenId,
      user: user,
      domain,
    })
  }

  public async me({ request, authUser, response }: HttpContextContract) {

    try {

      const user = authUser || null

      const origin: any = request.input('origin', request.header('origin'))

      const project: any = Env.get('project')

      const depositBonus = Env.get('DEPOSIT_BONUS', 0)

      const baziwala: any = Env.get('baziwala', 0)

      let url: string | null = null

      // ✅ Resolve URL

      if (user) {

        user.singleDealer = JSON.parse(Env.get('SINGLE_DEALER', 'true'))

        url = user.domain || origin?.replace('www.', '')

      } else {

        url = origin ? origin.replace('www.', '') : null

      }

      // ✅ Cache domain

      const domainCacheKey = `domain:${url}`

      let domain = await Cache.remember(domainCacheKey, 60 * 60, async () => {

        return Database.from('domains')

          .where((q) => {

            if (user) {

              if (user.usetype != 3) {

                q.where('value', user.domain)

              } else {

                q.where('alternate_url', user.domain)

              }

            } else {

              q.where('value', url!).orWhere('alternate_url', url!)

            }

          })

          .first()

      })

      // ✅ Production validation

      if (Env.get('NODE_ENV') === 'production') {

        response.abortIf(!domain, {

          status: false,

          message: 'Please contact upline.',

        })

        response.abortIf(

          !origin?.startsWith('http://localhost') &&

          ![domain.value, domain.alternate_url].includes(origin),

          {

            status: false,

            message: 'Invalid username or password.',

          }

        )

      } else if (!domain) {

        domain = await Database.from('domains').first()

      }

      // ✅ Prepare async tasks (ONLY cache safe things)

      const tasks: any = {

        banners: Promise.resolve([]),

        socialMedia: Promise.resolve([]),

        demoUser: Promise.resolve(null),

        parent: Promise.resolve(null),

        app: Cache.get('apk'),

      }

      // ✅ Load banners & social (cached)

      if (user?.usetype == 3) {

        tasks.banners = Cache.remember(`banner:${domain.value}`, 600, async () => {

          return Database.from('banners')

            .where('domain', domain.value)

            .select('*')

        })

        tasks.socialMedia = Cache.remember(`social:${domain.value}`, 600, async () => {

          return Database.from('social_links')

            .where('domain', domain.value)

            .select('*')

        })

      }

      // ✅ Demo user (cached)

      if (domain?.show_register == 0) {

        tasks.demoUser = Cache.remember(`demo:${domain.value}`, 600, async () => {

          return Database.from('createmaster')

            .where('domain', domain.value)

            .where('is_demo', 1)

            .where('usetype', 3)

            .select(

              'mstruserid AS username',

              Database.raw("'12345A' AS password")

            )

            .orderBy('mstrid', 'asc')

            .first()

        })

      }

      // ✅ Parent (NO CACHE - user specific)

      if (user?.usetype == 55) {

        tasks.parent = Database.from('createmaster')

          .where('mstrid', user.parentId)

          .select('mstrid', 'usetype', 'mstruserid', 'mstrname')

          .first()

      }

      // ✅ Execute all in parallel

      const [banners, socialMedia, demoUser, parent, app] = await Promise.all([

        tasks.banners,

        tasks.socialMedia,

        tasks.demoUser,

        tasks.parent,

        tasks.app,

      ])

      // ✅ FINAL RESPONSE (NO CACHE HERE ❌)

      return response.json({

        status: true,

        message: null,

        user, // always real-time ✅

        domain,

        demoUser,

        banners,

        parent,

        socialMedia,

        depositBonus,

        project,

        systemMaintainance: false,

        baziwala,

        app,

      })

    } catch (error) {

      console.error('ME API ERROR:', error)

      return response.status(500).json({

        status: false,

        message: 'Something went wrong',

      })

    }

  }


  public async captcha({ response }: HttpContextContract) {
    let num1 = Math.floor(Math.random() * 10)
    let num2 = Math.floor(Math.random() * 10)
    let num3 = Math.floor(Math.random() * 10)
    let num4 = Math.floor(Math.random() * 10)

    let unix = Math.floor(Date.now() / 1000)
    return response.json({
      captcha: [num1, num2, num3, num4],
      unix,
    })
  }

  public async me2({ request, authUser, response }: HttpContextContract) {
    let user = authUser || null
    const origin: any = request.input('origin', request.header('origin'))
    let url: any = null

    if (user) {
      if (user.domain) {
        url = user.domain
      } else {
        url = origin.replace('www.', '')
      }
    } else {
      url = origin ? origin.replace('www.', '') : null
    }

    let domain = await Cache.get('domain:' + url)

    if (!domain) {
      domain = await Database.from('domains').where('value', url).firstOrFail()
      await Cache.forever('domain:' + url, domain)
    }

    if (origin?.startsWith('http://localhost')) {
      domain = await Database.from('domains').first()
    }

    return response.json({
      status: true,
      message: null,
      user: user,
      domain,
    })
  }

  public async changePassword({ request, authUser, response }: HttpContextContract) {
    const data = await request.validate({
      schema: schema.create({
        old_password: schema.string(),
        newpassword: schema.string({}, [
          rules.confirmed('Renewpassword'),
          // rules.minLength(6),
          // rules.regex(/[A-Z]/),
        ]),
      }),
      messages: {
        'newpassword.minLength': 'Password must be at least {{ options.minLength }} characters.',
        'newpassword.regex': 'Password must contain at least one uppercase letter.',
      },
    })

    const user = await UserService.verifyPassword(authUser.mstrid, data.old_password)

    if (user) {
      await UserService.changePassword(authUser.mstrid, data.newpassword)

      const passwordHistory = {
        user_id: user.mstrid,
        changer_id: authUser.mstrid,
        ip: request.ip(),
        created_at: new Date(),
      }

      await Database.table('password_history').insert(passwordHistory)
    } else {
      return response.badRequest({
        message: 'Current password is wrong.',
        status: true,
      })
    }

    return response.json({
      message: 'Password has been changed.',
      status: true,
    })
  }

  public async logout({ request, response }: HttpContextContract) {
    const token: any = request.header('authorization')?.substr(7)
    if (token) {
      await Redis.del(token)
    }
    await Redis.publish('ACTIVE_USERS', '')

    return response.json({ message: 'Logout successfully.' })
  }

  public async username({ request, response }: HttpContextContract) {
    const data = await request.validate({
      schema: schema.create({
        username: schema.string({ trim: true }, [
          rules.alphaNum({
            allow: ['underscore'],
          }),
        ]),
      }),
      messages: {
        'username.alphaNum': 'The username can only include letters, numbers, and underscores.',
      },
    })

    const isExists = await Database.from('createmaster').where('mstruserid', data.username).first()

    return response.json({
      status: !isExists,
    })
  }

  public async requestUsername({ request, response }: HttpContextContract) {
    const data = await request.validate({
      schema: schema.create({
        username: schema.string({ trim: true }, [
          rules.alphaNum({
            allow: ['underscore'],
          }),
        ]),
      }),
      messages: {
        'username.alphaNum': 'The username can only include letters, numbers, and underscores.',
      },
    })

    const isExists = await Database.from('request_users').where('mstruserid', data.username).first()

    return response.json({
      status: !isExists,
    })
  }

  public async ip({ request, response }: HttpContextContract) {
    return response.json({
      ip: request.ip(),
    })
  }

  public async logs({ request, response, authUser }: HttpContextContract) {
    const page = request.input('page', 1)
    const limit = 50
    const offset = (page - 1) * limit

    const logs = await Mongo.collection('logs')
      .aggregate([
        { $match: { userId: authUser.mstrid } },
        {
          $facet: {
            total: [{ $count: 'total' }],
            data: [{ $sort: { createdAt: -1 } }, { $skip: offset }, { $limit: limit }],
          },
        },
        {
          $project: {
            total: { $arrayElemAt: ['$total.total', 0] },
            data: 1,
          },
        },
      ])
      .toArray()

    const data = logs[0]

    return response.json({
      status: true,
      message: null,
      ...data,
      pageSize: limit,
    })
  }

  public async getLogsByUsername({ request, response, authUser }: HttpContextContract) {
    const page = Number(request.input('page', 1))
    const limit = Number(request.input('limit', 50))
    const offset = (page - 1) * limit

    const username = request.input('username')

    if (authUser.usetype == 11) {
      const user = await Database.from('createmaster').where('mstruserid', username).first()

      if (!user) {
        return response.badRequest({
          message: `User doesn't exists!`,
        })
      }

      let parents: any = await UserService.parents(user.mstrid)

      const hasAccess = parents.some((i: any) => i.mstrid == authUser.mstrid)

      if (!hasAccess) {
        return response.badRequest({
          message: `User doesn't exists!`,
        })
      }
    }

    const logs = await Mongo.collection('logs')
      .aggregate([
        { $match: { username } },
        {
          $facet: {
            total: [{ $count: 'total' }],
            data: [{ $sort: { createdAt: -1 } }, { $skip: offset }, { $limit: limit }],
          },
        },
        {
          $project: {
            total: { $arrayElemAt: ['$total.total', 0] },
            data: 1,
          },
        },
      ])
      .toArray()

    const result = logs[0] || { total: 0, data: [] }

    return response.json({
      status: true,
      message: null,
      pageSize: limit,
      data: result.data,
      total: result.total || 0,
      meta: {
        total: result.total || 0,
        page,
        perPage: limit,
        lastPage: Math.ceil((result.total || 0) / limit),
      },
    })
  }
}
