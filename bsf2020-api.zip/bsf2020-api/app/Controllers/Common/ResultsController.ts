/* eslint-disable eqeqeq */
import { HttpContextContract } from '@ioc:Adonis/Core/HttpContext'
import Database from '@ioc:Adonis/Lucid/Database'

export default class ResultsController {
  public async index({ request, response }: HttpContextContract) {
    const page = request.input('page', 1)
    const limit = request.input('limit', 50)
    const sportId = request.input('sport_id')
    const matchId = request.input('match_id')
    const date = request.input('date')
    const data = await Database.query()
      .from('tblresult')
      .innerJoin('matchmst', 'tblresult.matchId', 'matchmst.MstCode')
      .innerJoin('sportmst', 'tblresult.sportId', 'sportmst.id')
      .leftJoin('market', (builder) => {
        builder.andOnVal('tblresult.isFancy', '=', '0').andOn('tblresult.marketId', 'market.id')
      })
      .leftJoin('tblselection', (builder) => {
        builder
          .andOnVal('tblresult.isFancy', '=', '0')
          .andOn('tblresult.selectionId', 'tblselection.selectionId')
          .andOn('tblresult.marketId', 'tblselection.marketId')
          .andOn('tblresult.matchId', 'tblselection.matchId')
      })
      .leftJoin('matchfancy', (builder) => {
        builder
          .andOnVal('tblresult.isFancy', '=', '1')
          .andOn('tblresult.selectionId', 'matchfancy.Id')
          .andOn('tblresult.matchId', 'matchfancy.matchId')
      })
      .whereNotIn('tblresult.sportId', [1233, 1234, 1235, 1236])
      .if(sportId, (q) => q.where('tblresult.sportId', sportId))
      .if(matchId, (q) => q.where('tblresult.matchId', matchId))
      .if(date, (q) =>
        q
          .where('tblresult.date', '>=', date + 'T00:00:00')
          .where('tblresult.date', '<=', date + 'T23:59:59')
      )
      .select(
        'matchmst.matchName AS MatchName',
        Database.raw(
          "CASE WHEN tblresult.isFancy = 1 THEN 'Session Fancy' ELSE market.Name END AS MarketName"
        ),
        'sportmst.name AS sportName',
        Database.raw(
          'CASE WHEN tblresult.isFancy = 1 THEN matchfancy.HeadName ELSE (CASE WHEN tblresult.selectionId = 0 THEN (CASE WHEN tblresult.sportId = 7 OR tblresult.sportId = 4339 THEN "Scratched" ELSE "Match Abandoned" END) ELSE tblselection.selectionName END) END AS SelectionName'
        ),
        'tblresult.*'
      )
      .orderBy('tblresult.date', 'desc')
      .paginate(page, limit)

    return response.json(data)
  }
}
