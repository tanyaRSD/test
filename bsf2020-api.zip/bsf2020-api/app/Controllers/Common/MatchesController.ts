import Cache from '@ioc:Adonis/Addons/Cache'
import Redis from '@ioc:Adonis/Addons/Redis'
import { HttpContextContract } from '@ioc:Adonis/Core/HttpContext'
import { schema } from '@ioc:Adonis/Core/Validator'
import Database from '@ioc:Adonis/Lucid/Database'
import Settings from 'App/Services/Settings'
import Sp from 'App/Services/Sp'
import ThirdParty from 'App/Services/ThirdParty'
import UserService from 'App/Services/UserService'
import axios from 'axios'

export default class MatchesController {
  public async show({ request, response, params, authUser }: HttpContextContract) {

    let matchId = params.id ? params.id : 0
    let marketId = request.input('marketId', 0)
    let marketOnly = request.input('marketOnly', 'yes')

    // ✅ Redis Key (unique banana important hai)
    const cacheKey = `match_show_${matchId}_${marketId}_${marketOnly}_${authUser.mstrid}`

    // ✅ 1. REDIS CHECK
    const cachedData = await Cache.get(cacheKey)
    if (cachedData) {
      return response.json({
        status: true,
        message: null,
        data: JSON.parse(cachedData),
      })
    }

    // ------------------ EXISTING CODE SAME ------------------ //
    let betCountQuery: any[] = []

    if (marketOnly == 'yes') {
      betCountQuery = [
        Database.from('tblbets')
          .count('*')
          .whereNull('ResultID')
          .where('matchId', matchId)
          .where((qq) => {
            qq.where('UserId', authUser.mstrid)
              .orWhere('ParantId', authUser.mstrid)
              .orWhere('DealerID', authUser.mstrid)
              .orWhere('MasterID', authUser.mstrid)
              .orWhere('SMasterID', authUser.mstrid)
              .orWhere('SAdminID', authUser.mstrid)
              .orWhere('AdminID', authUser.mstrid)
              .orWhere('CompanyID', authUser.mstrid)
              .orWhere('ParentExchCompanyID', authUser.mstrid)
          })
          .as('unsettled_bets_count'),
        Database.from('tblbets')
          .count('*')
          .whereNotNull('ResultID')
          .where('matchId', matchId)
          .where((qq) => {
            qq.where('UserId', authUser.mstrid)
              .orWhere('ParantId', authUser.mstrid)
              .orWhere('DealerID', authUser.mstrid)
              .orWhere('MasterID', authUser.mstrid)
              .orWhere('SMasterID', authUser.mstrid)
              .orWhere('SAdminID', authUser.mstrid)
              .orWhere('AdminID', authUser.mstrid)
              .orWhere('CompanyID', authUser.mstrid)
              .orWhere('ParentExchCompanyID', authUser.mstrid)
          })
          .as('settled_bets_count'),
      ]
    } else {
      betCountQuery = [
        Database.from('bet_entry')
          .count('*')
          .whereNull('ResultID')
          .where('matchId', matchId)
          .where((qq) => {
            qq.where('UserId', authUser.mstrid)
              .orWhere('ParantId', authUser.mstrid)
              .orWhere('DealerID', authUser.mstrid)
              .orWhere('MasterID', authUser.mstrid)
              .orWhere('SMasterID', authUser.mstrid)
              .orWhere('SAdminID', authUser.mstrid)
              .orWhere('AdminID', authUser.mstrid)
              .orWhere('CompanyID', authUser.mstrid)
              .orWhere('ParentExchCompanyID', authUser.mstrid)
          })
          .as('unsettled_bets_count'),
        Database.from('bet_entry')
          .count('*')
          .whereNotNull('ResultID')
          .where('matchId', matchId)
          .where((qq) => {
            qq.where('UserId', authUser.mstrid)
              .orWhere('ParantId', authUser.mstrid)
              .orWhere('DealerID', authUser.mstrid)
              .orWhere('MasterID', authUser.mstrid)
              .orWhere('SMasterID', authUser.mstrid)
              .orWhere('SAdminID', authUser.mstrid)
              .orWhere('AdminID', authUser.mstrid)
              .orWhere('CompanyID', authUser.mstrid)
              .orWhere('ParentExchCompanyID', authUser.mstrid)
          })
          .as('settled_bets_count'),
      ]
    }

    const match = await Database.query()
      .from('matchmst')
      .join('sportmst', 'matchmst.SportID', '=', 'sportmst.id')
      .where('mstcode', matchId)
      // .where('sportmst.is_betfair', 1)
      .whereNotIn(
        'matchmst.SportID',
        Database.from('blocked_sports').select('sport_id').whereIn('user_id', authUser.parentIds)
      )
      .whereNotIn(
        'matchmst.mstcode',
        Database.from('user_deactive_match')
          .select('match_id')
          .whereIn('user_id', authUser.parentIds)
      )
      .select(['*', ...betCountQuery])
      .first()

    try {
      if (match) {
        const sportId = match.SportID.toString()
        // const tvBase = 'https://bholabet.com/live/tv/'
        const tvBase = 'https://e765432.diamondcricketid.com/dtv.php?id='
        if ((!match.tvUrl || match.tvUrl == 0) && ['1', '2', '4'].indexOf(sportId) > -1) {
          match.tvUrl = `${tvBase}${matchId}&sportid=${sportId}`
          await Database.from('matchmst').where('MstCode', matchId).update({ tvUrl: matchId })
        } else {
          match.tvUrl = `${tvBase}${matchId}&sportid=${sportId}`
        }

        if (['7', '4339'].indexOf(sportId) > -1) {
          const key = 'channel_' + marketId
          const channel = await Cache.get(key)
          if (!channel) {
            const res = await axios.get(ThirdParty.horseChannelsApi)
            const m = res.data.find((d: any) => d.MatchID == marketId)
            if (m) {
              match.tvUrl = tvBase + m.Channel
              Cache.put(key, m.Channel, 36000)
            }
          } else {
            match.tvUrl = tvBase + channel
          }
        }
      }
    } catch (error) {
      console.log(error)
    }

    // ✅ 2. SAVE TO REDIS (TTL optional)
    await Cache.put(cacheKey, JSON.stringify(match), 90) // 90 sec cache

    return response.json({
      status: true,
      message: null,
      data: match,
    })
  }

  public async markets({ request, authUser, response, params }: HttpContextContract) {
    let matchId = params.id
    let marketId = request.input('marketId')
    let sportId = request.input('sportId', '')

    let key = 'matchmarkets:' + sportId + ':' + matchId + ':' + authUser.mstrid

    key = ['7', '4339'].indexOf(sportId.toString()) > -1 ? key + ':' + marketId : key

    let parents: any = await UserService.parents(authUser.mstrid)
    parents = parents.map((i: any) => i.mstrid)

    const data = await Cache.remember(key, 800, async () => {
      return await Database.from('market')
        .leftJoin('matchmst', 'market.matchId', 'matchmst.MstCode')
        .leftJoin('sportmst', 'matchmst.SportID', 'sportmst.id')
        .leftJoin('seriesmst', 'seriesmst.seriesId', 'matchmst.seriesId')
        .joinRaw(
          `LEFT JOIN user_sport_limit as usl ON usl.id = (SELECT id FROM user_sport_limit WHERE user_id IN (${parents.toString()}) AND sport_id = market.sportsId AND type = CASE WHEN market.Id LIKE '%B%' THEN CASE WHEN market.name = 'Toss' THEN 'toss' ELSE 'bookmaker' END ELSE 'market' END  ORDER BY user_id DESC LIMIT 1)`

          // `LEFT JOIN user_sport_limit as usl ON usl.id = (SELECT id FROM user_sport_limit WHERE user_id IN (${parents.toString()}) AND sport_id = market.sportsId AND type = CASE WHEN market.Id LIKE '%B%' THEN 'bookmaker' ELSE 'market' END ORDER BY user_id DESC LIMIT 1)`
        )
        .joinRaw(
          `LEFT JOIN market_settings as ms ON ms.id = (SELECT id FROM market_settings WHERE user_id IN (${parents.toString()}) AND market_id = market.Id ORDER BY user_id DESC LIMIT 1)`
        )
        .if(authUser.usetype != 0, (q) => {
          q.whereNotIn(
            'matchmst.SportID',
            Database.from('blocked_sports')
              .select('sport_id')
              .whereNot('user_id', authUser.mstrid)
              .whereIn('user_id', parents)
          )
            .whereNotIn(
              'market.Id',
              Database.from('blocked_markets')
                .select('market_id')
                .whereIn('user_id', parents)
                .whereNot('locked_by', authUser.mstrid)
            )
            .whereNotIn(
              'matchmst.mstcode',
              Database.from('user_deactive_match')
                .select('match_id')
                .whereIn('user_id', parents)
                .whereNot('locked_by', authUser.mstrid)
            )
        })
        .leftJoin('blocked_markets AS bm', (builder) => {
          builder
            .andOnVal('bm.user_id', '=', authUser.mstrid)
            .andOn('bm.market_id', '=', 'market.Id')
            .andOnVal('bm.locked_by', '=', authUser.mstrid)
        })
        .if(
          matchId,
          (q) => {
            q.where('matchmst.mstcode', matchId)
          },
          (q) => {
            q.whereExists((query) => {
              query
                .from('tblbets')
                .whereColumn('tblbets.MarketId', 'market.Id')
                .where((qq) => {
                  qq.where('tblbets.UserId', authUser.mstrid)
                    .orWhere('tblbets.ParantId', authUser.mstrid)
                    .orWhere('tblbets.DealerID', authUser.mstrid)
                    .orWhere('tblbets.MasterID', authUser.mstrid)
                    .orWhere('tblbets.SMasterID', authUser.mstrid)
                    .orWhere('tblbets.SAdminID', authUser.mstrid)
                    .orWhere('tblbets.AdminID', authUser.mstrid)
                    .orWhere('tblbets.CompanyID', authUser.mstrid)
                    .orWhere('tblbets.ParentExchCompanyID', authUser.mstrid)
                })
                .limit(1)
            })
          }
        )
        .if(sportId, (q) => {
          q.where('market.sportsId', sportId)
        })
        .if(authUser.usetype == 3, (qq) => {
          qq.where('matchmst.active', 1)
          qq.where('matchmst.completed', 0)
          qq.where('market.active', 1)
        })

        .select(
          'market.Id as marketid',
          'market.isManualMatchOdds',
          'market.isBetAllowedOnManualMatchOdds',
          'market.visibility',
          'market.Name as market_name',
          'market.max_bet_liability',
          'market.max_market_liability',
          'market.is_manual',
          'market.createdOn',
          // Database.raw(
          //   'ROUND(LEAST(market.max_market_profit, COALESCE(usl.max_profit, 0), COALESCE(ms.max_profit, 0)),0) as max_market_profit'
          // ),
          // Database.raw(
          //   'ROUND(GREATEST(market.min_stack, COALESCE(usl.min_stake, 0), COALESCE(ms.min_stack, 0)),0) as min_stack'
          // ),
          // Database.raw('GREATEST(market.volume, COALESCE(usl.market_volume, 1)) as volume'),

          // Database.raw(
          //   'LEAST(market.max_market_liability, COALESCE(usl.max_market_liability, 0)) as max_market_liability'
          // ),
          // Database.raw(
          //   'ROUND(LEAST(market.max_stack, COALESCE(usl.max_stake, 5000000), COALESCE(ms.max_stack, 5000000)),0) as max_stack'
          // ),
          Database.raw(`
  ROUND(
    COALESCE(ms.max_profit, usl.max_profit, market.max_market_profit),
  0) as max_market_profit
`),

          Database.raw(`
  ROUND(
    COALESCE(ms.min_stack, usl.min_stake, market.min_stack),
  0) as min_stack
`),

          Database.raw(`
  COALESCE(usl.market_volume, market.volume, 1) as volume
`),

          Database.raw(`
  COALESCE(
    usl.max_market_liability,
    market.max_market_liability
  ) as max_market_liability
`),

          Database.raw(`
  ROUND(
    COALESCE(ms.max_stack, usl.max_stake, market.max_stack),
  0) as max_stack
`),
          'market.message',
          'market.volume',
          'market.market_runner_json as runner_json',
          Database.raw('IF(bm.id IS NOT NULL, 0, market.active) AS active'),
          'market.odds_limit',
          'matchmst.matchName',
          'matchmst.MstCode as matchid',
          'matchmst.oddsLimit',
          'matchmst.volumeLimit',
          'matchmst.scoreboard_id as scoreboard_id',
          'matchmst.runner_json as match_runner_json',
          'matchmst.MstDate',
          'matchmst.MstDate as matchdate',
          'matchmst.has_bookmaker',
          'matchmst.score_board_json',
          'seriesmst.Name as series_name',
          'seriesmst.seriesId as seriesId',
          'sportmst.name as sportname',
          'sportmst.id as SportId',
          Database.from('tblbets')
            .count('*')
            .whereNull('ResultID')
            .whereColumn('tblbets.MarketId', 'market.Id')
            .where((qq) => {
              qq.where('tblbets.UserId', authUser.mstrid)
                .orWhere('tblbets.ParantId', authUser.mstrid)
                .orWhere('tblbets.DealerID', authUser.mstrid)
                .orWhere('tblbets.MasterID', authUser.mstrid)
                .orWhere('tblbets.SMasterID', authUser.mstrid)
                .orWhere('tblbets.SAdminID', authUser.mstrid)
                .orWhere('tblbets.AdminID', authUser.mstrid)
                .orWhere('tblbets.CompanyID', authUser.mstrid)
                .orWhere('tblbets.ParentExchCompanyID', authUser.mstrid)
            })
            .as('unsettled_bets_count'),
          Database.from('tblbets')
            .count('*')
            .whereNotNull('ResultID')
            .whereColumn('tblbets.MarketId', 'market.Id')
            .where((qq) => {
              qq.where('tblbets.UserId', authUser.mstrid)
                .orWhere('tblbets.ParantId', authUser.mstrid)
                .orWhere('tblbets.DealerID', authUser.mstrid)
                .orWhere('tblbets.MasterID', authUser.mstrid)
                .orWhere('tblbets.SMasterID', authUser.mstrid)
                .orWhere('tblbets.SAdminID', authUser.mstrid)
                .orWhere('tblbets.AdminID', authUser.mstrid)
                .orWhere('tblbets.CompanyID', authUser.mstrid)
                .orWhere('tblbets.ParentExchCompanyID', authUser.mstrid)
            })
            .as('settled_bets_count')
        )
        .if(['7', '4339'].indexOf(sportId.toString()) > -1 && marketId, (query: any) => {
          query.where('market.Id', marketId)
        })
        .orderBy('matchmst.matchName', 'asc')
        .orderBy('market.createdOn', 'asc')
    })

    return response.json({
      status: true,
      data: data,
    })
  }

  // public async fancies({ request, params, authUser, response }: HttpContextContract) {
  //   const matchId = params.id
  //   const category = request.input('category')
  //   const filter = request.input('filter', Settings.fancyPriorities[0].value)

  //   const redisKey = `fancies:${matchId}`

  //   const redisData = await Redis.hgetall(redisKey)

  //   let value: any[] = []
  //   let value2: any[] = []
  //   let source = 'database'

  //   if (Object.keys(redisData).length > 0) {
  //     value = Object.values(redisData).map((fancyJson) => JSON.parse(fancyJson))
  //     source = 'redis'
  //   } else {
  //     let parents: any = await UserService.parents(authUser.mstrid)
  //     parents = parents.map((i: any) => i.mstrid)

  //     value = await Database.from('matchfancy')
  //       .innerJoin('matchmst', 'matchfancy.MatchID', 'matchmst.MstCode')
  //       .joinRaw(
  //         `LEFT JOIN user_sport_limit as usl ON usl.id = (SELECT id FROM user_sport_limit WHERE user_id IN (${parents.toString()}) AND sport_id = matchfancy.SprtId AND type = 'fancy' ORDER BY user_id DESC LIMIT 1)`
  //       )
  //       .joinRaw(
  //         `LEFT JOIN fancy_settings as fs ON fs.id = (SELECT id FROM fancy_settings WHERE user_id IN (${parents.toString()}) AND fancy_id = matchfancy.ID ORDER BY user_id DESC LIMIT 1)`
  //       )
  //       .whereNull('matchfancy.result')
  //       .if(['0'].indexOf(authUser.usetype) > -1, (q) => {
  //         q.whereNot('matchfancy.active', 9)
  //       })
  //       .whereNotIn(
  //         'matchfancy.SprtId',
  //         Database.from('blocked_sports')
  //           .select('sport_id')
  //           .whereNot('user_id', authUser.mstrid)
  //           .whereIn('user_id', parents)
  //       )
  //       .whereNotIn(
  //         'matchmst.MstCode',
  //         Database.from('user_deactive_match')
  //           .select('match_id')
  //           .whereIn('user_id', parents)
  //           .whereNot('locked_by', authUser.mstrid)
  //       )
  //       .whereNotIn(
  //         'matchfancy.Id',
  //         Database.from('blocked_fancies')
  //           .select('fancy_id')
  //           .whereIn('user_id', parents)
  //           .whereNot('locked_by', authUser.mstrid)
  //       )
  //       .leftJoin('blocked_fancies AS bf', (builder) => {
  //         builder
  //           .andOnVal('bf.user_id', '=', authUser.mstrid)
  //           .andOn('bf.fancy_id', '=', 'matchfancy.Id')
  //           .andOnVal('bf.locked_by', '=', authUser.mstrid)
  //       })
  //       .where('matchmst.MstCode', matchId)
  //       .select(
  //         'matchfancy.*',
  //         Database.raw('IF(bf.id IS NOT NULL, 0, matchfancy.active) AS active'),
  //         Database.raw(
  //           'ROUND(GREATEST(matchfancy.MinStake, COALESCE(usl.min_stake, 0), COALESCE(fs.min_stack, 0)),0) as min_stack'
  //         ),
  //         Database.raw(
  //           'ROUND(LEAST(matchfancy.MaxStake, COALESCE(usl.max_stake, 5000000), COALESCE(fs.max_stack, 5000000)),0) as max_stack'
  //         ),
  //         Database.from('bet_entry')
  //           .count('*')
  //           .whereNull('ResultID')
  //           .whereColumn('matchmst.MstCode', 'matchfancy.MatchID')
  //           .as('unsettled_bets_count'),
  //         Database.from('bet_entry')
  //           .count('*')
  //           .whereNotNull('ResultID')
  //           .whereColumn('matchmst.MstCode', 'matchfancy.MatchID')
  //           .as('settled_bets_count')
  //       )
  //       .if(category == 'Session', (q: any) => {
  //         q.where('matchfancy.Remarks', 'INDIAN_SESSION_FANCY')
  //         q.where('matchfancy.in_priority', filter)
  //       })
  //       .if(category == 'Result Waiting', (q: any) => {
  //         q.where('matchfancy.Remarks', 'INDIAN_SESSION_FANCY')
  //       })
  //       .if(category == 'Line', (q: any) => {
  //         q.where('matchfancy.Remarks', 'INDIAN_LINE_FANCY')
  //       })
  //       .orderBy('matchfancy.order', 'desc')
  //       .orderBy('matchfancy.in_priority')

  //     value2 = [...value]
  //     const redisSetData: Record<string, string> = {}
  //     value.forEach((f) => {
  //       redisSetData[f.ind_fancy_selection_id] = JSON.stringify(f)
  //     })
  //     if (Object.keys(redisSetData).length > 0) {
  //       await Redis.hset(redisKey, redisSetData)
  //       await Redis.expire(redisKey, 300)
  //     }
  //   }

  //   if (category == 'Session') {
  //     value = value.filter((f) => f?.Remarks == 'INDIAN_SESSION_FANCY' && f.in_priority == filter)
  //   } else if (category == 'Result Waiting') {
  //     value = value.filter((f) => f?.Remarks == 'INDIAN_SESSION_FANCY')
  //   } else if (category == 'Line') {
  //     value = value.filter((f) => f?.Remarks == 'INDIAN_LINE_FANCY')
  //   }

  //   return response.json({
  //     data: value,
  //     priorities: Settings.fancyPriorities,
  //     source,
  //     value2,
  //   })
  // }

  // public async fancies({ request, params, authUser, response }: HttpContextContract) {
  //   const matchId = params.id
  //   const category = request.input('category')
  //   const filter = request.input('filter', Settings.fancyPriorities[0].value)
  //   const forceRefresh = request.input('refresh', false) // New: force refresh from DB

  //   const redisKey = `fancies:${matchId}`
  //   let value: any[] = []
  //   // let source = 'database'
  //   let redisData: Record<string, string> = {}

  //   if (!forceRefresh) {
  //     redisData = await Redis.hgetall(redisKey)
  //   }

  //   if (Object.keys(redisData).length > 0) {
  //     value = Object.values(redisData).map((fancyJson) => JSON.parse(fancyJson))
  //     // source = 'redis'
  //   } else {
  //     let parents: any = await UserService.parents(authUser.mstrid)
  //     parents = parents.map((i: any) => i.mstrid)

  //     value = await Database.from('matchfancy')
  //       .innerJoin('matchmst', 'matchfancy.MatchID', 'matchmst.MstCode')
  //       .joinRaw(
  //         `LEFT JOIN user_sport_limit as usl ON usl.id = (SELECT id FROM user_sport_limit WHERE user_id IN (${parents.toString()}) AND sport_id = matchfancy.SprtId AND type = 'fancy' ORDER BY user_id DESC LIMIT 1)`
  //       )
  //       .joinRaw(
  //         `LEFT JOIN fancy_settings as fs ON fs.id = (SELECT id FROM fancy_settings WHERE user_id IN (${parents.toString()}) AND fancy_id = matchfancy.ID ORDER BY user_id DESC LIMIT 1)`
  //       )
  //       .whereNull('matchfancy.result')
  //       .if(['0'].indexOf(authUser.usetype) > -1, (q) => {
  //         q.whereNot('matchfancy.active', 9)
  //       })
  //       .whereNotIn(
  //         'matchfancy.SprtId',
  //         Database.from('blocked_sports')
  //           .select('sport_id')
  //           .whereNot('user_id', authUser.mstrid)
  //           .whereIn('user_id', parents)
  //       )
  //       .whereNotIn(
  //         'matchmst.MstCode',
  //         Database.from('user_deactive_match')
  //           .select('match_id')
  //           .whereIn('user_id', parents)
  //           .whereNot('locked_by', authUser.mstrid)
  //       )
  //       .whereNotIn(
  //         'matchfancy.Id',
  //         Database.from('blocked_fancies')
  //           .select('fancy_id')
  //           .whereIn('user_id', parents)
  //           .whereNot('locked_by', authUser.mstrid)
  //       )
  //       .leftJoin('blocked_fancies AS bf', (builder) => {
  //         builder
  //           .andOnVal('bf.user_id', '=', authUser.mstrid)
  //           .andOn('bf.fancy_id', '=', 'matchfancy.Id')
  //           .andOnVal('bf.locked_by', '=', authUser.mstrid)
  //       })
  //       .where('matchmst.MstCode', matchId)
  //       .select(
  //         'matchfancy.*',
  //         Database.raw('IF(bf.id IS NOT NULL, 0, matchfancy.active) AS active'),
  //         Database.raw(
  //           'ROUND(GREATEST(matchfancy.MinStake, COALESCE(usl.min_stake, 0), COALESCE(fs.min_stack, 0)),0) as min_stack'
  //         ),
  //         Database.raw(
  //           'ROUND(LEAST(matchfancy.MaxStake, COALESCE(usl.max_stake, 5000000), COALESCE(fs.max_stack, 5000000)),0) as max_stack'
  //         ),
  //         Database.from('bet_entry')
  //           .count('*')
  //           .whereNull('ResultID')
  //           .whereColumn('matchmst.MstCode', 'matchfancy.MatchID')
  //           .as('unsettled_bets_count'),
  //         Database.from('bet_entry')
  //           .count('*')
  //           .whereNotNull('ResultID')
  //           .whereColumn('matchmst.MstCode', 'matchfancy.MatchID')
  //           .as('settled_bets_count')
  //       )
  //       .if(category == 'Session', (q: any) => {
  //         q.where('matchfancy.Remarks', 'INDIAN_SESSION_FANCY')
  //         q.where('matchfancy.in_priority', filter)
  //       })
  //       .if(category == 'Result Waiting', (q: any) => {
  //         q.where('matchfancy.Remarks', 'INDIAN_SESSION_FANCY')
  //       })
  //       .if(category == 'Line', (q: any) => {
  //         q.where('matchfancy.Remarks', 'INDIAN_LINE_FANCY')
  //       })
  //       .orderBy('matchfancy.order', 'desc')
  //       .orderBy('matchfancy.in_priority')

  //     const redisSetData: Record<string, string> = {}
  //     value.forEach((f) => {
  //       redisSetData[f.ind_fancy_selection_id] = JSON.stringify(f)
  //     })
  //     if (Object.keys(redisSetData).length > 0) {
  //       await Redis.hset(redisKey, redisSetData)
  //       await Redis.expire(redisKey, 300)
  //     }
  //   }

  //   // Company-wise disable (apply for all except global admin)
  //   if (authUser.usetype !== 0 && authUser.usetype !== 55) {
  //     let companyId = authUser.mstrid
  //     if (authUser.usetype !== 11) {
  //       let parents = await UserService.parents(authUser.mstrid)
  //       parents = Array.isArray(parents) ? parents : []
  //       const company = parents.find((p: any) => p.usetype === 11)
  //       if (company) {
  //         companyId = company.mstrid
  //       }
  //     }

  //     const companyBlockKey = `fancy:company-block:${companyId}:${matchId}`

  //     const blockedFancies = await Redis.hkeys(companyBlockKey)

  //     if (blockedFancies.length > 0) {
  //       const blockedSet = new Set(blockedFancies)

  //       value = value.map((f) => {
  //         if (blockedSet.has(f.ID.toString())) {
  //           return { ...f, active: 9 } // mark as blocked
  //         }
  //         return f
  //       })
  //     }
  //   }

  //   if (category == 'Session') {
  //     value = value.filter((f) => f?.Remarks == 'INDIAN_SESSION_FANCY' && f.in_priority == filter)
  //   } else if (category == 'Result Waiting') {
  //     value = value.filter((f) => f?.Remarks == 'INDIAN_SESSION_FANCY')
  //   } else if (category == 'Line') {
  //     value = value.filter((f) => f?.Remarks == 'INDIAN_LINE_FANCY')
  //   }

  //   return response.json({
  //     data: value,
  //     priorities: Settings.fancyPriorities,
  //   })
  // }


  public async fancies({ request, params, authUser, response }: HttpContextContract) {
    const matchId = params.id
    const category = request.input('category')
    const filter = request.input('filter', Settings.fancyPriorities[0].value)
    const forceRefresh = request.input('refresh', false)

    const redisKey = `fancies:${matchId}:${authUser.mstrid}:${category}:${filter}`
    const parentKey = `parents:${authUser.mstrid}`

    try {
      // ⚡ PARALLEL REDIS FETCH
      const [redisData, cachedParents] = await Promise.all([
        !forceRefresh ? Redis.get(redisKey) : null,
        Redis.get(parentKey)
      ])

      const companyData = await Database.rawQuery(`
        WITH RECURSIVE user_tree AS (
          SELECT mstrid, parentId, usetype
          FROM createmaster
          WHERE mstrid = ?

          UNION ALL

          SELECT t.mstrid, t.parentId, t.usetype
          FROM createmaster t
          INNER JOIN user_tree ut ON t.mstrid = ut.parentId
        )
        SELECT mstrid AS company_id
        FROM user_tree
        WHERE usetype = 11
        LIMIT 1
      `, [authUser.mstrid]);

      console.log('Company Data:', companyData);
      let limits: any = []
      let fancyLimits: any = []
      if (companyData?.[0]?.length > 0 && companyData[0][0].company_id) {
        limits = await Database.from('user_sport_limit')
          .where('user_id', companyData?.[0]?.[0]?.company_id)
          .where('sport_id', 4)
          .where('type', 'fancy')
          .whereIn('usertype', [11, 0])
          .orderByRaw('usertype = 11 DESC')
          .orderBy('user_id', 'desc');

        // fetch fancy_settings based on matchId that exist into matchfancy table and select only fancy_id , min_stack and max_stack columns
        fancyLimits = await Database.from('fancy_settings as fs')
          .join('matchfancy as mf', 'mf.ID', 'fs.fancy_id')
          .where('fs.user_id', companyData?.[0]?.[0]?.company_id)
          .where('mf.MatchID', matchId)
          .select('fs.fancy_id', 'fs.min_stack', 'fs.max_stack');
      }
      // ✅ RETURN FROM CACHE
      if (redisData) {
        console.log('Fancies fetched from Redis cache.')
        return response.json({
          data: JSON.parse(redisData),
          priorities: Settings.fancyPriorities,
          limits: limits.length > 0 ? limits : null,
          fancyLimits: fancyLimits.length > 0 ? fancyLimits : null
        })
      }

      // ✅ GET PARENTS (CACHE FIRST)
      let parents: any[] = []

      if (cachedParents) {
        // ✅ FIX: ensure number[]
        parents = JSON.parse(cachedParents).map((p: any) =>
          typeof p === 'object' ? p.mstrid : p
        )
      } else {
        const parentData = await UserService.parents(authUser.mstrid)
        parents = (parentData || []).map((p: any) => p.mstrid)

        await Redis.set(parentKey, JSON.stringify(parents), 'EX', 3600)

      }

      const parentIds = [...parents, authUser.mstrid]

      // 🔥 PRIORITY MAP (Super Admin → User)

      const priorityMap = new Map()

      parentIds.forEach((id, index) => {

        priorityMap.set(id, index)

      })

      const sortByPriority = (a, b) =>

        priorityMap.get(a.user_id) - priorityMap.get(b.user_id)

      // ⚡ FETCH FANCIES

      let query = Database.from('matchfancy')

        .innerJoin('matchmst', 'matchfancy.MatchID', 'matchmst.MstCode')

        .whereNull('matchfancy.result')

        .where('matchmst.MstCode', matchId)

        .select('matchfancy.*')

      if (category === 'Session') {

        query = query

          .where('matchfancy.Remarks', 'INDIAN_SESSION_FANCY')

          .where('matchfancy.in_priority', filter)

      } else if (category === 'Result Waiting') {

        query = query.where('matchfancy.Remarks', 'INDIAN_SESSION_FANCY')

      } else if (category === 'Line') {

        query = query.where('matchfancy.Remarks', 'INDIAN_LINE_FANCY')

      }

      const fancies = await query

        .orderBy('matchfancy.order', 'desc')

        .orderBy('matchfancy.in_priority')

      const fancyIds = fancies.map(f => f.ID)

      // ⚡ FETCH LIMIT SETTINGS

      const [sportLimits, fancySettings] = await Promise.all([

        Database.from('user_sport_limit')

          .whereIn('user_id', parentIds)

          .where('sport_id', 4)

          .where('type', 'fancy'),

        Database.from('fancy_settings')

          .whereIn('user_id', parentIds)

          .where((q) => {

            q.whereNull('match_id').orWhere('match_id', matchId)

          })

          .where((q) => {

            q.whereNull('fancy_id').orWhereIn('fancy_id', fancyIds)

          })

      ])

      // ⚡ SORT BY USER PRIORITY

      sportLimits.sort(sortByPriority)

      fancySettings.sort(sortByPriority)

      // 🔵 SPLIT SUPER ADMIN + COMPANY DATA

      const superAdminLimits = sportLimits.filter(

        s => priorityMap.get(s.user_id) === 0

      )

      const companySettings = fancySettings.filter(

        f => priorityMap.get(f.user_id) > 0

      )

      // 🧠 FINAL RESOLVE FUNCTION

      const resolveLimits = (fancy) => {

        let min = fancy.MinStake

        let max = fancy.MaxStake

        // 🔵 1. SUPER ADMIN GLOBAL (BASE)

        for (const s of superAdminLimits) {

          if (s.min_stake != null) min = s.min_stake

          if (s.max_stake != null) max = s.max_stake

        }

        // 🟡 2. COMPANY GLOBAL

        const companyGlobal = companySettings

          .filter(f => f.match_id == null && f.fancy_id == null)

        if (companyGlobal.length) {

          const last = companyGlobal[companyGlobal.length - 1]

          if (last.min_stack != null) min = last.min_stack

          if (last.max_stack != null) max = last.max_stack

        }

        // 🟡 3. COMPANY MATCH LEVEL

        const matchLevel = companySettings

          .filter(f => f.match_id === matchId && f.fancy_id == null)

        if (matchLevel.length) {

          const last = matchLevel[matchLevel.length - 1]

          if (last.min_stack != null) min = last.min_stack

          if (last.max_stack != null) max = last.max_stack

        }

        // 🟡 4. COMPANY FANCY LEVEL

        const fancyLevel = companySettings

          .filter(f => f.match_id === matchId && f.fancy_id === fancy.ID)

        if (fancyLevel.length) {

          const last = fancyLevel[fancyLevel.length - 1]

          if (last.min_stack != null) min = last.min_stack

          if (last.max_stack != null) max = last.max_stack

        }

        return {

          min: Math.round(min),

          max: Math.round(max)

        }

      }

      // ⚡ APPLY FINAL VALUES

      fancies.forEach(f => {

        const resolved = resolveLimits(f)

        f.MinStake = resolved.min

        f.MaxStake = resolved.max

        delete f.min_stack

        delete f.max_stack

      })

      // ⚡ COMPANY BLOCK LOGIC

      if (authUser.usetype !== 0 && authUser.usetype !== 55) {

        let companyId = authUser.mstrid

        if (authUser.usetype !== 11) {

          const parentData = await UserService.parents(authUser.mstrid)

          const company = (parentData || []).find((p: any) => p.usetype === 11)

          if (company) companyId = company.mstrid

        }

        const companyBlockKey = `fancy:company-block:${companyId}:${matchId}`

        const blocked = await Redis.smembers(companyBlockKey)

        if (blocked.length) {

          const blockedSet = new Set(blocked)

          fancies.forEach(f => {

            if (blockedSet.has(f.ID.toString())) {

              f.active = 9

            }

          })

        }

      }

      // ⚡ CACHE RESPONSE

      await Redis.set(redisKey, JSON.stringify(fancies), 'EX', 300)

      return response.json({
        data: fancies,
        priorities: Settings.fancyPriorities,
        limits: limits.length > 0 ? limits : null,
        fancyLimits: fancyLimits.length > 0 ? fancyLimits : null
      })

    } catch (error) {

      console.error('Fancies API Error:', error)

      return response.status(500).json({

        message: 'Something went wrong',

      })

    }

  }

  public async fancyLiability({ params, authUser, response }: HttpContextContract) {
    const userId = authUser?.mstrid
    const { liability: sumLiability } = await Database.from('bet_entry')
      .where('MatchId', params.id)
      .whereNull('ResultID')
      .where((query) => {
        query
          .where('UserId', userId)
          .orWhere('ParantId', userId)
          .orWhere('DealerID', userId)
          .orWhere('MasterID', userId)
          .orWhere('SMasterID', userId)
          .orWhere('SAdminID', userId)
          .orWhere('AdminID', userId)
          .orWhere('CompanyID', userId)
          .orWhere('ParentExchCompanyID', userId)
      })
      .sum('bet_value as liability')
      .first()

    return response.json({
      data: +sumLiability || 0,
    })
  }

  public async oddsPlByMatch({ request, authUser, response }: HttpContextContract) {
    const resVal = await Sp.readCall('_odds_pl_by_match(:userId,:matchId)', {
      userId: authUser.mstrid,
      matchId: request.input('matchId', 0),
    })

    return response.json({
      data: resVal,
    })
  }

  public async score({ params, response }: HttpContextContract) {
    const matchId = params.id
    const tvScore = await axios.get(ThirdParty.tvScoreApiUrl + matchId)
    if (tvScore.data.length) {
      return response.json({ data: tvScore.data })
    } else {
      return response.badRequest({ message: 'Not Found' })
    }
  }

  public async getOddsGraph({ request, response }: HttpContextContract) {
    let v = await request.validate({
      schema: schema.create({
        marketId: schema.string(),
        selectionId: schema.string(),
      }),
    })

    const key = `odds_chart:${v.marketId}:${v.selectionId}`

    // Retrieve all data from Redis sorted set
    const data = await Redis.zrange(key, 0, -1)

    // Parse and format the retrieved data
    const formattedData: any = {
      Back: { name: 'Odds', data: [] },
      BackSize: { name: 'Volume', data: [] },
      Lay: { name: 'Odds', data: [] },
      LaySize: { name: 'Volume', data: [] },
    }

    data.forEach((item: any) => {
      const { back, backSize, lay, laySize, timestamp } = JSON.parse(item)

      formattedData.Back.data.push([timestamp, back])
      formattedData.BackSize.data.push([timestamp, backSize])
      formattedData.Lay.data.push([timestamp, lay])
      formattedData.LaySize.data.push([timestamp, laySize])
    })

    // Send the formatted data as the response
    response.json({
      back: [formattedData.Back, formattedData.BackSize],
      lay: [formattedData.Lay, formattedData.LaySize],
    })
  }

  public async toggleFavorite({ request, authUser, response }: HttpContextContract) {
    const matchId = request.input('matchId', null)

    if (authUser.usetype == 3) {
      if (await Redis.sismember('favorite_by_users:' + matchId, authUser.mstrid)) {
        await Redis.srem('favorite_by_users:' + matchId, authUser.mstrid)
      } else {
        await Redis.sadd('favorite_by_users:' + matchId, authUser.mstrid)
      }

      return response.ok({
        data: matchId,
      })
    }

    return response.badRequest({
      message: "You don't have permission.",
    })
  }
}
