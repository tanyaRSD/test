import { HttpContextContract } from '@ioc:Adonis/Core/HttpContext'
import { rules, schema } from '@ioc:Adonis/Core/Validator'
import Database from '@ioc:Adonis/Lucid/Database'

export default class RequestDomainsController {
  public async index({ response }: HttpContextContract) {
    let data: any = []
    data = await Database.from('request_domains').select('*')

    return response.json(data)
  }

  public async store({ request, response, authUser }: HttpContextContract) {
    if (authUser.usetype == 0 || authUser.usetype == 55) {
      const data = await request.validate({
        schema: schema.create({
          name: schema.string(),
          value: schema.string([
            rules.url({
              protocols: ['http', 'https'],
            }),
            rules.normalizeUrl({
              stripWWW: true,
              removeSingleSlash: true,
            }),
          ]),
        }),
      })

      await Database.table('request_domains').insert({
        name: data.name,
        value: data.value,
      })

      return response.json({
        message: 'Domain created.',
      })
    }
    return response.badRequest({
      message: "You don't have permission",
    })
  }

  public async update({ request, response, authUser, params }: HttpContextContract) {
    if (authUser.usetype == 0 || authUser.usetype == 55) {
      const data = await request.validate({
        schema: schema.create({
          name: schema.string.optional(),
          value: schema.string.optional([
            rules.url({
              protocols: ['http', 'https'],
            }),
            rules.normalizeUrl({
              stripWWW: true,
              removeSingleSlash: true,
            }),
          ]),
        }),
      })

      const domain = await Database.from('request_domains').where('id', params.id).first()

      if (domain) {
        await Database.from('request_domains').where('id', domain.id).update({
          name: data.name,
          value: data.value,
        })

        return response.json({
          message: 'Domain updated.',
        })
      }
    }

    return response.badRequest({
      message: "You don't have permission",
    })
  }
}
