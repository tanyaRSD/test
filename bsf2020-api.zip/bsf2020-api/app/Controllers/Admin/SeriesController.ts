import Redis from '@ioc:Adonis/Addons/Redis'
import { HttpContextContract } from '@ioc:Adonis/Core/HttpContext'
import { schema } from '@ioc:Adonis/Core/Validator'
import Database from '@ioc:Adonis/Lucid/Database'
import ThirdParty from 'App/Services/ThirdParty'
import UserService from 'App/Services/UserService'
import axios from 'axios'

export default class SeriesController {
  public async index({ request, authUser, response }: HttpContextContract) {
    if (authUser.usetype == 55) {
      authUser = await UserService.checkPersmission(authUser, 'Active Matches and Manage Series')

      if (!authUser) {
        return response.badRequest({
          message: 'Invalid request.',
        })
      }
    }
    const sportId = request.input('sportId')

    if ((authUser.usetype == 0 || authUser.usetype == 55) && request.input('type') == 'manage') {
      try {
        const rows = await axios.get(ThirdParty.seriesListApiUrl + sportId)
        const series = await Database.from('seriesmst').where('active', 1).where('SportID', sportId)
        const data = rows.data.map((el: any) => el.competition)

        let manualSeries: any = await Redis.smembers('MANUAL_SERIES_LIST')
        manualSeries = manualSeries
          .map((el: any) => JSON.parse(el))
          .filter((el: any) => el.sportId == sportId)

        // returning api data and manual series data togather
        return response.json({
          seriesfrmApiAndManual: [...data, ...manualSeries],
          seriesfrmDataBase: series,
        })
      } catch (e) {
        console.log(e)
        return response.json({
          seriesfrmApiAndManual: [],
          seriesfrmDataBase: [],
        })
      }
    } else {
      let rows: any = []
      if (authUser.usetype == 0 || authUser.usetype == 55) {
        rows = await Database.from('seriesmst')
          .join('sportmst', 'seriesmst.SportID', 'sportmst.id')
          .if(
            sportId > 0,
            (q) => {
              q.where('seriesmst.SportId', sportId)
            },
            (q) => {
              q.where('seriesmst.SportId', '<', 5)
            }
          )
          .select('seriesmst.*', 'sportmst.name as sportname')
          .orderBy('seriesmst.Name', 'asc')
      }

      return response.json({
        data: rows,
      })
    }
  }

  public async store({ request, authUser, response }: HttpContextContract) {
    const data = await request.validate({
      schema: schema.create({
        seriesId: schema.string(),
        seriesName: schema.string(),
        sportId: schema.string(),
        is_manual: schema.boolean.optional(),
        is_auto: schema.boolean.optional(),
      }),
    })

    if (authUser.usetype == 0 || authUser.usetype == 55) {
      const series = await Database.query()
        .from('seriesmst')
        .where('seriesId', data.seriesId)
        .first()
      if (series) {
        if (!data.is_auto) {
          await Database.from('seriesmst')
            .where('seriesId', data.seriesId)
            .update({
              active: series.active ? 0 : 1,
            })

          await Database.from('matchmst')
            .where('seriesId', data.seriesId)
            .update({
              active: series.active ? 0 : 1,
              HelperID: 0,
            })
        }
        return response.json({
          message: 'Series updated.',
        })
      } else {
        await Database.insertQuery().table('seriesmst').insert({
          SportID: data.sportId,
          seriesId: data.seriesId,
          Name: data.seriesName,
          createdOn: new Date(),
          active: 1,
          is_manual: data.is_manual,
        })

        return response.json({
          message: 'Series saved.',
        })
      }
    }

    return response.badRequest({
      message: "You don' have permission",
    })
  }

  public async manualSeries({ request, authUser, response }: HttpContextContract) {
    const data = await request.validate({
      schema: schema.create({
        seriesId: schema.string(),
        seriesName: schema.string(),
        sportId: schema.string(),
        is_manual: schema.boolean(),
      }),
    })

    if (authUser.usetype == 0) {
      const Dbseries = await Database.query()
        .from('seriesmst')
        .where('seriesId', data.seriesId)
        .first()

      if (Dbseries) {
        return response.badRequest({
          message: 'Series already activated!',
        })
      }

      let redisSeries: any = await Redis.smembers('MANUAL_SERIES_LIST')

      redisSeries = redisSeries.map((el: any) => JSON.parse(el))

      if (redisSeries) {
        const isExists = redisSeries.find((s: any) => s.id == data.seriesId)

        if (isExists) {
          return response.badRequest({
            message: 'Series already exists!',
          })
        }
      }

      await Redis.sadd(
        'MANUAL_SERIES_LIST',
        JSON.stringify({
          id: data.seriesId.toString(),
          name: data.seriesName.toString(),
          is_manual: data.is_manual,
          sportId: data.sportId.toString(),
        })
      )

      return response.json({
        message: 'Series saved.',
      })
    }

    return response.badRequest({
      message: "You don' have permission",
    })
  }
}
