import { HttpContextContract } from '@ioc:Adonis/Core/HttpContext'
import { rules, schema } from '@ioc:Adonis/Core/Validator'
import Database from '@ioc:Adonis/Lucid/Database'

export default class RegisterRequest {
  public async getRegisterRequests({ request, authUser, response }: HttpContextContract) {
    const status = request.input('status', null)
    const limit = request.input('limit', 50)
    const page = request.input('page', 1)

    if (authUser.usetype == 2) {
      const registerRequests = await Database.from('register_requests')
        .leftJoin('request_users', 'register_requests.user_id', 'request_users.mstrid')
        .select(
          'register_requests.*',
          'request_users.mstrname',
          'request_users.mstruserid',
          'request_users.phone'
        )
        .where('status', status)
        .orderBy('date', 'desc')
        .paginate(page, limit)

      return response.json({
        status: true,
        data: registerRequests,
      })
    } else {
      return response.badRequest({
        message: "You don't have permission.",
      })
    }
  }

  public async update({ request, authUser, response, params }: HttpContextContract) {
    const data = await request.validate({
      schema: schema.create({
        status: schema.string(),
        remarks: schema.string.optional(),
        link: schema.string.nullableAndOptional([
          rules.url({
            protocols: ['http', 'https'],
          }),
        ]),
        req_username: schema.string.nullableAndOptional(),
        req_password: schema.string.nullableAndOptional(),
        type: schema.number(),
        user_id: schema.string(),
      }),
    })

    if (authUser.usetype == 2) {
      const registerRequest = await Database.from('register_requests')
        .where('user_id', data.user_id)
        .where('type', 1)
        .where('status', 'APPROVED')
        .first()

      if (!registerRequest && data.type == 1 && data.status == 'APPROVED') {
        if (!data.link || !data.req_username || !data.req_password) {
          return response.badRequest({
            message: 'You need to provide link, username and password',
          })
        }
      }
      await Database.from('register_requests').where('mstrid', params.id).firstOrFail()

      await Database.from('register_requests').where('mstrid', params.id).update({
        status: data.status,
        mstrremarks: data.remarks,
        link: data.link,
        req_username: data.req_username,
        req_password: data.req_password,
      })

      return response.json({
        status: true,
        message: `Register Request is ${data.status}`,
      })
    } else {
      return response.badRequest({
        message: "You don't have permission.",
      })
    }
  }

  public async checkDepositStatus({ request, authUser, response }: HttpContextContract) {
    const userId = request.input('userId', -1)

    if (authUser.usetype == 2) {
      const registerRequest = await Database.from('register_requests')
        .where('user_id', userId)
        .where('type', 1)
        .where('status', 'APPROVED')
        .first()

      return response.json({
        status: true,
        data: registerRequest,
      })
    } else {
      return response.badRequest({
        message: "You don't have permission.",
      })
    }
  }
}
