import Cache from '@ioc:Adonis/Addons/Cache'
import { HttpContextContract } from '@ioc:Adonis/Core/HttpContext'
import Database from '@ioc:Adonis/Lucid/Database'

export default class DashboardController {
  public async index({ request, authUser, response }: HttpContextContract) {
    let sportId = request.input('sport_id', 4)
    const key = 'dashboard:' + authUser.mstrid + ':' + sportId

    let data = await Cache.remember(key, 1800, async () => {
      const matches = await Database.query()
        .from('matchmst')
        .if(
          [7, 4339].indexOf(sportId) > -1,
          (q) => {
            q.leftJoin('market', (builder) => {
              builder.andOnVal('market.active', 1).andOn('market.matchid', 'matchmst.mstcode')
            })
          },
          (q) => {
            q.leftJoin('market', (builder) => {
              builder
                .andOnVal('market.Name', '=', 'Match Odds')
                .andOn('market.matchid', 'matchmst.mstcode')
            })
          }
        )
        .innerJoin('sportmst as sport', 'matchmst.sportid', 'sport.id')
        .where('sport.active', 1)
        .if(sportId != 0, (query) => {
          query.where('sport.id', sportId)
        })
        .if(![0, 55].includes(authUser.usetype), (query) => {
          query.where('matchmst.active', 1)
        })
        .whereNotIn('matchmst.SportID', [1233, 1234, 1235, 1236])
        // .where('matchmst.active', 1)
        .where((q) => {
          q.whereExists((query) => {
            query
              .from('market')
              .whereColumn('matchmst.MstCode', 'market.matchId')
              .where('active', 1)
              .limit(1)
          }).orWhereExists((query) => {
            query
              .from('matchfancy')
              .whereColumn('matchmst.MstCode', 'matchfancy.MatchID')
              .whereNull('matchfancy.result')
              .limit(1)
          })
        })
        .whereNotIn('matchmst.mstcode', (query) => {
          query
            .select('match_id')
            .from('user_deactive_match')
            .whereIn('user_id', authUser.parentIds)
            .whereRaw('CASE WHEN locked_by IS NULL THEN user_id != :userId ELSE 1=1 END', {
              userId: authUser.mstrid,
            })
        })
        .whereNotIn('matchmst.SportID', (query) => {
          query
            .select('sport_id')
            .from('blocked_sports')
            .whereIn('user_id', authUser.parentIds)
            .whereRaw('user_id!=:userId', { userId: authUser.mstrid })
        })
        .select(
          'matchmst.matchName',
          'matchmst.MstDate AS date',
          'matchmst.SportID',
          'matchmst.country_code',
          'matchmst.MstCode AS matchId',
          'market.market_runner_json AS runner_json',
          'market.Name AS marketName',
          'market.Id AS marketId',
          Database.raw(
            "GROUP_CONCAT(market.Id,'|',market.start_time,'|',(SELECT COUNT(*) FROM tblbets WHERE MarketId = market.Id) ORDER BY market.start_time ASC SEPARATOR ', ') as start_times"
          ),
          Database.raw(
            '(SELECT COUNT(DISTINCT MstCode) FROM tblbets WHERE MatchId = matchId AND UserId = :userId) + (SELECT COUNT(DISTINCT bet_id) FROM bet_entry WHERE matchId = matchId AND userId = :userId) as bets_count',
            { userId: authUser?.mstrid }
          ),
          Database.raw(
            'CASE WHEN :usetype NOT IN (0, 55) THEN (CASE WHEN matchmst.mstcode IN (SELECT match_id FROM user_deactive_match WHERE user_id =:userId) THEN 0 ELSE 1 END ) ELSE matchmst.active END as active',
            { usetype: authUser.usetype, userId: authUser.mstrid }
          )
        )

        .groupBy('matchId')
        .orderBy('date')

      return matches || []
    })

    return response.json({
      status: true,
      message: null,
      data: data,
    })
  }
}
