import Redis from '@ioc:Adonis/Addons/Redis'
import { HttpContextContract } from '@ioc:Adonis/Core/HttpContext'
import { rules, schema } from '@ioc:Adonis/Core/Validator'
import Database from '@ioc:Adonis/Lucid/Database'
import MarketService from 'App/Services/MarketService'
import Parent from 'App/Services/Parent'
import Settings from 'App/Services/Settings'
import Sp from 'App/Services/Sp'
import ThirdParty from 'App/Services/ThirdParty'
import UserService from 'App/Services/UserService'
import axios from 'axios'
import { DateTime } from 'luxon'
export default class MatchController {
  public async index({ request, authUser, response }: HttpContextContract) {
    if ((authUser.usetype == 0 || authUser.usetype == 55) && request.input('type') == 'manage') {
      if (authUser.usetype == 55) {
        authUser = await UserService.checkPersmission(authUser, 'Active Matches and Manage Series')

        if (!authUser) {
          return response.badRequest({
            message: 'Invalid request.',
          })
        }
      }

      const seriesId = request.input('seriesId')
      const sportId = request.input('sportId')
      try {
        // const url =
        //   ['7', '4339'].indexOf(sportId.toString()) > -1
        //     ? ThirdParty.horseMarketApi + sportId
        //     : `http://18.132.86.137/api/matchapi.php?Action=listEvents&EventTypeID=${sportId}&CompetitionID=${seriesId}`

        const url =
          ['7', '4339'].indexOf(sportId.toString()) > -1
            ? ThirdParty.horseMarketApi + sportId
            : ThirdParty.matchListApiUrl + `?sportId=${sportId}&seriesId=${seriesId}`
        const rows = await axios.get(url)

        let manualMatch: any = await Redis.smembers('MANUAL_MATCH_LIST')

        manualMatch = manualMatch
          .map((el: any) => JSON.parse(el))
          .filter((el: any) => {
            return el.seriesId == seriesId
          })
          .map((el: any) => {
            return {
              event: el,
            }
          })

        const matches = await Database.from('matchmst')
          .where('active', 1)
          .where('seriesId', seriesId)
          .where('SportID', sportId)

        const data = rows.data
        return response.json({
          matchfrmApiAndManual: [...data, ...manualMatch],
          matchfrmDataBase: matches,
        })
      } catch (e) {
        console.log(e)
        return response.json({
          matchfrmApiAndManual: [],
          matchfrmDataBase: [],
        })
      }
    } else {
    }
  }

  public async store({ request, authUser, response }: HttpContextContract) {
    if (authUser.usetype == 0 || authUser.usetype == 55) {
      let data = await request.validate({
        schema: schema.create({
          matchId: schema.string(),
          matchName: schema.string(),
          date: schema.string(),
          seriesId: schema.string(),
          tvUrl: schema.string.optional(),
          score_board_json: schema.string.optional(),
          countryCode: schema.string.optional(),
          is_manual: schema.boolean.optional(),
          type: schema.string.optional(),
          is_auto: schema.boolean.optional(),
        }),
      })

      let isManual = 0
      if (data.matchId.startsWith('111')) {
        isManual = 1
      }

      if (authUser.usetype == 55) {
        authUser = await UserService.checkPersmission(authUser, 'Active Matches and Manage Series')

        if (!authUser) {
          return response.badRequest({
            message: 'Invalid request.',
          })
        }
      }

      const series = await Database.query()
        .from('seriesmst')
        .where('seriesId', data.seriesId)
        .first()
      if (series) {
        if (series.active == 0 && !data.is_auto) {
          return response.badRequest({
            message: 'Series is not active',
          })
        }
      } else {
        return response.badRequest({
          message: 'Series is not found.',
        })
      }

      const event = await Database.query().from('matchmst').where('MstCode', data.matchId).first()
      if (event) {
        if (data?.type == 'manage' && !data.is_auto) {
          await Database.from('matchmst')
            .where('MstCode', data.matchId)
            .update({
              active: event.active ? 0 : 1,
            })

          if (!event.active) {
            const redisKeyMinMax = `fanciesMinMax:${data.matchId}:*`
            if (redisKeyMinMax.length > 0) {
              await Redis.del(redisKeyMinMax)
            }
          }
          await Redis.publish('DASHBOARD_UPDATE_USER', '')
          await Redis.publish('DASHBOARD_UPDATE_ADMIN', '')
          return response.json({
            message: 'Match updated.',
          })
        }

        return response.json({
          message: 'Match already exists.',
        })
      } else {
        const runners = []

        if ([1, 2, 4].indexOf(series.SportID)) {
          //Soccer
          if (!data.tvUrl && !data.is_auto) {
            let match: any

            try {
              const res = await axios.get(ThirdParty.channelsApi)
              match = res.data.find((d: any) => d.MatchID == data.matchId)
            } catch (e) { }

            if (match) {
              data.tvUrl = match.Channel
            } else {
              data.tvUrl = ''
            }
          }
          data.score_board_json = ''
        } else {
          if (!data.tvUrl) {
            data.tvUrl = ''
          }
          data.score_board_json = ''
        }

        const settings = await Settings.all()
        const delay: any = settings.line_fancy_delay
        const lineFancyVolume = settings.line_fancy_volume
        const oddsLimit = settings.match_odds_limit
        const dateTime = DateTime.fromISO(data.date, { zone: 'utc' })

        await Database.insertQuery()
          .table('matchmst')
          .insert({
            MstCode: data.matchId,
            mstDate: isManual == 0 ? dateTime.toLocal().toISO() : data.date,
            matchName: data.matchName,
            seriesId: data.seriesId,
            SportID: series.SportID,
            marketCount: 0,
            createdOn: new Date(),
            active: 1,
            runner_json: JSON.stringify(runners),
            tvUrl: data.tvUrl,
            score_board_json: data.score_board_json,
            line_fancy_delay: delay,
            line_fancy_volume: lineFancyVolume,
            oddsLimit: oddsLimit,
            country_code: data.countryCode,
            is_manual: data.is_manual,
          })

        return response.json({
          message: 'Match saved.',
        })
      }
    }

    return response.badRequest({
      message: "You don' have permission",
    })
  }

  public async addManualMatch({ request, authUser, response }: HttpContextContract) {
    if (authUser.usetype == 0 || authUser.usetype == 55) {
      let data = await request.validate({
        schema: schema.create({
          matchId: schema.string(),
          matchName: schema.string(),
          date: schema.string(),
          seriesId: schema.string(),
          is_manual: schema.boolean(),
        }),
      })

      if (authUser.usetype == 55) {
        authUser = await UserService.checkPersmission(authUser, 'Active Matches and Manage Series')

        if (!authUser) {
          return response.badRequest({
            message: 'Invalid request.',
          })
        }
      }

      const series = await Database.query()
        .from('seriesmst')
        .where('seriesId', data.seriesId)
        .first()
      if (series) {
        if (series.active == 0) {
          return response.badRequest({
            message: 'Series is not active',
          })
        }
      } else {
        return response.badRequest({
          message: 'Series is not found.',
        })
      }

      const event = await Database.query().from('matchmst').where('MstCode', data.matchId).first()
      if (event) {
        return response.json({
          message: 'Match already exists.',
        })
      } else {
        let manualMatch: any = await Redis.smembers('MANUAL_MATCH_LIST')

        manualMatch = manualMatch.map((el: any) => JSON.parse(el))

        if (manualMatch) {
          const isExists = manualMatch.find((s: any) => s.id == data.matchId)

          if (isExists) {
            return response.badRequest({
              message: 'Match already exists!',
            })
          }
        }

        await Redis.sadd(
          'MANUAL_MATCH_LIST',
          JSON.stringify({
            id: data.matchId,
            name: data.matchName,
            openDate: data.date,
            seriesId: data.seriesId,
            is_manual: data.is_manual,
          })
        )
        return response.json({
          message: 'Match saved.',
        })
      }
    }

    return response.badRequest({
      message: "You don' have permission",
    })
  }

  public async update({ request, authUser, response, params }: HttpContextContract) {
    if (authUser.usetype == 0 || authUser.usetype == 55) {
      const data = await request.validate({
        schema: schema.create({
          oddsLimit: schema.number(),
          volumeLimit: schema.number(),
          tvUrl: schema.string.optional(),
          score_board_json: schema.string.optional(),
          active: schema.boolean(),
          line_fancy_delay: schema.number(),
          line_fancy_volume: schema.number(),
          auto_add_fancy: schema.boolean.optional(),
        }),
      })
      const matchId = params.id

      if (!data.hasOwnProperty('tvUrl')) {
        data.tvUrl = ''
      }

      if (!data.hasOwnProperty('score_board_json')) {
        data.score_board_json = ''
      }

      const event = await Database.query().from('matchmst').where('MstCode', matchId).first()

      if (event) {
        if (data.hasOwnProperty('auto_add_fancy') && data.auto_add_fancy != event.auto_add_fancy) {
          if (data.auto_add_fancy) {
            await Redis.sadd('auto_fancy_matches', matchId)
          } else {
            await Redis.srem('auto_fancy_matches', matchId)
          }
        }

        await Database.from('matchmst').where('MstCode', matchId).update(data)

        const markets = await Database.from('market').where('matchId', matchId).select('Id')

        for (const market of markets) {
          UserService.deleteKeys(await Redis.keys('marketDb:' + market.Id + ':*')).then()
        }

        if (Number(data.active) == event.active) {
          let matchData = {
            match_id: event.matchId,
            data: {
              match_id: matchId,
              oddsLimit: data.oddsLimit,
              volumeLimit: data.volumeLimit,
              tvUrl: data.tvUrl,
              line_fancy_delay: data.line_fancy_delay,
              line_fancy_volume: data.line_fancy_volume,
            },
          }
          await MarketService.removeMarketCache(matchId)
          await Redis.publish('UPDATE_MATCH_EVENT', JSON.stringify(matchData))
        } else {
          await Redis.publish('MATCH_UPDATE_DATA', JSON.stringify({ matchId: matchId }))
        }

        await Redis.publish('DASHBOARD_UPDATE_USER', '')
        await Redis.publish('DASHBOARD_UPDATE_ADMIN', '')

        return response.json({
          message: 'Detail updated.',
        })
      }
    }

    return response.badRequest({
      message: "You don' have permission",
    })
  }

  public async getActiveMatches({ request, authUser, response }: HttpContextContract) {
    const data = await request.validate({
      schema: schema.create({
        sportId: schema.number(),
      }),
    })

    let rows: any = []

    if (
      authUser.usetype == 0 ||
      authUser.usetype == 55 ||
      (authUser.usetype == 11 && authUser.allow_result_declare)
    ) {
      rows = await Database.from('matchmst')
        .join('sportmst', 'sportmst.id', '=', 'matchmst.SportID')
        .where('matchmst.active', 1)
        .where('matchmst.SportID', data.sportId)
        .select('matchmst.*', 'sportmst.name')
    }

    return response.json({
      data: rows,
    })
  }

  public async getMatchesForResult({ request, authUser, response }: HttpContextContract) {
    const data = await request.validate({
      schema: schema.create({
        sportId: schema.number(),
      }),
    })

    let rows: any = []

    if (
      authUser.usetype == 0 ||
      authUser.usetype == 55 ||
      (authUser.usetype == 11 && authUser.allow_result_declare) ||
      (authUser.usetype == 11 && authUser.mstrid == 4957 && authUser?.domain == 'https://bsf247.pro') ||
      (authUser.usetype == 11 && authUser.mstrid == 2 && authUser.mstrname == 'Ccompany')
    ) {
      rows = await Database.from('matchmst')
        .join('sportmst', 'sportmst.id', '=', 'matchmst.SportID')
        // .where('matchmst.active', 1)
        .where('matchmst.SportID', data.sportId)
        .whereExists((query) => {
          query
            .from('market')
            .whereColumn('matchmst.MstCode', 'market.matchId')
            .where('active', 1)
            .limit(1)
        })
        .select('matchmst.*', 'sportmst.name')
    }

    return response.json({
      data: rows,
    })
  }

  public async getMatchMarketList({ request, response }: HttpContextContract) {
    const data = await request.validate({
      schema: schema.create({
        sportsId: schema.number(),
        matchId: schema.number(),
      }),
    })

    const getResultData = await Database.from('market')
      .where('sportsId', data.sportsId)
      .where('MatchID', data.matchId)
      .where('active', 1)

    return response.json({
      data: getResultData,
    })
  }

  public async querySelection({ request, response }: HttpContextContract) {
    const data = await request.validate({
      schema: schema.create({
        marketId: schema.string(),
      }),
    })

    const getResultData = await Database.from('tblselection').where('marketId', data.marketId)

    return response.json({
      data: getResultData,
    })
  }

  public async blockedMatchUsers({ request, authUser, response }: HttpContextContract) {
    if (request.method() == 'GET') {
      const data = await request.validate({
        schema: schema.create({
          matchId: schema.number(),
        }),
      })
      const search = request.input('search');
      const filter = request.input('filter');
      let rows: any = await Database.from('nested_users')
        .withRecursive('nested_users', (query) => {
          query
            .select(
              'm.mstrid',
              'm.mstruserid',
              'm.mstrname',
              'm.parentId',
              Database.raw('IF(bm.id IS NOT NULL, 1, 0) AS is_blocked')
            )
            .from('createmaster AS m')
            .leftJoin('user_deactive_match AS bm', (builder) => {
              builder
                .andOn('m.mstrid', 'bm.user_id')
                .andOnVal('bm.match_id', '=', data.matchId)
                .andOnVal('bm.locked_by', '=', authUser.mstrid)
            })
            .where('m.mstrid', authUser.mstrid)
            .unionAll((builder) => {
              builder
                .select(
                  'u.mstrid',
                  'u.mstruserid',
                  'u.mstrname',
                  'u.parentId',
                  Database.raw('IF(bm.id IS NOT NULL, 1, 0) AS is_blocked')
                )
                .from('createmaster AS u')
                .innerJoin('nested_users AS nu', 'nu.mstrid', 'u.parentId')
                .leftJoin('user_deactive_match AS bm', (builder) => {
                  builder
                    .andOn('u.mstrid', 'bm.user_id')
                    .andOnVal('bm.match_id', '=', data.matchId)
                    .andOnVal('bm.locked_by', '=', authUser.mstrid)
                })
            })
        })
        .whereNot('mstrid', authUser.mstrid)
        .if(search, (builder) => {
          builder.where((q) => {
            q.whereILike('mstrname', '%' + search + '%')
            q.orWhereILike('mstruserid', '%' + search + '%')
          })
        }).if(filter !== '', (builder) => {
          builder.where('is_blocked', filter)
        })
        .limit(50)

      return response.json(rows)
    } else {
      const data = await request.validate({
        schema: schema.create({
          matchId: schema.number(),
          usersId: schema.array([rules.distinct('*')]).members(schema.number()),
        }),
      })

      await Database.from('user_deactive_match')
        .where('match_id', data.matchId)
        .where('locked_by', '=', authUser.mstrid)
        .delete()

      if (data.usersId.length > 0) {
        await Database.table('user_deactive_match').multiInsert(
          data.usersId.map((el: any) => {
            return {
              created: new Date(),
              match_id: data.matchId,
              user_id: el,
              locked_by: authUser.mstrid,
            }
          })
        )
      }

      return response.json({
        message: 'Data saved.',
      })
    }
  }

  public async blockedMatches({ request, authUser, response }: HttpContextContract) {
    const data = await request.validate({
      schema: schema.create({
        match_id: schema.number(),
        status: schema.string(),
        userId: schema.number.optional(),
      }),
    })

    if (authUser.usetype == 55) {
      authUser = await UserService.checkPersmission(authUser, 'Match On and Off')

      if (!authUser) {
        return response.badRequest({
          message: 'Invalid request.',
        })
      }
    }

    const userId = request.input('userId', authUser.mstrid)

    if (authUser.mstrid !== 1 && authUser.usetype !== 55) {
      if (!(await Parent.validate(authUser, userId))) {
        return response.badRequest({
          message: 'Invalid request.',
        })
      }

      const isDeactivated = await Database.from('user_deactive_match')
        .where('match_id', data.match_id)
        .where('user_id', userId)
        .whereNull('locked_by')
        .select('id')
        .first()

      if (isDeactivated && data.status == 'A') {
        await Database.from('user_deactive_match')
          .where('match_id', data.match_id)
          .where('user_id', userId)
          .whereNull('locked_by')
          .delete()
      } else {
        await Database.table('user_deactive_match').insert({
          created: new Date(),
          match_id: data.match_id,
          user_id: userId,
        })
      }

      await Redis.del('dashboard:' + authUser.mstrid)
    } else {
      const matchId = data.match_id
      const event = await Database.query().from('matchmst').where('MstCode', matchId).first()

      if (event) {
        const active = data.status == 'D' ? 0 : 1
        await Database.from('matchmst').where('MstCode', matchId).update({ active })

        if (!data.status) {
          const redisKeyMinMax = `fanciesMinMax:${matchId}:*`
          if (redisKeyMinMax.length > 0) {
            await Redis.del(redisKeyMinMax)
          }
        }

        const markets = await Database.from('market').where('matchId', matchId).select('Id')

        for (const market of markets) {
          UserService.deleteKeys(await Redis.keys('marketDb:' + market.Id + ':*')).then()
        }

        await Redis.publish('DASHBOARD_UPDATE_USER', '')
        await Redis.publish('DASHBOARD_UPDATE_ADMIN', '')
        return response.json({
          message: 'Detail updated.',
        })
      }
    }

    await Redis.publish('DASHBOARD_UPDATE_USER', '')
    await Redis.publish('DASHBOARD_UPDATE_ADMIN', '')

    return response.json({
      message: 'Updated',
    })
  }

  public async getUserPosition({ request, authUser, response }: HttpContextContract) {
    const data = await request.validate({
      schema: schema.create({
        matchId: schema.string(),
        marketId: schema.string(),
        userId: schema.number(),
        userType: schema.number(),
      }),
    })

    if (authUser.usetype != '55') {
      const userPosition = await Sp.readCall(
        '_get_user_position(:userId,:userType,:match_Id,:marketId)',
        {
          match_Id: data.matchId,
          marketId: data.marketId,
          userId: data.userId,
          userType: data.userType,
        }
      )

      return response.json({
        data: { userPosition },
      })
    }

    return response.badRequest({
      message: "You don't have permission",
    })
  }

  public async getLiveTv({ request, authUser, response }: HttpContextContract) {
    const chid = request.input('chid')

    if (authUser.usetype == 0) {
      const res = await axios.get(`https://directlive88.com/directstreaming.php?chid=${chid}`)

      return response.json({
        data: res.data,
      })
    }

    return response.badRequest({
      message: "You don't have permission",
    })
  }
}
