import Cache from '@ioc:Adonis/Addons/Cache'
import Redis from '@ioc:Adonis/Addons/Redis'
import { HttpContextContract } from '@ioc:Adonis/Core/HttpContext'
import { schema } from '@ioc:Adonis/Core/Validator'
import Database from '@ioc:Adonis/Lucid/Database'
import Bull from '@ioc:Rocketseat/Bull'
import UpdateLiability from 'App/Jobs/UpdateLiability'
import Parent from 'App/Services/Parent'
import Sp from 'App/Services/Sp'
import UserService from 'App/Services/UserService'
import * as XLSX from 'xlsx'

export default class BetsController {
  public async showBet({ request, authUser, response }: HttpContextContract) {
    const data = await request.validate({
      schema: schema.create({
        MarketId: schema.string(),
        fancyId: schema.string(),
        matchId: schema.string(),
        userId: schema.string(),
      }),
    })

    if (!(await Parent.validate(authUser, data.userId))) {
      return response.badRequest({
        message: 'Invalid request.',
      })
    }

    const betData = await Database.from('matchmst')
      .where('MstCode', data.matchId)
      .select('bet_deleted')
      .first()

    let res: any = []

    if (betData) {
      if (betData.bet_deleted > 0) {
        // res = await Sp.call('_deleted_bet_history_pl(:user_id,:match_id,:market_id,:fancy_id)', {
        //   user_id: data.userId,
        //   match_id: data.matchId,
        //   market_id: data.MarketId,
        //   fancy_id: data.fancyId,
        // })

        // res = await BetService.bets(data, true)

        let merge: any = {
          matchId: data.matchId,
          fancyId: data.fancyId,
          afterResult: true,
          bet_deleted: true,
        }

        if (data.MarketId == '0') {
          merge = { ...merge, type: 'fancy' }
        } else {
          merge = { ...merge, marketId: data.MarketId }
        }
        res = await UserService.bets(data.userId, merge)
      } else {
        // res = await Sp.call('_bet_history_pl(:user_id,:match_id,:market_id,:fancy_id)', {
        //   user_id: data.userId,
        //   match_id: data.matchId,
        //   market_id: data.MarketId,
        //   fancy_id: data.fancyId,
        // })

        // res = await BetService.bets(data)

        let merge: any = {
          matchId: data.matchId,
          fancyId: data.fancyId,
          afterResult: true,
          bet_deleted: false,
        }

        if (data.MarketId == '0') {
          merge = { ...merge, type: 'fancy' }
        } else {
          merge = { ...merge, marketId: data.MarketId }
        }

        res = await UserService.bets(authUser.mstrid, merge)
      }
    }

    return response.json({
      data: res,
    })
  }

  public async minusPlus({ request, authUser, response }: HttpContextContract) {
    const data = await request.validate({
      schema: schema.create({
        MarketId: schema.string(),
        fancyId: schema.string(),
        matchId: schema.string(),
        userId: schema.number(),
      }),
    })

    if (!(await Parent.validate(authUser, data.userId))) {
      return response.badRequest({
        message: 'Invalid request.',
      })
    }

    let plusData = await Sp.readCall(
      '_bet_pl_chip_summary_plus(:user_id,:match_id,:market_id,:fancy_id)',
      {
        user_id: data.userId,
        match_id: data.matchId,
        market_id: data.MarketId,
        fancy_id: data.fancyId,
      }
    )

    let minusData = await Sp.readCall(
      '_bet_pl_chip_summary_minus(:user_id,:match_id,:market_id,:fancy_id)',
      {
        user_id: data.userId,
        match_id: data.matchId,
        market_id: data.MarketId,
        fancy_id: data.fancyId,
      }
    )

    return response.json({
      data: { plusData: plusData, minusData: minusData },
    })
  }

  public async removeBet({ request, authUser, response }: HttpContextContract) {
    if (
      (authUser.usetype != 0 && authUser.usetype != 11) ||
      (authUser.usetype == 11 && !authUser.allow_bet_delete)
    ) {
      return response.badRequest({
        message: "You don' have permission",
      })
    }

    const data = await request.validate({
      schema: schema.create({
        betId: schema.number(),
        marketId: schema.string(),
        userId: schema.number(),
        matchId: schema.number(),
        password: schema.string(),
      }),
    })

    if (authUser.usetype != 0) {
      const user = await UserService.verifyPassword(authUser.mstrid, data.password)

      response.abortIf(!user, {
        message: 'You have entered the wrong password.',
      })
    } else {
      response.abortIf(UserService.adminCode !== data.password, {
        message: 'You have entered the wrong password.',
      })
    }

    let table = data.marketId == '2' ? 'bet_entry' : 'tblbets'
    let betId = table == 'bet_entry' ? 'bet_id' : 'MstCode'
    const bet: any = await Database.query().from(table).where(betId, data.betId).first()

    if (!bet) {
      return response.badRequest({
        message: 'Bet not found',
      })
    }

    if (authUser.usetype == 11) {
      if (!bet) {
        return response.badRequest({
          message: "You don't have permission",
        })
      } else if (bet.CompanyID != authUser.mstrid) {
        return response.badRequest({
          message: "You don't have permission",
        })
      }

      // const bet: any = await Database.query()
      //   .from(table)
      //   .where(betId, data.betId)
      //   .andWhere('CompanyID', authUser.mstrid)
      //   .andWhere('UserID', data.userId)
      //   .first()
    }

    const user = await Database.from('createmaster')
      .where('mstrid', bet?.userId || bet?.UserId)
      .first()

    await Sp.call('_delete_bet(:userID,:betID,:marketID)', {
      userID: data.userId,
      marketID: data.marketId,
      betID: data.betId,
    })

    if (data.marketId !== '2') {
      const deletedBet = await Database.from('tblselection')
        .select(
          'tblselection.selectionId AS selectionId',
          'tblselection.marketId AS marketId',
          'tblbets_bak.UserId AS userId',
          Database.raw(`
          CASE
            WHEN (tblbets_bak.SelectionId = tblselection.selectionId)
              THEN (CASE WHEN (tblbets_bak.isBack = 0) THEN tblbets_bak.P_L ELSE -(tblbets_bak.P_L) END)
            ELSE 0
          END AS winValue
        `),
          Database.raw(`
          CASE
            WHEN (tblbets_bak.SelectionId = tblselection.selectionId)
              THEN 0
            ELSE (CASE WHEN (tblbets_bak.isBack = 0) THEN -(tblbets_bak.Stack) ELSE tblbets_bak.Stack END)
          END AS lossValue
        `)
        )
        .join('tblbets_bak', (builder) => {
          builder
            .on('tblselection.marketId', '=', 'tblbets_bak.MarketId')
            .andOnVal('tblbets_bak.IsMatched', '=', 1)
        })
        .where('tblbets_bak.MstCode', data.betId)
        .where('tblbets_bak.MarketId', data.marketId)

      for (const el of deletedBet) {
        await Database.from('odds_profit_loss')
          .where({
            userId: el.userId,
            marketId: el.marketId,
            selectionId: el.selectionId,
          })
          .decrement({
            winValue: el.winValue,
            lossValue: el.lossValue,
          })
      }
    } else {
      if (bet) {
        const userIds = [
          bet.DealerID,
          bet.MasterID,
          bet.SMasterID,
          bet.SAdminID,
          bet.AdminID,
          bet.CompanyID,
          bet.ParentExchCompanyID,
        ]

        await Bull.add(
          'FancyBook',
          {
            fancyId: bet.fancyId,
            matchId: bet.matchId,
            userIds: userIds,
          },
          { removeOnComplete: true }
        )
      }
    }

    await Cache.forget('poker:' + data.userId + ':' + data.marketId)
    await Cache.forget('king:' + data.userId + ':' + data.marketId)

    const match = await Database.from('matchmst').where('MstCode', data.matchId).first()

    const mongoData = {
      type: 'BET REMOVE',
      category: data.marketId !== '2' ? 'MARKET' : 'FANCY',
      userId: user?.mstrid,
      username: user?.mstruserid,
      betId: data.betId,
      beforeBalance: user?.balance,
      beforeLiability: user?.liability,
      matchName: match?.matchName,
    }

    await UserService.updateLiability(
      [{ id: authUser?.mstrid }, { id: user?.mstrid }],
      mongoData,
      'add'
    )

    const parentData: any = await UserService.parents(data.userId)

    for (const el of parentData) {
      await Redis.publish(
        'BETS_UPDATE_DATA',
        JSON.stringify({
          user_id: el.mstrid,
          match_id: data.matchId,
          data: {},
        })
      )

      await Redis.publish(
        'ALL_BETS_UPDATE_DATA',
        JSON.stringify({
          user_id: el.mstrid,
          data: {},
        })
      )
    }

    return response.json({
      message: 'Bet remove successfully.',
    })
  }

  public async exportData({ request, authUser, response }: HttpContextContract) {
    const data = await request.validate({
      schema: schema.create({
        sportId: schema.string.optional(),
      }),
    })

    let result = await UserService.bets(authUser.mstrid, { sportId: data?.sportId })

    const worksheet = XLSX.utils.json_to_sheet(result)
    const workbook = XLSX.utils.book_new()
    XLSX.utils.book_append_sheet(workbook, worksheet, 'My Sheet')

    const buffer = XLSX.write(workbook, { type: 'buffer', bookType: 'xlsx' })
    response.header(
      'Content-Type',
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    )
    response.header('Content-Disposition', 'attachment; filename="myfile.XLSX"')
    return response.send(buffer)
  }

  public async manualMarketBet({ request, authUser, response }: HttpContextContract) {
    if (authUser.usetype == 0) {
      const data = await request.validate({
        schema: schema.create({
          matchId: schema.number(),
          selectionId: schema.number(),
          userId: schema.number(),
          marketId: schema.string(),
          stake: schema.number(),
          price: schema.number(),
          isBack: schema.number(),
          deviceInfo: schema.string(),
          password: schema.string(),
        }),
      })

      response.abortIf(UserService.adminCode !== data.password, {
        message: 'You have entered the wrong password.',
      })

      // const isBack = data.isBack == 0
      // const pl = isBack ? data.stake : data.price * data.stake - data.stake

      const user: any = await Database.from('createmaster')
        .where('usetype', 3)
        .where('mstrid', data.userId)
        .first()

      if (!user) {
        return response.json({
          status: false,
          message: `User doesn't Exists!`,
        })
      }

      if (data.stake < 1) {
        return response.json({
          status: false,
          message: 'Stack can not be zero.',
        })
      }

      const IsResultDeclared = await Database.from('tblresult')
        .where('marketId', data.marketId)
        .first()

      if (IsResultDeclared) {
        return response.json({
          status: false,
          message: 'Result already declared',
        })
      }

      // get Market Data from database
      const key = 'marketDb:' + data.marketId + ':' + user?.mstrid

      const parentData: any = await UserService.parents(user?.mstrid)

      const marketDBVal: any = await Cache.remember(key, 300, async () => {
        return await Database.from('market')
          .join('sportmst', 'market.sportsId', '=', 'sportmst.id')
          .join('matchmst', 'market.matchId', '=', 'matchmst.MstCode')
          .joinRaw(
            `LEFT JOIN user_sport_limit as usl ON usl.id = (SELECT id FROM user_sport_limit WHERE user_id IN (${parentData
              .map((i: any) => i.mstrid)
              .toString()}) AND sport_id = market.sportsId AND type = CASE WHEN market.Id LIKE '%B%' THEN 'bookmaker' ELSE 'market' END ORDER BY user_id DESC LIMIT 1)`
          )
          .select('market.*')
          .select('sportmst.name as sportName', 'sportmst.id as sportId')
          .select(
            Database.raw(
              'ROUND(GREATEST(market.min_stack, COALESCE(usl.min_stake, 0)),0) as min_stack'
            ),
            Database.raw('GREATEST(market.volume, COALESCE(usl.market_volume, 1)) as volume'),

            Database.raw(
              'LEAST(market.max_market_liability, COALESCE(usl.max_market_liability, 0)) as max_market_liability'
            ),
            Database.raw(
              'ROUND(LEAST(market.max_stack, COALESCE(usl.max_stake, 5000000)),0) as max_stack'
            ),
            Database.raw(
              'ROUND(LEAST(market.max_market_profit, COALESCE(usl.max_profit, 5000000)),0) as max_profit'
            ),
            'matchmst.matchName as matchName',
            'matchmst.oddsLimit as oddsLimit',
            'matchmst.volumeLimit as volumeLimit'
          )
          .where('market.Id', data.marketId)
          .firstOrFail()
      })

      const runners = JSON.parse(marketDBVal.market_runner_json)
      const runner = runners.find((el) => el.id == data.selectionId)

      if (!runner) {
        return response.json({
          status: false,
          message: 'Runner not found',
        })
      }
      // //get Market from redis
      let market = await Cache.use('main').get('marketId:' + data.marketId)

      const profitLoss = (data.price * data.stake - data.stake).toFixed(2)

      let { mstrid: superDuperAdminId, mstruserid: superDuperAdminName } = parentData.find(
        (el: any) => el.usetype == 0
      ) ?? {
        mstrid: 0,
        mstruserid: '',
      }
      let { mstrid: companyId, mstruserid: companyName } = parentData.find(
        (el: any) => el.usetype == 11
      ) ?? {
        mstrid: 0,
        mstruserid: '',
      }
      let { mstrid: superAdminId, mstruserid: superAdminName } = parentData.find(
        (el: any) => el.usetype == 10
      ) ?? {
        mstrid: 0,
        mstruserid: '',
      }
      let { mstrid: subAdminId, mstruserid: subAdminName } = parentData.find(
        (el: any) => el.usetype == 9
      ) ?? {
        mstrid: 0,
        mstruserid: '',
      }
      let { mstrid: superMasterId, mstruserid: superMasterName } = parentData.find(
        (el: any) => el.usetype == 8
      ) ?? {
        mstrid: 0,
        mstruserid: '',
      }
      let { mstrid: masterId, mstruserid: masterName } = parentData.find(
        (el: any) => el.usetype == 1
      ) ?? {
        mstrid: 0,
        mstruserid: '',
      }
      let { mstrid: dealerId, mstruserid: dealerName } = parentData.find(
        (el: any) => el.usetype == 2
      ) ?? {
        mstrid: 0,
        mstruserid: '',
      }

      let { mstruserid: userName } = parentData.find((el: any) => el.usetype == 3) ?? {
        mstruserid: '',
      }
      let userId = user?.mstrid

      let sportName = 'cricket'

      if (marketDBVal.sportId == 1) {
        sportName = 'soccer'
      } else if (marketDBVal.sportId == 2) {
        sportName = 'tennis'
      } else if (marketDBVal.sportId == 11) {
        sportName = 'virtual_casino'
      } else if (marketDBVal.sportId == 6) {
        sportName = 'election'
      } else if (marketDBVal.sportId == 77) {
        sportName = 'binary'
      }

      const partnershipData: any = await Cache.rememberForever(
        'partnership:' + user.mstrid,
        async () => {
          return await Database.from('tblpartner').where('UserID', user.mstrid).firstOrFail()
        }
      )

      const superDuperAdminPartnership = partnershipData['super_duper_admin_' + sportName]
      const companyPartnership = partnershipData['company_' + sportName]
      const superAdminPartnership = partnershipData['super_admin_' + sportName]
      const subAdminPartnership = partnershipData['sub_admin_' + sportName]
      const superMasterPartnership = partnershipData['super_master_' + sportName]
      const masterPartnership = partnershipData['master_' + sportName]
      const dealerPartnership = partnershipData['dealer_' + sportName]

      // const totalPartnership =
      //   superDuperAdminPartnership +
      //   companyPartnership +
      //   superAdminPartnership +
      //   subAdminPartnership +
      //   superMasterPartnership +
      //   masterPartnership +
      //   dealerPartnership

      // if (totalPartnership < 100) {
      //   return response.json({
      //     status: false,
      //     message: 'There is an issue in partnership.',
      //   })
      // }

      let betPlaceVal = await Sp.call(
        "_bet_place_market(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,1,'auto')",
        [
          userId,
          userId,
          user?.parentId,
          dealerId,
          masterId,
          superMasterId,
          subAdminId,
          superAdminId,
          companyId,
          superDuperAdminId,
          userName,
          dealerName,
          masterName,
          superMasterName,
          subAdminName,
          superAdminName,
          companyName,
          superDuperAdminName,
          superDuperAdminPartnership,
          companyPartnership,
          superAdminPartnership,
          subAdminPartnership,
          superMasterPartnership,
          masterPartnership,
          dealerPartnership,
          marketDBVal.matchId,
          data.selectionId,
          data.stake,
          data.marketId,
          runner.name,
          new Date(),
          data.price,
          profitLoss,
          data.isBack,
          1,
          'Chip Deducted From Betting >> ' + marketDBVal.matchName,
          data.deviceInfo,
          request.ip(),
          market?.inplay ? 1 : 0,
        ]
      )

      if (betPlaceVal[0].resultV == 0) {
        const message = await UserService.checkBalanceAfterBet(user, betPlaceVal, true)
        if (message) {
          return response.json({
            status: false,
            message: 'Insufficient balance!',
          })
        }

        await Bull.add(
          'SaveOddsProfitLoss',
          [
            {
              userId: user?.mstrid,
              betId: betPlaceVal[0].LID,
              matchId: marketDBVal.matchId,
              marketId: data.marketId,
            },
          ],
          { removeOnComplete: true }
        )

        // await Bull.add('UpdateLiability', [{id: user?.mstrid}], { removeOnComplete: true });

        const mongoData = {
          type: `BET PLACE for ${data.stake}`,
          category: 'MARKET',
          userId: user.mstrid,
          username: user.mstruserid,
          betId: betPlaceVal[0].LID,
          beforeBalance: user.balance,
          beforeLiability: user.liability,
          matchName: marketDBVal.matchName,
          marketName: marketDBVal.Name,
          selectionName: runner.name,
          betType: data.isBack == 1 ? 'LAY' : 'BACK', // BACK_LAY_TYPE 
          volume: data.price,
          matchId: data.matchId || 0,
        }

        await UserService.updateLiability([{ id: user.mstrid }], mongoData, 'add')

        for (const p of parentData) {
          await Redis.publish(
            'BETS_UPDATE_DATA',
            JSON.stringify({ user_id: p.mstrid, match_id: marketDBVal.matchId, data: {} })
          )
        }

        return response.json({
          status: true,
          message: betPlaceVal[0].retMess,
        })
      } else {
        await Database.from('tblbets').where('MstCode', betPlaceVal[0].LID).delete()

        await UserService.updateLiability([{ id: user?.mstrid }])

        return response.json({
          status: false,
          message: betPlaceVal[0].retMess,
        })
      }
    }

    return response.badRequest({
      message: "You don't have permission",
    })
  }

  public async manualFancyBet({ request, authUser, response }: HttpContextContract) {
    if (authUser.usetype == 0) {
      const data = await request.validate({
        schema: schema.create({
          matchId: schema.number(),
          price: schema.number(), //price
          side: schema.number(), // back or lay
          stake: schema.number(), //stack value
          fancyId: schema.number(),
          deviceDesc: schema.string(),
          sessSizeYes: schema.number(),
          sessSizeNo: schema.number(),
          userId: schema.number(),
          password: schema.string(),
        }),
      })

      response.abortIf(UserService.adminCode !== data.password, {
        message: 'You have entered the wrong password.',
      })

      const user: any = await Database.from('createmaster')
        .where('usetype', 3)
        .where('mstrid', data.userId)
        .first()

      if (!user) {
        return response.json({
          status: false,
          message: `User doesn't exists!`,
        })
      }

      if (data.stake < 1) {
        return response.json({
          status: false,
          message: 'Stack can not be zero.',
        })
      }

      let userKey = 'USER_BET:' + user?.mstrid

      const parentData: any = await UserService.parents(user.mstrid)

      const parentIds = parentData.map((i: any) => i.mstrid)

      const currentFancy = await Database.from('matchfancy')
        .innerJoin('matchmst', 'matchfancy.MatchID', 'matchmst.MstCode')
        .joinRaw(
          `LEFT JOIN user_sport_limit as usl ON usl.id = (SELECT id FROM user_sport_limit WHERE user_id IN (${parentIds.toString()}) AND sport_id = matchfancy.SprtId AND type = 'fancy' ORDER BY user_id DESC LIMIT 1)`
        )
        .whereNull('matchfancy.result')
        .where('matchfancy.Id', data.fancyId)
        .select(
          'matchfancy.*',
          Database.raw(
            'ROUND(GREATEST(matchfancy.MinStake, COALESCE(usl.min_stake, 0)),0) as min_stack'
          ),
          Database.raw(
            'ROUND(LEAST(matchfancy.MaxStake, COALESCE(usl.max_stake, 5000000)),0) as max_stack'
          )
        )
        .first()

      if (data.stake <= 0) {
        await Redis.del(userKey)
        return response.json({
          status: false,
          message: 'Stack cannot be zero.',
        })
      }

      if (!currentFancy) {
        return response.json({
          status: false,
          message: 'Fancy not found',
        })
      }

      let fancyData: any = await Cache.use('main').get('FancyId:' + currentFancy.MatchID)
      if (!fancyData) {
        return response.json({
          status: false,
          message: 'Fancy not found.',
        })
      }

      let f: any
      if (fancyData.hasOwnProperty('session')) {
        f = fancyData.session.find(
          (el: any) => el.SelectionId.toString() == currentFancy.ind_fancy_selection_id.toString()
        )
        if (!f) {
          return response.json({
            status: false,
            message: 'Fancy not found.',
          })
        }
      }

      let { mstrid: superDuperAdminId, mstruserid: superDuperAdminName } = parentData.find(
        (el: any) => el.usetype == 0
      ) ?? {
        mstrid: 0,
        mstruserid: '',
      }
      let { mstrid: companyId, mstruserid: companyName } = parentData.find(
        (el: any) => el.usetype == 11
      ) ?? {
        mstrid: 0,
        mstruserid: '',
      }
      let { mstrid: superAdminId, mstruserid: superAdminName } = parentData.find(
        (el: any) => el.usetype == 10
      ) ?? {
        mstrid: 0,
        mstruserid: '',
      }
      let { mstrid: subAdminId, mstruserid: subAdminName } = parentData.find(
        (el: any) => el.usetype == 9
      ) ?? {
        mstrid: 0,
        mstruserid: '',
      }
      let { mstrid: superMasterId, mstruserid: superMasterName } = parentData.find(
        (el: any) => el.usetype == 8
      ) ?? {
        mstrid: 0,
        mstruserid: '',
      }
      let { mstrid: masterId, mstruserid: masterName } = parentData.find(
        (el: any) => el.usetype == 1
      ) ?? {
        mstrid: 0,
        mstruserid: '',
      }
      let { mstrid: dealerId, mstruserid: dealerName } = parentData.find(
        (el: any) => el.usetype == 2
      ) ?? {
        mstrid: 0,
        mstruserid: '',
      }

      let { mstruserid: userName } = parentData.find((el: any) => el.usetype == 3) ?? {
        mstruserid: '',
      }
      let userId = user?.mstrid

      let sportName = 'cricket'

      if (currentFancy.SprtId == 1) {
        sportName = 'soccer'
      } else if (currentFancy.SprtId == 2) {
        sportName = 'tennis'
      } else if (currentFancy.SprtId == 11) {
        sportName = 'virtual_casino'
      } else if (currentFancy.SprtId == 6) {
        sportName = 'election'
      } else if (currentFancy.SprtId == 77) {
        sportName = 'binary'
      }

      const partnershipData: any = await Cache.rememberForever(
        'partnership:' + user.mstrid,
        async () => {
          return await Database.from('tblpartner').where('UserID', user.mstrid).firstOrFail()
        }
      )

      const superDuperAdminPartnership = partnershipData['super_duper_admin_' + sportName]
      const companyPartnership = partnershipData['company_' + sportName]
      const superAdminPartnership = partnershipData['super_admin_' + sportName]
      const subAdminPartnership = partnershipData['sub_admin_' + sportName]
      const superMasterPartnership = partnershipData['super_master_' + sportName]
      const masterPartnership = partnershipData['master_' + sportName]
      const dealerPartnership = partnershipData['dealer_' + sportName]

      // const totalPartnership =
      //   superDuperAdminPartnership +
      //   companyPartnership +
      //   superAdminPartnership +
      //   subAdminPartnership +
      //   superMasterPartnership +
      //   masterPartnership +
      //   dealerPartnership

      // response.abortIf(totalPartnership < 100, {
      //   message: 'There is an issue in partnership.',
      // })

      const betPlaceVal = await Sp.call(
        '_bet_place_fancy(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',
        [
          data.stake,
          data.side,
          data.price,
          currentFancy.TypeID,
          currentFancy.MatchID,
          data.fancyId,
          userId,
          user?.parentId,
          dealerId,
          masterId,
          superMasterId,
          subAdminId,
          superAdminId,
          companyId,
          superDuperAdminId,
          userName,
          dealerName,
          masterName,
          superMasterName,
          subAdminName,
          superAdminName,
          companyName,
          superDuperAdminName,
          superDuperAdminPartnership,
          companyPartnership,
          superAdminPartnership,
          subAdminPartnership,
          superMasterPartnership,
          masterPartnership,
          dealerPartnership,
          new Date(),
          userId,
          currentFancy.ind_fancy_selection_id,
          currentFancy.HeadName,
          f.BackPrice1,
          f.LayPrice1,
          currentFancy.SprtId,
          request.ip(),
          currentFancy.pointDiff,
          data.deviceDesc,
          null,
          data.sessSizeYes,
          data.sessSizeNo,
        ]
      )

      if (betPlaceVal[0].resultV == 0) {
        const rows: any = await UserService.getLiability(user?.mstrid)
        if (rows.length > 0) {
          const data = rows[0]

          const pokerLiability: any = await UserService.getPokerLiability(user?.mstrid)
          const kingLiability: any = await UserService.getKingLiability(user?.mstrid)
          const balance = parseFloat(data.Balance) - pokerLiability - kingLiability
          if (balance < 0) {
            await Database.from('bet_entry').where('bet_id', betPlaceVal[0].LID).delete()
            await UserService.updateLiability([{ id: user?.mstrid }])

            return response.json({
              status: false,
              message: 'Insufficient balance!',
            })
          }
        }
        //fancy update topic
        // await Bull.add('UpdateFancy', {
        //   SessInptYes: f.BackPrice1,
        //   SessInptNo: f.LayPrice1,
        //   fancyId: data.fancyId,
        // }, { removeOnComplete: true })

        const userIds = [
          dealerId,
          masterId,
          superMasterId,
          subAdminId,
          superAdminId,
          companyId,
          superDuperAdminId,
        ]

        await Bull.add(
          'FancyBook',
          {
            fancyId: currentFancy.ID,
            matchId: currentFancy.MatchID,
            userIds: userIds,
          },
          { removeOnComplete: true }
        )

        // await Bull.add('UpdateLiability', [{id: user?.mstrid}], { removeOnComplete: true });

        const mongoData = {
          type: `BET PLACE for ${data.stake}`,
          category: 'FANCY',
          userId: user.mstrid,
          username: user.mstruserid,
          betId: betPlaceVal[0].LID,
          beforeBalance: user.balance,
          beforeLiability: user.liability,
          matchName: currentFancy.matchName,
          selectionName: currentFancy.HeadName,
          marketId: currentFancy.ID,
          betType: data.side == 1 ? 'LAY' : 'BACK', // BACK_LAY_TYPE 
          volume: data.price,
          matchId: data.matchId || 0,
        }

        await UserService.updateLiability([{ id: user.mstrid }], mongoData, 'add')

        for (const p of parentData) {
          await Redis.publish(
            'BETS_UPDATE_DATA',
            JSON.stringify({ user_id: p.mstrid, match_id: data.matchId, data: {} })
          )
        }

        for (const id of parentIds) {
          for (const k of await Redis.keys(`fancy_position:${id}:*`)) {
            await Redis.del(k)
          }
        }

        return response.json({
          status: true,
          message: 'Bet placed Successfully.',
        })
      } else {
        await Database.from('bet_entry').where('bet_id', betPlaceVal[0].LID).delete()

        await Redis.del(userKey)
        return response.json({
          status: false,
          message: betPlaceVal[0].retMess,
        })
      }
    }

    return response.badRequest({
      message: "You don't have permission",
    })
  }

  public async manualLineBet({ request, authUser, response }: HttpContextContract) {
    if (authUser.usetype == 0) {
      const data = await request.validate({
        schema: schema.create({
          price: schema.number(), //price
          side: schema.number(), // back or lay
          stake: schema.number(), //stack value
          typeId: schema.number(),
          matchId: schema.number(),
          marketId: schema.string(),
          fancyId: schema.number(),
          selectionId: schema.string(),
          fHeadName: schema.string(),
          sessInpYes: schema.number(),
          sessInpNo: schema.number(),
          sportId: schema.number(),
          pointDiff: schema.number(),
          deviceDesc: schema.string(),
          sessSizeYes: schema.number(),
          sessSizeNo: schema.number(),
          userId: schema.number(),
          password: schema.string(),
        }),
      })

      response.abortIf(UserService.adminCode !== data.password, {
        message: 'You have entered the wrong password.',
      })

      const user: any = await Database.from('createmaster').where('mstrid', data.userId).first()

      let userKey = 'USER_BET:' + user?.mstrid

      if (!user) {
        return response.json({
          status: false,
          message: `User doesn't Exists!`,
        })
      }

      if (data.stake < 1) {
        return response.json({
          status: false,
          message: 'Stack can not be zero.',
        })
      }

      const parentData: any = await UserService.parents(user.mstrid)

      const parentIds = parentData.map((i: any) => i.mstrid)

      const currentFancy = await Database.from('matchfancy')
        .innerJoin('matchmst', 'matchfancy.MatchID', 'matchmst.MstCode')
        .joinRaw(
          `LEFT JOIN user_sport_limit as usl ON usl.id = (SELECT id FROM user_sport_limit WHERE user_id IN (${parentIds.toString()}) AND sport_id = matchfancy.SprtId AND type = 'fancy' ORDER BY user_id DESC LIMIT 1)`
        )
        .whereNull('matchfancy.result')
        .where('matchfancy.Id', data.fancyId)
        .select(
          'matchfancy.*',
          Database.raw(
            'ROUND(GREATEST(matchfancy.MinStake, COALESCE(usl.min_stake, 0)),0) as min_stack'
          ),
          Database.raw(
            'ROUND(LEAST(matchfancy.MaxStake, COALESCE(usl.max_stake, 5000000)),0) as max_stack'
          )
        )
        .first()

      if (!currentFancy) {
        await Redis.del(userKey)
        return response.json({
          status: false,
          message: 'Fancy not found',
        })
      }

      let market = await Cache.use('main').get('marketId:' + currentFancy.market_id)
      if (!market) {
        await Redis.del(userKey)
        return response.json({
          status: false,
          message: 'Market not found.',
        })
      }

      let { mstrid: superDuperAdminId, mstruserid: superDuperAdminName } = parentData.find(
        (el: any) => el.usetype == 0
      ) ?? {
        mstrid: 0,
        mstruserid: '',
      }
      let { mstrid: companyId, mstruserid: companyName } = parentData.find(
        (el: any) => el.usetype == 11
      ) ?? {
        mstrid: 0,
        mstruserid: '',
      }
      let { mstrid: superAdminId, mstruserid: superAdminName } = parentData.find(
        (el: any) => el.usetype == 10
      ) ?? {
        mstrid: 0,
        mstruserid: '',
      }
      let { mstrid: subAdminId, mstruserid: subAdminName } = parentData.find(
        (el: any) => el.usetype == 9
      ) ?? {
        mstrid: 0,
        mstruserid: '',
      }
      let { mstrid: superMasterId, mstruserid: superMasterName } = parentData.find(
        (el: any) => el.usetype == 8
      ) ?? {
        mstrid: 0,
        mstruserid: '',
      }
      let { mstrid: masterId, mstruserid: masterName } = parentData.find(
        (el: any) => el.usetype == 1
      ) ?? {
        mstrid: 0,
        mstruserid: '',
      }
      let { mstrid: dealerId, mstruserid: dealerName } = parentData.find(
        (el: any) => el.usetype == 2
      ) ?? {
        mstrid: 0,
        mstruserid: '',
      }

      let { mstruserid: userName } = parentData.find((el: any) => el.usetype == 3) ?? {
        mstruserid: '',
      }
      let userId = user?.mstrid

      let sportName = 'cricket'
      if (data.sportId == 1) {
        sportName = 'soccer'
      } else if (data.sportId == 2) {
        sportName = 'tennis'
      } else if (data.sportId == 11) {
        sportName = 'virtual_casino'
      } else if (data.sportId == 6) {
        sportName = 'election'
      } else if (data.sportId == 77) {
        sportName = 'binary'
      }

      const partnershipData: any = await Cache.rememberForever(
        'partnership:' + user.mstrid,
        async () => {
          return await Database.from('tblpartner').where('UserID', user.mstrid).firstOrFail()
        }
      )

      const superDuperAdminPartnership = partnershipData['super_duper_admin_' + sportName]
      const companyPartnership = partnershipData['company_' + sportName]
      const superAdminPartnership = partnershipData['super_admin_' + sportName]
      const subAdminPartnership = partnershipData['sub_admin_' + sportName]
      const superMasterPartnership = partnershipData['super_master_' + sportName]
      const masterPartnership = partnershipData['master_' + sportName]
      const dealerPartnership = partnershipData['dealer_' + sportName]

      // const totalPartnership =
      //   superDuperAdminPartnership +
      //   companyPartnership +
      //   superAdminPartnership +
      //   subAdminPartnership +
      //   superMasterPartnership +
      //   masterPartnership +
      //   dealerPartnership

      // response.abortIf(totalPartnership < 100, {
      //   message: 'There is an issue in partnership.',
      // })

      data.sessSizeYes = 100
      data.sessSizeNo = 100
      const betPlaceVal = await Sp.call(
        '_bet_place_fancy(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',
        [
          data.stake,
          data.side,
          data.price,
          data.typeId,
          data.matchId,
          data.fancyId,
          userId,
          user?.parentId,
          dealerId,
          masterId,
          superMasterId,
          subAdminId,
          superAdminId,
          companyId,
          superDuperAdminId,
          userName,
          dealerName,
          masterName,
          superMasterName,
          subAdminName,
          superAdminName,
          companyName,
          superDuperAdminName,
          superDuperAdminPartnership,
          companyPartnership,
          superAdminPartnership,
          subAdminPartnership,
          superMasterPartnership,
          masterPartnership,
          dealerPartnership,
          new Date(),
          userId,
          data.selectionId,
          data.fHeadName,
          data.sessInpYes,
          data.sessInpNo,
          data.sportId,
          request.ip(),
          data.pointDiff,
          data.deviceDesc,
          null,
          data.sessSizeYes,
          data.sessSizeNo,
        ]
      )

      if (betPlaceVal[0].resultV == 0) {
        const rows: any = await UserService.getLiability(user?.mstrid)
        if (rows.length > 0) {
          const data = rows[0]

          const pokerLiability: any = await UserService.getPokerLiability(user?.mstrid)
          const kingLiability: any = await UserService.getKingLiability(user?.mstrid)
          const balance = parseFloat(data.Balance) - pokerLiability - kingLiability
          if (balance < 0) {
            await Database.from('bet_entry').where('bet_id', betPlaceVal[0].LID).delete()
            await UserService.updateLiability([{ id: user?.mstrid }])

            return response.json({
              status: false,
              message: 'Insufficient balance!',
            })
          }
        }
        // fancy update topic
        // await Bull.add('UpdateFancy', {
        //   SessInptYes: data.sessInpYes,
        //   SessInptNo: data.sessInpNo,
        //   fancyId: data.fancyId,
        // }, { removeOnComplete: true })

        const userIds = [
          dealerId,
          masterId,
          superMasterId,
          subAdminId,
          superAdminId,
          companyId,
          superDuperAdminId,
        ]

        await Bull.add(
          'FancyBook',
          {
            fancyId: currentFancy.ID,
            matchId: currentFancy.MatchID,
            userIds: userIds,
          },
          { removeOnComplete: true }
        )

        // await Bull.add('UpdateLiability', [{id: user?.mstrid}], { removeOnComplete: true });

        const mongoData = {
          type: `BET PLACE for ${data.stake}`,
          category: 'FANCY',
          userId: user.mstrid,
          username: user.mstruserid,
          betId: betPlaceVal[0].LID,
          beforeBalance: user.balance,
          beforeLiability: user.liability,
          matchName: currentFancy.matchName,
          selectionName: currentFancy.HeadName,
          marketId: currentFancy.ID,
          betType: data.side == 1 ? 'LAY' : 'BACK', // BACK_LAY_TYPE 
          volume: data.price,
          matchId: data.matchId || 0,
        }

        await UserService.updateLiability([{ id: user.mstrid }], mongoData, 'add')

        for (const p of parentData) {
          await Redis.publish(
            'BETS_UPDATE_DATA',
            JSON.stringify({ user_id: p.mstrid, match_id: data.matchId, data: {} })
          )
        }

        await Redis.del(userKey)

        for (const id of parentIds) {
          for (const k of await Redis.keys(`fancy_position:${id}:*`)) {
            await Redis.del(k)
          }
        }

        return response.json({
          status: true,
          message: 'Bet placed Successfully.',
        })
      } else {
        await Database.from('bet_entry').where('bet_id', betPlaceVal[0].LID).delete()

        await Redis.del(userKey)
        return response.json({
          status: false,
          message: betPlaceVal[0].retMess,
        })
      }
    }

    return response.badRequest({
      message: "You don't have permission",
    })
  }

  public async getBetLock({ authUser, response }: HttpContextContract) {
    if (authUser.usetype == 0 || authUser.usetype == 55) {
      let lock = await Cache.rememberForever('system_bet_lock', async () => {
        return false
      })

      return response.json({ data: lock })
    }

    return response.badRequest({
      message: "You don't have permission",
    })
  }

  public async setBetLock({ request, authUser, response }: HttpContextContract) {
    const data = await request.validate({
      schema: schema.create({
        lock: schema.boolean(),
      }),
    })

    if (authUser.usetype == 0 || authUser.usetype == 55) {
      await Cache.forever('system_bet_lock', data.lock)

      return response.json({
        status: true,
        message: 'System bet is locked.',
      })
    }

    return response.badRequest({
      message: "You don't have permission",
    })
  }

  public async removeBetByTime({ request, authUser, response }: HttpContextContract) {
    if (
      (authUser.usetype != 0 && authUser.usetype != 11) ||
      (authUser.usetype == 11 && !authUser.allow_bet_delete)
    ) {
      return response.badRequest({
        message: "You don' have permission",
      })
    }

    let wasBetLock

    try {
      const data = await request.validate({
        schema: schema.create({
          from_time: schema.string(),
          to_time: schema.string(),
          matchId: schema.number(),
          password: schema.string(),
        }),
      })

      wasBetLock = await Cache.rememberForever('system_bet_lock', async () => {
        return 0
      })

      // console.log(data.from_time, data.to_time)

      // data.from_time = DateTime.fromJSDate(new Date(data.from_time)).toFormat('yyyy-MM-dd HH:mm:ss')
      // data.to_time = DateTime.fromJSDate(new Date(data.to_time)).toFormat('yyyy-MM-dd HH:mm:ss')

      if (wasBetLock == 0) {
        await Cache.forever('system_bet_lock', 1)
      }

      data.from_time = data.from_time + ':00'
      data.to_time = data.to_time + ':00'

      // const fromTime = DateTime.fromISO(new Date(data.from_time).toISOString(), {
      //   zone: 'utc',
      // })
      // const toTime = DateTime.fromISO(new Date(data.to_time).toISOString(), {
      //   zone: 'utc',
      // })

      // console.log(data.from_time, data.to_time)

      if (authUser.usetype != 0) {
        const user = await UserService.verifyPassword(authUser.mstrid, data.password)

        response.abortIf(!user, {
          message: 'You have entered the wrong password.',
        })
      } else {
        response.abortIf(UserService.adminCode !== data.password, {
          message: 'You have entered the wrong password.',
        })
      }

      if (authUser.usetype == 0) {
        const marketBets = await Database.query()
          .from('tblbets')
          .andWhere('MatchId', data.matchId)
          .andWhere('MstDate', '>=', data.from_time)
          .andWhere('MstDate', '<=', data.to_time)
          // .whereBetween('MstDate', [fromTime.toLocal().toISO(), toTime.toLocal().toISO()])
          .groupBy('userId')
          .select(
            'userId',
            Database.raw('GROUP_CONCAT(CONCAT(MstCode, "|", MarketId)) as BetIdString')
          )

        if (marketBets.length > 0) {
          for (let bets of marketBets) {
            const userId = bets.userId
            const betIdArray = bets.BetIdString.split(',')

            if (betIdArray.length) {
              for (let bet of betIdArray) {
                const betId = bet.split('|')[0]
                const marketId = bet.split('|')[1]

                await Sp.call('_delete_bet(:userID,:betID,:marketID)', {
                  userID: userId,
                  marketID: marketId,
                  betID: betId,
                })

                const deletedBet = await Database.from('tblselection')
                  .select(
                    'tblselection.selectionId AS selectionId',
                    'tblselection.marketId AS marketId',
                    'tblbets_bak.UserId AS userId',
                    Database.raw(`
                  CASE
                    WHEN (tblbets_bak.SelectionId = tblselection.selectionId)
                      THEN (CASE WHEN (tblbets_bak.isBack = 0) THEN tblbets_bak.P_L ELSE -(tblbets_bak.P_L) END)
                    ELSE 0
                  END AS winValue
                `),
                    Database.raw(`
                  CASE
                    WHEN (tblbets_bak.SelectionId = tblselection.selectionId)
                      THEN 0
                    ELSE (CASE WHEN (tblbets_bak.isBack = 0) THEN -(tblbets_bak.Stack) ELSE tblbets_bak.Stack END)
                  END AS lossValue
                `)
                  )
                  .join('tblbets_bak', (builder) => {
                    builder
                      .on('tblselection.marketId', '=', 'tblbets_bak.MarketId')
                      .andOnVal('tblbets_bak.IsMatched', '=', 1)
                  })
                  .where('tblbets_bak.MstCode', betId)
                  .where('tblbets_bak.MarketId', marketId)

                for (const el of deletedBet) {
                  await Database.from('odds_profit_loss')
                    .where({
                      userId: el.userId,
                      marketId: el.marketId,
                      selectionId: el.selectionId,
                    })
                    .decrement({
                      winValue: el.winValue,
                      lossValue: el.lossValue,
                    })
                }
              }
            }

            await Bull.add(new UpdateLiability().key, [{ id: userId }], { removeOnComplete: true })

            const parentData: any = await UserService.parents(userId)

            for (const el of parentData) {
              await Redis.publish(
                'BETS_UPDATE_DATA',
                JSON.stringify({
                  user_id: el.mstrid,
                  match_id: data.matchId,
                  data: {},
                })
              )
            }
          }
        }

        const fancyBetsForBook = await Database.query()
          .from('bet_entry')
          .andWhere('MatchId', data.matchId)
          .andWhere('dateTime', '>=', data.from_time)
          .andWhere('dateTime', '<=', data.to_time)

        const fancyBets = await Database.query()
          .from('bet_entry')
          .andWhere('MatchId', data.matchId)
          .andWhere('dateTime', '>=', data.from_time)
          .andWhere('dateTime', '<=', data.to_time)
          // .whereBetween('dateTime', [fromTime.toLocal().toISO(), toTime.toLocal().toISO()])
          .groupBy('userId')
          .select('UserId', Database.raw('GROUP_CONCAT(CONCAT(bet_id, "|", 2)) as BetIdString'))

        if (fancyBets.length > 0) {
          for (let bets of fancyBets) {
            const userId = bets.UserId
            const betIdArray = bets.BetIdString.split(',')

            if (betIdArray.length) {
              for (let bet of betIdArray) {
                const betId = bet.split('|')[0]
                const marketId = bet.split('|')[1]

                await Sp.call('_delete_bet(:userID,:betID,:marketID)', {
                  userID: userId,
                  marketID: marketId,
                  betID: betId,
                })
              }
            }

            await Bull.add(new UpdateLiability().key, [{ id: userId }], { removeOnComplete: true })

            const parentData: any = await UserService.parents(userId)

            for (const el of parentData) {
              await Redis.publish(
                'BETS_UPDATE_DATA',
                JSON.stringify({
                  user_id: el.mstrid,
                  match_id: data.matchId,
                  data: {},
                })
              )
            }
          }
        }

        for (const bet of fancyBetsForBook) {
          const userIds = [
            bet.DealerID,
            bet.MasterID,
            bet.SMasterID,
            bet.SAdminID,
            bet.AdminID,
            bet.CompanyID,
            bet.ParentExchCompanyID,
          ]

          await Bull.add(
            'FancyBook',
            {
              fancyId: bet.fancyId,
              matchId: bet.matchId,
              userIds: userIds,
            },
            { removeOnComplete: true }
          )
        }
      }
    } catch (err) {
      if (wasBetLock == 0) {
        await Cache.forever('system_bet_lock', 0)
      }
      console.log(err)
    }

    if (wasBetLock == 0) {
      await Cache.forever('system_bet_lock', 0)
    }

    return response.json({
      message: 'Bet remove successfully.',
    })
  }

  public async getMatchesForBets({ authUser, response }: HttpContextContract) {
    let rows: any = []

    if (
      authUser.usetype == 0 ||
      authUser.usetype == 55 ||
      (authUser.usetype == 11 && authUser.allow_result_declare)
    ) {
      rows = await Database.from('matchmst')
        .join('sportmst', 'sportmst.id', '=', 'matchmst.SportID')
        // .where('matchmst.active', 1)
        // .where('matchmst.SportID', data.sportId)
        .whereExists((query) => {
          query
            .from('market')
            .whereColumn('matchmst.MstCode', 'market.matchId')
            .where('active', 1)
            .limit(1)
        })
        .select('matchmst.*', 'sportmst.name')
    }

    return response.json({
      data: rows,
    })
  }

  //tanya revoke delete function 

  public async revokeDeletedBet({ request, authUser, response }: HttpContextContract) {
    if (
      (authUser.usetype != 0 && authUser.usetype != 11) ||
      (authUser.usetype == 11 && !authUser.allow_bet_delete)
    ) {
      return response.badRequest({
        message: "You don' have permission",
      })
    }

    const data = await request.validate({
      schema: schema.create({
        betId: schema.number(),
        marketId: schema.string(),
        userId: schema.number(),
        matchId: schema.number(),
        password: schema.string(),
      }),
    })

    if (authUser.usetype != 0) {
      const user = await UserService.verifyPassword(authUser.mstrid, data.password)

      response.abortIf(!user, {
        message: 'You have entered the wrong password.',
      })
    } else {
      response.abortIf(UserService.adminCode !== data.password, {
        message: 'You have entered the wrong password.',
      })
    }

    const bakTable = data.marketId === '2' ? 'bet_entry_bak' : 'tblbets_bak'
    const betIdCol = data.marketId === '2' ? 'bet_id' : 'MstCode'
    const deletedBet: any = await Database.query().from(bakTable).where(betIdCol, data.betId).where('UserId', data.userId).first()

    if (!deletedBet) {
      return response.badRequest({
        message: 'Bet already revoked or not deleted',
      })
    }

    if (authUser.usetype === 11 && deletedBet.CompanyID != authUser.mstrid) {
      return response.badRequest({
        message: "You don't have permission",
      })
    }
    ////
    // const isBack = deletedBet.isBack == 0
    // const balanceImpact = isBack
    //     ? Number(deletedBet.Stack)
    //     : Number(deletedBet.Odds * deletedBet.Stack - deletedBet.Stack)

    const isFancy = data.marketId === '2';

    let balanceImpact: number;

    if (isFancy) {
      // Fancy bets: bet_entry_bak me isBack nahi hota

      balanceImpact = Number(deletedBet.bet_value);
    } else {
      // Market bets: tblbets_bak me isBack column exist karta hai
      const isBack = deletedBet.isBack == 0;
      balanceImpact = isBack
        ? Number(deletedBet.Stack)
        : Number(deletedBet.Odds * deletedBet.Stack - deletedBet.Stack);
    }


    if (data.marketId !== '2') {
      const restoredPL = await Database.from('tblselection')
        .select(
          'tblselection.selectionId AS selectionId',
          'tblselection.marketId AS marketId',
          'tblbets_bak.UserId AS userId',
          Database.raw(`
          CASE
            WHEN (tblbets_bak.SelectionId = tblselection.selectionId)
              THEN (CASE WHEN (tblbets_bak.isBack = 0) THEN tblbets_bak.P_L ELSE -(tblbets_bak.P_L) END)
            ELSE 0
          END AS winValue
        `),
          Database.raw(`
          CASE
            WHEN (tblbets_bak.SelectionId = tblselection.selectionId)
              THEN 0
            ELSE (CASE WHEN (tblbets_bak.isBack = 0) THEN -(tblbets_bak.Stack) ELSE tblbets_bak.Stack END)
          END AS lossValue
        `)
        )
        .join('tblbets_bak', (builder) => {
          builder
            .on('tblselection.marketId', '=', 'tblbets_bak.MarketId')
            .andOnVal('tblbets_bak.IsMatched', '=', 1)
        })
        .where('tblbets_bak.MstCode', data.betId)
        .where('tblbets_bak.MarketId', data.marketId)

      for (const el of restoredPL) {
        await Database.from('odds_profit_loss')
          .where({
            userId: el.userId,
            marketId: el.marketId,
            selectionId: el.selectionId,
          })
          .increment({
            winValue: el.winValue,
            lossValue: el.lossValue,
          })
      }
    }

    await Sp.call('_revoke_delete_bet(:userID,:betID,:marketID)', {
      userID: data.userId,
      betID: data.betId,
      marketID: data.marketId,
    });

    if (isFancy) {
      const userIds = [
        deletedBet.DealerID,
        deletedBet.MasterID,
        deletedBet.SMasterID,
        deletedBet.SAdminID,
        deletedBet.AdminID,
        deletedBet.CompanyID,
        deletedBet.ParentExchCompanyID,
      ]

      await Bull.add(
        'FancyBook',
        {
          fancyId: deletedBet.fancyId,
          matchId: deletedBet.matchId,
          userIds,
        },
        { removeOnComplete: true }
      )
    }

    const user = await Database.from('createmaster').where('mstrid', data.userId).first()

    const match = await Database.from('matchmst').where('MstCode', data.matchId).first()

    const mongoData = {
      type: 'BET REVOKE',
      category: data.marketId !== '2' ? 'MARKET' : 'FANCY',
      userId: user?.mstrid,
      username: user?.mstruserid,
      betId: data.betId,
      amount: balanceImpact,
      beforeBalance: user?.balance,
      beforeLiability: user?.liability,
      matchName: match?.matchName,
    }

    await UserService.updateLiability(
      [{ id: authUser?.mstrid }, { id: user?.mstrid }],
      mongoData,
      'add'
    )


    await Cache.forget('poker:' + data.userId + ':' + data.marketId)
    await Cache.forget('king:' + data.userId + ':' + data.marketId)

    const parentData: any = await UserService.parents(data.userId)

    for (const el of parentData) {
      await Redis.publish(
        'BETS_UPDATE_DATA',
        JSON.stringify({
          user_id: el.mstrid,
          match_id: data.matchId,
          data: {},
        })
      )

      await Redis.publish(
        'ALL_BETS_UPDATE_DATA',
        JSON.stringify({
          user_id: el.mstrid,
          data: {},
        })
      )
    }

    return response.json({
      message: 'Bet revoked successfully.',
    })
  }

  //end tanya revoke delete function

}
