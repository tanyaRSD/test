import Cache from '@ioc:Adonis/Addons/Cache'
import Drive from '@ioc:Adonis/Core/Drive'
import Env from '@ioc:Adonis/Core/Env'
import { HttpContextContract } from '@ioc:Adonis/Core/HttpContext'
import { schema } from '@ioc:Adonis/Core/Validator'
import Database from '@ioc:Adonis/Lucid/Database'

export default class BannerController {
  public async index({ authUser, response }: HttpContextContract) {
    let data: any = []
    if (authUser.usetype == 11) {
      data = await Database.from('banners').where('domain', authUser.domain)
    }

    return response.json(data)
  }
  public async store({ request, response, authUser }: HttpContextContract) {
    if (authUser.usetype == 11) {
      const data = await request.validate({
        schema: schema.create({
          image: schema.file({
            size: '1mb',
            extnames: ['jpg', 'png', 'jpeg'],
          }),
        }),
      })

      await data.image.moveToDisk('banners', {}, 's3')
      // @ts-ignore
      const imgUrl: any = data.image.filePath

      await Database.table('banners').insert({
        domain: authUser.domain,
        image: imgUrl,
      })

      await Cache.forget('banner:' + authUser.domain)

      return response.json({
        message: 'Banner saved.',
      })
    }
    return response.badRequest({
      message: "You don't have permission",
    })
  }

  public async update({ request, response, authUser, params }: HttpContextContract) {
    if (authUser.usetype == 11) {
      const data = await request.validate({
        schema: schema.create({
          image: schema.file({
            size: '1mb',
            extnames: ['jpg', 'png', 'jpeg'],
          }),
        }),
      })

      const banner = await Database.from('banners')
        .where('id', params.id)
        .where('domain', authUser.domain)
        .firstOrFail()

      if (data.image) {
        await data.image.moveToDisk('banners', {}, 's3')
        // @ts-ignore
        const imgUrl: any = data.image.filePath

        if (banner.image) {
          const host = Env.get('S3_ENDPOINT')
          const bucket = Env.get('S3_BUCKET')
          await Drive.use('s3').delete(banner.image.replace(host + '/' + bucket + '/', ''))
        }

        await Database.from('banners').where('id', banner.id).update('image', imgUrl)
      }

      await Cache.forget('banner:' + banner.domain)

      return response.json({
        message: 'Banner updated.',
      })
    }

    return response.badRequest({
      message: "You don't have permission",
    })
  }

  public async delete({ response, authUser, params }: HttpContextContract) {
    if (authUser.usetype == 11) {
      const banner = await Database.from('banners')
        .where('id', params.id)
        .where('domain', authUser.domain)
        .firstOrFail()

      await Database.from('banners')
        .where('id', params.id)
        .where('domain', authUser.domain)
        .delete()

      const host = Env.get('S3_ENDPOINT')
      const bucket = Env.get('S3_BUCKET')
      await Drive.use('s3').delete(banner.image.replace(host + '/' + bucket + '/', ''))

      await Cache.forget('banner:' + banner.domain)

      return response.json({
        message: 'Banner deleted.',
      })
    }
    return response.badRequest({
      message: "You don't have permission",
    })
  }
}
