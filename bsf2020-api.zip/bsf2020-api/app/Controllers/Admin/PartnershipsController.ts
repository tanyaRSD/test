import Cache from '@ioc:Adonis/Addons/Cache'
import { HttpContextContract } from '@ioc:Adonis/Core/HttpContext'
import { schema } from '@ioc:Adonis/Core/Validator'
import Database from '@ioc:Adonis/Lucid/Database'
import Parent from 'App/Services/Parent'

export default class PartnershipsController {
  public async getPartnershipData({ request, authUser, response }: HttpContextContract) {
    const data = await request.validate({
      schema: schema.create({
        userid: schema.number(),
      }),
    })

    if (!(await Parent.validate(authUser, data.userid))) {
      return response.badRequest({
        message: 'Invalid request.',
      })
    }

    const Result: any = await Cache.rememberForever('partnership:' + data.userid, async () => {
      return await Database.from('tblpartner').where('UserID', data.userid).firstOrFail()
    })

    response.json({
      data: Result,
    })
  }
}
