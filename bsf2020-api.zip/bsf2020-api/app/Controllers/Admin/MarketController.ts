import Redis from '@ioc:Adonis/Addons/Redis'
import { HttpContextContract } from '@ioc:Adonis/Core/HttpContext'
import Logger from '@ioc:Adonis/Core/Logger'
import { rules, schema } from '@ioc:Adonis/Core/Validator'
import Database from '@ioc:Adonis/Lucid/Database'
import MarketService from 'App/Services/MarketService'
import Parent from 'App/Services/Parent'
import Settings from 'App/Services/Settings'
import ThirdParty from 'App/Services/ThirdParty'
import UserService from 'App/Services/UserService'
import axios from 'axios'
import { DateTime } from 'luxon'

export default class MarketController {
  public async index({ request, authUser, response }: HttpContextContract) {
    if ((authUser.usetype == 0 || authUser.usetype == 55) && request.input('type') == 'manage') {
      if (authUser.usetype == 55) {
        authUser = await UserService.checkPersmission(authUser, 'Active Matches and Manage Series')

        if (!authUser) {
          return response.badRequest({
            message: 'Invalid request.',
          })
        }
      }
      try {
        const matchId = request.input('matchId')
        const sportId = request.input('sportId')
        const category = request.input('category', 'market')

        const rows = await axios.get(
          ['7', '4339'].indexOf(sportId.toString()) > -1
            ? ThirdParty.horseMarketApi + sportId
            : ThirdParty.marketListApiUrl + matchId
        )

        let markets: any
        let activeMarkets: any = []
        let manualMarkets: any = []

        if (category == 'line') {
          markets = await Database.from('matchfancy')
            .where('MatchID', matchId)
            .where('is_indian_fancy', 0)
            .select('market_id as Id')

          let publishedMarkets = await Redis.smembers('ACTIVE_LINE_MARKETS')
          publishedMarkets = publishedMarkets.map((el: any) => JSON.parse(el))
          for (let market of markets) {
            const isPublished = publishedMarkets.find((el: any) => el.marketId == market.Id)
            activeMarkets.push({ Id: market.Id, isPublished: !!isPublished })
          }
        } else {
          markets = await Database.from('market').where('matchId', matchId).select('Id')

          manualMarkets = await Redis.smembers('MANUAL_MARKET_LIST')

          manualMarkets = manualMarkets
            .map((el: any) => JSON.parse(el))
            .filter((el) => el.match_id == matchId)

          let publishedMarkets = await Redis.smembers('ACTIVE_MARKETS')
          publishedMarkets = publishedMarkets.map((el: any) => JSON.parse(el))
          for (let market of markets) {
            const isPublished = publishedMarkets.find((el: any) => el.marketId == market.Id)
            activeMarkets.push({ Id: market.Id, isPublished: !!isPublished })
          }
        }

        let data: any = []
        if (Array.isArray(rows.data)) {
          data = rows.data
        }

        return response.json({
          data,
          manualMarkets,
          activeMarkets: activeMarkets,
        })
      } catch (e) {
        console.log(e)
      }
    } else {
    }
  }

  public async store({ request, authUser, response }: HttpContextContract) {
    const data = await request.validate({
      schema: schema.create({
        marketId: schema.string(),
        marketName: schema.string(),
        match_id: schema.string(),
        series_id: schema.string(),
        sports_id: schema.string(),
        totalMatched: schema.number(),
      }),
    })

    if (authUser.usetype == 0 || authUser.usetype == 55) {
      if (authUser.usetype == 55) {
        authUser = await UserService.checkPersmission(authUser, 'Active Matches and Manage Series')

        if (!authUser) {
          return response.badRequest({
            message: 'Invalid request.',
          })
        }
      }
      const match = await Database.query().from('matchmst').where('MstCode', data.match_id).first()
      if (match) {
        if (match.active == 0) {
          return response.badRequest({
            message: 'Match is not active.',
          })
        }
      } else {
        if (!this.addMatchIfNot(data)) {
          return response.badRequest({
            message: 'Match is not found.',
          })
        }
      }

      const marketsData = await axios.get(ThirdParty.marketRunnersApiUrl + data.marketId)
      if (marketsData.data) {
        if (Array.isArray(marketsData.data)) {
          const market = marketsData.data.find((el: any) => el.marketId == data.marketId)
          if (market) {
            response.abortIf(market.runners.length == 0, {
              message: 'There is no selection available.',
            })

            if (market.marketName.trim().endsWith('Line')) {
              const runner = market.runners[0]
              const fancy = await Database.query()
                .from('matchfancy')
                .where('MatchID', data.match_id)
                .where('ind_fancy_selection_id', runner.selectionId)
                .where('is_indian_fancy', 0)
                .where('market_id', market.marketId)
                .first()

              response.abortIf(fancy, {
                message: 'Fancy already activated.',
              })
              const settings = await Settings.all()

              const sportId = '4'
              const defaultLimits = Settings.defaultSportLimit
              const limit = defaultLimits.find(
                (el: any) => el.type == 'fancy' && el.sport_id == sportId
              )

              const maxStake = limit.max_stake
              const minStake = limit.min_stake
              const maxSessionBetLiaibility = settings.fancy_max_session_bet_liability
              const maxSessionLiability = settings.fancy_max_session_liability

              await Database.insertQuery()
                .table('matchfancy')
                .insert({
                  market_id: data.marketId,
                  MatchID: data.match_id,
                  super_admin_fancy_id: runner.selectionId,
                  HeadName: market.marketName,
                  TypeID: 2,
                  Remarks: 'INDIAN_LINE_FANCY',
                  date: new Date(),
                  time: DateTime.now().toLocaleString(DateTime.TIME_24_WITH_SECONDS),
                  SessInptYes: 0,
                  SessInptNo: 0,
                  fancyRange: 0,
                  PlayerId: 0,
                  active: 1,
                  SprtId: sportId,
                  rateDiff: 1,
                  pointDiff: 10,
                  MinStake: minStake,
                  MaxStake: maxStake,
                  NoValume: 100,
                  YesValume: 100,
                  DisplayMsg: 'Close Fancy',
                  is_indian_fancy: 0,
                  ind_fancy_selection_id: runner.selectionId,
                  fancy_mode: 'A',
                  max_session_bet_liability: maxSessionBetLiaibility,
                  max_session_liability: maxSessionLiability,
                })

              const f = await Database.query()
                .from('matchfancy')
                .leftJoin('matchmst', 'matchfancy.MatchID', '=', 'matchmst.MstCode')
                .where('matchfancy.market_id', market.marketId)
                .where('matchfancy.ind_fancy_selection_id', runner.selectionId)
                .where('matchfancy.MatchID', data.match_id)
                .where('matchfancy.is_indian_fancy', 0)
                .select('matchfancy.*')
                .first()

              if (f) {
                await Redis.publish('UPDATE_FANCY', JSON.stringify({ matchId: data.match_id }))
              }

              return response.json({
                message: 'Line fancy activated.',
              })
            } else {
              // @ts-ignore
              data.runners = market.runners
              // @ts-ignore
              data.market_runner_json = JSON.stringify(this.buildRunnerJson(market.runners))
              await this.createMarket({ ...data, startTime: market.marketStartTime })

              return response.json({
                message: 'Market added.',
              })
            }
          }
        }
      }

      return response.badRequest({
        message: 'Market not added.',
      })
    }

    return response.badRequest({
      message: "You don' have permission",
    })
  }

  public async directActivate({ request, authUser, response }: HttpContextContract) {
    if (authUser.usetype == 0 || authUser.usetype == 55) {
      const primaryAPI = await Redis.get('PRIMARY_API') || '1';
      if (request.method() == 'GET') {
        const v = await request.validate({
          schema: schema.create({
            sportId: schema.string(),
          }),
        })

        if (v.sportId == '77') {
          v.sportId = '7'
        }

        if (authUser.usetype == 55) {
          authUser = await UserService.checkPersmission(
            authUser,
            'Active Matches and Manage Series'
          )

          if (!authUser) {
            return response.badRequest({
              message: 'Invalid request.',
            })
          }
        }

        let data: any = []

        try {
          const rows: any = await axios.get(primaryAPI === '2' ? ThirdParty.directActiveApiUrl2 : primaryAPI === '3' ? ThirdParty.directActiveApiUrl3 : ThirdParty.directActiveApiUrl)

          // New API format: data[sportId] = array of events with eid, na, le, li, st, ip, odds[], bookmaker[], toss[]
          const sportEvents = rows.data?.data?.[v.sportId] || []
          data = [
            {
              sportId: v.sportId,
              eventList: sportEvents.map((event: any) => {
                const matchOdds = (event.odds || []).find((o: any) => o.ty === 'match-odd')
                const runners = matchOdds?.r?.map((r: any) => ({
                  secId: r.rid,
                  runner: r.na,
                })) || []

                return {
                  eventData: {
                    eventId: event.eid,
                    name: event.na,
                    time: new Date(event.st).getTime() / 1000,
                    league: event.le || 'League',
                    compId: event.li || event.eid || 99999,
                    channelId: '',
                    sportId: v.sportId,
                  },
                  marketList: {
                    match_odd: {
                      marketId: matchOdds?.mid || '',
                      runners: JSON.stringify(runners),
                    },
                  },
                  ip: event.ip,
                  gm: event.go,
                  bm: event.bookmaker?.length > 0 ? 1 : 0,
                }
              }),
            },
          ]

          // Old API format (commented out):
          // const rows: any = await axios.get(ThirdParty.directActiveApiUrl + v.sportId)
          // if (rows.data && !rows.data.gameList) {
          //   const sportEvents = rows.data.data || rows.data[v.sportId] || []
          //   data = [{
          //     sportId: v.sportId,
          //     eventList: sportEvents.map((event: any) => ({
          //       eventData: {
          //         eventId: event.matchId || event.eventid,
          //         name: event.matchName || event.matchname,
          //         time: new Date(event.openDate || event.startdate).getTime() / 1000,
          //         league: event.seriesname || (event.matchName || event.matchname)?.split(' v ')?.[0] || 'League',
          //         compId: event.li || event.seriesid || event.matchId || event.eventid || 99999,
          //         channelId: '',
          //         sportId: v.sportId,
          //       },
          //       marketList: {
          //         match_odd: {
          //           marketId: event.marketId || event.marketid,
          //           runners: JSON.stringify([
          //             { secId: (event.matchId || event.eventid) * 10 + 1, runner: (event.matchName || event.matchname)?.split(' v ')?.[0] || 'Team 1' },
          //             { secId: (event.matchId || event.eventid) * 10 + 2, runner: (event.matchName || event.matchname)?.split(' v ')?.[1] || 'Team 2' },
          //           ]),
          //         },
          //       },
          //       ip: event.inPlay != null ? event.inPlay : event.ip,
          //       gm: event.GM != null ? event.GM : event.gm,
          //       bm: event.bm,
          //     })),
          //   }]
          // } else {
          //   data = rows.data.gameList
          // }
        } finally {
        }

        let activeMarkets: any = []
        let publishedMarkets = await Redis.smembers('ACTIVE_MARKETS')
        publishedMarkets = publishedMarkets.map((el: any) => JSON.parse(el))
        let markets: any

        if (['11', '77', '6'].indexOf(v.sportId) > -1) {
          markets = await Database.from('matchmst')
            .where('SportID', v.sportId)
            .where('active', 1)
            .select('MstCode AS Id', 'has_fancy')
        } else {
          markets = await Database.from('market')
            .join('matchmst', 'market.matchId', '=', 'matchmst.MstCode')
            .where('market.sportsId', v.sportId)
            .where('market.active', 1)
            .select('market.Id', 'matchmst.has_fancy', 'market.Name', 'market.matchId')
        }

        if (v.sportId != '11') {
          for (let market of markets) {
            const isPublished = publishedMarkets.find((el: any) => el.marketId == market.Id)
            activeMarkets.push({
              Id: market.Id,
              isPublished: !!isPublished,
              has_fancy: market.has_fancy,
              name: market.Name || '',
              matchId: market.matchId,
            })
          }
        } else {
          for (let market of markets) {
            activeMarkets.push({ Id: market.Id })
          }
        }

        return response.json({
          data: data,
          activeMarkets,
        })
      } else {
        const v = await request.validate({
          schema: schema.create({
            sportId: schema.string(),
            marketId: schema.string(),
            is_auto: schema.boolean.optional(),
          }),
        })

        if (v.sportId == '77') {
          v.sportId = '7'
        }

        if (authUser.usetype == 55) {
          authUser = await UserService.checkPersmission(
            authUser,
            'Active Matches and Manage Series'
          )

          if (!authUser) {
            return response.badRequest({
              message: 'Invalid request.',
            })
          }
        }

        try {
          const rows: any = await axios.get(primaryAPI === '2' ? ThirdParty.directActiveApiUrl2 : primaryAPI === '3' ? ThirdParty.directActiveApiUrl3 : ThirdParty.directActiveApiUrl)

          if (rows.data) {
            // New API format: data[sportId] = array of events with eid, na, le, odds[], etc.
            let sport: any
            const sportEvents = rows.data?.data?.[v.sportId] || []
            const eventList: any[] = []
            for (const event of sportEvents) {
              const matchOdds = (event.odds || []).find((o: any) => o.ty === 'match-odd')
              const runners = matchOdds?.r?.map((r: any) => ({
                secId: r.rid,
                runner: r.na,
              })) || []

              eventList.push({
                eventData: {
                  eventId: event.eid,
                  name: event.na,
                  time: new Date(event.st).getTime() / 1000,
                  league: event.le || 'League',
                  compId: event.li || event.eid || 99999,
                  channelId: '',
                  sportId: v.sportId,
                },
                marketList: {
                  match_odd: {
                    marketId: matchOdds?.mid || '',
                    runners: JSON.stringify(runners),
                  },
                },
                ip: event.ip,
                gm: event.go,
                bm: event.bookmaker?.length > 0 ? 1 : 0,
              })
            }

            sport = {
              sportId: v.sportId,
              eventList,
            }

            // Old API format (commented out):
            // const rows: any = await axios.get(ThirdParty.directActiveApiUrl + v.sportId)
            // if (!rows.data.gameList) {
            //   const sportEvents = rows.data.data || rows.data[v.sportId] || []
            //   const eventList: any[] = []
            //   for (const event of sportEvents) {
            //     const eventId = event.matchId || event.eventid
            //     const eventName = event.matchName || event.matchname
            //     const eventMarketId = event.marketId || event.marketid
            //     let runners: any[] = []
            //     try {
            //       const marketListRes: any = await axios.get(`http://20.198.8.85:8081/api/fancy/v1/marketLiist/${eventId}`)
            //       const marketData = marketListRes.data?.[eventId]
            //       if (marketData?.Odds?.length > 0) {
            //         const matchOdds = marketData.Odds.find((o: any) => o.mid === eventMarketId)
            //         if (matchOdds?.r?.length > 0) {
            //           runners = matchOdds.r.map((r: any) => ({ secId: r.rid, runner: r.na }))
            //         }
            //       }
            //     } catch (e) {
            //       console.log('Failed to fetch marketLiist for event:', eventId)
            //     }
            //     if (runners.length === 0) {
            //       runners = [
            //         { secId: eventId * 10 + 1, runner: eventName?.split(' v ')?.[0] || 'Team 1' },
            //         { secId: eventId * 10 + 2, runner: eventName?.split(' v ')?.[1] || 'Team 2' },
            //       ]
            //     }
            //     eventList.push({
            //       eventData: { eventId, name: eventName, time: new Date(event.openDate || event.startdate).getTime() / 1000, league: event.seriesname || eventName?.split(' v ')?.[0] || 'League', compId: event.li || event.seriesid || 99999, channelId: '', sportId: v.sportId },
            //       marketList: { match_odd: { marketId: eventMarketId, runners: JSON.stringify(runners) } },
            //       ip: event.inPlay != null ? event.inPlay : event.ip, gm: event.GM != null ? event.GM : event.gm, bm: event.bm,
            //     })
            //   }
            //   sport = { sportId: v.sportId, eventList }
            // } else {
            //   sport = rows.data.gameList.find((el: any) => el.sportId == v.sportId)
            // }
            const isVirtualCasino = ['11', '6', '77'].indexOf(v.sportId) > -1

            if (!isVirtualCasino && sport) {
              for (const event of sport.eventList) {
                const m =
                  v.sportId != '11' ? event.marketList['match_odd'] : event.marketList['casino']

                if (m && ['1', '2', '4'].indexOf(v.sportId) > -1 && m.marketId == v.marketId) {
                  const market = {
                    marketId: m.marketId,
                    marketName: 'Match Odds',
                    totalMatched: 0,
                    runners: JSON.parse(m.runners).map((el: any) => {
                      return {
                        selectionId: el.secId,
                        runnerName: el.runner,
                      }
                    }),
                  }

                  const eventData = event.eventData

                  const sport = {
                    id: v.sportId,
                  }

                  let series = {
                    id: eventData.compId,
                    name: eventData.league,
                  }

                  if (!eventData.compId || eventData.compId == '') {
                    const marketRows = await axios.get(
                      ThirdParty.marketListApiUrl + eventData.eventId
                    )
                    let marketsList: any = []
                    if (Array.isArray(marketRows.data)) {
                      marketsList = marketRows.data
                      if (marketsList.length > 0) {
                        const firstMarket = marketsList[0]
                        series.id = firstMarket.competition.id
                      } else {
                        return response.badRequest({
                          message: 'Match not found for series.',
                        })
                      }
                    } else {
                      return response.badRequest({
                        message: 'Series ID not found.',
                      })
                    }
                  }

                  const match = {
                    id: eventData.eventId,
                    name: eventData.name,
                    openDate: eventData.time,
                    channelId: eventData.channelId,
                  }

                  const isMarketExists = await Database.query()
                    .from('market')
                    .where('Id', market.marketId)
                    .first()

                  if (isMarketExists) {
                    return response.status(v.is_auto ? 200 : 400).json({
                      message: 'Market already activated.',
                    })
                  } else {
                    if (market.runners.length > 0) {
                      // save series
                      const isSeriesExists = await Database.query()
                        .from('seriesmst')
                        .where('seriesId', series.id)
                        .first()

                      if (!isSeriesExists) {
                        await Database.insertQuery().table('seriesmst').insert({
                          SportID: sport.id,
                          seriesId: series.id,
                          Name: series.name,
                          createdOn: new Date(),
                          active: 1,
                          mCount: 0,
                        })
                      }

                      // save match
                      const eventExists = await Database.query()
                        .from('matchmst')
                        .where('MstCode', match.id)
                        .first()
                      if (!eventExists) {
                        const runners = []
                        const settings = await Settings.all()
                        const delay: any = settings.line_fancy_delay
                        const lineFancyVolume = settings.line_fancy_volume
                        const oddsLimit = settings.match_odds_limit
                        const timestampInMilliseconds = eventData.time * 1000
                        const dateTime = DateTime.fromISO(
                          new Date(timestampInMilliseconds).toISOString(),
                          {
                            zone: 'utc',
                          }
                        )

                        await Database.insertQuery()
                          .table('matchmst')
                          .insert({
                            MstCode: match.id,
                            matchName: match.name,
                            mstDate: dateTime.toLocal().toISO(),
                            seriesId: series.id,
                            SportID: sport.id,
                            marketCount: 0,
                            createdOn: new Date(),
                            active: 1,
                            runner_json: JSON.stringify(runners),
                            tvUrl: match.channelId,
                            score_board_json: '',
                            line_fancy_delay: delay,
                            line_fancy_volume: lineFancyVolume,
                            oddsLimit: oddsLimit,
                          })
                      }

                      // save market
                      const data = {
                        marketId: market.marketId,
                        marketName: market.marketName,
                        match_id: match.id,
                        series_id: series.id,
                        sports_id: sport.id,
                        totalMatched: market.totalMatched,
                        runners: market.runners,
                        market_runner_json: JSON.stringify(this.buildRunnerJson(market.runners)),
                      }

                      await MarketService.createMarket(data)

                      await MarketService.removeMarketCache(match.id)

                      await Redis.publish(
                        'UPDATE_MATCH_DATA',
                        JSON.stringify({ match_id: match.id })
                      )
                      // if (market.marketName == 'Match Odds') {
                      await Redis.publish('DASHBOARD_UPDATE_USER', '')
                      await Redis.publish('DASHBOARD_UPDATE_ADMIN', '')
                      // }

                      return response.json({
                        message: 'Market added.',
                      })
                    }
                  }
                }
              }
            } else {
              for (const event of sport.eventList) {
                if (
                  ['77', '6', '11'].indexOf(v.sportId) > -1 &&
                  event.eventData.eventId == v.marketId
                ) {
                  const eventData = event.eventData

                  const sport = {
                    id: v.sportId,
                  }

                  const series = {
                    id: '1111' + sport.id,
                    name: eventData.league,
                  }

                  const match = {
                    id: eventData.eventId,
                    name: eventData.name,
                    openDate: eventData.time,
                    channelId: eventData.channelId,
                  }

                  // save series
                  const isSeriesExists = await Database.query()
                    .from('seriesmst')
                    .where('seriesId', series.id)
                    .first()

                  if (!isSeriesExists) {
                    await Database.insertQuery().table('seriesmst').insert({
                      SportID: sport.id,
                      seriesId: series.id,
                      Name: series.name,
                      createdOn: new Date(),
                      active: 1,
                    })
                  }

                  // save match
                  const eventExists = await Database.query()
                    .from('matchmst')
                    .where('MstCode', match.id)
                    .first()
                  if (!eventExists) {
                    const runners = []
                    const settings = await Settings.all()
                    const delay: any = settings.line_fancy_delay
                    const lineFancyVolume = settings.line_fancy_volume
                    const oddsLimit = settings.match_odds_limit
                    const timestampInMilliseconds = eventData.time * 1000
                    const dateTime = DateTime.fromISO(
                      new Date(timestampInMilliseconds).toISOString(),
                      {
                        zone: 'utc',
                      }
                    )

                    await Database.insertQuery()
                      .table('matchmst')
                      .insert({
                        MstCode: match.id,
                        matchName: match.name,
                        mstDate: dateTime.toLocal().toISO(),
                        seriesId: series.id,
                        SportID: sport.id,
                        marketCount: 0,
                        createdOn: new Date(),
                        active: 1,
                        runner_json: JSON.stringify(runners),
                        tvUrl: match.channelId,
                        score_board_json: '',
                        line_fancy_delay: delay,
                        line_fancy_volume: lineFancyVolume,
                        oddsLimit: oddsLimit,
                      })
                  }

                  // orginal
                  // await Redis.sadd('ACTIVE_FANCIES', `${match.id}|`)
                  await Database.from('matchmst')
                    .where('MstCode', match.id)
                    .update({ has_fancy: 1 })

                  return response.json({
                    message: 'Match Activated.',
                  })
                }
              }
            }
          }

          return response.badRequest({
            message: 'Market not activated.',
          })
        } catch (e: any) {
          Logger.error('DIRECT ACTIVATE %o', e)
          console.log('DIRECT ACTIVATE ERROR:', e?.message || e)
          console.log('STACK:', e?.stack)
          return response.badRequest({
            message: 'API Error: ' + (e?.message || 'Unknown error'),
          })
        }
      }
    }

    return response.badRequest({
      message: "You don' have permission",
    })
  }

  public async update({ request, authUser, response, params }: HttpContextContract) {
    if (authUser.usetype == 0 || authUser.usetype == 55) {
      const data = await request.validate({
        schema: schema.create({
          min_stack: schema.number(),
          max_stack: schema.number(),
          max_bet_liability: schema.number(),
          max_market_liability: schema.number(),
          max_market_profit: schema.number(),
          volume: schema.number(),
          message: schema.string.nullable(),
          odds_limit: schema.number(),
        }),
      })

      const market = await Database.query()
        .from('market')
        // .where('sportsId', '<', 5)
        .where('Id', params.id)
        .first()
      if (market) {
        await Database.from('market').where('Id', params.id).update({
          min_stack: data.min_stack,
          max_stack: data.max_stack,
          max_bet_liability: data.max_bet_liability,
          max_market_liability: data.max_market_liability,
          max_market_profit: data.max_market_profit,
          message: data.message,
          volume: data.volume,
          odds_limit: data.odds_limit,
        })

        // const mKeys = await Redis.keys('marketDb:' + params.id + ':*')
        // if (mKeys.length > 0) {
        //   await Redis.del(mKeys)
        // }

        UserService.deleteKeys(await Redis.keys('marketDb:' + params.id + ':*')).then()

        let marketData = {
          match_id: market.matchId,
          data: {
            market_id: params.id,
            min_stack: data.min_stack,
            max_stack: data.max_stack,
            max_bet_liability: data.max_bet_liability,
            max_market_liability: data.max_market_liability,
            max_market_profit: data.max_market_profit,
            message: data.message,
            volume: data.volume,
            odds_limit: data.odds_limit,
          },
        }

        await MarketService.removeMarketCache(market.matchId)

        await Redis.publish('MARKET_UPDATE_DATA', JSON.stringify(marketData))

        return response.json({
          message: 'Detail updated.',
        })
      }
    } else if (authUser.usetype == 11) {
      let data: any = await request.validate({
        schema: schema.create({
          min_stack: schema.number(),
          max_stack: schema.number(),
          max_market_profit: schema.number(),
        }),
      })

      const marketId = params.id
      const table = 'market_settings'

      let parents: any = await UserService.parents(authUser.mstrid)
      parents = parents.map((i: any) => i.mstrid)

      const market = await Database.from('market')
        .joinRaw(
          `LEFT JOIN user_sport_limit as usl ON usl.id = (SELECT id FROM user_sport_limit WHERE user_id IN (${parents.toString()}) AND sport_id = market.sportsId AND type = CASE WHEN market.Id LIKE '%B%' THEN 'bookmaker' ELSE 'market' END ORDER BY user_id DESC LIMIT 1)`
        )
        .where('market.Id', marketId)
        .select(
          'market.matchId',
          Database.raw(
            'ROUND(GREATEST(market.max_market_profit, COALESCE(usl.max_profit, 0)),0) as max_market_profit'
          ),
          Database.raw(
            'ROUND(GREATEST(market.min_stack, COALESCE(usl.min_stake, 0)),0) as min_stack'
          ),
          Database.raw('GREATEST(market.volume, COALESCE(usl.market_volume, 1)) as volume'),

          Database.raw(
            'LEAST(market.max_market_liability, COALESCE(usl.max_market_liability, 0)) as max_market_liability'
          ),
          Database.raw(
            'ROUND(LEAST(market.max_stack, COALESCE(usl.max_stake, 5000000)),0) as max_stack'
          )
        )
        .firstOrFail()

      if (market.min_stack > data.min_stack) {
        return response.badRequest({
          message: `Min stake can not be less than ${market.min_stack}.`,
        })
      }

      if (market.max_stack < data.max_stack) {
        return response.badRequest({
          message: `Max stake can not be greater than ${market.max_stack}.`,
        })
      }

      if (market.max_market_profit < data.max_market_profit) {
        return response.badRequest({
          message: `Max profit can not be greater than ${market.max_market_profit}.`,
        })
      }

      const isSettingExists = await Database.query()
        .from(table)
        .where('user_id', authUser.mstrid)
        .where('market_id', marketId)
        .first()

      if (isSettingExists) {
        data.max_profit = data.max_market_profit
        delete data.max_market_profit

        await Database.query()
          .from(table)
          .where('user_id', authUser.mstrid)
          .where('market_id', marketId)
          .update(data)
      } else {
        await Database.table(table).insert({
          user_id: authUser.mstrid,
          market_id: marketId,
          min_stack: data.min_stack,
          max_stack: data.max_stack,
          max_profit: data.max_market_profit,
        })
      }

      await MarketService.removeMarketCache(market.matchId)

      await Redis.publish('UPDATE_MATCH_DATA', JSON.stringify({ match_id: market.matchId }))

      return response.json({
        message: 'Market settings updated.',
      })
    }

    return response.badRequest({
      message: "You don' have permission.",
    })
  }

  public async blockedMarketUsers({ request, authUser, response }: HttpContextContract) {
    if (request.method() == 'GET') {
      const data = await request.validate({
        schema: schema.create({
          marketId: schema.string(),
        }),
      })
      const search = request.input('search');
      const filter = request.input('filter');

      let rows: any = await Database.from('nested_users')
        .withRecursive('nested_users', (query) => {
          query
            .select(
              'm.mstrid',
              'm.mstruserid',
              'm.mstrname',
              'm.parentId',
              Database.raw('IF(bm.id IS NOT NULL, 1, 0) AS is_blocked')
            )
            .from('createmaster AS m')
            .leftJoin('blocked_markets AS bm', (builder) => {
              builder
                .andOn('m.mstrid', 'bm.user_id')
                .andOnVal('bm.market_id', '=', data.marketId)
                .andOnVal('bm.locked_by', '=', authUser.mstrid)
            })
            .where('m.mstrid', authUser.mstrid)
            .unionAll((builder) => {
              builder
                .select(
                  'u.mstrid',
                  'u.mstruserid',
                  'u.mstrname',
                  'u.parentId',
                  Database.raw('IF(bm.id IS NOT NULL, 1, 0) AS is_blocked')
                )
                .from('createmaster AS u')
                .innerJoin('nested_users AS nu', 'nu.mstrid', 'u.parentId')
                .leftJoin('blocked_markets AS bm', (builder) => {
                  builder
                    .andOn('u.mstrid', 'bm.user_id')
                    .andOnVal('bm.market_id', '=', data.marketId)
                    .andOnVal('bm.locked_by', '=', authUser.mstrid)
                })
            })
        })
        .whereNot('mstrid', authUser.mstrid)
        .if(search, (builder) => {
          builder.where((q) => {
            q.whereILike('mstrname', '%' + search + '%')
            q.orWhereILike('mstruserid', '%' + search + '%')
          })
        }) // filter
        .if(filter !== '', (builder) => {
          builder.where('is_blocked', filter)
        })
        .limit(50)

      return response.json(rows)
    } else {
      const data = await request.validate({
        schema: schema.create({
          marketId: schema.string(),
          usersId: schema.array([rules.distinct('*')]).members(schema.number()),
          matchId: schema.number(),
        }),
      })

      for (let id of data.usersId) {
        if (!(await Parent.validate(authUser, id))) {
          return response.badRequest({
            message: 'Invalid request.',
          })
        }
      }

      await Database.from('blocked_markets')
        .where('market_id', data.marketId)
        .if(request.input('self') == 'yes', (q) => {
          q.where('user_id', authUser.mstrid)
        })
        .where('locked_by', '=', authUser.mstrid)
        .delete()

      if (data.usersId.length > 0) {
        await Database.table('blocked_markets').multiInsert(
          data.usersId.map((el: any) => {
            return {
              market_id: data.marketId,
              user_id: el,
              locked_by: authUser.mstrid,
            }
          })
        )
      }

      if (request.input('self') == 'yes') {
        const marketData = {
          sportId: request.input('sportId').toString(),
          seriesId: request.input('seriesId').toString(),
          matchId: data.matchId.toString(),
          marketId: data.marketId.toString(),
        }

        if (data.usersId.length > 0) {
          await Redis.srem('ACTIVE_MARKETS', JSON.stringify(marketData))
        } else {
          await Redis.sadd('ACTIVE_MARKETS', JSON.stringify(marketData))
        }

        await Redis.publish('UPDATE_ACTIVE_MARKET', '')
      }

      await MarketService.removeMarketCache(data.matchId)

      await Redis.publish('UPDATE_MATCH_DATA', JSON.stringify({ match_id: data.matchId }))

      return response.json({
        message: 'Data saved.',
      })
    }
  }

  public async publishData({ request, authUser, response }: HttpContextContract) {
    const data = await request.validate({
      schema: schema.create({
        MarketId: schema.string(),
        SportId: schema.string(),
      }),
    })

    const category = request.input('category', 'market')

    if (authUser.usetype == 0 || authUser.usetype == 55) {
      if (authUser.usetype == 55) {
        authUser = await UserService.checkPersmission(authUser, 'Active Matches and Manage Series')

        if (!authUser) {
          return response.badRequest({
            message: 'Invalid request.',
          })
        }
      }

      let matchId: number
      let seriesId: number
      let sportId: number

      if (category == 'line') {
        const market = await Database.query()
          .from('matchfancy')
          .join('matchmst', 'matchmst.MstCode', '=', 'matchfancy.MatchID')
          .where('matchfancy.market_id', data.MarketId)
          .select('matchfancy.*', 'matchmst.seriesId as seriesId', 'matchmst.SportID AS SportID')
          .first()

        response.abortIf(!market, { message: 'Please activate line fancy first!' })

        matchId = market.MatchID
        seriesId = market.seriesId
        sportId = market.SportID
      } else {
        const market = await Database.query().from('market').where('Id', data.MarketId).first()

        response.abortIf(!market, { message: 'Please activate market first!' })

        matchId = market.matchId
        seriesId = market.seriesId
        sportId = market.sportsId
      }

      let marketKey = 'ACTIVE_MARKETS'

      if (data.MarketId.includes('M')) {
        marketKey = 'ACTIVE_MANUAL_MARKET'
      }

      await Redis.sadd(
        category == 'line' ? 'ACTIVE_LINE_MARKETS' : marketKey,
        JSON.stringify({
          sportId: sportId.toString(),
          seriesId: seriesId.toString(),
          matchId: matchId.toString(),
          marketId: data.MarketId.toString(),
        })
      )

      await Redis.publish('UPDATE_ACTIVE_MARKET', '')

      return response.json({
        message: 'Data published',
      })
    }

    return response.badRequest({
      message: "You don' have permission",
    })
  }

  public async unpublishData({ request, authUser, response }: HttpContextContract) {
    const data = await request.validate({
      schema: schema.create({
        MarketId: schema.string(),
      }),
    })

    if (authUser.usetype == 0 || authUser.usetype == 55) {
      if (authUser.usetype == 55) {
        authUser = await UserService.checkPersmission(authUser, 'Active Matches and Manage Series')

        if (!authUser) {
          return response.badRequest({
            message: 'Invalid request.',
          })
        }
      }

      let matchId: number
      let seriesId: number
      let sportId: number

      const category = request.input('category', 'market')

      if (category == 'line') {
        const market = await Database.query()
          .from('matchfancy')
          .join('matchmst', 'matchmst.MstCode', '=', 'matchfancy.MatchID')
          .where('matchfancy.market_id', data.MarketId)
          .select('matchfancy.*', 'matchmst.seriesId as seriesId', 'matchmst.SportID AS SportID')
          .first()

        response.abortIf(!market, { message: 'Please activate line fancy first!' })

        matchId = market.MatchID
        seriesId = market.SeriesId
        sportId = market.SportID
      } else {
        const market = await Database.query().from('market').where('Id', data.MarketId).first()

        response.abortIf(!market, { message: 'Please activate market first!' })

        matchId = market.matchId
        seriesId = market.seriesId
        sportId = market.sportsId
      }

      let marketKey = 'ACTIVE_MARKETS'

      if (data.MarketId.includes('M')) {
        marketKey = 'ACTIVE_MANUAL_MARKET'
      }

      await Redis.srem(
        category == 'line' ? 'ACTIVE_LINE_MARKETS' : marketKey,
        JSON.stringify({
          sportId: sportId.toString(),
          seriesId: seriesId.toString(),
          matchId: matchId.toString(),
          marketId: data.MarketId.toString(),
        })
      )

      // await Redis.srem(
      //   'ACTIVE_MARKETS',
      //   JSON.stringify({
      //     sportId: data.SportId.toString(),
      //     seriesId: data.SeriesId.toString(),
      //     matchId: data.MatchId.toString(),
      //     marketId: data.MarketId.toString(),
      //   })
      // )

      // await Redis.srem(
      //   'ACTIVE_LINE_MARKETS',
      //   JSON.stringify({
      //     sportId: data.SportId.toString(),
      //     seriesId: data.SeriesId.toString(),
      //     matchId: data.MatchId.toString(),
      //     marketId: data.MarketId.toString(),
      //   })
      // )

      await Redis.publish('UPDATE_ACTIVE_MARKET', '')
      // await Redis.publish('DASHBOARD_UPDATE_USER', '');

      return response.json({
        message: 'Data unpublished',
      })
    }

    return response.badRequest({
      message: "You don' have permission",
    })
  }

  public async mannual({ request, authUser, response }: HttpContextContract) {
    const data = await request.validate({
      schema: schema.create({
        seriesId: schema.string(),
        seriesName: schema.string(),
        sportId: schema.string(),
        matchId: schema.string(),
        matchName: schema.string(),
        date: schema.string(),
        tvUrl: schema.string.optional(),
        score_board_json: schema.string.optional(),
        marketId: schema.string(),
        marketName: schema.string(),
        match_id: schema.string(),
        series_id: schema.string(),
        sports_id: schema.string(),
        totalMatched: schema.number(),
        runners: schema.array([rules.minLength(2)]).members(
          schema.object().members({
            selectionId: schema.number(),
            runnerName: schema.string(),
          })
        ),
      }),
    })

    if (authUser.usetype == 0) {
      const series = await Database.query()
        .from('seriesmst')
        .where('seriesId', data.seriesId)
        .first()

      if (!series) {
        await Database.insertQuery().table('seriesmst').insert({
          SportID: data.sportId,
          seriesId: data.seriesId,
          Name: data.seriesName,
          createdOn: new Date(),
          active: 1,
        })
      } else {
        if (series.active == 0) {
          return response.badRequest({
            message: 'Series is not active',
          })
        }
      }

      const event = await Database.query().from('matchmst').where('MstCode', data.matchId).first()
      if (!event) {
        const runners = []

        if ([1, 2, 4].indexOf(series.SportID)) {
          //Soccer
          data.tvUrl = ''
          data.score_board_json = ''
        } else {
          data.tvUrl = ''
          data.score_board_json = ''
        }

        const settings = await Settings.all()
        const delay: any = settings.line_fancy_delay
        const lineFancyVolume = settings.line_fancy_volume
        const oddsLimit = settings.match_odds_limit
        const dateTime = DateTime.fromISO(data.date)

        await Database.insertQuery()
          .table('matchmst')
          .insert({
            MstCode: data.matchId,
            mstDate: dateTime.toISO(),
            matchName: data.matchName,
            seriesId: data.seriesId,
            SportID: series.SportID,
            marketCount: 0,
            createdOn: new Date(),
            active: 1,
            runner_json: JSON.stringify(runners),
            tvUrl: data.tvUrl,
            score_board_json: data.score_board_json,
            line_fancy_delay: delay,
            line_fancy_volume: lineFancyVolume,
            oddsLimit: oddsLimit,
          })
      } else {
        if (event.active == 0) {
          return response.badRequest({
            message: 'Match is not active.',
          })
        }
      }

      // @ts-ignore
      data.market_runner_json = JSON.stringify(this.buildRunnerJson(data.runners))
      await this.createMarket(data)

      return response.json({
        message: 'Market added.',
      })
    }
  }

  public async blockedMarkets({ request, authUser, response }: HttpContextContract) {
    const data = await request.validate({
      schema: schema.create({
        match_id: schema.number(),
        marketId: schema.string(),
        status: schema.string(),
      }),
    })

    if (authUser.mstrid == 1) {
      const selectedMarket = await Database.from('market').where('Id', data.marketId).first()

      if (!selectedMarket) {
        return response.json({
          status: false,
          message: 'Market doesnt exist!',
        })
      }

      const marketData = {
        sportId: selectedMarket.sportsId.toString(),
        seriesId: selectedMarket.seriesId.toString(),
        matchId: data.match_id.toString(),
        marketId: data.marketId.toString(),
      }

      if (data.status == 'A') {
        if (selectedMarket.active == 1) {
          return response.json({
            status: false,
            message: 'Market already active',
          })
        }
        await Database.from('market').where('Id', data.marketId).update({ active: 1 })

        await Redis.sadd('ACTIVE_MARKETS', JSON.stringify(marketData))
      } else {
        if (selectedMarket.active == 0) {
          return response.json({
            status: false,
            message: 'Market already deactivated',
          })
        }
        await Database.from('market').where('Id', data.marketId).update({ active: 0 })

        await Redis.srem('ACTIVE_MARKETS', JSON.stringify(marketData))

        UserService.deleteKeys(await Redis.keys('marketDb:' + data.marketId + ':*')).then()
      }

      return response.json({
        message: 'Updated',
      })
    }
    return response.json({
      status: false,
      message: 'You dont have permission',
    })
  }

  public async manualMarket({ request, authUser, response }: HttpContextContract) {
    const data = await request.validate({
      schema: schema.create({
        marketId: schema.string(),
        marketName: schema.string(),
        match_id: schema.string(),
        series_id: schema.string(),
        sports_id: schema.string(),
        totalMatched: schema.number(),
        runners: schema
          .array([rules.minLength(2), rules.distinct('selectionId'), rules.distinct('runnerName')])
          .members(
            schema.object().members({
              selectionId: schema.number(),
              runnerName: schema.string(),
            })
          ),
        is_manual: schema.boolean.optional(),
      }),
    })

    if (authUser.usetype == 0 || authUser.usetype == 55) {
      if (authUser.usetype == 55) {
        authUser = await UserService.checkPersmission(authUser, 'Active Matches and Manage Series')

        if (!authUser) {
          return response.badRequest({
            message: 'Invalid request.',
          })
        }
      }
      const match = await Database.query().from('matchmst').where('MstCode', data.match_id).first()
      if (match) {
        if (match.active == 0) {
          return response.badRequest({
            message: 'Match is not active.',
          })
        }
      } else {
        return response.badRequest({
          message: 'Match is not found.',
        })
      }

      const market = await Database.query()
        .from('market')
        .where('matchId', data.match_id)
        .where(function (builder) {
          builder.where('Id', data.marketId).orWhere('name', data.marketName)
        })
        .first()

      if (market) {
        return response.badRequest({
          message: 'Market Already Exists!',
        })
      } else {
        await Redis.sadd(
          'MANUAL_MARKET_LIST',
          JSON.stringify({
            marketId: data.marketId,
            marketName: data.marketName,
            match_id: data.match_id,
            series_id: data.series_id,
            sports_id: data.sports_id,
            totalMatched: data.totalMatched,
            runners: data.runners,
            is_manual: data.is_manual,
          })
        )
      }

      // @ts-ignore
      data.market_runner_json = JSON.stringify(this.buildRunnerJson(data.runners))
      await this.createMarket({ ...data })

      await Redis.sadd(
        'ACTIVE_MANUAL_MARKETS',
        JSON.stringify({
          sportId: data.sports_id.toString(),
          seriesId: data.series_id.toString(),
          matchId: data.match_id.toString(),
          marketId: data.marketId.toString(),
        })
      )

      return response.json({
        message: 'Market added.',
      })
    }

    return response.badRequest({
      message: "You don' have permission",
    })
  }

  public async getRunnersByMarket({ request, authUser, response }: HttpContextContract) {
    const data = await request.validate({
      schema: schema.create({
        marketId: schema.string(),
        matchId: schema.string(),
      }),
    })

    if (authUser.usetype == 0 || authUser.usetype == 55) {
      if (authUser.usetype == 55) {
        authUser = await UserService.checkPersmission(authUser, 'Active Matches and Manage Series')

        if (!authUser) {
          return response.badRequest({
            message: 'Invalid request.',
          })
        }
      }
      const match = await Database.query().from('matchmst').where('MstCode', data.matchId).first()
      if (match) {
        if (match.active == 0) {
          return response.badRequest({
            message: 'Match is not active.',
          })
        }
      } else {
        return response.badRequest({
          message: 'Match is not found.',
        })
      }

      const marketsData = await axios.get(ThirdParty.marketRunnersApiUrl + data.marketId)
      let market: any = []
      if (marketsData.data) {
        if (Array.isArray(marketsData.data)) {
          market = marketsData.data.find((el: any) => el.marketId == data.marketId)
          if (market) {
            response.abortIf(market.runners.length == 0, {
              message: 'There is no selection available.',
            })
          }
        }
      }

      return response.json({
        status: true,
        data: market?.runners || [],
      })
    }

    return response.badRequest({
      message: "You don' have permission",
    })
  }

  public async addManualMarket({ request, authUser, response }: HttpContextContract) {
    const data = await request.validate({
      schema: schema.create({
        marketId: schema.string(),
        marketName: schema.string(),
        match_id: schema.string(),
        series_id: schema.string(),
        sports_id: schema.string(),
        totalMatched: schema.number(),
        runners: schema
          .array([rules.minLength(2), rules.distinct('selectionId'), rules.distinct('runnerName')])
          .members(
            schema.object().members({
              selectionId: schema.number(),
              runnerName: schema.string(),
            })
          ),
        is_manual: schema.boolean.optional(),
      }),
    })

    if (authUser.usetype == 0 || authUser.usetype == 55) {
      if (authUser.usetype == 55) {
        authUser = await UserService.checkPersmission(authUser, 'Active Matches and Manage Series')

        if (!authUser) {
          return response.badRequest({
            message: 'Invalid request.',
          })
        }
      }
      const series = await Database.query()
        .from('seriesmst')
        .where('seriesId', data.series_id)
        .first()
      if (series) {
        if (series.active == 0) {
          return response.badRequest({
            message: 'Series is not active',
          })
        }
      } else {
        return response.badRequest({
          message: 'Series is not found.',
        })
      }

      const match = await Database.query().from('matchmst').where('MstCode', data.match_id).first()
      if (match) {
        if (match.active == 0) {
          return response.badRequest({
            message: 'Match is not active.',
          })
        }
      } else {
        return response.badRequest({
          message: 'Match is not found.',
        })
      }

      const Dbmarket = await Database.query()
        .from('market')
        .where('matchId', data.match_id)
        .where(function (builder) {
          builder.where('Id', data.marketId).orWhere('name', data.marketName)
        })
        .first()

      if (Dbmarket) {
        return response.badRequest({
          message: 'Market Already Exists!',
        })
      }

      let manualMarket: any = await Redis.smembers('MANUAL_MARKET_LIST')

      manualMarket = manualMarket.map((el: any) => JSON.parse(el))

      if (manualMarket) {
        let isExists = manualMarket.find((s: any) => s.marketId == data.marketId)

        if (isExists) {
          return response.badRequest({
            message: 'MarketId already exists!',
          })
        }

        isExists = manualMarket.find(
          (s: any) => s.match_id == data.match_id && s.marketName == data.marketName
        )

        if (isExists) {
          return response.badRequest({
            message: `Market with Name ${data.marketName} already exists!`,
          })
        }
      }

      await Redis.sadd(
        'MANUAL_MARKET_LIST',
        JSON.stringify({
          marketId: data.marketId,
          marketName: data.marketName,
          match_id: data.match_id,
          series_id: data.series_id,
          sports_id: data.sports_id,
          totalMatched: data.totalMatched,
          runners: data.runners,
          is_manual: data.is_manual,
        })
      )

      return response.json({
        message: 'Market added.',
      })
    }

    return response.badRequest({
      message: "You don' have permission",
    })
  }

  public async addGoalMarkets({ request, authUser, response }: HttpContextContract) {
    const data = await request.validate({
      schema: schema.create({
        match_id: schema.string(),
        totalMatched: schema.number(),
        series_id: schema.string.nullableAndOptional(),
        sports_id: schema.string.nullableAndOptional(),
      }),
    })

    if (authUser.usetype == 0 || authUser.usetype == 55) {
      if (authUser.usetype == 55) {
        authUser = await UserService.checkPersmission(authUser, 'Active Matches and Manage Series')

        if (!authUser) {
          return response.badRequest({
            message: 'Invalid request.',
          })
        }
      }
      const match = await Database.query().from('matchmst').where('MstCode', data.match_id).first()
      if (match) {
        if (match.active == 0) {
          return response.badRequest({
            message: 'Match is not active.',
          })
        }
      } else {
        return response.badRequest({
          message: 'Match is not found.',
        })
      }

      data.sports_id = match.SportID.toString()
      data.series_id = match.seriesId.toString()

      let marketNameList = ['Over/Under 0.5 Goals', 'Over/Under 1.5 Goals', 'Over/Under 2.5 Goals']

      const rows = await axios.get(ThirdParty.marketListApiUrl + data.match_id)
      let markets: any

      if (rows.data) {
        markets = rows.data.filter((market: any) => marketNameList.indexOf(market.marketName) > -1)
        markets.sort((a: any, b: any) => {
          const overNumberA = parseFloat(a.marketName.match(/\d+(\.\d+)?/)[0])
          const overNumberB = parseFloat(b.marketName.match(/\d+(\.\d+)?/)[0])

          return overNumberA - overNumberB
        })
      }

      response.abortIf(!markets, {
        message: 'There is no goals market available.',
      })

      for (let m of markets) {
        const marketsData = await axios.get(ThirdParty.marketRunnersApiUrl + m.marketId)
        if (marketsData.data) {
          if (Array.isArray(marketsData.data)) {
            const market = marketsData.data.find((el: any) => el.marketId == m.marketId)
            if (market) {
              // @ts-ignore
              data.runners = market.runners
              // @ts-ignore
              data.marketId = m.marketId
              // @ts-ignore
              data.marketName = m.marketName
              // @ts-ignore

              data.market_runner_json = JSON.stringify(this.buildRunnerJson(market.runners))
              await this.createMarket({ ...data, startTime: market.marketStartTime })

              await this.sleep(1000)

              await Redis.sadd(
                'ACTIVE_MARKETS',
                JSON.stringify({
                  sportId: match.SportID.toString(),
                  seriesId: match.seriesId.toString(),
                  matchId: data.match_id.toString(),
                  marketId: m.marketId.toString(),
                })
              )
            }
          }
        }
      }

      await Redis.publish('UPDATE_ACTIVE_MARKET', '')

      return response.ok({
        message: 'Markets are added.',
      })
    }
  }

  public async toggleManualActivation({ request, authUser, response }: HttpContextContract) {
    const data = await request.validate({
      schema: schema.create({
        status: schema.boolean(),
        type: schema.enum(['market', 'fancy'] as const),
      }),
    })

    if (authUser.usetype != 0) {
      return response.badRequest({
        message: "You don' have permission",
      })
    }

    if (data.type == 'market') {
      const markets = await Database.from('market')
        .join('matchmst', 'matchmst.MstCode', 'market.matchId')
        .where('market.Id', 'like', '%B%')
        .where('market.Name', 'Bookmaker')
        .where('market.active', 1)
        .select('market.Id')

      const marketIds = markets.map((m: any) => m.Id)
      const statusValue = data.status ? 1 : 0

      if (marketIds.length > 0) {
        if (data.type == 'market') {
          await Database.from('market').whereIn('Id', marketIds).update({ is_manual: statusValue })

          const keys = await Redis.keys(`matchmarkets:*`)
          if (keys.length > 0) {
            await Redis.del(...keys)
          }
        } else {
          await Database.from('market').whereIn('Id', marketIds).update({ is_fancy: statusValue })
        }
      }

      await Redis.set('MANUAL_MARKET_ACTIVATED', data.status ? 'true' : 'false')

      return response.json({
        message: data.status ? 'Manual Market Activated' : 'Manual Market Deactivated',
      })
    }
  }

  private buildRunnerJson(runnerArray: any) {
    const data: any = []
    let order = 0
    runnerArray.forEach((r: any) => {
      let sortPriority = r.sortPriority
      if (!sortPriority) {
        order++
        sortPriority = order
      }
      const runner: any = {
        id: r.selectionId,
        name: r.runnerName,
        sortPriority,
      }

      const backLay: any = []
      for (const { } of [1, 2, 3]) {
        backLay.push({ size: '--', price: '--' })
      }

      runner.back = backLay
      runner.lay = backLay
      data.push(runner)
    })
    return data
  }

  private async createMarket(data) {
    await MarketService.createMarket(data)
    await MarketService.removeMarketCache(data.match_id)

    await Redis.publish('UPDATE_MATCH_DATA', JSON.stringify({ match_id: data.match_id }))

    if (data.marketName == 'Match Odds') {
      await Redis.publish('DASHBOARD_UPDATE_USER', '')
      await Redis.publish('DASHBOARD_UPDATE_ADMIN', '')
    }
  }

  private sleep(ms: number) {
    return new Promise((resolve) => setTimeout(resolve, ms))
  }

  private async addMatchIfNot(d: any) {
    try {
      const { data } = await axios.get(ThirdParty.horseMarketApi + d.sports_id)

      if (data && Array.isArray(data)) {
        const market = data.find((el) => el.marketId == d.marketId)
        if (market) {
          const match = market.event

          const settings = await Settings.all()
          const delay: any = settings.line_fancy_delay
          const lineFancyVolume = settings.line_fancy_volume
          const oddsLimit = settings.match_odds_limit
          const dateTime = DateTime.fromISO(match.openDate, { zone: match.timezone || 'utc' })

          await Database.insertQuery()
            .table('matchmst')
            .insert({
              MstCode: match.id,
              mstDate: dateTime.toLocal().toISO(),
              matchName: match.name,
              seriesId: d.series_id,
              SportID: market.eventType.id,
              marketCount: 0,
              createdOn: new Date(),
              active: 1,
              runner_json: JSON.stringify([]),
              tvUrl: '',
              score_board_json: '',
              line_fancy_delay: delay,
              line_fancy_volume: lineFancyVolume,
              oddsLimit: oddsLimit,
              country_code: match.countryCode,
            })

          return true
        }
      }
      return false
    } catch (e) {
      return false
    }
  }
}
