import { HttpContextContract } from '@ioc:Adonis/Core/HttpContext'
import { schema } from '@ioc:Adonis/Core/Validator'
import Database from '@ioc:Adonis/Lucid/Database'

export default class SocialMediaController {
  public async index({ authUser, response }: HttpContextContract) {
    let data: any = []
    if (authUser.usetype == 11) {
      data = await Database.from('social_links').where('domain', authUser.domain)
    }

    return response.json(data)
  }
  public async store({ request, response, authUser }: HttpContextContract) {
    if (authUser.usetype == 11) {
      const data = await request.validate({
        schema: schema.create({
          name: schema.string(),
          type: schema.string(),
          value: schema.string(),
        }),
      })

      await Database.table('social_links').insert({
        domain: authUser.domain,
        ...data,
      })

      return response.json({
        message: 'Social Media Added.',
      })
    }
    return response.badRequest({
      message: "You don't have permission",
    })
  }

  public async update({ request, response, authUser, params }: HttpContextContract) {
    if (authUser.usetype == 11) {
      const data = await request.validate({
        schema: schema.create({
          name: schema.string(),
          type: schema.string(),
          value: schema.string(),
        }),
      })

      const socialMedia = await Database.from('social_links')
        .where('id', params.id)
        .where('domain', authUser.domain)
        .firstOrFail()

      await Database.from('social_links')
        .where('id', socialMedia.id)
        .update({
          ...data,
        })

      return response.json({
        message: 'Social Media Updated.',
      })
    }

    return response.badRequest({
      message: "You don't have permission",
    })
  }

  public async delete({ response, authUser, params }: HttpContextContract) {
    if (authUser.usetype == 11) {
      const socialMedia = await Database.from('social_links')
        .where('id', params.id)
        .where('domain', authUser.domain)
        .firstOrFail()

      if (socialMedia) {
        await Database.from('social_links')
          .where('id', params.id)
          .where('domain', authUser.domain)
          .delete()

        return response.json({
          message: 'Social Media deleted.',
        })
      }
    }
    return response.badRequest({
      message: "You don't have permission",
    })
  }
}
