import { schema } from '@ioc:Adonis/Core/Validator'
import Database from '@ioc:Adonis/Lucid/Database'
import Bull from '@ioc:Rocketseat/Bull'
import UpdateLiability from 'App/Jobs/UpdateLiability'

export default class SettlementsController {
  public async index({ request, response }) {
    let page = request.input('page', 1)
    let limit = request.input('limit', 50)

    const data = await Database.from('tblcashentry')
      .select(
        'createmaster.mstruserid AS parentUser',
        'createmaster_1.mstruserid AS childUser',
        'rowId',
        'tblcashentry.parentId',
        'childId',
        'onDate',
        'typeId',
        'amountV',
        'remarkV',
        'CrDr'
      )
      .innerJoin('createmaster', 'tblcashentry.parentId', 'createmaster.mstrid')
      .innerJoin('createmaster AS createmaster_1', 'tblcashentry.childId', 'createmaster_1.mstrid')
      .where('typeId', 50)
      .orderBy('onDate', 'desc')
      .paginate(page, limit)

    return response.json({
      data: data,
    })
  }

  public async getSettleMatchList({ request, authUser, response }) {
    const data = await request.validate({
      schema: schema.create({
        bet_deleted: schema.string.optional(),
        from_date: schema.string.nullable(),
        limit: schema.number(),
        match_name: schema.string.optional(),
        page_no: schema.number(),
        sport_id: schema.number.optional(),
        to_date: schema.string.nullable(),
      }),
    })

    let page = request.input('page', 1)
    let limit = request.input('limit', 50)

    let rows: any = []

    if (authUser.usetype == 0 || authUser.usetype == 10) {
      rows = await Database.from('matchmst')
        .leftJoin('market', 'matchmst.MstCode', '=', 'market.matchId')
        .join('tblresult', 'tblresult.marketId', '=', 'market.Id')
        .where('market.Name', 'Match Odds')
        .if(data.match_name, (q) => {
          q.where('matchmst.matchName', 'LIKE', '%' + data.match_name + '%')
        })
        .if(data.sport_id, (q) => {
          q.where('matchmst.SportID', data.sport_id)
        })
        .if(data.from_date, (q) => {
          q.where('matchmst.MstDate', '>=', data.from_date + 'T00:00:00')
        })
        .if(data.to_date, (q) => {
          q.where('matchmst.MstDate', '<=', data.to_date + 'T23:59:59')
        })
        .select('matchmst.*')
        .orderBy('createdOn', 'desc')
        .paginate(page, limit)
    }

    return response.json({
      data: rows,
    })
  }

  public async removeSettlementList({ request, response }) {
    const data = await request.validate({
      schema: schema.create({
        ID: schema.number(),
      }),
    })

    const ids = await Database.from('tblcashentry')
      .distinct('parentId as id')
      .where('rowId', data.ID)
      .union(
        [
          (query) => {
            query.from('tblcashentry').distinct('childId as id').where('rowId', data.ID)
          },
        ],
        true
      )

    await Database.table('tblcashentrybackup').insert((builder) => {
      builder.select('*').from('tblcashentry').where({
        rowId: data.ID,
      })
    })

    await Database.from('tblcashentry').where('rowId', data.ID).delete()
    await Database.from('tblchipdet').where('cashentryid', data.ID).delete()

    if (ids.length > 0) {
      await Bull.add(new UpdateLiability().key, ids, { removeOnComplete: true })
    }

    // Update Balance and liability common process (TOPIC) for the  users came from abpve select query
    return response.json({
      message: 'Delete successfully',
    })
  }
}
