import Cache from '@ioc:Adonis/Addons/Cache'
import Redis from '@ioc:Adonis/Addons/Redis'
import Application from '@ioc:Adonis/Core/Application'
import Encryption from '@ioc:Adonis/Core/Encryption'
import Env from '@ioc:Adonis/Core/Env'
import { cuid } from '@ioc:Adonis/Core/Helpers'
import { HttpContextContract } from '@ioc:Adonis/Core/HttpContext'
import { rules, schema } from '@ioc:Adonis/Core/Validator'
import Database from '@ioc:Adonis/Lucid/Database'
import Bull from '@ioc:Rocketseat/Bull'
import LockUnlockBetting from 'App/Jobs/LockUnlockBetting'
import LockUnlockUser from 'App/Jobs/LockUnlockUser'
import Auto from 'App/Services/Auto'
import LiabilityEngine from 'App/Services/Ledger/LiabilityEngine'
import PartnershipCalculator from 'App/Services/Ledger/PartnershipCalculator'
import { Mongo } from 'App/Services/Mongo'
import Parent from 'App/Services/Parent'
import Poker from 'App/Services/Poker'
import Sp from 'App/Services/Sp'
import UserService from 'App/Services/UserService'
import axios from 'axios'
import { DateTime } from 'luxon'


export default class UsersController {
  // public async index({ request, authUser, response }: HttpContextContract) {
  //   const search = request.input('search')
  //   const data = await request.validate({
  //     schema: schema.create({
  //       userid: schema.number(),
  //       page: schema.number.optional(),
  //       user_lock: schema.enum.optional(['0', '1', '2']),
  //       type: schema.enum.optional(['0', '1', '2', '3', '8', '9', '10', '11']),
  //       category: schema.enum.optional(['AGENT', 'CLIENT']),
  //     }),
  //   })

  //   if (authUser.usetype == 55) {
  //     authUser = await UserService.checkPersmission(authUser)

  //     if (!authUser) {
  //       return response.badRequest({
  //         message: 'Invalid request.',
  //       })
  //     }
  //   }

  //   if (!(await Parent.validate(authUser, data.userid))) {
  //     return response.badRequest({
  //       message: 'Invalid request.',
  //     })
  //   }

  //   const pageLimit = request.input('limit', 50)
  //   const sort = request.input('sort', 'usecrdt')
  //   const order = request.input('order', 'desc')

  //   let rows: any = Database.from('createmaster')
  //     .whereNot('usetype', 55)
  //     .whereNot('mstrid', authUser.mstrid)
  //     .where('parentId', data.userid)
  //     .if(search, (builder) => {
  //       builder.where((q) => {
  //         q.whereILike('mstrname', '%' + search + '%')
  //         q.orWhereILike('mstruserid', '%' + search + '%')
  //         q.orWhereILike('phone', '%' + search + '%')
  //         q.orWhereILike('email', '%' + search + '%')
  //       })
  //     })
  //     .if(data.type, (q: any) => {
  //       q.where('usetype', data.type)
  //     })
  //     .if(data.category == 'AGENT', (q: any) => {
  //       q.whereNot('usetype', 3)
  //     })
  //     .if(data.category == 'CLIENT', (q: any) => {
  //       q.where('usetype', 3)
  //     })
  //     .select([
  //       'balance',
  //       'Commission',
  //       'freeChips',
  //       'domain',
  //       'Liability',
  //       'OtherComm',
  //       'mstrid',
  //       'P_L',
  //       'SessionComm',
  //       'active',
  //       'create_no_of_child',
  //       'ipadress',
  //       'bet_lock',
  //       'phone',
  //       'mstrlock',
  //       'mstrname',
  //       'mstrremarks',
  //       'mstruserid',
  //       'parentId',
  //       'partner',
  //       'stakeLimit',
  //       'usecrdt',
  //       'usetype',
  //       'email',
  //       'partner_casino',
  //       'partner_cricket',
  //       'partner_tennis',
  //       'partner_soccer',
  //       'partner_dream',
  //       'partner_binary',
  //       'partner_election',
  //       'partner_virtual_casino',
  //       'rolling_commission',
  //       'fancy_rolling_commission',
  //       Database.raw(
  //         'ROUND((SELECT SUM(ChipsCr - ChipsDr) FROM tblchipdet WHERE UserID =  createmaster.mstrid AND ChildId = 0),2) AS pl'
  //       ),
  //       'profit_loss',
  //       Database.from('createmaster as cc')
  //         .sum('cc.Balance')
  //         .whereColumn('cc.parentId', 'createmaster.mstrid')
  //         .as('downline_balance'),
  //       Database.raw(
  //         'ROUND((SELECT SUM(ChipsDr - ChipsCr) FROM tblchipdet WHERE oppAcID =  createmaster.mstrid AND ChildId != 0 GROUP BY oppAcID),2) AS settlementAmount'
  //       ),
  //     ])
  //     .if(data.user_lock && data.user_lock != '2', (q: any) => {
  //       q.where('mstrlock', data.user_lock)
  //     })
  //     .orderBy(sort, order)
  //     .orderBy('mstrlock', 'desc')

  //   if (data.page) rows = rows.paginate(data.page, pageLimit)

  //   return response.json({
  //     data: await rows,
  //   })
  // }

  // public async index({ request, authUser, response }: HttpContextContract) {
  //   // Validate request input once upfront
  //   const data = await request.validate({
  //     schema: schema.create({
  //       userid: schema.number(),
  //       page: schema.number.optional(),
  //       user_lock: schema.enum.optional(['0', '1', '2']),
  //       type: schema.enum.optional(['0', '1', '2', '3', '8', '9', '10', '11']),
  //       category: schema.enum.optional(['AGENT', 'CLIENT']),
  //     }),
  //   })

  //   const search = request.input('search')
  //   const pageLimit = request.input('limit', 50)
  //   const sort = request.input('sort', 'usecrdt')
  //   const order = request.input('order', 'desc')

  //   // Permission check for usertype 55
  //   if (authUser.usetype === 55) {
  //     authUser = await UserService.checkPersmission(authUser)
  //     if (!authUser) {
  //       return response.badRequest({ message: 'Invalid request.' })
  //     }
  //   }

  //   // Validate parent relationship
  //   const isValidParent = await Parent.validate(authUser, data.userid)
  //   if (!isValidParent) {
  //     return response.badRequest({ message: 'Invalid request.' })
  //   }

  //   // Build the query
  //   let query = Database.from('createmaster')
  //     .whereNot('usetype', 55)
  //     .whereNot('mstrid', authUser.mstrid)
  //     .where('parentId', data.userid)

  //   if (search) {
  //     query = query.where((builder) => {
  //       builder
  //         .whereILike('mstrname', `%${search}%`)
  //         .orWhereILike('mstruserid', `%${search}%`)
  //         .orWhereILike('phone', `%${search}%`)
  //         .orWhereILike('email', `%${search}%`)
  //     })
  //   }

  //   if (data.type) {
  //     query = query.where('usetype', data.type)
  //   }

  //   if (data.category === 'AGENT') {
  //     query = query.whereNot('usetype', 3)
  //   } else if (data.category === 'CLIENT') {
  //     query = query.where('usetype', 3)
  //   }

  //   if (data.user_lock && data.user_lock !== '2') {
  //     query = query.where('mstrlock', data.user_lock)
  //   }

  //   query = query.select([
  //     'balance',
  //     'Commission',
  //     'freeChips',
  //     'domain',
  //     'Liability',
  //     'OtherComm',
  //     'mstrid',
  //     'P_L',
  //     'SessionComm',
  //     'active',
  //     'create_no_of_child',
  //     'ipadress',
  //     'bet_lock',
  //     'phone',
  //     'mstrlock',
  //     'mstrname',
  //     'mstrremarks',
  //     'mstruserid',
  //     'parentId',
  //     'partner',
  //     'stakeLimit',
  //     'usecrdt',
  //     'usetype',
  //     'email',
  //     'partner_casino',
  //     'partner_cricket',
  //     'partner_tennis',
  //     'partner_soccer',
  //     'partner_dream',
  //     'partner_binary',
  //     'partner_election',
  //     'partner_virtual_casino',
  //     'rolling_commission',
  //     'fancy_rolling_commission',
  //     Database.raw(
  //       `ROUND((SELECT SUM(ChipsCr - ChipsDr) FROM tblchipdet WHERE UserID = createmaster.mstrid AND ChildId = 0), 2) AS pl`
  //     ),
  //     'profit_loss',
  //     Database.raw(
  //       `ROUND((SELECT SUM(ChipsDr - ChipsCr) FROM tblchipdet WHERE oppAcID = createmaster.mstrid AND ChildId != 0 GROUP BY oppAcID), 2) AS settlementAmount`
  //     ),
  //   ])

  //   query = query.orderBy(sort, order).orderBy('mstrlock', 'desc')

  //   // Execute the query (paginate if page provided)
  //   const rows = data.page ? await query.paginate(data.page, pageLimit) : await query

  //   return response.json({
  //     data: rows,
  //   })
  // }

  public async index({ request, authUser, response }: HttpContextContract) {
    const data = await request.validate({
      schema: schema.create({
        userid: schema.number(),
        // page: schema.number.optional(),
        user_lock: schema.enum.optional(['0', '1', '2']),
        type: schema.enum.optional(['0', '1', '2', '3', '8', '9', '10', '11']),
        category: schema.enum.optional(['AGENT', 'CLIENT']),
      }),
    })

    const search = request.input('search')
    // const pageLimit = request.input('limit', 50)
    const sort = request.input('sort', 'usecrdt')
    const order = request.input('order', 'desc')

    if (authUser.usetype === 55) {
      authUser = await UserService.checkPersmission(authUser)

      if (!authUser) {
        return response.badRequest({ message: 'Invalid request.' })
      }
    }

    const isValidParent = await Parent.validate(authUser, authUser.mstrid)

    if (!isValidParent) {
      return response.badRequest({ message: 'Invalid request.' })
    }

    let query = Database.from('createmaster as cm')
      .leftJoin('user_pl_summary as ups', 'ups.user_id', 'cm.mstrid')
      .where('cm.parentId', data.userid)
      .whereNot('cm.usetype', 55)
      .whereNot('cm.mstrid', authUser.mstrid)

    if (search) {
      query.where((builder) => {
        builder
          .whereILike('cm.mstrname', `%${search}%`)
          .orWhereILike('cm.mstruserid', `%${search}%`)
          .orWhereILike('cm.phone', `%${search}%`)
          .orWhereILike('cm.email', `%${search}%`)
      })
    }

    if (data.type) {
      query.where('cm.usetype', data.type)
    }

    if (data.category === 'AGENT') {
      query.whereNot('cm.usetype', 3)
    } else if (data.category === 'CLIENT') {
      query.where('cm.usetype', 3)
    }

    if (data.user_lock && data.user_lock !== '2') {
      query.where('cm.mstrlock', data.user_lock)
    }

    query.select([
      'cm.balance',
      'cm.Commission',
      'cm.freeChips',
      'cm.domain',
      'cm.Liability',
      'cm.OtherComm',
      'cm.mstrid',
      'cm.P_L',
      'cm.SessionComm',
      'cm.active',
      'cm.create_no_of_child',
      'cm.ipadress',
      'cm.bet_lock',
      'cm.phone',
      'cm.mstrlock',
      'cm.mstrname',
      'cm.mstrremarks',
      'cm.mstruserid',
      'cm.parentId',
      'cm.partner',
      'cm.stakeLimit',
      'cm.usecrdt',
      'cm.usetype',
      'cm.email',
      'cm.partner_casino',
      'cm.partner_cricket',
      'cm.partner_tennis',
      'cm.partner_soccer',
      'cm.partner_dream',
      'cm.partner_binary',
      'cm.partner_election',
      'cm.partner_virtual_casino',
      'cm.rolling_commission',
      'cm.fancy_rolling_commission',
      'cm.profit_loss',
      Database.raw('COALESCE(ups.pl,0) as pl'),
      Database.raw('COALESCE(ups.settlement_amount,0) as settlementAmount'),
    ])

    query.orderBy(`cm.${sort}`, order)
    query.orderBy('cm.mstrlock', 'desc')

    const rows = await query;
    // data.page
    //   ? await query.paginate(data.page, pageLimit)
    //   : await query.limit(pageLimit)

    return response.json({
      data: { data: rows, meta: { total: rows.length } },
    })
  }

  public async store({ request, authUser, response }: HttpContextContract) {
    const typeId = request.input('typeId')
    const data: any = await request.validate({
      schema: schema.create({
        master_name: schema.string(),
        username: schema.string({}, [
          rules.unique({ table: 'createmaster', column: 'mstruserid' }),
          rules.alphaNum({
            allow: ['underscore'],
          }),
        ]),
        // password: schema.string([rules.minLength(6), rules.regex(/[A-Z]/)]),
        password: schema.string(),
        Commission: schema.number.optional([
          rules.requiredWhen('typeId', '=', 11),
          rules.range(0, 100),
        ]),
        sessionCommission: schema.number([rules.range(0, 100)]),
        rolling_commission: schema.number([rules.range(0, 100)]),
        fancy_rolling_commission: schema.number([rules.range(0, 100)]),
        remarks: schema.string.optional(),
        typeId: schema.enum([1, 2, 3, 8, 9, 10, 11]),
        parantId: schema.number(),
        HelperID: schema.string(),
        otherCommission: schema.number(),
        isPartnership: schema.boolean(),
        domain: schema.string.optional([
          rules.requiredWhen('typeId', '=', 11),
          rules.exists({ table: 'domains', column: 'value' }),
        ]),
        allow_deposit_withdraw: schema.boolean(),
        create_no_of_child: schema.number.optional([rules.requiredWhen('typeId', '!=', 3)]),
        partner_casino: schema.number.optional([
          rules.requiredWhen('isPartnership', '=', 'true'),
          rules.range(0, 100),
        ]),
        partner_cricket: schema.number.optional([
          rules.requiredWhen('isPartnership', '=', 'true'),
          rules.range(0, 100),
        ]),
        partner_tennis: schema.number.optional([
          rules.requiredWhen('isPartnership', '=', 'true'),
          rules.range(0, 100),
        ]),
        partner_soccer: schema.number.optional([
          rules.requiredWhen('isPartnership', '=', 'true'),
          rules.range(0, 100),
        ]),
        partner_dream: schema.number.optional([
          rules.requiredWhen('isPartnership', '=', 'true'),
          rules.range(0, 100),
        ]),
        partner_binary: schema.number.optional([
          rules.requiredWhen('isPartnership', '=', 'true'),
          rules.range(0, 100),
        ]),
        partner_election: schema.number.optional([
          rules.requiredWhen('isPartnership', '=', 'true'),
          rules.range(0, 100),
        ]),
        partner_virtual_casino: schema.number.optional([
          rules.requiredWhen('isPartnership', '=', 'true'),
          rules.range(0, 100),
        ]),
        deposit: schema.number([rules.range(0, typeId == 3 ? 1000000 : 500000000)]),
        reference: schema.string.optional(),
        allow_bet_delete: schema.boolean.optional([rules.requiredWhen('typeId', '=', 11)]),
        allow_result_declare: schema.boolean.optional([rules.requiredWhen('typeId', '=', 11)]),
        allow_result_revoke: schema.boolean.optional([rules.requiredWhen('typeId', '=', 11)]),
        // payment_type = 1 when manual else 0 for automatic
        payment_type: schema.number.optional(),
        bonus: schema.number.optional([rules.range(0, 100)]),
        casino_limit: schema.number.optional(),
      }),
      messages: {
        'username.alphaNum': 'The username can only include letters, numbers, and underscores.',
        'username.unique': 'Username is not available.',
        'password.minLength': 'Password must be at least {{ options.minLength }} characters.',
        'password.regex': 'Password must contain at least one uppercase letter.',
      },
    })

    data.payment_type = 1

    if (authUser.usetype == 55) {
      authUser = await UserService.checkPersmission(authUser)

      if (!authUser) {
        return response.badRequest({
          message: 'Invalid request.',
        })
      }
    }

    if (!(await Parent.validate(authUser, data.parantId))) {
      return response.badRequest({
        message: 'Invalid request.',
      })
    }

    const parent = await Database.from('createmaster').where('mstrid', data.parantId).first()

    if (parent) {
      if (data.typeId != 11) {
        data.domain = parent.domain
        data.Commission = parent.Commission
      } else {
        if (Application.inProduction && Env.get('SINGLE_DOMAIN', 'true') == 'true') {
          const domainUsed = await Database.from('createmaster')
            .where('domain', data.domain)
            .first()
          response.abortIf(domainUsed, {
            message: 'Domain has already been used by other company.',
          })
        }
      }

      if (data.typeId == 3) {
        data.payment_type = parent.payment_type
        const domain = await Database.from('domains').where('value', parent.domain).first()
        data.domain = domain.alternate_url
      }

      response.abortIf(data.Commission > parent.Commission, {
        message: 'Commission can not be greater than parent.',
      })

      response.abortIf(data.sessionCommission > parent.SessionComm, {
        message: 'Session commission can not be greater than parent.',
      })

      response.abortIf(data.rolling_commission > parent.rolling_commission, {
        message: 'Bookmaker rolling commission can not be greater than parent.',
      })

      response.abortIf(data.fancy_rolling_commission > parent.fancy_rolling_commission, {
        message: 'Fancy rolling commission can not be greater than parent.',
      })

      response.abortIf(data.partner_casino > parent.partner_casino, {
        message: 'Casino partnership can not be greater than ' + parent.partner_casino,
      })

      response.abortIf(data.partner_cricket > parent.partner_cricket, {
        message: 'Cricket partnership can not be greater than ' + parent.partner_cricket,
      })

      response.abortIf(data.partner_soccer > parent.partner_soccer, {
        message: 'Soccer partnership can not be greater than ' + parent.partner_soccer,
      })

      response.abortIf(data.partner_tennis > parent.partner_tennis, {
        message: 'Tennis partnership can not be greater than ' + parent.partner_tennis,
      })

      response.abortIf(data.partner_dream > parent.partner_dream, {
        message: 'Dream partnership can not be greater than ' + parent.partner_dream,
      })

      response.abortIf(data.partner_binary > parent.partner_binary, {
        message: 'Binary partnership can not be greater than ' + parent.partner_binary,
      })

      response.abortIf(data.partner_election > parent.partner_election, {
        message: 'Election partnership can not be greater than ' + parent.partner_election,
      })

      response.abortIf(data.partner_virtual_casino > parent.partner_virtual_casino, {
        message:
          'Virtual game partnership can not be greater than ' + parent.partner_virtual_casino,
      })

      const c = await Database.from('createmaster')
        .select(
          'createmaster.create_no_of_child as childuser',
          Database.from('createmaster')
            .where('parentId', data.parantId)
            .count('mstrid as tot_childcount')
            .as('tot_childcount')
        )
        .where('createmaster.mstrid', data.parantId)
        .first()

      if (parent.usetype != 0) data.allow_deposit_withdraw = parent.allow_deposit_withdraw

      response.abortIf(
        parent.usetype == 11 && parent.allow_deposit_withdraw == 1 && data.typeId != 1,
        {
          message: 'You can only create a master account.',
        }
      )

      // if (Env.get('SINGLE_DEALER', 'true') == 'true') {

      const m = await Database.from('createmaster')
        .where('parentId', data.parantId)
        .where('usetype', 1)
        .first()
      response.abortIf(
        parent.usetype == 11 && parent.allow_deposit_withdraw == 1 && data.typeId == 1 && m,
        {
          message: 'You can only create one master account.',
        }
      )
      // }

      // child can not create parent validation
      if (
        (parent.usetype == 0 && [1, 2, 3, 8, 9, 10, 11].indexOf(data.typeId) > -1) ||
        (parent.usetype == 11 && [1, 2, 3, 8, 9, 10].indexOf(data.typeId) > -1) ||
        (parent.usetype == 10 && [1, 2, 3, 8, 9].indexOf(data.typeId) > -1) ||
        (parent.usetype == 9 && [1, 2, 3, 8].indexOf(data.typeId) > -1) ||
        (parent.usetype == 8 && [1, 2, 3].indexOf(data.typeId) > -1) ||
        (parent.usetype == 1 && [2, 3].indexOf(data.typeId) > -1) ||
        (parent.usetype == 2 && [3].indexOf(data.typeId) > -1)
      ) {
        response.abortIf(!c, {
          message: 'Could not save user.',
        })

        if (c.tot_childcount < c.childuser || data.parantId == 1) {
          if (data.typeId == 3) {
            data.Partner = 0
            data['create_no_of_child'] = 0
            // data['sessionCommission'] = 0
            // data['Commission'] = 1
          }

          if (data.isPartnership && data.typeId == 11) {
            response.abortIf(data.partner_casino <= 0, {
              message: 'Casino partnership must be greater than 0.',
            })

            response.abortIf(data.partner_cricket <= 0, {
              message: 'Cricket partnership must be greater than 0.',
            })

            response.abortIf(data.partner_soccer <= 0, {
              message: 'Soccer partnership must be greater than 0.',
            })

            response.abortIf(data.partner_tennis <= 0, {
              message: 'Tennis partnership must be greater than 0.',
            })

            response.abortIf(data.partner_dream <= 0, {
              message: 'Dream partnership must be greater than 0.',
            })

            response.abortIf(data.partner_binary <= 0, {
              message: 'Binary partnership must be greater than 0.',
            })

            response.abortIf(data.partner_election <= 0, {
              message: 'Election partnership must be greater than 0.',
            })

            response.abortIf(data.partner_virtual_casino <= 0, {
              message: 'Virtual game partnership must be greater than 0.',
            })
          }

          // add deposit validation
          if (data.deposit > 0) {
            const Result1 = await UserService.getLiability(data.parantId)
            const pokerLiability: any = await UserService.getPokerLiability(data.parentId)
            const kingLiability: any = await UserService.getKingLiability(data.parentId)
            if (Result1[0].Balance - pokerLiability - kingLiability < data.deposit) {
              return response.badRequest({
                message: 'Insufficient balance.',
              })
            }
          }

          data.FromDate = DateTime.now().toFormat('yyyy-MM-dd')

          // generate username
          // 11 Company
          // 10 Super Admin
          // 9  Sub Admin
          // 8  Super Master
          // 1  Master
          // 2  Dealer
          // 3  User
          // Auto Generate user id will start with
          // Adimin: AD1, Sub company: SC1, Super Stockist: SST1, Stockist: SS1, Super Agent: SA1, User: SP1

          let mstrid = 0
          const trx = await Database.transaction()
          try {
            const addUser = await trx
              .table('createmaster')
              .returning('mstrid')
              .insert({
                mstrname: data.master_name,
                mstruserid: data.username,
                mstrpassword: Database.raw('sha1(:password)', { password: data.password }),
                usetype: data.typeId,
                mstrremarks: data.remarks || '',
                ipadress: request.ip(),
                loginid: authUser.mstrid,
                parentId: data.parantId,
                usecrdt: new Date(),
                partner: data.Partner || 0,
                Commission: 0,
                SessionComm: data.sessionCommission,
                rolling_commission: data.rolling_commission,
                fancy_rolling_commission: data.fancy_rolling_commission,
                OtherComm: 0,
                create_no_of_child: data.create_no_of_child,
                HelperID: data.HelperID,
                isPartnership: data.isPartnership,
                partner_casino: data.partner_casino ? data.partner_casino : 0,
                partner_cricket: data.partner_cricket ? data.partner_cricket : 0,
                partner_tennis: data.partner_tennis ? data.partner_tennis : 0,
                partner_soccer: data.partner_soccer ? data.partner_soccer : 0,
                partner_dream: data.partner_dream ? data.partner_dream : 0,
                partner_binary: data.partner_binary ? data.partner_binary : 0,
                partner_election: data.partner_election ? data.partner_election : 0,
                partner_virtual_casino: data.partner_virtual_casino
                  ? data.partner_virtual_casino
                  : 0,

                domain: data.domain,
                allow_deposit_withdraw: data.allow_deposit_withdraw,
                allow_bet_delete: data.allow_bet_delete || false,
                allow_result_declare: data.allow_result_declare || false,
                allow_result_revoke: data.allow_result_revoke || false,
                is_demo: data.typeId == 3 ? request.header('X-code') == Auto.code : 0,
                payment_type: data.payment_type || 0,
                deposit_bonus: data.bonus || 0,
                gamehub_password: Encryption.encrypt(cuid().toLowerCase()),
              })

            response.abortIf(addUser.length == 0, {
              message: 'Could not save user.',
            })

            mstrid = addUser[0]

            if (data.typeId == 11) {
              await trx
                .from('domains')
                .where('value', data.domain)
                .update({ show_register: data.allow_deposit_withdraw })
            }

            // add balance
            if (data.deposit > 0) {
              const insertId = await trx
                .table('tblchips')
                .insert({
                  MstDate: new Date(),
                  UserID: mstrid,
                  RefID: data.reference || '',
                  LoginID: authUser.mstrid,
                  CrDr: 1,
                  Chips: data.deposit,
                  txnId: 0,
                  IsFree: 1,
                  Narration: 'Upper Loan',
                  HelperID: 0,
                })
                .returning('MstCode')

              const insId = insertId[0]

              await trx.table('tblchips').insert({
                MstDate: new Date(),
                UserID: data.parantId,
                RefID: data.reference || '',
                LoginID: authUser.mstrid,
                CrDr: 2,
                Chips: -data.deposit,
                txnId: insId,
                IsFree: 1,
                Narration: data.username + ' loan',
                HelperID: 0,
              })

              // Maintain denormalised balance columns incrementally inside the same
              // transaction (replaces the dead UpdateLiability job): credit the new
              // user's free chips, debit the parent's (the loan).
              await LiabilityEngine.applyChip(trx, { accountId: mstrid, freechips: data.deposit })
              await LiabilityEngine.applyChip(trx, {
                accountId: data.parantId,
                freechips: -data.deposit,
              })
            }

            // Build the tblpartner share matrix from a single, data-driven rule
            // (see PartnershipCalculator) — replaces ~600 lines of hand-unrolled,
            // bug-prone per-(typeId × game × level) assignments.
            const parentPartner = await trx
              .from('tblpartner')
              .where('UserID', data.parantId)
              .first()

            const shareRow = PartnershipCalculator.compute(
              parentPartner,
              parent.usetype,
              data.typeId,
              {
                cricket: data.partner_cricket,
                soccer: data.partner_soccer,
                tennis: data.partner_tennis,
                casino: data.partner_casino,
                dream: data.partner_dream,
                binary: data.partner_binary,
                election: data.partner_election,
                virtual_casino: data.partner_virtual_casino,
              },
              !!data.isPartnership
            )

            await trx.table('tblpartner').insert({
              TypeID: data.typeId,
              ParentID: data.parantId,
              UserID: mstrid,
              ...shareRow,
            })

            let v: any = await Cache.get('defaultStake')

            if (v) {
              await trx
                .from('createmaster')
                .where('mstrid', mstrid)
                .update({
                  match_stake: JSON.stringify(v.map((el: any) => el.value)),
                })
            } else {
              await trx
                .from('createmaster')
                .where('mstrid', mstrid)
                .update({
                  match_stake: JSON.stringify([100, 200, 300, 500, 1000]),
                })
            }

            // All createmaster + tblpartner + tblchips writes commit atomically.
            await trx.commit()
          } catch (err) {
            await trx.rollback()
            throw err
          }

          if (!data.allow_deposit_withdraw && data.typeId == 11) {
            try {
              const company: any = await Database.from('createmaster')
                .where('mstrid', mstrid)
                .first()

              const domain = await Database.from('domains').where('value', data.domain).first()
              const domainId = domain.id
              const dealerPayload: any = {
                master_name: 'dealer' + domainId,
                FromDate: DateTime.now().toFormat('yyyy-MM-dd'),
                username: 'dealer' + domainId,
                password: '12345A',
                Commission: '1.00',
                sessionCommission: '0.00',
                remarks: '',
                typeId: 2,
                parantId: company.mstrid,
                HelperID: '0',
                rolling_commission: 0,
                otherCommission: 0,
                allow_deposit_withdraw: 0,
                isPartnership: 0,
                deposit: data.deposit > 1000 ? 1000 : 0,
                reference: '',
                partner_casino: 0,
                create_no_of_child: 1000000,
                partner_soccer: 0,
                partner_cricket: 0,
                partner_tennis: 0,
                partner_dream: 0,
                partner_binary: 0,
                partner_election: 0,
                partner_virtual_casino: 0,
              }

              const apiUrl = data.domain + '/api/admin/users'

              const headers: any = {
                'X-code': Auto.code,
                'Content-Type': 'application/json',
              }

              await axios.post(apiUrl, dealerPayload, {
                headers,
              })

              await this.sleep(500)

              const dealer: any = await Database.from('createmaster')
                .where('mstruserid', 'dealer' + domainId)
                .first()

              const userPayload = {
                master_name: 'user' + domainId,
                FromDate: DateTime.now().toFormat('yyyy-MM-dd'),
                username: 'user' + domainId,
                password: '12345A',
                Commission: '1.00',
                sessionCommission: '0.00',
                rolling_commission: 0,
                remarks: '',
                typeId: 3,
                parantId: dealer.mstrid,
                HelperID: '0',
                otherCommission: 0,
                allow_deposit_withdraw: 0,
                isPartnership: 0,
                deposit: data.deposit > 1000 ? 1000 : 0,
                reference: '',
              }

              await axios.post(apiUrl, userPayload, {
                headers,
              })
            } catch (err) {
              console.log('DEMO', JSON.stringify(err))
            }
          }

          if (data.typeId == 11) {
            await Mongo.collection('casino_limit_logs').insertOne({
              companyName: data.master_name,
              casino_limit: data.casino_limit || 0,
              createdAt: new Date(),
              updatedAt: new Date(),
            })
          }

          return response.json({
            message: 'User Created.',
          })
        } else {
          return response.badRequest({
            message: 'Child limit reached',
          })
        }
      } else {
        return response.badRequest({
          message: 'User can not create parent.',
        })
      }
    }

    return response.badRequest({
      message: 'Parent does not exists.',
    })
  }

  public async show({ authUser, request, params, response }: HttpContextContract) {
    if (authUser.usetype == 55) {
      authUser = await UserService.checkPersmission(authUser)

      if (!authUser) {
        return response.badRequest({
          message: 'Invalid request.',
        })
      }
    }

    if (!(await Parent.validate(authUser, params.id))) {
      return response.badRequest({
        message: 'Invalid request.1',
      })
    }

    const user = await Database.from('createmaster')
      .where('mstrid', params.id)
      .select(
        'createmaster.*',
        Database.raw(
          '(SELECT COUNT(*) FROM createmaster WHERE parentId = :parentId) as childCount',
          { parentId: params.id }
        )
      )
      .first()

    delete user.mstrpassword
    delete user.betfair_session_token

    user.singleDealer = JSON.parse(Env.get('SINGLE_DEALER', 'true'))

    const settlementAmount = await Sp.call('_settlement_amount(:userId)', {
      userId: params.id,
    })

    user.settlementAmount = settlementAmount[0]?.amount || 0
    const type = request.input('createtype')
    let username = ''
    if (type) {
      if (!(await Redis.exists('userCount'))) {
        const lastUser = await Database.from('createmaster').orderBy('mstrid', 'desc').first()
        await Redis.set('userCount', lastUser.mstrid + 1)
      }

      const prefixes: Record<number, string> = {
        10: 'AD',
        9: 'SC',
        8: 'SST',
        1: 'SS',
        2: 'SA',
        3: 'SP',
      }
      const prefix = prefixes[type]

      if (prefix) {
        // Keep advancing the counter until the candidate is actually free in
        // createmaster. The counter is seeded from mstrid and can drift out of
        // sync with existing mstruserid values (Redis re-seed, historical
        // usernames that don't map 1:1 to mstrid), so a raw counter value can
        // collide with an existing account — which left the (readonly) username
        // field permanently showing "Username already exit". Looping on a real
        // uniqueness check guarantees the suggested username is always available.
        do {
          const count = await Redis.incr('userCount')
          username = prefix + (count + 1)
        } while (await Database.from('createmaster').where('mstruserid', username).first())
      }
    }
    return response.json({
      data: user,
      username,
    })
  }

  // public async getUserData({ request, authUser, response }: HttpContextContract) {
  //   const data = await request.validate({
  //     schema: schema.create({
  //       userid: schema.number(),
  //     }),
  //   })

  //   if (!(await Parent.validate(authUser, data.userid))) {
  //     return response.badRequest({
  //       message: 'Invalid request.',
  //     })
  //   }

  //   const rows = await Database.from('createmaster')
  //     .where('parentId ', data.userid)
  //     .select(['mstrid', 'mstrname', 'mstruserid', 'usetype'])

  //   return response.json({
  //     data: rows,
  //   })
  // }

  public async changeUserPassword({ request, authUser, response }: HttpContextContract) {
    const data = await request.validate({
      schema: schema.create({
        // newPassword: schema.string([rules.minLength(6), rules.regex(/[A-Z]/)]),
        newPassword: schema.string(),
        userId: schema.number(),
      }),
      messages: {
        'newPassword.minLength': 'Password must be at least {{ options.minLength }} characters.',
        'newPassword.regex': 'Password must contain at least one uppercase letter.',
      },
    })

    if (authUser.mstrid == data.userId) {
      return response.badRequest({
        message: 'Invalid request.',
      })
    }

    if (!(await Parent.validate(authUser, data.userId)) && authUser.usetype != 55) {
      return response.badRequest({
        message: 'Invalid request.',
      })
    }

    await UserService.changePassword(data.userId, data.newPassword, false)

    const passwordHistory = {
      user_id: data.userId,
      changer_id: authUser.mstrid,
      ip: request.ip(),
      created_at: new Date(),
    }

    await Database.table('password_history').insert(passwordHistory)

    return response.json({
      message: 'Password changed.',
    })
  }

  public async chipSummary({ request, authUser, response }: HttpContextContract) {
    const data = await request.validate({
      schema: schema.create({
        mstrid: schema.number(),
        sportId: schema.string.nullableAndOptional(),
        matchId: schema.string.nullableAndOptional(),
        useCache: schema.boolean.optional(),
        cacheRefresh: schema.boolean.optional(),
      }),
    })

    if (!(await Parent.validate(authUser, data.mstrid))) {
      return response.badRequest({
        message: 'Invalid request.',
      })
    }

    let plusData: any[] = []
    let minusData: any[] = []
    let isRedisEmpty = true
    const cacheKey = `chip_summary:${data.mstrid}`

    if (data.cacheRefresh) {
      // Delete the existing cache if cacheRefresh is true
      await Redis.del(cacheKey)
    }

    if (data.useCache) {
      const cached = await Redis.get(cacheKey)
      if (cached) {
        isRedisEmpty = false
        const parsed = JSON.parse(cached)
        return response.json({
          ...parsed,
          source: 'redis',
        })
      } else {
        isRedisEmpty = true
      }
    }

    if (isRedisEmpty) {
      if (!data.sportId && !data.matchId) {
        const v = await request.validate({
          schema: schema.create({
            typeId: schema.number.optional(),
          }),
        })
        plusData = await Sp.call('_chip_summary_plus(:user_id,:type_id)', {
          user_id: data.mstrid,
          type_id: v.typeId,
        })

        minusData = await Sp.call('_chip_summary_minus(:user_id,:type_id)', {
          user_id: data.mstrid,
          type_id: v.typeId,
        })
      } else if (data.matchId) {
        plusData = await Sp.call('_chip_summary_plus_match(:user_id,:matchId)', {
          user_id: data.mstrid,
          matchId: data.matchId,
        })

        minusData = await Sp.call('_chip_summary_minus_match(:user_id,:matchId)', {
          user_id: data.mstrid,
          matchId: data.matchId,
        })
      } else {
        plusData = await Sp.call('_chip_summary_plus_sport(:userId,:sportId)', {
          userId: data.mstrid,
          sportId: data.sportId,
        })

        minusData = await Sp.call('_chip_summary_minus_sport(:userId,:sportId)', {
          userId: data.mstrid,
          sportId: data.sportId,
        })
      }
    }

    const result = {
      data: { plusData, minusData },
    }
    if (data.useCache && isRedisEmpty) {
      await Redis.set(cacheKey, JSON.stringify(result))
    }

    return response.json({
      data: { plusData, minusData },
    })
  }

  public async clearChip({ request, authUser, response }: HttpContextContract) {
    const data = await request.validate({
      schema: schema.create({
        Chips: schema.number(),
        CrDr: schema.enum([1, 2]),
        IsFree: schema.number(),
        Narration: schema.string.optional(),
        discount: schema.number(),
        userId: schema.number(),
        sportId: schema.number.optional(),
      }),
    })

    if (
      !(await Parent.validate(authUser, data.userId)) ||
      data.Chips < 0 ||
      authUser.usetype == 3
    ) {
      return response.badRequest({
        message: 'Invalid request.',
      })
    }

    const user = await Database.query()
      .from('createmaster')
      .where('mstrid', data.userId)
      .firstOrFail()

    const parent = await Database.query()
      .from('createmaster')
      .where('mstrid', user.parentId)
      .first()

    let sportName = 'cricket'

    if (data.sportId == 1) {
      sportName = 'soccer'
    } else if (data.sportId == 2) {
      sportName = 'tennis'
    } else if (data.sportId == 11) {
      sportName = 'virtual_casino'
    } else if (data.sportId == 6) {
      sportName = 'election'
    } else if (data.sportId == 77) {
      sportName = 'binary'
    }

    const partnershipData: any = await Cache.rememberForever(
      'partnership:' + data.userId,
      async () => {
        return await Database.from('tblpartner').where('UserID', data.userId).firstOrFail()
      }
    )

    const superDuperAdminPartnership = parseFloat(partnershipData['super_duper_admin_' + sportName])
    const companyPartnership = parseFloat(partnershipData['company_' + sportName])
    const superAdminPartnership = parseFloat(partnershipData['super_admin_' + sportName])
    const subAdminPartnership = parseFloat(partnershipData['sub_admin_' + sportName])
    const superMasterPartnership = parseFloat(partnershipData['super_master_' + sportName])
    const masterPartnership = parseFloat(partnershipData['master_' + sportName])
    const dealerPartnership = parseFloat(partnershipData['dealer_' + sportName])

    let totalPartnership = 0
    if (user.usetype == 11) {
      totalPartnership += superDuperAdminPartnership
    } else if (user.usetype == 10) {
      totalPartnership += superDuperAdminPartnership + companyPartnership
    } else if (user.usetype == 9) {
      totalPartnership += superDuperAdminPartnership + companyPartnership + superAdminPartnership
    } else if (user.usetype == 8) {
      totalPartnership +=
        superDuperAdminPartnership +
        companyPartnership +
        superAdminPartnership +
        subAdminPartnership
    } else if (user.usetype == 1) {
      totalPartnership +=
        superDuperAdminPartnership +
        companyPartnership +
        superAdminPartnership +
        subAdminPartnership +
        superMasterPartnership
    } else if (user.usetype == 2) {
      totalPartnership +=
        superDuperAdminPartnership +
        companyPartnership +
        superAdminPartnership +
        subAdminPartnership +
        superMasterPartnership +
        masterPartnership
    } else {
      totalPartnership +=
        superDuperAdminPartnership +
        companyPartnership +
        superAdminPartnership +
        subAdminPartnership +
        superMasterPartnership +
        masterPartnership +
        dealerPartnership
    }

    // if (totalPartnership < 100) {
    //   console.log(totalPartnership)
    //   return response.badRequest({
    //     message: 'There is an issue in partnership.',
    //   })
    // }

    if (totalPartnership > 100 || user.usetype == 3) {
      totalPartnership = 1
    } else {
      totalPartnership = 100 - totalPartnership || 1
    }

    const originalAmount = data.Chips

    const amount = data.Chips * totalPartnership

    // let userBalance = user.balance
    // if (user.usetype == 3) {
    //   const Result1 = await UserService.getLiability(data.userId)
    //   const pokerLiability: any = await UserService.getPokerLiability(data.userId)
    //   const kingLiability: any = await UserService.getKingLiability(data.userId)
    //   userBalance = Result1[0].Balance - pokerLiability - kingLiability
    // }

    // // plus users
    // if (amount > userBalance && data.CrDr == 1) {
    //   return response.badRequest({
    //     message: 'Insufficient balance.',
    //   })
    // }

    // // minus users
    // if (amount > +parseFloat(parent.balance + parent.freechips) && data.CrDr == 2) {
    //   return response.badRequest({
    //     message: 'Insufficient balance.',
    //   })
    // }

    const GetCHiPSPL = await Database.rawQuery(
      'SELECT SUM(a.ChipsDr-a.ChipsCr) chipspnl FROM tblchipdet a INNER JOIN createmaster b ON b.mstrid = a.oppAcID WHERE a.ChildID=:uid GROUP BY b.mstrid, usetype, mstruserid, mstrname, ChildID',
      {
        uid: data.userId,
      }
    )

    let getChips = GetCHiPSPL[0]

    if (originalAmount <= Math.abs(getChips[0].chipspnl)) {
      let Result2 = await Sp.call(
        '_clear_chip(:user_id,:loginId,:crDr,:chips,:isFree,:narration,:parent_id,:originalAmount)',
        {
          user_id: data.userId,
          loginId: authUser.mstrid,
          crDr: data.CrDr,
          chips: amount,
          isFree: data.IsFree,
          narration: data.Narration || '',
          parent_id: user.parentId,
          originalAmount: originalAmount,
        }
      )

      const mongoData = {
        type: 'SETTLEMENT',
        category: 'CHIP SUMMARY',
        userId: user?.mstrid,
        username: user?.mstruserid,
        betId: null,
        beforeBalance: user?.balance,
        beforeLiability: user?.liability,
        amount,
      }

      await UserService.updateLiability([{ id: data.userId }], mongoData, 'add')

      const mongoParentData = {
        type: 'SETTLEMENT',
        category: 'CHIP SUMMARY',
        userId: parent?.mstrid,
        username: parent?.mstruserid,
        betId: null,
        beforeBalance: parent?.balance,
        beforeLiability: parent?.liability,
        amount,
      }

      await UserService.updateLiability([{ id: parent?.mstrid }], mongoParentData, 'add')

      response.json({
        message: Result2[0].retMess,
      })
    } else {
      response.badRequest({
        message: 'Settlement amount must be less then or equal to ' + getChips[0].chipspnl,
      })
    }
  }

  // public async chipHistoryID({ request, authUser, response }: HttpContextContract) {
  //   const data = await request.validate({
  //     schema: schema.create({
  //       parentId: schema.string(),
  //       userId: schema.string(),
  //       parentData: schema.boolean.optional(),
  //     }),
  //   })
  //   // tanya changes start for adding match id
  //   let matchId = request.input('matchId')

  //   if (matchId && String(matchId).length > 0) {
  //     matchId = String(matchId)
  //   } else {
  //     matchId = 0
  //   }
  //   // tanya changes end for adding match id

  //   if (!(await Parent.validate(authUser, data.userId))) {
  //     return response.badRequest({
  //       message: 'Invalid request.',
  //     })
  //   }

  //   if (data.parentData) {
  //     const parent = await Database.from('createmaster').where('mstrid', authUser.parentId).first()
  //     data.parentId = parent.parentId
  //     data.userId = parent.mstrid
  //   }

  //   let Result = await Sp.call(
  //     '_ledger(:type,:userId,:chipType,:parrentId,:fromDate,:toDate,:matchId)',
  //     {
  //       type: authUser.usetype,
  //       userId: data.userId,
  //       chipType: '5',
  //       parrentId: data.parentId,
  //       fromDate: null,
  //       toDate: null,
  //       matchId: matchId,
  //     }
  //   )

  //   response.json({
  //     data: Result,
  //   })
  // }

  public async chipHistoryID({ request, authUser, response }: HttpContextContract) {
    const data = await request.validate({
      schema: schema.create({
        parentId: schema.string(),
        userId: schema.string(),
        parentData: schema.boolean.optional(),
        page: schema.number.optional(),
        matchId: schema.string.optional(),
        filterType: schema.enum.optional(['ALL', 'Match', 'Single', 'Settlement']),
        typeId: schema.number.optional(),
      }),
    })

    const limit = Number(request.input('limit', 50))
    const filterType = data.filterType ?? 'ALL'

    // If matchId not provided or empty → pass '0'
    const matchId = data.matchId && data.matchId.length > 0 ? data.matchId : '0'

    if (!(await Parent.validate(authUser, data.userId))) {
      return response.badRequest({
        message: 'Invalid request.',
      })
    }

    if (data.parentData) {
      const parent = await Database.from('createmaster').where('mstrid', authUser.parentId).first()

      data.parentId = parent.parentId
      data.userId = parent.mstrid
    }

    // Fast path for the heavy full ledger ('ALL', no specific match/type filter):
    // efficient DB-side pagination (window function + LIMIT) instead of fetching the
    // entire 100k+ row history and slicing it in app memory. Filtered/typed/match
    // views fall through to the SP + app-side pagination below (they return few rows).
    if (data.page && filterType === 'ALL' && matchId === '0' && !data.typeId) {
      return this.chipHistoryPaginated(data, Number(data.page), request, response)
    }

    let Result = await Sp.call(
      '_ledger(:type,:userId,:chipType,:parrentId,:fromDate,:toDate,:matchId,:filterType)',
      {
        type: authUser.usetype,
        userId: data.userId,
        chipType: '5',
        parrentId: data.parentId,
        fromDate: null,
        toDate: null,
        matchId: matchId,
        filterType: filterType,
      }
    )

    if (matchId == '0' && data.typeId) {
      Result = Result.filter((item: any) => item.TypeID === data.typeId)
    }

    if (data.page) {
      const page = data.page
      const offset = (page - 1) * limit
      const paginatedData = Result.slice(offset, offset + limit)

      return response.json({
        data: paginatedData,
        meta: {
          total: Result.length,
          page,
          perPage: limit,
          lastPage: Math.ceil(Result.length / limit),
        },
      })
    }

    return response.json({
      data: Result,
    })
  }

  /**
   * Paginated equivalent of the `_ledgerAll` full ledger (chipType '5'). Mirrors
   * the procedure's two branches exactly, but computes the running Balance with a
   * window function (identical to the SP's row-by-row `@runtot`) and returns only
   * the requested page plus a `meta` block for the UI's paginator.
   */
  private async chipHistoryPaginated(
    data: { userId: any; parentId: any },
    page: number,
    request: HttpContextContract['request'],
    response: HttpContextContract['response']
  ) {
    const perPage = Math.min(Math.max(Number(request.input('limit', 50)) || 50, 1), 500)
    const offset = (page - 1) * perPage
    const parentId = Number(data.parentId)

    // Match _ledgerAll: parentId > 0 filters by the (UserID, oppAcID) pair and
    // blanks oppAcID in the output; otherwise it's the chipType '5' branch
    // (msttype 5..49, fancy markets show fancyid as MarketId).
    let whereSql: string
    let whereBindings: any[]
    let oppAcCol: string
    let marketCol: string
    if (parentId > 0) {
      whereSql = 'a.UserID = ? AND a.oppAcID = ?'
      whereBindings = [data.userId, parentId]
      oppAcCol = '0 AS oppAcID'
      marketCol = 'a.MarketId AS MarketId'
    } else {
      whereSql = 'a.UserID = ? AND a.msttype > 4 AND a.msttype < 50'
      whereBindings = [data.userId]
      oppAcCol = 'a.oppAcID AS oppAcID'
      marketCol = 'CASE WHEN a.msttype = 8 THEN a.fancyid ELSE a.MarketId END AS MarketId'
    }

    const dataSql = `
      SELECT * FROM (
        SELECT
          ROUND(a.ChipsCr, 2) AS Credit,
          ROUND(a.ChipsDr, 2) AS Debit,
          a.MatchId,
          ${marketCol},
          a.MstDate AS EDate,
          a.narration,
          a.msttype AS TypeID,
          a.UserID,
          IFNULL(a.childid, 0) AS ChildID,
          ROUND(SUM(a.ChipsCr - a.ChipsDr) OVER (
            ORDER BY a.MstDate, a.MstCode, a.CrDr
            ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
          ), 2) AS Balance,
          a.MstCode AS Mstcode,
          a.CrDr,
          ${oppAcCol}
        FROM tblchipdet a
        WHERE ${whereSql}
      ) X
      ORDER BY EDate DESC, Mstcode DESC, CrDr
      LIMIT ? OFFSET ?`

    const countSql = `SELECT COUNT(*) AS total FROM tblchipdet a WHERE ${whereSql}`

    const [rowsRes, countRes] = await Promise.all([
      Database.rawQuery(dataSql, [...whereBindings, perPage, offset], { mode: 'read' }),
      Database.rawQuery(countSql, whereBindings, { mode: 'read' }),
    ])

    const rows = rowsRes[0]
    const total = Number(countRes[0][0]?.total || 0)

    return response.json({
      data: rows,
      meta: {
        total,
        perPage,
        currentPage: page,
        lastPage: Math.max(Math.ceil(total / perPage), 1),
      },
    })
  }

  public async chipHistoryParentID({ request, authUser, response }: HttpContextContract) {
    const data = await request.validate({
      schema: schema.create({
        parentId: schema.string(),
        userId: schema.string(),
        parentData: schema.boolean.optional(),
        filterType: schema.enum.optional(['ALL', 'Match', 'Single', 'Settlement']),
        page: schema.number.optional(),
      }),
    })
    const limit = Number(request.input('limit', 50))

    if (!(await Parent.validate(authUser, data.userId))) {
      return response.badRequest({
        message: 'Invalid request.',
      })
    }

    if (data.parentData) {
      const parent = await Database.from('createmaster').where('mstrid', authUser.parentId).first()
      data.parentId = parent.parentId
      data.userId = parent.mstrid
    }

    // The `_ledger_parent` SP is an expensive aggregation that returns the full
    // result set; pagination is applied in-memory below. Cache the full result
    // for a short window so paging (page=1,2,3…) doesn't re-run the SP each time.
    const ledgerCacheKey = `ledger_parent:${authUser.usetype}:${data.userId}:${data.parentId}:${data.filterType ?? 'ALL'}`

    let Result = await Cache.remember(ledgerCacheKey, 30, async () =>
      Sp.call('_ledger_parent(:type,:userId,:chipType,:parrentId,:fromDate,:toDate, :filterType)', {
        type: authUser.usetype,
        userId: data.userId,
        chipType: '5',
        parrentId: data.parentId,
        fromDate: null,
        toDate: null,
        filterType: data.filterType,
      })
    )

    if (data.page) {
      const page = data.page
      const offset = (page - 1) * limit
      const paginatedData = Result.slice(offset, offset + limit)

      return response.json({
        data: paginatedData,
        meta: {
          total: Result.length,
          page,
          perPage: limit,
          lastPage: Math.ceil(Result.length / limit),
        },
      })
    }

    return response.json({
      data: Result,
    })
  }

  public async chipHistoryWithMatchId({ request, authUser, response }: HttpContextContract) {
    const data = await request.validate({
      schema: schema.create({
        parentId: schema.string(),
        userId: schema.string(),
        parentData: schema.boolean.optional(),
        matchId: schema.string(),
      }),
    })

    if (!(await Parent.validate(authUser, data.userId))) {
      return response.badRequest({
        message: 'Invalid request.',
      })
    }

    if (data.parentData) {
      const parent = await Database.from('createmaster').where('mstrid', authUser.parentId).first()
      data.parentId = parent.parentId
      data.userId = parent.mstrid
    }

    let Result = await Sp.call(
      '_ledger_matchID(:type,:userId,:chipType,:parentId,:matchId,:fromDate,:toDate)',
      {
        type: authUser.usetype,
        userId: data.userId,
        chipType: '5',
        parentId: data.parentId,
        fromDate: null,
        toDate: null,
        matchId: data.matchId,
      }
    )

    response.json({
      data: Result,
    })
  }

  public async updateComm({ request, response }: HttpContextContract) {
    const data = await request.validate({
      schema: schema.create({
        HelperID: schema.number(),
        ID: schema.number(),
        oddsComm: schema.number(),
        otherComm: schema.number(),
        sessionComm: schema.number(),
      }),
    })

    const user = await Database.from('createmaster').where('mstrid', data.ID).first()
    const parent = await Database.from('createmaster').where('mstrid', user.parentId).first()
    if (parent) {
      response.abortIf(data.sessionComm > parent.SessionComm, {
        message: 'Session commission can not be greater than parent.',
      })

      data.oddsComm = parent.usetype == 11 ? data.oddsComm : user.Commission

      await Database.from('createmaster').where('mstrid', data.ID).update({
        Commission: data.oddsComm,
        SessionComm: data.sessionComm,
        OtherComm: data.otherComm,
        HelperID: data.HelperID,
      })

      return response.json({
        message: 'Data updated.',
      })
    }

    return response.badRequest({
      message: 'Parent not found.',
    })
  }

  public async coinLedger({ request, authUser, response }: HttpContextContract) {
    const data = await request.validate({
      schema: schema.create({
        toDate: schema.string.optional(),
        fromDate: schema.string.optional(),
        selectType: schema.number(),
        userId: schema.number(),
        usertype: schema.number(),
        matchId: schema.string.optional(),
        filterType: schema.enum.optional(['ALL', 'Match', 'Single', 'Settlement']),
        page: schema.number.optional(),
      }),
    })
    const limit = Number(request.input('limit', 50))

    if (!(await Parent.validate(authUser, data.userId))) {
      return response.badRequest({
        message: 'Invalid request.',
      })
    }

    const matchId = data.matchId && data.matchId.length > 0 ? data.matchId : '0'

    const Result = await Sp.call(
      '_ledger(:type,:userID,:chipType,:parentID,:from,:to,:matchId,:filterType)',
      {
        type: data.usertype,
        userID: data.userId,
        chipType: data.selectType,
        parentID: 0,
        from: data.fromDate,
        to: data.toDate,
        matchId: matchId,
        filterType: data.filterType ?? 'ALL',
      }
    )

    if (data.page) {
      const page = data.page
      const offset = (page - 1) * limit
      const paginatedData = Result.slice(offset, offset + limit)

      return response.json({
        data: paginatedData,
        meta: {
          total: Result.length,
          page,
          perPage: limit,
          lastPage: Math.ceil(Result.length / limit),
        },
      })
    }

    return response.json({
      data: Result,
    })
  }

  public async updateAccount({ request, authUser, response }: HttpContextContract) {
    const data = await request.validate({
      schema: schema.create({
        HelperID: schema.number(),
        Name: schema.string(),
        create_no_of_child: schema.number(),
        id: schema.number(),
        parantId: schema.number(),
        remarks: schema.string.optional(),
        userType: schema.number(),
      }),
    })

    if (authUser.mstrid == data.id) {
      return response.badRequest({
        message: 'Invalid request.',
      })
    }

    if (!(await Parent.validate(authUser, data.id))) {
      return response.badRequest({
        message: 'Invalid request.',
      })
    }

    const user = await Database.from('createmaster').where('mstrid', data.id).first()

    const parent = await Database.from('createmaster').where('mstrid', user.parentId).first()

    if (parent) {
      const { totalChild } = await Database.from('createmaster')
        .where('parentId', user.parentId)
        .count('mstrid')
        .first()

      if (data.create_no_of_child < totalChild && data.userType !== 3) {
        return response.badRequest({
          message: 'No of users must be less than or equal to' + totalChild,
        })
      } else {
        await Database.from('createmaster')
          .where('mstrid', data.id)
          .update({
            mstrname: data.Name,
            mstrRemarks: data.remarks || '',
            create_no_of_child: data.create_no_of_child,
            HelperID: data.HelperID,
          })

        await UserService.deleteKeys(await Redis.keys('matchmarkets:*' + data.id))

        const keys = await Redis.keys('auth:' + data.id + '|*')

        for (const key of keys) {
          let user: any = await Cache.get(key)
          if (user) {
            user.mstrname = data.Name
            await Cache.put(key, user, 3600)
          }
        }

        let userData = {
          user_id: data.id,
          data: {
            type: 'balance',
            data: {
              mstrname: data.Name,
              mstrRemarks: data.remarks || '',
              create_no_of_child: data.create_no_of_child,
              HelperID: data.HelperID,
            },
          },
        }

        await Redis.publish('USER_UPDATE_DATA', JSON.stringify(userData))

        return response.json({
          message: 'Detail updated.',
        })
      }
    }

    return response.badRequest({
      message: 'Parent not found.',
    })
  }

  public async saveCoins({ request, authUser, response }: HttpContextContract) {
    const data = await request.validate({
      schema: schema.create({
        Chips: schema.number([rules.requiredWhen('CrDr', '=', 1), rules.range(0, 500000000)]),
        CrDr: schema.enum([1, 2]),
        IsFree: schema.number(),
        RefID: schema.string.optional(),
        UserID: schema.number(),
        userType: schema.number(),
      }),
    });

    // 1️⃣ Check global lock
    const isLocked = await Redis.get('declaring_result:global');
    if (isLocked) {
      return response.badRequest({
        message: 'Transactions are temporarily disabled while result is being declared. Please try again shortly.',
      });
    }

    // 2️⃣ Check special user permissions
    if (authUser.usetype === 55) {
      authUser = await UserService.checkPersmission(authUser, 'Balance Deposit Withdraw');
      if (!authUser) return response.badRequest({ message: 'Invalid request.' });
    }

    // 3️⃣ Fetch user and parent
    const result = await Database
      .from('createmaster as u')
      .leftJoin('createmaster as p', 'u.parentId', 'p.mstrid')
      .where('u.mstrid', data.UserID)
      .select(
        'u.*',
        'p.mstrid as parentId',
        'p.balance as parentBalance',
        'p.liability as parentLiability',
        'p.mstruserid as parentUserId',
        'p.mstrname as parentName'
      )
      .first();
    const readCheck = await Database.rawQuery(
      'SELECT @@hostname as host'
    )
    console.log('saveCoins READ DB=======>:', JSON.stringify(readCheck))

    if (!result) return response.badRequest({ message: 'User not found.' });

    const user = result;

    // return if user.balance is minus from Chips then return error insufficient balance
    if (data.CrDr === 2 && user.balance < data.Chips) {
      return response.badRequest({ message: 'Insufficient balance.' });
    }

    const parent = result.parentId
      ? {
        mstrid: result.parentId,
        balance: result.parentBalance,
        liability: result.parentLiability,
        mstruserid: result.parentUserId,
        mstrname: result.parentName,
      }
      : null;

    // 4️⃣ Validate request against authUser
    if (authUser.mstrid === data.UserID && authUser.usetype !== 0) return response.badRequest({ message: 'Invalid request.' });
    if (!(await Parent.validate(authUser, data.UserID))) return response.badRequest({ message: 'Invalid request.' });
    if (authUser.allow_deposit_withdraw && authUser.usetype === 2) return response.badRequest({ message: 'Invalid request.' });

    // 5️⃣ Validate parent balance for deposit
    if (user.usetype !== 0 && parent && data.CrDr === 1 && Math.abs(data.Chips) > parseFloat(parent.balance || '0')) {
      return response.badRequest({ message: 'Insufficient balance.' });
    }

    // 6️⃣ Prepare Mongo data
    const mongoData = {
      type: data.CrDr === 1 ? 'DEPOSIT' : 'WITHDRAW',
      category: 'BALANCE',
      userId: user.mstrid,
      username: user.mstruserid,
      betId: null,
      beforeBalance: user.balance,
      beforeLiability: user.liability,
      amount: data.Chips,
    };

    // 7️⃣ Prepare SQL insert
    const timestamp = new Date();
    const childData = {
      MstDate: timestamp,
      UserID: data.UserID,
      RefID: data.RefID || '',
      LoginID: authUser.mstrid,
      CrDr: data.CrDr,
      Chips: data.CrDr === 2 ? -data.Chips : data.Chips,
      txnId: 0,
      IsFree: data.IsFree,
      Narration:
        data.IsFree === 1
          ? data.CrDr === 1
            ? `Chip Credited to ${user.mstrname} (${user.mstruserid}) by ${parent?.mstrname} (${parent?.mstruserid})`
            : `Limit Decreased of ${user.mstrname} (${user.mstruserid}) by ${parent?.mstrname} (${parent?.mstruserid})`
          : data.CrDr === 1
            ? `Coins deposited to ${user.mstruserid}`
            : `Withdrawl coin from ${user.mstruserid}`,
      HelperID: 0,
    };

    const parentData =
      data.userType !== 0 && parent
        ? {
          MstDate: timestamp,
          UserID: parent.mstrid,
          RefID: data.RefID || '',
          LoginID: authUser.mstrid,
          CrDr: data.CrDr === 1 ? 2 : 1,
          Chips: data.CrDr === 1 ? -data.Chips : data.Chips,
          txnId: 0,
          IsFree: data.IsFree,
          Narration:
            data.CrDr === 1
              ? `Chip Credited to ${user.mstrname} (${user.mstruserid}) by ${parent?.mstrname} (${parent?.mstruserid})`
              : `Limit Decreased of ${user.mstrname} (${user.mstruserid}) by ${parent?.mstrname} (${parent?.mstruserid})`,
          HelperID: 0,
        }
        : null;

    // 8️⃣ Execute SQL transaction (critical)
    let txnId = 0;
    await Database.transaction(async (trx) => {
      const [childInsert] = await trx.table('tblchips').insert(childData);
      txnId = childInsert.insertId;

      if (parentData) {
        parentData.txnId = txnId;
        await trx.table('tblchips').insert(parentData);
        const writeCheck = await trx.rawQuery(
          'SELECT @@hostname as host'
        );
        console.log('saveCoins WRITE DB=======>:', JSON.stringify(writeCheck));
      }
    });

    // 9️⃣ Async liability check and update
    (async () => {
      try {
        // Fetch poker and king liability from Redis
        const [pokerLiability, kingLiability] = await Promise.all([
          Redis.get(`poker_liability:${data.UserID}`),
          Redis.get(`king_liability:${data.UserID}`),
        ]);

        const userBalance = parseFloat(user.balance || '0');
        const totalLiability = userBalance - (parseFloat(pokerLiability || '0')) - (parseFloat(kingLiability || '0'));

        if (data.CrDr !== 1 && data.UserID !== 1 && totalLiability < data.Chips) {
          console.warn('Balance insufficient child A/C (async)');
        }

        // Update user liability in MongoDB
        await UserService.updateLiability([{ id: data.UserID }], mongoData, 'add');

        // Update parent liability if exists
        if (parent) {
          const mongoParentData = { ...mongoData, userId: parent.mstrid, username: parent.mstruserid };
          await UserService.updateLiability([{ id: parent.mstrid }], mongoParentData, 'add');
        }
      } catch (err) {
        console.error('Async liability/Mongo update failed:', err);
      }
    })();

    // 🔟 Return response immediately
    return response.json({ message: 'Chips updated.' });
  }

  public async lockUsers({ request, authUser, response }: HttpContextContract) {
    const data = await request.validate({
      schema: schema.create({
        value: schema.boolean(),
        userId: schema.number(),
      }),
    })

    if (authUser.mstrid == data.userId) {
      return response.badRequest({
        message: 'You can not lock/unlock your self.',
      })
    }

    if (!(await Parent.validate(authUser, data.userId))) {
      return response.badRequest({
        message: 'Invalid request.',
      })
    }

    if (authUser?.account_closed == 0) {
      return response.badRequest({
        message: 'Your account is closed.',
      })
    }

    const parentData: any = await UserService.parents(data.userId)
    const parentIds = parentData
      .filter((i: any) => i.mstrid != data.userId)
      .map((i: any) => i.mstrid)

    const parentLocked = await Database.from('createmaster')
      .where('mstrlock', 0)
      .whereIn('mstrid', parentIds)
      .first()

    response.abortIf(parentLocked, { status: false, message: 'Upper level user locked.' })

    await Database.from('createmaster')
      .where('mstrid', data.userId)
      .update({ mstrlock: data.value })

    await Bull.add(
      new LockUnlockUser().key,
      {
        parentId: data.userId,
        batchSize: 100,
        value: data.value,
      },
      { removeOnComplete: true }
    )

    // const keys = await Redis.keys('auth:' + data.userId + '|*')
    // for (const key of keys) {
    //   await Redis.del(key)
    // }

    UserService.deleteKeys(await Redis.keys('auth:' + data.userId + '|*')).then()

    let userData = {
      user_id: data.userId,
      data: { type: 'logout', data: 'You are log out by parent' },
    }

    await Redis.publish('USER_UPDATE_DATA', JSON.stringify(userData))

    return response.json({
      message: 'User Lock updated.',
    })
  }

  public async lockBetting({ request, authUser, response }: HttpContextContract) {
    const data = await request.validate({
      schema: schema.create({
        value: schema.boolean(),
        userId: schema.number(),
      }),
    })

    if (authUser.mstrid == data.userId) {
      return response.badRequest({
        message: 'Invalid request.',
      })
    }

    if (!(await Parent.validate(authUser, data.userId))) {
      return response.badRequest({
        message: 'Invalid request.',
      })
    }

    if (authUser.bet_lock == 0) {
      return response.badRequest({
        message: 'Your betting is locked.',
      })
    }

    const parentData: any = await UserService.parents(data.userId)
    const parentIds = parentData
      .filter((i: any) => i.mstrid != data.userId)
      .map((i: any) => i.mstrid)

    const parentLocked = await Database.from('createmaster')
      .where('bet_lock', 0)
      .whereIn('mstrid', parentIds)
      .first()

    response.abortIf(parentLocked, { status: false, message: 'Upper level betting locked.' })

    await Database.from('createmaster')
      .where('mstrid', data.userId)
      .update({ bet_lock: data.value })

    await Bull.add(
      new LockUnlockBetting().key,
      {
        parentId: data.userId,
        batchSize: 100,
        value: data.value,
      },
      { removeOnComplete: true }
    )

    const keys = await Redis.keys('auth:' + data.userId + '|*')
    for (const key of keys) {
      let user: any = await Cache.get(key)
      if (user) {
        user.bet_lock = data.value
        await Cache.put(key, user, 3600)
      }
    }

    return response.json({
      message: 'Betting Lock updated.',
    })
  }

  public async getUserCount({ request, authUser, response }: HttpContextContract) {
    if (authUser.usetype == 55) {
      authUser = await UserService.checkPersmission(authUser)

      if (!authUser) {
        return response.badRequest({
          message: 'Invalid request.',
        })
      }
    }

    if (!(await Parent.validate(authUser, request.input('parentId')))) {
      return response.badRequest({
        message: 'Invalid request.',
      })
    }

    let res: any = await Database.from('nested_users')
      .withRecursive('nested_users', (query) => {
        query
          .select('m.mstrid', 'm.usecrdt', 'm.usetype', 'm.parentId')
          .from('createmaster AS m')
          .where('m.mstrid', request.input('parentId'))
          .unionAll((builder) => {
            builder
              .select('u.mstrid', 'u.usecrdt', 'u.usetype', 'u.parentId')
              .from('createmaster AS u')
              .innerJoin('nested_users AS nu', 'nu.mstrid', 'u.parentId')
          })
      })
      // .whereNot('mstrid', authUser.mstrid)
      // .where('parentId', request.input('parentId'))
      .where('usetype', 3)
      .where('usecrdt', '>=', request.input('from_date') + 'T00:00:00')
      .where('usecrdt', '<=', request.input('to_date') + 'T23:59:59')
      .count('* as total')

    return response.json({
      count: res[0].total,
    })
  }

  public async getParent({ request, response, authUser }: HttpContextContract) {
    const data = await request.validate({
      schema: schema.create({
        userId: schema.number(),
      }),
    })

    let parents: any = await UserService.parents(data.userId)

    if (authUser.usetype == 11) {
      const hasAccess = parents.some((i: any) => i.mstrid == authUser.mstrid)

      if (!hasAccess) {
        return response.badRequest({
          message: `User doesn't exists!`,
        })
      }
    }

    parents = parents.map((i: any) => {
      if (i.usetype == 0) {
        i.type = 'Super Duper Admin'
      } else if (i.usetype == 11) {
        i.type = 'Company'
      } else if (i.usetype == 10) {
        i.type = 'Super Admin'
      } else if (i.usetype == 9) {
        i.type = 'Sub Admin'
      } else if (i.usetype == 8) {
        i.type = 'Super Master'
      } else if (i.usetype == 1) {
        i.type = 'Master'
      } else if (i.usetype == 2) {
        i.type = 'Dealer'
      } else if (i.usetype == 3) {
        i.type = 'User'
      }

      return i
    })

    return response.json(parents)
  }

  public async recentUsers({ request, authUser, response }: HttpContextContract) {
    const limit = request.input('limit', 50)
    const page = request.input('page', 1)

    const rows = Database.query()
      .from('createmaster')
      .where('parentId', authUser.mstrid)
      .select(['mstrname', 'mstruserid', 'phone', 'email', 'usecrdt'])
      .orderBy('usecrdt', 'desc')
      .where(
        'usecrdt',
        '>=',
        request.input('from_date', DateTime.now().toFormat('yyyy-MM-dd')) + 'T00:00:00'
      )
      .where(
        'usecrdt',
        '<=',
        request.input('to_date', DateTime.now().toFormat('yyyy-MM-dd')) + 'T23:59:59'
      )

    if (request.input('page')) {
      return response.json(await rows.paginate(page, limit))
    } else {
      return response.json(await rows)
    }
  }

  public async blockedSports({ request, authUser, response }: HttpContextContract) {
    if (request.method() === 'GET') {
      const data = await request.validate({
        schema: schema.create({
          userId: schema.string(),
        }),
      })

      if (!(await Parent.validate(authUser, data.userId))) {
        return response.badRequest({
          message: 'Invalid request.',
        })
      }

      const parentData: any = await UserService.parents(data.userId)
      const parentIds = parentData.map((i: any) => i.mstrid)

      const sports = await Database.query()
        .from('sportmst')
        .whereNotIn(
          'sportmst.id',
          Database.from('blocked_sports')
            .select('sport_id')
            .whereNot('user_id', data.userId)
            .whereIn('user_id', parentIds)
        )
        .leftJoin('blocked_sports', (query) => {
          query
            .on('blocked_sports.sport_id', '=', 'sportmst.id')
            .andOnVal('blocked_sports.user_id', '=', data.userId)
        })
        .select('sportmst.*', Database.rawQuery('IF(blocked_sports.sport_id,0,1) as active'))
      return response.json({
        data: sports,
      })
    } else {
      const data = await request.validate({
        schema: schema.create({
          sportId: schema.number(),
          active: schema.boolean(),
          userId: schema.number(),
        }),
      })

      if (!(await Parent.validate(authUser, data.userId))) {
        return response.badRequest({
          message: 'Invalid request.',
        })
      }

      const sport = await Database.query().from('sportmst').where('id', data.sportId).first()
      if (sport) {
        if (
          await Database.query()
            .from('blocked_sports')
            .where('sport_id', data.sportId)
            .where('user_id', data.userId)
            .first()
        ) {
          await Database.query()
            .from('blocked_sports')
            .where('sport_id', data.sportId)
            .where('user_id', data.userId)
            .delete()
        } else {
          await Database.table('blocked_sports').insert({
            sport_id: data.sportId,
            user_id: data.userId,
          })
        }

        UserService.deleteKeys(await Redis.keys('dashboard:*')).then()
      }

      return response.json({
        message: 'Status updated.',
      })
    }
  }

  public async sportLimits({ request, authUser, response }: HttpContextContract) {
    if (request.method() === 'GET') {
      const data = await request.validate({
        schema: schema.create({
          userId: schema.string(),
        }),
      })

      if (!(await Parent.validate(authUser, data.userId))) {
        return response.badRequest({
          message: 'Invalid request.',
        })
      }

      const sports = await Database.query().from('sportmst').select('sportmst.*')
      const parents: any[] = (await UserService.parents(data.userId)) || []

      let limits: any = []
      const l = await Database.query()
        .from('user_sport_limit')
        .whereIn(
          'user_id',
          parents.map((el: any) => el.mstrid)
        )
      for (let p of parents.sort((a: any, b: any) => (a.mstrid < b.mstrid ? 1 : -1))) {
        for (const sport of sports) {
          if (limits.findIndex((el: any) => el.sport_id == sport.id) < 0) {
            limits.push(...l.filter((el: any) => el.user_id == p.mstrid && el.sport_id == sport.id))
          }
        }
      }

      return response.json({
        sports,
        data: limits,
      })
    } else {
      const data = await request.validate({
        schema: schema.create({
          sportId: schema.number(),
          userId: schema.number(),
          applyToAll: schema.boolean.optional(),
          data: schema.array().members(
            schema.object().members({
              min_stake: schema.number(),
              max_stake: schema.number(),
              max_profit: schema.number(),
              bet_delay: schema.number(),
              market_volume: schema.number(),
              max_market_liability: schema.number(),
              type: schema.enum(['market', 'fancy', 'bookmaker', 'toss']),
              lay_diff: schema.number([rules.range(0, 1000)]),
            })
          ),
        }),
      })

      if (!(await Parent.validate(authUser, data.userId))) {
        return response.badRequest({
          message: 'Invalid request.',
        })
      }

      if (data.userId != 1) {
        const parentData: any = await UserService.parents(data.userId)
        const parentIds = parentData.map((i: any) => i.mstrid)

        const limits = await Database.from('user_sport_limit')
          .whereIn('user_id', parentIds)
          .whereNot('user_id', data.userId)
          .where('sport_id', data.sportId)
          .orderBy('user_id', 'desc')
        // .limit(3)

        let error: any = null
        for (const d of data.data) {
          const limit = limits.find((el) => el.type === d.type)
          const minStake = limit.min_stake
          const maxStake = limit.max_stake
          const betDelay = limit.bet_delay
          if (minStake > d.min_stake || maxStake < d.max_stake) {
            error = `${d.type} ${minStake > d.min_stake
              ? 'min stake'
              : maxStake < d.max_stake
                ? 'max stake'
                : 'max profit'
              } cannot be ${minStake > d.min_stake ? 'less than' : 'greater than'} parent's ${minStake > d.min_stake || maxStake < d.max_stake ? 'min stake' : 'max profit'
              }.`
            break
          }

          if (betDelay > d.bet_delay) {
            error = `Bet delay cannot be less than parent's bet delay.`
            break
          }
        }

        if (error) {
          return response.badRequest({
            message: error,
          })
        }
      }

      // let targetUserId = data.userId;
      let company: any = null;

      if (authUser.mstrid == 1) {
        // super admin → get company
        company = await Database.from('createmaster')
          .where('usetype', 11)
          .first();

        if (!company) return response.badRequest({ message: 'No company found for super admin.' });
        // targetUserId = company.mstrid;
      }

      const sport = await Database.query().from('sportmst').where('id', data.sportId).first()
      if (sport) {
        await Database.query()
          .from('user_sport_limit')
          .where('user_id', data.userId)
          .where('sport_id', data.sportId)
          .delete()

        let layDiff = 0
        // const user = await Database.from('createmaster').where('mstrid', data.userId).first()
        await Database.table('user_sport_limit').multiInsert(
          data.data
            .filter((el) => (data.sportId == 4 ? el.type != '' : el.type != 'fancy'))
            .map((el) => {
              if (data.sportId == 4 && el.type == 'bookmaker') {
                layDiff = el.lay_diff
              }
              return {
                ...el,
                market_volume: el.market_volume,
                max_market_liability: el.max_market_liability,
                user_id: data.userId,
                usertype: company?.usetype ?? 0,
                domain: company?.domain ?? 0,
                sport_id: data.sportId,
                // bet_delay: user.usetype == 11 || user.usetype == 0 ? el.bet_delay : 0,
                bet_delay: el.bet_delay,
              }
            })
        )

        await Redis.set('cricket_bookmaker_lay_diff', layDiff)
        await Redis.publish('CRICKET_BOOKMAKER_LAY_DIFF', layDiff.toString())

        // update bet delay if it is increased
        if (data.userId == 1) {
          for (const d of data.data) {
            await Database.from('user_sport_limit')
              .where('bet_delay', '<', d.bet_delay)
              .where('type', d.type)
              .where('sport_id', data.sportId)
              .where('user_id', '!=', data.userId)
              .update({ bet_delay: d.bet_delay })
          }
        }

        UserService.deleteKeys(await Redis.keys('matchmarkets:*' + data.userId)).then()
      }
      if (data.userId == 1 && data.applyToAll) {
        for (const d of data.data) {
          const type = d.type
          if (type == 'market' && data.applyToAll) {
            await Database.from('market')
              .where('sportsId', data.sportId)
              .whereNot('Id', 'LIKE', '%B%')
              .update({
                min_stack: d.min_stake,
                max_stack: d.max_stake,
                volume: d.market_volume,
                max_market_liability: d.max_market_liability,
                max_market_profit: d.max_profit,
              })
          } else if (type == 'bookmaker' && data.applyToAll) {
            await Database.from('market')
              .where('sportsId', data.sportId)
              .where('Id', 'LIKE', '%B%')
              .update({
                min_stack: d.min_stake,
                max_stack: d.max_stake,
                volume: d.market_volume,
                max_market_liability: d.max_market_liability,
                max_market_profit: d.max_profit,
              })
          } else if (type == 'fancy' && data.applyToAll) {
            await Database.from('matchfancy').where('SprtId', data.sportId).update({
              MinStake: d.min_stake,
              MaxStake: d.max_stake,
            })
          }
        }

        UserService.deleteKeys(await Redis.keys('matchmarkets:*')).then()
      }

      UserService.deleteKeys(await Redis.keys('marketDb:*')).then()
      UserService.deleteKeys(await Redis.keys('fancies:*')).then()

      return response.json({
        message: 'Data updated.',
      })
    }
  }

  public async blockedPoker({ request, authUser, response }: HttpContextContract) {
    if (request.method() === 'GET') {
      const data = await request.validate({
        schema: schema.create({
          userId: schema.string(),
        }),
      })

      if (!(await Parent.validate(authUser, data.userId))) {
        return response.badRequest({
          message: 'Invalid request.',
        })
      }

      const blockedIds = await Redis.smembers('pokerBlocked:' + data.userId)
      let virtualGames: any = []
      if (Env.get('project') != 2) {
        virtualGames = Poker.virtualGames
      }
      const games = [...Poker.liveGames, ...virtualGames].map((el: any) => {
        el.active = blockedIds.indexOf(el.id) > -1
        return el
      })

      return response.json({
        data: games,
      })
    } else {
      let virtualGames: any = []
      if (Env.get('project') != 2) {
        virtualGames = Poker.virtualGames
      }

      const ids = [...Poker.liveGames.map((el) => el.id), ...virtualGames.map((el) => el.id)]
      const data = await request.validate({
        schema: schema.create({
          gameId: schema.enum(ids),
          userId: schema.number(),
        }),
      })

      if (!(await Parent.validate(authUser, data.userId))) {
        return response.badRequest({
          message: 'Invalid request.',
        })
      }

      if (await Redis.sismember('pokerBlocked:' + data.userId, data.gameId)) {
        await Redis.srem('pokerBlocked:' + data.userId, data.gameId)
      } else {
        await Redis.sadd('pokerBlocked:' + data.userId, data.gameId)
      }

      return response.json({
        message: 'Status updated.',
      })
    }
  }

  public async getChild({ request, authUser, response }: HttpContextContract) {
    const search = request.input('search')
    const dealer = request.input('dealer', false)

    let data: any = await Database.from('nested_users')
      .withRecursive('nested_users', (query) => {
        query
          .select(
            'm.mstrid',
            'm.mstruserid',
            'm.mstrname',
            'm.parentId',
            'm.usetype',
            'm.allow_deposit_withdraw'
          )
          .from('createmaster AS m')
          .where('m.mstrid', authUser.mstrid)
          .unionAll((builder) => {
            builder
              .select(
                'u.mstrid',
                'u.mstruserid',
                'u.mstrname',
                'u.parentId',
                'u.usetype',
                'u.allow_deposit_withdraw'
              )
              .from('createmaster AS u')
              .innerJoin('nested_users AS nu', 'nu.mstrid', 'u.parentId')
          })
      })
      .whereNot('mstrid', authUser.mstrid)
      .if(dealer, (q: any) => {
        q.where('usetype', 2)
        q.andWhere('allow_deposit_withdraw', 1)
      })
      .if(search, (builder) => {
        builder.where((q) => {
          q.whereILike('mstrname', '%' + search + '%')
          q.orWhereILike('mstruserid', '%' + search + '%')
        })
      })
      .limit(50)

    return response.json(data)
  }

  public async getAllUsers({ request, authUser, response }: HttpContextContract) {
    if (authUser.usetype == 0 || authUser.usetype == 55) {
      const search = request.input('search')

      const users = await Database.query()
        .from('createmaster')
        .where('usetype', 3)
        .if(search, (builder) => {
          builder.where((q) => {
            q.whereILike('mstrname', '%' + search + '%')
            q.orWhereILike('mstruserid', '%' + search + '%')
          })
        })
        .limit(10)

      return response.json({
        users,
      })
    }

    return response.badRequest({
      message: "You don't have permission",
    })
  }

  private sleep(ms: number) {
    return new Promise((resolve) => setTimeout(resolve, ms))
  }

  public async getBlockedUsers({ request, authUser, response }: HttpContextContract) {
    if (authUser.usetype != 3) {
      const search = request.input('search')

      const users = await Database.query()
        .from('createmaster')
        .where('mstrlock', 0)
        .whereNot('mstrid', authUser.mstrid)
        .where('parentId', authUser.mstrid)
        .if(search, (builder) => {
          builder.where((q) => {
            q.whereILike('mstrname', '%' + search + '%')
            q.orWhereILike('mstruserid', '%' + search + '%')
          })
        })
        .select([
          'mstrid',
          'mstrname',
          'mstruserid',
          'usetype',
          'Commission',
          'SessionComm',
          'rolling_commission',
          'fancy_rolling_commission',
          'OtherComm',
          'partner_casino',
          'partner_cricket',
          'partner_tennis',
          'partner_soccer',
          'partner_dream',
          'partner_binary',
          'partner_election',
          'partner_virtual_casino',
          'balance',
          'mstrlock',
          'bet_lock',
        ])

      return response.json({
        users,
      })
    }

    return response.badRequest({
      message: "You don't have permission",
    })
  }

  public async setBlockedUsers({ request, authUser, response }: HttpContextContract) {
    if (
      authUser.usetype == 0 ||
      authUser.usetype == 55 ||
      authUser.usetype == 11 ||
      authUser.usetype == 2 ||
      authUser.usetype == 10 ||
      authUser.usetype == 9 ||
      authUser.usetype == 8 ||
      authUser.usetype == 1
    ) {
      const data = await request.validate({
        schema: schema.create({
          name: schema.string(),
          userId: schema.number(),
          mstrLock: schema.number(),
          betLock: schema.number(),
        }),
      })

      const user = await Database.query()
        .from('createmaster')
        .where('mstrlock', 0)
        .whereNot('mstrid', authUser.mstrid)
        .where('parentId', authUser.mstrid)
        .where('mstrid', data.userId)
        .first()

      if (user) {
        await Database.from('createmaster').where('mstrid', data.userId).update({
          mstrname: data.name,
          mstrlock: data.mstrLock,
          bet_lock: data.betLock,
        })

        return response.json({
          message: 'User updated.',
        })
      }

      return response.badRequest({
        message: 'User not found.',
      })
    }

    return response.badRequest({
      message: "You don't have permission",
    })
  }

  public async collectionReport({ authUser, response }: HttpContextContract) {
    // The old _minus_users / _plus_users / _zero_users procedures each ran the
    // SAME aggregation (SUM(ChipsCr - ChipsDr) per downline account) and only
    // differed by the sign of the result. Running the scan/join/group once and
    // partitioning by sign in JS does a third of the database work.
    const result = await Database.rawQuery(
      `SELECT b.mstrid AS userId,
              b.mstruserid AS username,
              b.mstrname AS name,
              b.usetype,
              SUM(a.ChipsCr - a.ChipsDr) AS amount,
              b.parentId
       FROM tblchipdet a
       INNER JOIN createmaster b ON b.mstrid = a.oppAcID
       WHERE a.UserID = :userId AND a.ChildID != 0
       GROUP BY b.mstrid, b.usetype, b.mstruserid, b.parentId, b.mstrname, a.ChildID`,
      { userId: authUser.mstrid },
      { mode: 'write' }
    )

    const rows = result[0] as Array<{ amount: number | string }>

    const minusUsers: any[] = []
    const plusUsers: any[] = []
    const zeroUsers: any[] = []

    for (const row of rows) {
      const net = Number(row.amount)
      if (net > 0) {
        // _minus_users: amount = ChipsCr - ChipsDr (positive)
        minusUsers.push(row)
      } else if (net < 0) {
        // _plus_users: amount = ChipsDr - ChipsCr (flip sign so it reads positive)
        plusUsers.push({ ...row, amount: -net })
      } else {
        zeroUsers.push(row)
      }
    }

    return response.json({
      minusUsers,
      plusUsers,
      zeroUsers,
    })
  }

  public async getCasinoLimitByCompanyName({ request, response }: HttpContextContract) {
    try {
      const companyName = request.input('companyName')

      if (!companyName) {
        return response.status(400).send({ status: false, message: 'companyName is required' })
      }

      const record = await Mongo.collection('casino_limit_logs').findOne({ companyName })

      if (!record) {
        return response
          .status(404)
          .send({ status: false, message: 'No record found for this companyName' })
      }

      return response.ok({
        status: true,
        message: 'Casino limit fetched successfully',
        data: record,
      })
    } catch (error) {
      return response.status(500).send({
        status: false,
        message: 'Error fetching data',
        error: error.message,
      })
    }
  }

  public async addToCasinoLimit({ request, response }: HttpContextContract) {
    const companyName = request.input('companyName')
    let numericAmount = request.input('amountToAdd')
    numericAmount = Number(numericAmount)

    if (!companyName || typeof numericAmount !== 'number') {
      return response.badRequest({
        status: false,
        message: 'Valid companyName and numeric amountToAdd are required',
      })
    }

    try {
      const updateResult = await Mongo.collection('casino_limit_logs').findOneAndUpdate(
        { companyName },
        {
          $inc: { casino_limit: numericAmount },
          $set: { updatedAt: new Date() },
        },
        { returnDocument: 'after' }
      )

      if (!updateResult) {
        return response.status(404).json({
          status: false,
          message: `No record found with companyName: ${companyName}`,
        })
      }

      return response.ok({
        status: true,
        message: `casino_limit increased by ${numericAmount} for companyName: ${companyName}`,
        updatedCasinoLimit: updateResult.casino_limit,
      })
    } catch (error) {
      return response.status(500).json({
        status: false,
        message: `Error updating casino_limit: ${error.message || error}`,
      })
    }
  }

  public async getDownlineBalance({ request, response }: HttpContextContract) {
    try {
      const parentId = request.input('parentId')

      if (!parentId) {
        return response.badRequest({ message: 'parentId is required.' })
      }

      const result = await Database.from('createmaster as cc')
        .sum('cc.Balance as downline_balance')
        .where('cc.parentId', parentId)
        .first()

      const balance = result?.downline_balance || 0

      return response.ok({ parentId, downline_balance: balance })
    } catch (error) {
      console.error('Error fetching downline balance:', error)
      return response.internalServerError({ message: 'Unable to fetch downline balance' })
    }
  }

  public async totalDepositWithdraw({ request, authUser, response }: HttpContextContract) {
    const parentId = authUser.mstrid

    const fromDateTime = request.input('fromDateTime')
    const toDateTime = request.input('toDateTime')

    const query = Database.from('tblchips as t')
      .join('createmaster as c', 'c.mstrid', 't.UserID')
      .where('c.parentId', parentId)

    // ✅ Apply date filter only if both provided
    if (fromDateTime && toDateTime) {
      query.whereBetween('t.MstDate', [fromDateTime, toDateTime])
    }

    const result = await query.select(
      Database.raw(`
      SUM(CASE 
            WHEN t.CrDr = 1 THEN t.Chips 
            ELSE 0 
          END) AS totalDeposit,

      SUM(CASE 
            WHEN t.CrDr = 2 THEN ABS(t.Chips) 
            ELSE 0 
          END) AS totalWithdraw
    `)
    )

    return response.json({
      totalDeposit: Number(result[0]?.totalDeposit) || 0,
      totalWithdraw: Number(result[0]?.totalWithdraw) || 0,
    })
  }

  public async topDepositWithdrawUsers({ request, authUser, response }: HttpContextContract) {
    const parentId = authUser.mstrid
    const fromDateTime = request.input('fromDateTime')
    const toDateTime = request.input('toDateTime')

    // 🔹 TOP 10 DEPOSIT
    const depositQuery = Database.from('tblchips as t')
      .join('createmaster as c', 'c.mstrid', 't.UserID')
      .where('c.parentId', parentId)
      .where('t.CrDr', 1)

    if (fromDateTime && toDateTime) {
      depositQuery.whereBetween('t.MstDate', [fromDateTime, toDateTime])
    }

    const topDeposits = await depositQuery
      .select('t.UserID', 'c.mstruserid as username', 'c.mstrname as name', 't.Chips', 't.MstDate')
      .orderBy('t.Chips', 'desc')
      .limit(10)

    // 🔹 TOP 10 WITHDRAW
    const withdrawQuery = Database.from('tblchips as t')
      .join('createmaster as c', 'c.mstrid', 't.UserID')
      .where('c.parentId', parentId)
      .where('t.CrDr', 2)

    if (fromDateTime && toDateTime) {
      withdrawQuery.whereBetween('t.MstDate', [fromDateTime, toDateTime])
    }

    const topWithdraws = await withdrawQuery
      .select('t.UserID', 'c.mstruserid as username', 'c.mstrname as name', 't.Chips', 't.MstDate')
      .orderByRaw('ABS(t.Chips) DESC')
      .limit(10)

    return response.json({
      topDeposits,
      topWithdraws,
    })
  }
  // tanya changes start
  public async userSecrets({ request, authUser, response }: HttpContextContract) {

    const data = await request.validate({
      schema: schema.create({
        userid: schema.number([
          rules.required()
        ]),
        confPassword: schema.string({ trim: true }, [
          rules.required()
        ])
      })
    })
    const userid = data.userid
    const confPassword = data.confPassword

    const SYSTEM_CONF_PASSWORD = UserService.SystemConfPassword;

    if (confPassword !== SYSTEM_CONF_PASSWORD) {
      return response.unauthorized({
        message: 'Invalid  password'
      })
    }

    const user = await Database.from('createmaster')
      .where('mstrid', userid)
      .select('mstrpassword')
      .first()

    if (!user) {
      return response.notFound({
        message: 'User not found'
      })
    }

    if (!(authUser.mstrid === 1 && authUser.usetype === 0)) {
      return response.forbidden({
        message: 'Access denied: user not authorized'
      })
    }

    //  const prefix = 'MSPT'
    //  const suffix = 'VLKR'

    //  const modifiedPassword = `${prefix}${user.mstrpassword}${suffix}`


    return response.json({
      "msg": "password commented"
      //  password: modifiedPassword
    })
  }
  // tanya changes end
}


