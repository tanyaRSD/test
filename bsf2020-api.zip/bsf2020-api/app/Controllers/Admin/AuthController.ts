import Cache from '@ioc:Adonis/Addons/Cache'
import { HttpContextContract } from '@ioc:Adonis/Core/HttpContext'
import { schema } from '@ioc:Adonis/Core/Validator'
import ThirdParty from 'App/Services/ThirdParty'
import axios from 'axios'

export default class AuthController {
  public async token({ authUser, response }: HttpContextContract) {
    if (authUser.usetype == 0) {
      const { data } = await axios.get(ThirdParty.tokenApiUrl)
      if (data.hasOwnProperty('token')) {
        return response.json({ message: 'Token generated.' })
      } else {
        return response.badRequest({ message: data.error })
      }
    }
  }

  public async getMaintainance({ authUser, response }: HttpContextContract) {
    if (authUser.usetype == 0 || authUser.usetype == 55) {
      let status = await Cache.rememberForever('system_maintainance', async () => {
        return false
      })

      return response.json({ data: status })
    }

    return response.badRequest({
      message: "You don't have permission",
    })
  }

  public async setMaintainance({ request, authUser, response }: HttpContextContract) {
    const data = await request.validate({
      schema: schema.create({
        status: schema.boolean(),
      }),
    })

    if (authUser.usetype == 0 || authUser.usetype == 55) {
      await Cache.forever('system_maintainance', data.status)

      return response.json({
        status: true,
        message: 'Maintainance status changed.',
      })
    }

    return response.badRequest({
      message: "You don't have permission",
    })
  }

  public async apk({ request, response }: HttpContextContract) {
    if (request.method() == 'GET') {
      return response.json(await Cache.get('apk'))
    } else {
      const data = await request.validate({
        schema: schema.create({
          version: schema.string(),
          file: schema.file({
            size: '50mb',
            extnames: ['apk'],
          }),
        }),
      })

      await data.file.moveToDisk('apks', {}, 's3')
      const filePath: any = data.file.filePath

      await Cache.forever('apk', { version: data.version, url: filePath })

      return response.json({
        status: true,
        message: 'APK uploaded.',
      })
    }
  }
}
