/* eslint-disable eqeqeq */
import Redis from '@ioc:Adonis/Addons/Redis'
import { HttpContextContract } from '@ioc:Adonis/Core/HttpContext'
import { schema } from '@ioc:Adonis/Core/Validator'
import Database from '@ioc:Adonis/Lucid/Database'
import Bull from '@ioc:Rocketseat/Bull'
import UpdateLiability from 'App/Jobs/UpdateLiability'
import LiabilityEngine from 'App/Services/Ledger/LiabilityEngine'
import MarketService from 'App/Services/MarketService'
import { Mongo } from 'App/Services/Mongo'
// import { Mongo } from 'App/Services/Mongo'
import Sp from 'App/Services/Sp'
import UserService from 'App/Services/UserService'

export default class ResultsController {
  public async store({ request, authUser, response }: HttpContextContract) {
    if (
      authUser.usetype == 0 ||
      authUser.usetype == 55 ||
      // (authUser.usetype == 11 && authUser.allow_result_declare)
      (authUser.usetype == 11 &&
        authUser.mstrid == 4957 &&
        authUser?.domain == 'https://bsf247.pro') ||
      (authUser.usetype == 11 && authUser.mstrid == 2 && authUser.mstrname == 'Ccompany')
    ) {
      const data = await request.validate({
        schema: schema.create({
          Sport_id: schema.number(),
          series_id: schema.number(),
          match_id: schema.number(),
          market_id: schema.string(),
          selectionId: schema.number(),
          isFancy: schema.boolean(),
          sportName: schema.string(),
          matchName: schema.string(),
          MarketName: schema.string(),
          selectionName: schema.string(),
        }),
      })

      const lockKey = 'declaring_result:global'
      const isLocked = await Redis.get(lockKey)
      if (isLocked) {
        return response.badRequest({
          message: 'Another result is currently being declared. Please wait.',
        })
      }
      await Redis.set(lockKey, '1', 'EX', 60) // lock for 60 seconds

      // 2. All logic in try...finally
      try {
        const result = await Database.query()
          .from('tblresult')
          .where('marketId', data.market_id)
          .where('isFancy', 0)
          .first()

        if (result) {
          return response.badRequest({
            message: 'Result already declared!',
          })
        }

        if (authUser.usetype == 55) {
          authUser = await UserService.checkPersmission(authUser, 'Match Result Declare')

          if (!authUser) {
            return response.badRequest({
              message: 'Invalid request.',
            })
          }
        }

        const market = await Database.query()
          .from('market')
          .where('Id', data.market_id)
          .where('active', 1)
          .whereNotIn('market.sportsId', [1233, 1234, 1235, 1236])
          .first()

        if (!market) {
          return response.badRequest({
            message: 'Market is not open',
          })
        }

        await Redis.del('marketId:' + data.market_id)

        await Redis.srem(
          'ACTIVE_MARKETS',
          JSON.stringify({
            sportId: data.Sport_id.toString(),
            seriesId: data.series_id.toString(),
            matchId: data.match_id.toString(),
            marketId: data.market_id.toString(),
          })
        )

        await Redis.srem(
          'ACTIVE_LINE_MARKETS',
          JSON.stringify({
            sportId: data.Sport_id.toString(),
            seriesId: data.series_id.toString(),
            matchId: data.match_id.toString(),
            marketId: data.market_id.toString(),
          })
        )

        const ids = await Database.from('tblbets')
          .distinct('UserId as id')
          .where('MatchId', data.match_id)
          .where('MarketId', data.market_id)
          .union(
            [
              (query) => {
                query
                  .from('tblbets')
                  .distinct('ParantId as id')
                  .where('MatchId', data.match_id)
                  .where('MarketId', data.market_id)
              },
              (query) => {
                query
                  .from('tblbets')
                  .distinct('DealerID as id')
                  .where('MatchId', data.match_id)
                  .where('MarketId', data.market_id)
              },
              (query) => {
                query
                  .from('tblbets')
                  .distinct('MasterID as id')
                  .where('MatchId', data.match_id)
                  .where('MarketId', data.market_id)
              },
              (query) => {
                query
                  .from('tblbets')
                  .distinct('SMasterID as id')
                  .where('MatchId', data.match_id)
                  .where('MarketId', data.market_id)
              },
              (query) => {
                query
                  .from('tblbets')
                  .distinct('SAdminID as id')
                  .where('MatchId', data.match_id)
                  .where('MarketId', data.market_id)
              },
              (query) => {
                query
                  .from('tblbets')
                  .distinct('AdminID as id')
                  .where('MatchId', data.match_id)
                  .where('MarketId', data.market_id)
              },
              (query) => {
                query
                  .from('tblbets')
                  .distinct('CompanyID as id')
                  .where('MatchId', data.match_id)
                  .where('MarketId', data.market_id)
              },
              (query) => {
                query
                  .from('tblbets')
                  .distinct('ParentExchCompanyID as id')
                  .where('MatchId', data.match_id)
                  .where('MarketId', data.market_id)
              },
            ],
            true
          )

        // Only clients (usetype 3) get a synchronous getLiability recompute in the
        // loop below. Upper panels are maintained incrementally by
        // LiabilityEngine.releaseMarket (it reverses their market liability out of
        // createmaster.liability/balance), so recomputing their full downline per
        // result was the scaling bottleneck.
        const users = await Database.from('createmaster')
          .whereIn(
            'mstrid',
            ids.map((el) => el.id)
          )
          .where('usetype', 3)

        if (data.selectionId == 0) {
          await Database.table('tblabandonedbets').insert((builder) => {
            builder
              .select('*')
              .from('tblbets')
              .where('MatchId', data.match_id)
              .where('MarketId', data.market_id)
          })

          await Database.table('tblresult').insert({
            sportId: data.Sport_id,
            matchId: data.match_id,
            marketId: data.market_id,
            date: new Date(),
            isFancy: 0,
            selectionId: data.selectionId,
            result: '1',
            userID: authUser.mstruserid,
          })

          await Database.from('tblbets')
            .where('MatchId', data.match_id)
            .where('MarketId', data.market_id)
            .delete()

          if (data.MarketName == 'Match Odds') {
            await Database.from('matchmst')
              .where('SportID', data.Sport_id)
              .where('MstCode', data.match_id)
              .whereNotIn('SportID', ['7', '4339'])
              .update({ active: 0 })
          }

          await Database.from('market')
            .where('sportsId', data.Sport_id)
            .where('matchId', data.match_id)
            .where('Id', data.market_id)
            .update({ active: 0 })
        } else if (data.selectionId != 0) {
          if (data.market_id.includes('B') && !data.MarketName.toLowerCase().includes('toss')) {
            await Sp.call(
              '_result_bookmaker(:sportId,:matchId,:marketId,:selectionId,:fancyId,:resultId,:sportNM,:matchNM, :marketNM, :selectionNM, :userNM)',
              {
                sportId: data.Sport_id,
                matchId: data.match_id,
                marketId: data.market_id,
                selectionId: data.selectionId,
                fancyId: 0,
                resultId: '1',
                sportNM: data.sportName,
                matchNM: data.matchName,
                marketNM: data.MarketName,
                selectionNM: data.selectionName,
                userNM: authUser.mstruserid,
              }
            )
          } else {
            await Sp.call(
              '_result_market(:sportId,:matchId,:marketId,:selectionId,:fancyId,:resultId,:sportNM,:matchNM, :marketNM, :selectionNM, :userNM)',
              {
                sportId: data.Sport_id,
                matchId: data.match_id,
                marketId: data.market_id,
                selectionId: data.selectionId,
                fancyId: 0,
                resultId: '1',
                sportNM: data.sportName,
                matchNM: data.matchName,
                marketNM: data.MarketName,
                selectionNM: data.selectionName,
                userNM: authUser.mstruserid,
              }
            )
          }
        }

        // Release upper-panel open-bet liability for the now-settled market — the
        // ledger/summary rows go to zero and the ancestors' liability columns are
        // reversed. Clients' liability drops automatically (getLiability filters
        // Result IS NULL).
        await LiabilityEngine.inTransaction((trx) =>
          LiabilityEngine.releaseMarket(trx, data.match_id, data.market_id)
        )

        // await Mongo.collection('bets').deleteMany({
        //   matchId: data.match_id,
        //   marketId: data.market_id,
        // })

        await Mongo.collection('declared_results').insertOne({
          sportId: data?.Sport_id,
          sportName: data?.sportName,
          seriesId: data?.series_id,
          matchId: data?.match_id,
          matchName: data?.matchName,
          marketId: data?.market_id,
          marketName: data?.MarketName,
          isFancy: data?.isFancy,
          selectionId: data?.selectionId,
          selectionName: data?.selectionName,
          declaredByname: authUser?.mstrname || 'Auto',
          declaredByMstrid: authUser?.mstrid || 'Auto',
          declaredByDomain: authUser?.domain,
          usetype: authUser?.usetype || 'Auto',
          createdAt: new Date(),
        })

        await MarketService.removeMarketCache(data.match_id)

        if (market.Name == 'Match Odds') {
          await Redis.srem('ACTIVE_BOOKMAKERS', data.match_id)
          await Redis.srem('ACTIVE_FANCIES', `${data.match_id}|${market.Id}`)
          await Redis.del('FancyId:' + data.match_id)
          await Redis.srem('auto_fancy_matches', data.match_id)
        }

        await Redis.publish('UPDATE_ACTIVE_MARKET', '')

        await Redis.publish('UPDATE_MATCH_DATA', JSON.stringify({ match_id: data.match_id }))

        for (const user of users) {
          const mongoData = {
            type: 'RESULT',
            category: 'MARKET',
            userId: user.mstrid,
            username: user.mstruserid,
            betId: null,
            beforeBalance: user.balance,
            beforeLiability: user.liability,
            marketName: data.MarketName,
            marketId: data.market_id,
            matchName: data.matchName,
          }

          await UserService.updateLiability([{ id: user.mstrid }], mongoData, 'add')
        }

        await Redis.publish('DASHBOARD_UPDATE_USER', '')
        await Redis.publish('DASHBOARD_UPDATE_ADMIN', '')
        for (const el of ids) {
          await Redis.publish(
            'BETS_UPDATE_DATA',
            JSON.stringify({
              user_id: el.id,
              match_id: data.match_id,
              data: {},
            })
          )

          await Redis.publish(
            'ALL_BETS_UPDATE_DATA',
            JSON.stringify({
              user_id: el.id,
              data: {},
            })
          )
        }

        return response.json({
          message: 'Result declared.',
        })
      } finally {
        await Redis.del(lockKey) // ✅ Always remove the lock
      }
    }

    return response.badRequest({
      message: "You don't have permission",
    })
  }

  public async rollbackMarketResult({ request, authUser, response }: HttpContextContract) {
    if (
      authUser.usetype == 0 ||
      authUser.usetype == 55 ||
      // (authUser.usetype == 11 && authUser.allow_result_revoke)
      (authUser.usetype == 11 &&
        authUser.mstrid == 4957 &&
        authUser?.domain == 'https://bsf247.pro') ||
      (authUser.usetype == 11 && authUser.mstrid == 2 && authUser.mstrname == 'Ccompany')
    ) {
      const data = await request.validate({
        schema: schema.create({
          resId: schema.number(),
          sportsId: schema.number(),
          match_id: schema.number(),
          selectionId: schema.number(),
          isFancy: schema.number(),
          marketId: schema.string(),
        }),
      })

      const matchId = data.match_id
      const marketId = data.marketId

      const match = await Database.query().from('matchmst').where('MstCode', matchId).first()
      if (match) {
        if (match.hard_bet_deleted || match.bet_deleted) {
          return response.badRequest({
            message: 'Result can not be revoked.',
          })
        }

        if ([1233, 1234, 1235, 1236].indexOf(parseInt(match.SportID)) > -1) {
          return response.badRequest({
            message: 'Result can not be revoked.',
          })
        }

        const result = await Database.query().from('tblresult').where('resid', data.resId).first()
        const isAbandoned = result.selectionId == 0 && result.isFancy == 0

        if (result) {
          // revoke abandoned market
          if (isAbandoned) {
            await Database.table('tblbets').insert((builder) => {
              builder.select('*').from('tblabandonedbets').where({
                matchId: matchId,
                marketId: marketId,
              })
            })

            // Step 2: Re-insert restored bets into MongoDB
            // const abandonedBets = await Database.from('tblbets')
            //   .where('matchId', matchId)
            //   .where('marketId', marketId)

            // for (const bet of abandonedBets) {
            // const mongoData = {
            //   MstCode: bet.LID, // Assuming LID is the unique bet identifier
            //   UserId: bet.UserId,
            //   Username: bet.Username,
            //   MatchId: bet.MatchId,
            //   MatchName: bet.MatchName,
            //   MarketId: bet.MarketId,
            //   MarketName: bet.MarketName,
            //   SelectionId: bet.SelectionId,
            //   SelectionName: bet.SelectionName,
            //   Odds: bet.Odds,
            //   Stake: bet.Stake,
            //   Type: bet.Type, // 'Back' or 'Lay'
            //   P_L: bet.P_L, // Profit/Loss
            //   DeviceInfo: bet.DeviceInfo,
            //   Ip: bet.Ip,
            //   Inplay: bet.Inplay, // 1 or 0 indicating in-play
            //   IsFancy: bet.IsFancy, // 0 or 1 for fancy bets
            //   MstDate: new Date(), // Insert date when the bet was restored
            //   // Additional Hierarchy fields (same as in the database)
            //   ParentId: bet.ParentId,
            //   DealerId: bet.DealerId,
            //   MasterId: bet.MasterId,
            //   SuperMasterId: bet.SuperMasterId,
            //   SubAdminId: bet.SubAdminId,
            //   SuperAdminId: bet.SuperAdminId,
            //   CompanyId: bet.CompanyId,
            //   SuperDuperAdminId: bet.SuperDuperAdminId,
            //   UsernameActual: bet.UsernameActual,
            //   DealerName: bet.DealerName,
            //   MasterName: bet.MasterName,
            //   SuperMasterName: bet.SuperMasterName,
            //   SubAdminName: bet.SubAdminName,
            //   SuperAdminName: bet.SuperAdminName,
            //   CompanyName: bet.CompanyName,
            //   SuperDuperAdminName: bet.SuperDuperAdminName,
            // }

            // Insert the restored bet into MongoDB
            // await Mongo.collection('bets').insertOne(mongoData)
            // }

            await Database.from('tblresult').where('resid', data.resId).delete()

            await Database.from('tblabandonedbets')
              .where('matchId', matchId)
              .where('marketId', marketId)
              .delete()

            await Database.query()
              .from('matchmst')
              .where('MstCode', matchId)
              .where('SportID', data.sportsId)
              .update({
                active: 1,
              })

            await Database.query()
              .from('market')
              .where('ID', marketId)
              .where('matchId', matchId)
              .where('sportsId ', data.sportsId)
              .update({
                active: 1,
              })
          }
          // revoke non abandoned(result declared) market
          else {
            await Sp.call(
              '_rollback_result(:sportId,:matchId,:marketId,:selectionId,:resultId,:fancyId)',
              {
                sportId: data.sportsId,
                matchId: matchId,
                marketId: marketId,
                selectionId: data.selectionId,
                resultId: data.resId,
                fancyId: 0,
              }
            )
          }

          // Delete declared result log in Mongo
          await Mongo.collection('declared_results').deleteMany({
            matchId: data?.match_id,
            marketId: data?.marketId,
          })

          await Mongo.collection('market_rollback_audit_logs').insertOne({
            action: 'ROLLBACK',
            sportId: data?.sportsId,
            matchId: data?.match_id,
            marketId: data?.marketId,
            selectionId: data?.selectionId,
            isFancy: data?.isFancy,

            revokedByName: authUser?.mstrname,
            revokedByMstrid: authUser?.mstrid,
            revokedByUsetype: authUser?.usetype,
            revokedByDomain: authUser?.domain,
            createdAt: new Date(),
          })

          await Redis.del('poker_result:' + data.marketId)

          const userIds = await Database.from('tblbets')
            .distinct('UserId as id')
            .where('MatchId', matchId)
            .where('MarketId', marketId)

          const users = await Database.from('createmaster')
            .whereIn(
              'mstrid',
              userIds.map((el) => el.id)
            )
            .select('mstrid', 'mstruserid', 'balance', 'liability')

          const ids = await UserService.betUserIds(matchId, marketId)

          await MarketService.removeMarketCache(matchId)

          await Redis.publish('UPDATE_MATCH_DATA', JSON.stringify({ match_id: matchId }))

          for (const user of users) {
            const mongoData = {
              type: 'ROLLBACK',
              category: 'MARKET',
              userId: user.mstrid,
              username: user.mstruserid,
              betId: null,
              beforeBalance: user.balance,
              beforeLiability: user.liability,
              marketId: marketId,
              matchName: match.matchName,
            }

            await UserService.updateLiability([{ id: user.mstrid }], mongoData, 'add')
          }

          if (ids.length > 0) {
            // remove user's id from ids array because we already update liabilty of them
            const filteredIds = ids
              .filter((id) => {
                return !users.find((user) => user.mstrid == id.id)
              })
              .map((el) => {
                el.type = 'ROLLBACK'
                return el
              })

            await Bull.add(new UpdateLiability().key, filteredIds, { removeOnComplete: true })
          }

          await Redis.publish('DASHBOARD_UPDATE_USER', '')
          await Redis.publish('DASHBOARD_UPDATE_ADMIN', '')
          for (const el of ids) {
            await Redis.publish(
              'BETS_UPDATE_DATA',
              JSON.stringify({
                user_id: el.id,
                match_id: data.match_id,
                data: {},
              })
            )

            await Redis.publish(
              'ALL_BETS_UPDATE_DATA',
              JSON.stringify({
                user_id: el.id,
                data: {},
              })
            )
          }
        }
      }

      return response.json({
        message: 'Result revoked.',
      })
    }

    return response.badRequest({
      message: "You don't have permission",
    })
  }

  public async rollbackFancyResult({ request, authUser, response }: HttpContextContract) {
    if (
      authUser.usetype == 0 ||
      authUser.usetype == 55 ||
      // (authUser.usetype == 11 && authUser.allow_result_revoke)
      (authUser.usetype == 11 &&
        authUser.mstrid == 4957 &&
        authUser?.domain == 'https://bsf247.pro') ||
      (authUser.usetype == 11 && authUser.mstrid == 2 && authUser.mstrname == 'Ccompany')
    ) {
      const data = await request.validate({
        schema: schema.create({
          resId: schema.number(),
          sportsId: schema.number(),
          match_id: schema.number(),
          selectionId: schema.number(),
          isFancy: schema.number(),
        }),
      })

      const match = await Database.query().from('matchmst').where('MstCode', data.match_id).first()
      if (match) {
        if (match.hard_bet_deleted || match.bet_deleted) {
          return response.badRequest({
            message: 'Result can not be revoked.',
          })
        }

        const result = await Database.query().from('tblresult').where('resid', data.resId).first()
        if (result) {
          const isAbandoned = result.selectionId !== 0 && result.isFancy !== 0

          if (isAbandoned) {
            if (result.result == -1) {
              await Database.rawQuery(
                'INSERT INTO bet_entry (BET_ID, BET_VALUE, ODDVALUE, ODDSNUMBER, TYPEID, MATCHID, FANCYID, userId, parantId,DealerID,MasterID,SMasterID,SAdminID,AdminID,CompanyID,ParentExchCompanyID, UserName,DealerName,MasterName,SMasterName,SAdminName,AdminName,CompanyName,ParentExchCompanyName, DATETIME, LOGINID, RESULTID, FNCY_REFID, FHEADNAME, SESSINPYES, SESSINPNO, SPORTID, PONITDIFF, IP_ADDRESS, DEVICEDESC,ParentExchCompany, Company, Admin, SAdmin, SMaster, Master, Dealer, CHIPS, SESSION_NO_SIZE, SESSION_YES_SIZE) SELECT BET_ID, BET_VALUE, ODDVALUE, ODDSNUMBER, TYPEID, MATCHID, FANCYID, userId, parantId,DealerID,MasterID,SMasterID,SAdminID,AdminID,CompanyID,ParentExchCompanyID, UserName,DealerName,MasterName,SMasterName,SAdminName,AdminName,CompanyName,ParentExchCompanyName, DATETIME,LOGINID, RESULTID, FNCY_REFID, FHEADNAME, SESSINPYES, SESSINPNO, SPORTID, PONITDIFF, IP_ADDRESS, DEVICEDESC,ParentExchCompany, Company, Admin, SAdmin, SMaster, Master, Dealer, CHIPS, SESSION_NO_SIZE, SESSION_YES_SIZE FROM abandoned_bet_entry WHERE MATCHID = :matchId AND FANCYID = :fancyId',
                {
                  matchId: data.match_id,
                  fancyId: data.selectionId,
                },
                {
                  mode: 'write',
                }
              )

              await Database.query()
                .from('matchfancy')
                .where('ID', data.selectionId)
                .where('matchId', data.match_id)
                .update({
                  result: null,
                  active: 4,
                  DisplayMsg: 'Decision Pending',
                })

              await Database.query()
                .from('matchmst')
                .where('MstCode', data.match_id)
                .where('SportID', data.sportsId)
                .update({
                  active: 1,
                })

              await Database.from('abandoned_bet_entry')
                .where('matchId', data.match_id)
                .where('fancyId', data.selectionId)
                .delete()
              await Database.from('tblresult').where('resid', data.resId).delete()

              // const restoredBets = await Database.from('bet_entry')
              //   .where('matchId', data.match_id)
              //   .where('fancyId', data.selectionId)

              // for (const bet of restoredBets) {
              //   const mongoData = {
              //     Description: `Cricket>${bet.matchName}>${bet.HeadName}`,
              //     MstCode: bet.LID,
              //     IsMatched: 0,
              //     Liability: '0',
              //     MarketId: bet.TypeID,
              //     MatchId: bet.MatchID,
              //     Odds: bet?.ODDVALUE?.toString(),
              //     P_L: bet?.BET_VALUE?.toLocaleString(), // stake value
              //     Profit: '0',
              //     STATUS: 'Open',
              //     SelectionId: bet.FANCYID,
              //     Stack: bet.BET_VALUE,
              //     Type: bet.TYPEID == 0 ? 'Back' : 'Lay',
              //     UserId: bet.userId,
              //     UserName: bet.UserName,
              //     ip: bet.IP_ADDRESS,
              //     isBack: bet.TYPEID == 0 ? 0 : 1,
              //     is_fancy: 1,
              //     matchName: bet.matchName,
              //     selectionName: bet.HeadName,
              //     sportName: 'Cricket', // Assuming this is always cricket; you can adjust accordingly
              //     sportsId: bet.SportID,
              //     volume: bet.TYPEID == 0 ? bet.SESSINPYES : bet.SESSINPNO,

              //     DealerId: bet.DealerID,
              //     DealerName: bet.DealerName,
              //     MasterId: bet.MasterID,
              //     MasterName: bet.MasterName,
              //     SuperMasterId: bet.SMasterID,
              //     SuperMasterName: bet.SMasterName,
              //     SubAdminId: bet.SAdminID,
              //     SubAdminName: bet.SAdminName,
              //     SuperAdminId: bet.AdminID,
              //     SuperAdminName: bet.AdminName,
              //     CompanyId: bet.CompanyID,
              //     CompanyName: bet.CompanyName,
              //     SuperDuperAdminId: bet.ParentExchCompanyID,
              //     SuperDuperAdminName: bet.ParentExchCompanyName,
              //   }

              //   // Insert into MongoDB collection
              //   // await Mongo.collection('fancy_bets').insertOne(mongoData)
              // }
            } else {
              await Sp.call(
                '_rollback_result(:sportId,:matchId,:marketId,:selectionId,:resultId,:fancyId)',
                {
                  sportId: data.sportsId,
                  matchId: data.match_id,
                  marketId: null,
                  selectionId: data.selectionId,
                  resultId: data.resId,
                  fancyId: data.selectionId,
                }
              )
            }

            await Redis.publish('UPDATE_FANCY', JSON.stringify({ matchId: data.match_id }))

            const ids = await Database.from('bet_entry')
              .distinct('UserId as id')
              .where('matchId', data.match_id)
              .where('fancyId', data.selectionId)
              .union(
                [
                  (query) => {
                    query
                      .from('bet_entry')
                      .distinct('ParantId as id')
                      .where('matchId', data.match_id)
                      .where('fancyId', data.selectionId)
                  },
                  (query) => {
                    query
                      .from('bet_entry')
                      .distinct('DealerID as id')
                      .where('matchId', data.match_id)
                      .where('fancyId', data.selectionId)
                  },
                  (query) => {
                    query
                      .from('bet_entry')
                      .distinct('MasterID as id')
                      .where('matchId', data.match_id)
                      .where('fancyId', data.selectionId)
                  },
                  (query) => {
                    query
                      .from('bet_entry')
                      .distinct('SMasterID as id')
                      .where('matchId', data.match_id)
                      .where('fancyId', data.selectionId)
                  },
                  (query) => {
                    query
                      .from('bet_entry')
                      .distinct('SAdminID as id')
                      .where('matchId', data.match_id)
                      .where('fancyId', data.selectionId)
                  },
                  (query) => {
                    query
                      .from('bet_entry')
                      .distinct('AdminID as id')
                      .where('matchId', data.match_id)
                      .where('fancyId', data.selectionId)
                  },
                  (query) => {
                    query
                      .from('bet_entry')
                      .distinct('CompanyID as id')
                      .where('matchId', data.match_id)
                      .where('fancyId', data.selectionId)
                  },
                  (query) => {
                    query
                      .from('bet_entry')
                      .distinct('ParentExchCompanyID as id')
                      .where('matchId', data.match_id)
                      .where('fancyId', data.selectionId)
                  },
                ],
                true
              )

            const userIds = await Database.from('bet_entry')
              .distinct('UserId as id')
              .where('matchId', data.match_id)
              .where('fancyId', data.selectionId)

            const users = await Database.from('createmaster').whereIn(
              'mstrid',
              userIds.map((el) => el.id)
            )

            const fancy = await Database.from('matchfancy')
              .join('matchmst', 'matchfancy.matchId', 'matchmst.MstCode')
              .where('matchfancy.ID', data.selectionId)
              .where('matchfancy.matchId', data.match_id)
              .select('matchfancy.*', 'matchmst.matchName')
              .first()

            // Re-add the fancy into Redis
            if (fancy && fancy.ind_fancy_selection_id) {
              const redisKey = `fancies:${data.match_id}`
              await Redis.hset(redisKey, {
                [fancy.ind_fancy_selection_id]: JSON.stringify(fancy),
              })
            }

            for (const user of users) {
              const mongoData = {
                type: 'ROLLBACK',
                category: 'FANCY',
                userId: user.mstrid,
                username: user.username,
                betId: null,
                beforeBalance: user.balance,
                beforeLiability: user.liability,
                matchName: fancy.matchName,
                selectionName: fancy.HeadName,
                marketId: fancy.ID,
              }

              await UserService.updateLiability([{ id: user.mstrid }], mongoData, 'add')
            }

            if (ids.length > 0) {
              // remove user's id from ids array because we already update liabilty of them
              const filteredIds = ids
                .filter((id) => {
                  return !users.find((user) => user.mstrid == id.id)
                })
                .map((el) => {
                  el.type = 'ROLLBACK'
                  return el
                })
              await Bull.add(new UpdateLiability().key, filteredIds, { removeOnComplete: true })
            }

            for (const el of ids) {
              await Redis.publish(
                'BETS_UPDATE_DATA',
                JSON.stringify({
                  user_id: el.id,
                  match_id: data.match_id,
                  data: {},
                })
              )

              await Redis.publish(
                'ALL_BETS_UPDATE_DATA',
                JSON.stringify({
                  user_id: el.id,
                  data: {},
                })
              )
            }
          }
        }
      }

      await Mongo.collection('fancy_declared_results').deleteOne({
        matchId: data.match_id,
        fancyId: data.selectionId,
      })

      await Mongo.collection('fancy_rollback_audit_logs').insertOne({
        action: 'ROLLBACK',

        sportId: data.sportsId,
        matchId: data.match_id,

        fancyId: data.selectionId,

        resultResId: data.resId,

        revokedByName: authUser?.mstrname,
        revokedByMstrid: authUser?.mstrid,
        revokedByUsetype: authUser?.usetype,
        revokedByDomain: authUser?.domain,
        revokedAt: new Date(),
      })

      return response.json({
        message: 'Result revoked.',
      })
    }

    return response.badRequest({
      message: "You don't have permission",
    })
  }

  public async getMatchesBySport({ authUser, request, response }: HttpContextContract) {
    if (
      authUser.usetype == 0 ||
      authUser.usetype == 55 ||
      (authUser.usetype == 11 && (authUser.allow_result_declare || authUser.allow_result_revoke)) ||
      (authUser.usetype == 11 &&
        authUser.mstrid == 4957 &&
        authUser?.domain == 'https://bsf247.pro') ||
      (authUser.usetype == 11 && authUser.mstrid == 2 && authUser.mstrname == 'ccompany')
    ) {
      const sportId = request.input('sport_id')
      const search = request.input('search')

      const data = await Database.query()
        .from('matchmst')
        .whereExists((query) => {
          query.from('tblresult').whereColumn('matchmst.mstcode', 'tblresult.matchId').limit(1)
        })
        .if(sportId, (q) => q.where('SportID', sportId))
        .where('SportID', '<', 5)
        .select('MstCode', 'matchName')
        .if(search, (builder) => {
          builder.where((q) => {
            q.whereILike('matchName', '%' + search + '%')
          })
        })
        .orderBy('MstDate', 'desc')
        .limit(10)

      console.log('RSD Log : if part', JSON.stringify(authUser))
      return response.json(data)
    } else {
      console.log('RSD Log : else part', JSON.stringify(authUser))
      return response.json({
        data: [],
      })
    }
  }

  public async getDeclaredTossResults({ request, response }: HttpContextContract) {
    const matchId = request.input('matchId')

    const data = await Database.query()
      .from('tblresult')
      .where('matchId', matchId)
      .where('isFancy', 0)
      .whereILike('marketName', '%toss%')
      .select('*')

    return response.json({
      data,
    })
  }
}
