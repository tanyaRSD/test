import Cache from '@ioc:Adonis/Addons/Cache'
import Redis from '@ioc:Adonis/Addons/Redis'
import { HttpContextContract } from '@ioc:Adonis/Core/HttpContext'
import Logger from '@ioc:Adonis/Core/Logger'
import { rules, schema } from '@ioc:Adonis/Core/Validator'
import Database from '@ioc:Adonis/Lucid/Database'
import Bull from '@ioc:Rocketseat/Bull'
import UpdateLiability from 'App/Jobs/UpdateLiability'
import { Mongo } from 'App/Services/Mongo'
import Parent from 'App/Services/Parent'
import Settings from 'App/Services/Settings'
import Sp from 'App/Services/Sp'
import UserService from 'App/Services/UserService'
import { DateTime } from 'luxon'

export default class FancyController {
  public async index({ authUser, request, response }: HttpContextContract) {
    // if (authUser.usetype == 0 || authUser.usetype == 55) {
    if (
      authUser.usetype == 0 ||
      authUser.usetype == 55 ||
      (authUser.usetype == 11 &&
        authUser.mstrid == 4957 &&
        authUser?.domain == 'https://bsf247.pro') ||
      (authUser.usetype == 11 && authUser.mstrid == 2 && authUser.mstrname == 'Ccompany')
    ) {
      const type = request.input('type')
      const page = request.input('page', 1)
      const search = request.input('search', '')
      let matchId = request.input('matchId', '')
      const limit = request.input('limit', 50)

      if (authUser.usetype == 55) {
        authUser = await UserService.checkPersmission(authUser, 'Fancy Result Declare')

        if (!authUser) {
          return response.badRequest({
            message: 'Invalid request.',
          })
        }
      }

      const matches = await Database.from('matchmst')
        // .where('SportID', 4)
        // .where('active', 1)
        .whereExists((query) => {
          query
            .from('matchfancy')
            .whereColumn('matchmst.MstCode', 'matchfancy.MatchID')
            .whereNull('matchfancy.result')
            .limit(1)
        })
        .select('MstCode', 'matchName')

      if (!matchId && matches.length > 0) {
        matchId = matches[0].MstCode
      }

      const rows = await Database.from('matchfancy')
        .select(
          'matchfancy.ID',
          'matchfancy.Remarks',
          'matchfancy.HeadName',
          'matchfancy.active',
          'matchfancy.TypeID',
          'matchfancy.MatchID',
          'matchfancy.is_indian_fancy',
          'matchfancy.fancy_mode',
          'matchfancy.ind_fancy_selection_id as mFancyId',
          'matchfancy.max_session_bet_liability',
          'matchfancy.max_session_liability',
          'matchfancy.MaxStake',
          'matchfancy.MinStake',
          'matchfancy.in_priority',
          'matchfancy.message',
          'matchfancy.HelperID',
          'matchmst.matchName',
          'matchmst.SportID AS SportID',
          'matchfancy.is_manual',
          'market.Id as market_id',
          Database.raw('"" as result')
        )
        .innerJoin('matchmst', 'matchfancy.MatchID', 'matchmst.MstCode')
        .leftJoin('market', (q) => {
          q.on('matchfancy.MatchID', '=', 'market.matchId').andOnVal(
            'market.Name',
            '=',
            'Match Odds'
          )
        })
        .if(matchId, (q) => {
          q.where('matchfancy.MatchID', matchId)
        })
        .if(type, (q) => {
          q.where('matchfancy.is_indian_fancy', type == 'session' ? 1 : 0)
        })
        .if(search, (q) => {
          q.whereILike('matchfancy.HeadName', `%${search}%`)
        })
        .whereNull('matchfancy.result')
        .orderBy('matchfancy.order', 'desc')
        .paginate(page, limit)

      const companyData = await Database.rawQuery(`
        WITH RECURSIVE user_tree AS (
          SELECT mstrid, parentId, usetype
          FROM createmaster
          WHERE mstrid = ?

          UNION ALL

          SELECT t.mstrid, t.parentId, t.usetype
          FROM createmaster t
          INNER JOIN user_tree ut ON t.mstrid = ut.parentId
        )
        SELECT mstrid AS company_id
        FROM user_tree
        WHERE usetype = 11
        LIMIT 1
      `, [authUser?.mstrid]);

      console.log('Company Data:', companyData);

      let limits: any = []
      if (companyData?.[0]?.length > 0 && companyData[0][0].company_id) {
        limits = await Database.from('user_sport_limit')
          .where('user_id', companyData?.[0]?.[0]?.company_id)
          .where('sport_id', 4)
          .where('usertype', 11)
          .orderBy('user_id', 'desc');
      }

      return response.json({
        data: rows.all(),
        meta: rows.getMeta(),
        limit: limits.length > 0 ? limits : null,
        matches,
        matchId: parseInt(matchId),
      })
    }

    return response.badRequest({
      message: "You don' have permission",
    })
  }

  public async store({ response, authUser, request }: HttpContextContract) {
    if (authUser.usetype == 0 || authUser.usetype == 55) {
      const data = await request.validate({
        schema: schema.create({
          SelectionId: schema.string(),
          match_id: schema.string(),
          sportId: schema.string.optional(),
          RunnerName: schema.string.optional(),
          marketId: schema.string.optional(),
          is_auto: schema.boolean.optional(),
        }),
      })

      if (data.is_auto) {
        await this.sleep(1000)
      }

      const match = await Database.query().from('matchmst').where('MstCode', data.match_id).first()

      if (!match) {
        return response.badRequest({
          message: 'Please activate match first!',
        })
      }

      const fancy = await Database.query()
        .from('matchfancy')
        .where('MatchID', data.match_id)
        .where('ind_fancy_selection_id', data.SelectionId)
        .first()

      if (fancy) {
        return response.status(data.is_auto ? 200 : 400).json({
          message: 'Fancy already activated.',
        })
      }

      const settings = await Settings.all()
      const defaultLimits = Settings.defaultSportLimit
      let sportId: any = '4'
      const limit = defaultLimits.find((el: any) => el.type == 'fancy' && el.sport_id == sportId)
      const maxStake = limit.max_stake
      const minStake = limit.min_stake
      const maxSessionBetLiaibility = settings.fancy_max_session_bet_liability
      const maxSessionLiability = settings.fancy_max_session_liability

      sportId = data.sportId ? data.sportId : '4'

      let requiredfancy: any

      if (['11', '77', '6'].indexOf(sportId) == -1) {
        const allFancy: any = await Cache.use('main').get('FancyId:' + data.match_id)
        const allManualFancy: any = await Cache.use('main').get('manualFancyId:' + data.match_id)

        if (allFancy || allManualFancy) {
          if (allManualFancy) {
            // allFancy.session.push(...allManualFancy.session.filter((ele)=> ))
            // const mergedArray = array1.concat(array2);
            allFancy.session = [...allFancy.session, ...allManualFancy].filter(
              (obj, index, array) =>
                array.findIndex((o) => o.SelectionId === obj.SelectionId) === index
            )
          }
          requiredfancy = allFancy.session.find((f: any) => f.SelectionId == data.SelectionId)
        } else {
          return response.badRequest({
            message: 'Fancy not found!',
          })
        }

        if (!requiredfancy) {
          return response.badRequest({
            message: 'Selection not found!',
          })
        }
      }

      let type = 4
      const runnerName = requiredfancy ? requiredfancy.RunnerName : data.RunnerName
      //1 Over Runs
      //2 Player Run
      //3 Wicket
      //4 Others
      if (runnerName.toLowerCase().includes('over')) {
        type = 1
      } else if (runnerName.toLowerCase().includes('run')) {
        type = 2
      } else if (runnerName.toLowerCase().includes('wkt')) {
        type = 3
      }

      await Database.insertQuery()
        .table('matchfancy')
        .insert({
          MatchID: data.match_id,
          super_admin_fancy_id: data.SelectionId,
          HeadName: runnerName,
          TypeID: 2,
          Remarks: 'INDIAN_SESSION_FANCY',
          date: new Date(),
          time: DateTime.now().toLocaleString(DateTime.TIME_24_WITH_SECONDS),
          SessInptYes: 0,
          SessInptNo: 0,
          fancyRange: 0,
          PlayerId: 0,
          active: 1,
          SprtId: sportId,
          rateDiff: 1,
          pointDiff: 10,
          MinStake: minStake,
          MaxStake: maxStake,
          NoValume: 100,
          YesValume: 100,
          DisplayMsg: 'Close Fancy',
          is_indian_fancy: 1,
          ind_fancy_selection_id: data.SelectionId,
          fancy_mode: 'A',
          max_session_bet_liability: maxSessionBetLiaibility,
          max_session_liability: maxSessionLiability,
          in_priority: type,
          order: requiredfancy ? requiredfancy.Srno : null,
          is_manual: data.SelectionId.includes('M') ? 1 : 0,
        })

      const f = await Database.query()
        .from('matchfancy')
        .leftJoin('matchmst', 'matchfancy.MatchID', '=', 'matchmst.MstCode')
        .where('matchfancy.ind_fancy_selection_id', data.SelectionId)
        .where('matchfancy.MatchID', data.match_id)
        .select('matchfancy.*')
        .first()

      if (f) {
        await Redis.sadd(`active_fancies:${data.match_id}`, data.SelectionId)

        if (['11', '77', '6'].indexOf(sportId) > -1) {
          await Redis.sadd('ACTIVE_VIRTUAL_FANCIES', `${data.match_id}|${data.marketId}`)
        }
        // expire key after 6 days
        await Redis.expire(`active_fancies:${data.match_id}`, 518400)

        const redisKey = `fancies:${data.match_id}`

        // Add/update fancy data in the hash (field = SelectionId)
        await Redis.hset(redisKey, data.SelectionId, JSON.stringify(f))

        // Set expiration for this key (optional)
        await Redis.expire(redisKey, 518400)
      }

      await Redis.publish('UPDATE_FANCY', JSON.stringify({ matchId: data.match_id }))

      return response.json({
        message: 'Fancy activated.',
      })
    }

    return response.badRequest({
      message: "You don't have permission",
    })
  }

  public async show({ response, authUser, request }: HttpContextContract) {
    if (authUser.usetype == 0 || authUser.usetype == 55) {
      const activatedFancies = await Database.query()
        .from('matchfancy')
        .where('MatchID', request.input('matchId'))
      let data = await Cache.use('main').get('FancyId:' + request.input('matchId'))
      return response.json({
        activatedFancies,
        data,
      })
    }

    return response.badRequest({
      message: "You don' have permission",
    })
  }

  public async toggleCompanyFancy({ request, response, authUser }: HttpContextContract) {
    if (authUser.usetype !== 11) {
      return response.unauthorized({ message: 'Only company users can toggle fancies' })
    }

    const data = await request.validate({
      schema: schema.create({
        matchId: schema.string(), // or schema.number() if numeric
        fancyId: schema.string(),
        active: schema.enum(['1', '9']),
      }),
    })

    const { matchId, fancyId, active } = data

    const redisKey = `fancy:company-block:${authUser.mstrid}:${matchId}`

    if (active === '9') {
      // Block: store fancyId in Redis hash
      await Redis.hset(redisKey, {
        [fancyId]: '', // or '1' or any dummy value; not used
      })
    } else {
      // Unblock: remove fancyId from Redis
      await Redis.hdel(redisKey, fancyId)
    }

    await Redis.publish(
      'UPDATE_FANCY',
      JSON.stringify({
        fancyId,
        matchId,
        companyId: authUser.mstrid,
        active,
        source: 'company',
      })
    )

    return response.json({
      message: `Fancy ${active === '9' ? 'disabled' : 'enabled'} for your company`,
    })
  }

  public async update({ response, authUser, params, request }: HttpContextContract) {
    if (authUser.usetype == 0 || authUser.usetype == 55) {
      const data = await request.validate({
        schema: schema.create({
          active: schema.string(),
        }),
      })

      await Database.query()
        .from('matchfancy')
        .where('ID', params.id)
        .update({
          active: data.active,
        })

      const fancy = await this.getFancy(params.id)

      if (fancy?.matchId && fancy?.ind_fancy_selection_id) {
        const redisKey = `fancies:${fancy.matchId}`
        await Redis.hset(redisKey, {
          [fancy.ind_fancy_selection_id]: JSON.stringify(fancy),
        })
      }

      await Redis.publish('UPDATE_FANCY', JSON.stringify(fancy))

      return response.json({
        message: 'Fancy updated.',
      })
    }

    else if (authUser.usetype == 11) {
      const data = await request.validate({
        schema: schema.create({
          MinStake: schema.number(),
          MaxStake: schema.number(),
        }),
      })

      const fancyId = params.id
      const table = 'fancy_settings'

      let parents: any = await UserService.parents(authUser.mstrid)
      parents = parents.map((i: any) => i.mstrid)

      const matchFancy = await Database.from('matchfancy')
        .select('ID', 'MinStake', 'MaxStake', 'SprtId')
        .where('ID', fancyId)
        .firstOrFail()

      const userLimit = await Database.from('user_sport_limit')
        .whereIn('user_id', parents)
        .where('sport_id', matchFancy.SprtId)
        .where('type', 'fancy')
        .orderBy('user_id', 'desc')
        .first()

      // ======================================================
      // RAW EXISTING USER SETTINGS
      // ======================================================
      const existingSetting = await Database.from('fancy_settings')
        .where('user_id', authUser.mstrid)
        .where('fancy_id', fancyId)
        .first()

      // ======================================================
      // NORMALIZE NUMBERS
      // ======================================================
      const incomingMin = Number(data.MinStake)
      const incomingMax = Number(data.MaxStake)

      const baseMin = Number(matchFancy.MinStake || 0)
      const baseMax = Number(matchFancy.MaxStake || 5000000)

      const userMin = Number(userLimit?.min_stake || 0)
      const userMax = Number(userLimit?.max_stake || 5000000)

      const prevMin = Number(existingSetting?.min_stack || 0)
      const prevMax = Number(existingSetting?.max_stack || 5000000)

      // ======================================================
      // FINAL ALLOWED RANGE (RULE ENGINE)
      // ======================================================
      const allowedMin = Math.max(baseMin, userMin, prevMin)
      const allowedMax = Math.min(baseMax, userMax, prevMax)

      // ======================================================
      // VALIDATIONS
      // ======================================================

      // ❌ Min validation
      if (incomingMin < allowedMin) {
        return response.badRequest({
          message: `Min stake cannot be less than ${allowedMin}`,
        })
      }

      // ❌ Max validation
      if (incomingMax > allowedMax) {
        return response.badRequest({
          message: `Max stake cannot be greater than ${allowedMax}`,
        })
      }

      // ❌ Logical validation
      if (incomingMin > incomingMax) {
        return response.badRequest({
          message: 'Min stake cannot be greater than max stake',
        })
      }

      // ======================================================
      // INSERT / UPDATE
      // ======================================================
      if (existingSetting) {
        await Database.query()
          .from(table)
          .where('user_id', authUser.mstrid)
          .where('fancy_id', fancyId)
          .update({
            min_stack: incomingMin,
            max_stack: incomingMax,
          })
      } else {
        await Database.table(table).insert({
          user_id: authUser.mstrid,
          fancy_id: fancyId,
          min_stack: incomingMin,
          max_stack: incomingMax,
        })
      }

      const updatedFancy = await this.getFancy(fancyId)

      if (updatedFancy?.matchId && updatedFancy?.ind_fancy_selection_id) {
        const redisKey = `fancies:${updatedFancy.matchId}`
        await Redis.hset(redisKey, {
          [updatedFancy.ind_fancy_selection_id]: JSON.stringify(updatedFancy),
        })
      }

      await Redis.publish(
        'UPDATE_FANCY',
        JSON.stringify({ matchId: matchFancy.ID })
      )

      return response.json({
        message: 'Fancy settings updated successfully.',
      })
    }
    return response.badRequest({
      message: "You don't have permission",
    })
  }

  public async updateCompanyStake({ response, authUser, params, request }: HttpContextContract) {
    if (authUser.usetype == 11) {
      const data = await request.validate({
        schema: schema.create({
          MinStake: schema.number(),
          MaxStake: schema.number(),
        }),
      })

      if (data.MinStake > data.MaxStake) {
        return response.status(400).json({
          message: 'Min stake can not be greater than max stake.',
        })
      }

      const matchId = params.matchId
      const userType = authUser.usetype || 11;
      const table = 'fancy_settings'
      console.log('updateStack according to MatchId', matchId, 'UserType', userType)

      let parents: any = await UserService.parents(authUser.mstrid)
      parents = parents.map((i: any) => i.mstrid)

      const fancies = await Database.from('matchfancy')
        .joinRaw(
          `LEFT JOIN user_sport_limit as usl 
         ON usl.id = (
           SELECT id FROM user_sport_limit 
           WHERE user_id IN (${parents.toString()}) 
           AND sport_id = matchfancy.SprtId 
           AND type = 'fancy' 
           ORDER BY user_id DESC LIMIT 1
         )`
        )
        .whereNull('matchfancy.result')
        .where('matchfancy.MatchID', matchId)
        .select(
          'matchfancy.ID',
          Database.raw(
            'ROUND(GREATEST(matchfancy.MinStake, COALESCE(usl.min_stake, 0)),0) as min_stack'
          ),
          Database.raw(
            'ROUND(LEAST(matchfancy.MaxStake, COALESCE(usl.max_stake, 5000000)),0) as max_stack'
          )
        )

      // ✅ STEP 1: Validate ALL fancies first
      const errors: string[] = []

      for (const fancy of fancies) {
        if (data.MinStake < fancy.min_stack) {
          errors.push(
            `Fancy ${fancy.ID}: Min stake must be >= ${fancy.min_stack}`
          )
        }

        if (data.MaxStake > fancy.max_stack) {
          errors.push(
            `Fancy ${fancy.ID}: Max stake must be <= ${fancy.max_stack}`
          )
        }
      }

      // ❌ If any validation fails → STOP
      if (errors.length) {
        return response.status(400).json({
          message: 'Validation failed',
          errors,
        })
      }

      // ✅ STEP 2: Update after validation passes
      for (const fancy of fancies) {
        const fancyId = fancy.ID
        const isSettingExists = await Database.query()
          .from(table)
          .where('user_id', authUser.mstrid)
          .where('fancy_id', fancyId)
          .first()

        if (isSettingExists) {
          await Database.query()
            .from(table)
            .where('user_id', authUser.mstrid)
            .where('fancy_id', fancyId)
            .update({
              min_stack: data.MinStake,
              max_stack: data.MaxStake,
              matchid: matchId ? matchId : fancy.MatchID,
              usetype: userType
            })
        } else {
          await Database.table(table).insert({
            user_id: authUser.mstrid,
            fancy_id: fancyId,
            min_stack: data.MinStake,
            max_stack: data.MaxStake,
            matchid: matchId ? matchId : fancy.MatchID,
            usetype: userType
          })
        }
      }

      // ✅ FIX: delete ALL related redis keys (correct pattern + removed extra })
      const pattern = `fancies:${matchId}:${authUser.mstrid}:*`
      const redisKeyMinMax = `fanciesMinMax:${matchId}:${authUser.mstrid}`
      const keys = await Redis.keys(pattern)

      if (keys.length) {
        await Redis.del(...keys)
        await Redis.del(redisKeyMinMax)
      }
      await Redis.set(redisKeyMinMax, JSON.stringify({ min: data.MinStake, max: data.MaxStake })) // expire after 6 days

      // ✅ Notify system
      await Redis.publish(
        'UPDATE_FANCY',
        JSON.stringify({ matchId: matchId })
      )

      return response.json({
        message: 'Fancy settings updated successfully.',
      })
    }
    return response.badRequest({
      message: "You don't have permission",
    })
  }

  public async updateStake({ response, authUser, params, request }: HttpContextContract) {
    const data = await request.validate({
      schema: schema.create({
        MinStake: schema.number(),
        MaxStake: schema.number(),
        max_session_bet_liability: schema.number(),
        max_session_liability: schema.number(),
        message: schema.string.nullableAndOptional({ trim: true }),
      }),
    })

    if (authUser.usetype == 0 || authUser.usetype == 55) {
      await Database.query().from('matchfancy').where('ID', params.id).update(data)

      const fancy = await this.getFancy(params.id)

      const redisKey = `fancies:${fancy.MatchID}`
      const fieldKey = fancy.ind_fancy_selection_id

      const redisData = await Redis.hget(redisKey, fieldKey)

      if (redisData) {
        const existingFancy = JSON.parse(redisData)

        existingFancy.min_stack = data.MinStake
        existingFancy.max_stack = data.MaxStake
        existingFancy.max_session_bet_liability = data.max_session_bet_liability
        existingFancy.max_session_liability = data.max_session_liability
        existingFancy.message = data.message

        await Redis.hset(redisKey, {
          [fieldKey]: JSON.stringify(existingFancy),
        })
      }

      await Redis.publish('UPDATE_FANCY', JSON.stringify({ matchId: fancy.MatchID }))

      return response.json({
        message: 'Fancy updated.',
      })
    }

    return response.badRequest({
      message: "You don' have permission",
    })
  }

  public async declareFancyResult({ request, authUser, response }: HttpContextContract) {
    const data = await request.validate({
      schema: schema.create({
        fancy_Id: schema.number(),
        matchId: schema.number(),
        result: schema.string(),
        sportId: schema.number(),
        selectionId: schema.string.optional(),
      }),
    })

    let fancy: any

    if (data.selectionId) {
      fancy = await Database.from('matchfancy')
        .join('matchmst', 'matchfancy.MatchID', 'matchmst.MstCode')
        .where('matchfancy.ind_fancy_selection_id', data.selectionId)
        .where('matchfancy.MatchID', data.matchId)
        .whereNull('matchfancy.result')
        .select('matchfancy.*', 'matchmst.matchName as matchName')
        .first()
      if (!fancy) {
        return response.json({
          message: 'Fancy not found.',
        })
      } else {
        data.fancy_Id = fancy.ID
      }
    } else {
      fancy = await Database.from('matchfancy')
        .join('matchmst', 'matchfancy.MatchID', 'matchmst.MstCode')
        .where('matchfancy.ID', data.fancy_Id)
        .whereNull('matchfancy.result')
        .select('matchfancy.*', 'matchmst.matchName as matchName')
        .first()
      if (!fancy) {
        return response.badRequest({
          message: 'Fancy not found.',
        })
      }
    }

    if (data.selectionId) {
      await Redis.srem(`active_fancies:${data.matchId}`, data.selectionId)

      // Also remove from fancies hash if needed
      await Redis.hdel(`fancies:${data.matchId}`, data.selectionId)
    }

    if (fancy.ind_fancy_selection_id) {
      await Redis.srem(`active_fancies:${data.matchId}`, fancy.ind_fancy_selection_id)

      // Remove fancy from Redis hash as well
      await Redis.hdel(`fancies:${data.matchId}`, fancy.ind_fancy_selection_id)
    }

    const result = await Database.query()
      .from('tblresult')
      .where('matchId', data.matchId)
      .where('selectionId', data.fancy_Id)
      .where('isFancy', 1)
      .first()

    if (result) {
      return response.badRequest({
        message: 'Result already declared!',
      })
    }

    if (
      authUser.usetype == 0 ||
      authUser.usetype == 55 ||
      // (authUser.usetype == 11 && authUser.allow_result_declare)
      (authUser.usetype == 11 &&
        authUser.mstrid == 4957 &&
        authUser?.domain == 'https://bsf247.pro') ||
      (authUser.usetype == 11 && authUser.mstrid == 2 && authUser.mstrname == 'Ccompany')
    ) {
      try {
        if (authUser.usetype == 55) {
          authUser = await UserService.checkPersmission(authUser, 'Fancy Result Declare')

          if (!authUser) {
            return response.badRequest({
              message: 'Invalid request.',
            })
          }
        }

        const userIds = await Database.from('bet_entry')
          .distinct('UserId as id')
          .where('matchId', data.matchId)
          .where('fancyId', data.fancy_Id)

        const users = await Database.from('createmaster').whereIn(
          'mstrid',
          userIds.map((el) => el.id)
        )

        const rows = await Sp.call('_result_fancy(:sportId,:matchId,:fancyId,:result, :userNM)', {
          sportId: data.sportId,
          matchId: data.matchId,
          fancyId: data.fancy_Id,
          result: data.result,
          userNM: authUser.mstruserid,
        })

        if (rows.length > 0) {
          const user = rows[0]

          if (user.iReturn == 1) {
            // ✅ Remove fancy from all company block hashes starts **//
            const pattern = `fancy:company-block:*:${data.matchId}` // only match keys for this match
            const keys = await Redis.keys(pattern)

            if (keys.length > 0) {
              await Promise.all(keys.map((key) => Redis.hdel(key, data.fancy_Id.toString())))
            }
            // ✅ Remove fancy from all company block hashes ends**//

            for (const user of users) {
              const mongoData = {
                type: 'RESULT',
                category: 'FANCY',
                userId: user.mstrid,
                username: user.mstruserid,
                betId: null,
                beforeBalance: user.balance,
                beforeLiability: user.liability,
                matchName: fancy.matchName,
                selectionName: fancy.HeadName,
                marketId: fancy.ID,
              }

              await UserService.updateLiability([{ id: user.mstrid }], mongoData, 'add')
            }

            this.updateLiability(data.matchId, data.fancy_Id, 'bet_entry', users).then()

            if (fancy.market_id) {
              // remove line market from active markets key
              const fm = await Database.query()
                .from('matchfancy')
                .leftJoin('matchmst', 'matchfancy.MatchID', '=', 'matchmst.MstCode')
                .where('market_id', fancy.market_id)
                .select('matchfancy.*', 'matchmst.seriesId')
                .first()
              if (fm) {
                await Redis.srem(
                  'ACTIVE_MARKETS',
                  JSON.stringify({
                    sportId: fm.SprtId.toString(),
                    seriesId: fm.seriesId.toString(),
                    matchId: fm.MatchID.toString(),
                    marketId: fm.market_id.toString(),
                  })
                )

                await Redis.srem(
                  'ACTIVE_LINE_MARKETS',
                  JSON.stringify({
                    sportId: fm.SprtId.toString(),
                    seriesId: fm.seriesId.toString(),
                    matchId: fm.MatchID.toString(),
                    marketId: fm.market_id.toString(),
                  })
                )
              }
            }

            await Redis.publish('UPDATE_FANCY', JSON.stringify({ matchId: data.matchId }))

            await Mongo.collection('fancy_declared_results').insertOne({
              action: 'DECLARE',

              sportId: data.sportId,
              matchId: data.matchId,

              fancyId: data.fancy_Id,
              selectionId: fancy.ind_fancy_selection_id || null,

              result: data.result,

              declaredByName: authUser.mstrname,
              declaredByMstrid: authUser.mstrid,
              declaredByUsetype: authUser.usetype,
              declaredByDomain: authUser?.domain,

              declaredAt: new Date(),
            })

            return response.json({
              message: 'Result declared',
            })
          }
        }
      } catch (e) {
        Logger.error('FANCY RESULT %o', e)
      }

      return response.badRequest({
        message: 'There are error in procedure.',
      })
    }

    return response.badRequest({
      message: "You don' have permission",
    })
  }

  public async abandonedFancy({ request, authUser, response }: HttpContextContract) {
    const data = await request.validate({
      schema: schema.create({
        fancy_Id: schema.number(),
        matchId: schema.number(),
        sportId: schema.number(),
        selectionId: schema.string.optional(),
      }),
    })
    let fancy: any
    if (data.selectionId) {
      fancy = await Database.from('matchfancy')
        .where('ind_fancy_selection_id', data.selectionId)
        .where('MatchID', data.matchId)
        .whereNull('result')
        .first()
      if (!fancy) {
        return response.json({
          message: 'Fancy not found1.',
        })
      } else {
        data.fancy_Id = fancy.ID
      }
    } else {
      fancy = await Database.from('matchfancy')
        .where('ID', data.fancy_Id)
        .whereNull('result')
        .first()
      if (!fancy) {
        return response.badRequest({
          message: 'Fancy not found2.',
        })
      }
    }

    const result = await Database.query()
      .from('tblresult')
      .where('matchId', data.matchId)
      .where('selectionId', data.fancy_Id)
      .where('isFancy', 1)
      .first()

    if (result) {
      return response.badRequest({
        message: 'Result already declared!',
      })
    }

    if (
      authUser.usetype == 0 ||
      authUser.usetype == 55 ||
      (authUser.usetype == 11 &&
        authUser.mstrid == 4957 &&
        authUser?.domain == 'https://bsf247.pro') ||
      (authUser.usetype == 11 && authUser.mstrid == 2 && authUser.mstrname == 'Ccompany')
    ) {
      const fancy = await Database.query()
        .from('matchfancy')
        .join('matchmst', 'matchfancy.MatchID', 'matchmst.MstCode')
        .where('matchfancy.ID', data.fancy_Id)
        .where('matchfancy.active', 1)
        .where('matchfancy.MatchID', data.matchId)
        .select('matchfancy.*', 'matchmst.matchName as matchName')
        .first()

      if (fancy) {
        const userIds = await Database.from('bet_entry')
          .distinct('UserId as id')
          .where('matchId', data.matchId)
          .where('fancyId', data.fancy_Id)

        const users = await Database.from('createmaster').whereIn(
          'mstrid',
          userIds.map((el) => el.id)
        )

        await Database.rawQuery(
          'INSERT INTO abandoned_bet_entry (BET_ID, BET_VALUE, ODDVALUE, ODDSNUMBER, TYPEID, MATCHID, FANCYID, userId, parantId,DealerID,MasterID,SMasterID,SAdminID,AdminID,CompanyID,ParentExchCompanyID, UserName,DealerName,MasterName,SMasterName,SAdminName,AdminName,CompanyName,ParentExchCompanyName, DATETIME, LOGINID, RESULTID, FNCY_REFID, FHEADNAME, SESSINPYES, SESSINPNO, SPORTID, PONITDIFF, IP_ADDRESS, DEVICEDESC,ParentExchCompany, Company, Admin, SAdmin, SMaster, Master, Dealer, CHIPS, SESSION_NO_SIZE, SESSION_YES_SIZE) SELECT BET_ID, BET_VALUE, ODDVALUE, ODDSNUMBER, TYPEID, MATCHID, FANCYID, userId, parantId,DealerID,MasterID,SMasterID,SAdminID,AdminID,CompanyID,ParentExchCompanyID, UserName,DealerName,MasterName,SMasterName,SAdminName,AdminName,CompanyName,ParentExchCompanyName, DATETIME,LOGINID, RESULTID, FNCY_REFID, FHEADNAME, SESSINPYES, SESSINPNO, SPORTID, PONITDIFF, IP_ADDRESS, DEVICEDESC,ParentExchCompany, Company, Admin, SAdmin, SMaster, Master, Dealer, CHIPS, SESSION_NO_SIZE, SESSION_YES_SIZE FROM bet_entry WHERE MATCHID = :matchId AND FANCYID = :fancyId',
          {
            matchId: data.matchId,
            fancyId: data.fancy_Id,
          },
          {
            mode: 'write',
          }
        )

        await Database.insertQuery().table('tblresult').insert({
          sportId: data.sportId,
          matchId: data.matchId,
          date: new Date(),
          isFancy: 1,
          selectionId: data.fancy_Id,
          result: '-1',
          userID: authUser.mstruserid,
        })

        await Database.from('bet_entry')
          .where('matchId', data.matchId)
          .where('fancyId', data.fancy_Id)
          .delete()

        await Database.from('matchfancy')
          .where('SprtId', data.sportId)
          .where('MatchID', data.matchId)
          .where('ID', data.fancy_Id)
          .update({
            result: '-1',
            active: 2,
            DisplayMsg: 'Close Fancy',
          })

        for (const user of users) {
          const mongoData = {
            type: 'RESULT',
            category: 'FANCY',
            userId: user.mstrid,
            username: user.mstruserid,
            betId: null,
            beforeBalance: user.balance,
            beforeLiability: user.liability,
            matchName: fancy.matchName,
            selectionName: fancy.HeadName,
            marketId: fancy.ID,
          }

          await UserService.updateLiability([{ id: user.mstrid }], mongoData, 'add')
        }

        this.updateLiability(data.matchId, data.fancy_Id, 'abandoned_bet_entry', users).then()

        if (fancy.market_id) {
          // remove line market from active markets key
          const fm = await Database.query()
            .from('matchfancy')
            .leftJoin('matchmst', 'matchfancy.MatchID', '=', 'matchmst.MstCode')
            .where('market_id', fancy.market_id)
            .select('matchfancy.*', 'matchmst.seriesId')
            .first()
          if (fm) {
            await Redis.srem(
              'ACTIVE_MARKETS',
              JSON.stringify({
                sportId: fm.SprtId.toString(),
                seriesId: fm.seriesId.toString(),
                matchId: fm.MatchID.toString(),
                marketId: fm.market_id.toString(),
              })
            )

            await Redis.srem(
              'ACTIVE_LINE_MARKETS',
              JSON.stringify({
                sportId: fm.SprtId.toString(),
                seriesId: fm.seriesId.toString(),
                matchId: fm.MatchID.toString(),
                marketId: fm.market_id.toString(),
              })
            )
          }
        }

        await Redis.publish('UPDATE_FANCY', JSON.stringify({ matchId: data.matchId }))

        if (data.selectionId) {
          await Redis.srem(`active_fancies:${data.matchId}`, data.selectionId)
          await Redis.hdel(`fancies:${data.matchId}`, data.selectionId)
        }

        if (fancy.ind_fancy_selection_id) {
          await Redis.srem(`active_fancies:${data.matchId}`, fancy.ind_fancy_selection_id)
          await Redis.hdel(`fancies:${data.matchId}`, fancy.ind_fancy_selection_id)
        }

        await Mongo.collection('fancy_declared_results').insertOne({
          action: 'ABANDON',

          sportId: data.sportId,
          matchId: data.matchId,

          fancyId: data.fancy_Id,
          selectionId: fancy.ind_fancy_selection_id || null,

          result: '-1',

          declaredByName: authUser.mstrname,
          declaredByMstrid: authUser.mstrid,
          declaredByUsetype: authUser.usetype,
          declaredByDomain: authUser?.domain,

          declaredAt: new Date(),
        })

        return response.json({
          message: 'Fancy abandoned.',
        })
      }

      return response.badRequest({
        message: 'Fancy not found3.',
      })
    }

    return response.badRequest({
      message: "You don' have permission",
    })
  }

  public async fancyPos({ request, authUser, response }: HttpContextContract) {
    const data = await request.validate({
      schema: schema.create({
        fancyId: schema.number(),
        TypeID: schema.number(),
        currentRun: schema.number(),
      }),
    })

    if (authUser.usetype != '55') {
      const key = `fancy_position:${authUser.mstrid}:${data.fancyId}`
      const Result = await Cache.remember(key, 60, async () => {
        return await Sp.readCall('_get_score_position(:userId,:fancyId,:TypeID,:currentRun)', {
          userId: authUser.mstrid,
          TypeID: data.TypeID,
          fancyId: data.fancyId,
          currentRun: data.currentRun,
        })
      })

      return response.json({
        data: Result,
      })
    }

    return response.badRequest({
      message: "You don' have permission",
    })
  }

  public async fancyLiability({ request, authUser, response }: HttpContextContract) {
    const data = await request.validate({
      schema: schema.create({
        fancyIds: schema.array().members(schema.string()),
      }),
    })
    let bookData: any = []

    if (data.fancyIds.length > 0) {
      if (authUser.usetype == 55) {
        bookData = (await Redis.hmget('fancyBookData:' + 1, ...data.fancyIds)) || []
      } else {
        bookData = (await Redis.hmget('fancyBookData:' + authUser.mstrid, ...data.fancyIds)) || []
      }

      bookData = bookData.map((el: any) => JSON.parse(el)).filter((el: any) => el)
    }

    return response.json({
      data: bookData,
    })
  }

  public async blockedFancyUsers({ request, authUser, response }: HttpContextContract) {
    if (request.method() == 'GET') {
      const data = await request.validate({
        schema: schema.create({
          fancyId: schema.number(),
        }),
      })
      const search = request.input('search');
      const filter = request.input('filter');
      let rows: any = await Database.from('nested_users')
        .withRecursive('nested_users', (query) => {
          query
            .select(
              'm.mstrid',
              'm.mstruserid',
              'm.mstrname',
              'm.parentId',
              Database.raw('IF(bf.id IS NOT NULL, 1, 0) AS is_blocked')
            )
            .from('createmaster AS m')
            .leftJoin('blocked_fancies AS bf', (builder) => {
              builder
                .andOn('m.mstrid', 'bf.user_id')
                .andOnVal('bf.fancy_id', '=', data.fancyId)
                .andOnVal('bf.locked_by', '=', authUser.mstrid)
            })
            .where('m.mstrid', authUser.mstrid)
            .unionAll((builder) => {
              builder
                .select(
                  'u.mstrid',
                  'u.mstruserid',
                  'u.mstrname',
                  'u.parentId',
                  Database.raw('IF(bf.id IS NOT NULL, 1, 0) AS is_blocked')
                )
                .from('createmaster AS u')
                .innerJoin('nested_users AS nu', 'nu.mstrid', 'u.parentId')
                .leftJoin('blocked_fancies AS bf', (builder) => {
                  builder
                    .andOn('u.mstrid', 'bf.user_id')
                    .andOnVal('bf.fancy_id', '=', data.fancyId)
                    .andOnVal('bf.locked_by', '=', authUser.mstrid)
                })
            })
        })
        .whereNot('mstrid', authUser.mstrid)
        .if(search, (builder) => {
          builder.where((q) => {
            q.whereILike('mstrname', '%' + search + '%')
            q.orWhereILike('mstruserid', '%' + search + '%')
          })
        }).if(filter !== '', (builder) => {
          builder.where('is_blocked', filter)
        })
        .limit(50)

      return response.json(rows)
    } else {
      const data = await request.validate({
        schema: schema.create({
          fancyId: schema.number(),
          usersId: schema.array([rules.distinct('*')]).members(schema.number()),
          matchId: schema.number(),
        }),
      })

      for (let id of data.usersId) {
        if (!(await Parent.validate(authUser, id))) {
          return response.badRequest({
            message: 'Invalid request.',
          })
        }
      }

      await Database.from('blocked_fancies')
        .where('fancy_id', data.fancyId)
        .if(request.input('self') == 'yes', (q) => {
          q.where('user_id', authUser.mstrid)
        })
        .where('locked_by', '=', authUser.mstrid)
        .delete()

      if (data.usersId.length > 0) {
        await Database.table('blocked_fancies').multiInsert(
          data.usersId.map((el: any) => {
            return {
              fancy_id: data.fancyId,
              user_id: el,
              locked_by: authUser.mstrid,
            }
          })
        )
      }

      await Redis.publish('UPDATE_FANCY', JSON.stringify({ matchId: data.matchId }))

      return response.json({
        message: 'Data saved.',
      })
    }
  }

  public async activateFancy({ request, authUser, response }: HttpContextContract) {
    const data = await request.validate({
      schema: schema.create({
        matchId: schema.string(),
      }),
    })

    if (authUser.usetype == 0 || authUser.usetype == 55) {
      const market = await Database.query()
        .from('market')
        .where('matchId', data.matchId)
        .where('Name', 'Match Odds')
        .first()
      if (!market) {
        return response.badRequest({
          message: 'Please activate match odds market first!',
        })
      }

      if (await Redis.sismember('ACTIVE_FANCIES', `${data.matchId}|${market.Id}`)) {
        return response.badRequest({
          message: 'Fancy already activated.',
        })
      }

      // orginal
      await Redis.sadd('ACTIVE_FANCIES', `${data.matchId}|${market.Id}`)
      await Database.from('matchmst')
        .where('MstCode', data.matchId)
        .update({ has_fancy: 1, auto_add_fancy: 1 })
      await Redis.sadd('auto_fancy_matches', data.matchId)

      return response.json({
        message: 'Fancy activated successfully.',
      })
    }

    return response.badRequest({
      message: "You don' have permission",
    })
  }

  public async deActivateFancy({ request, authUser, response }: HttpContextContract) {
    const data = await request.validate({
      schema: schema.create({
        matchId: schema.string(),
      }),
    })

    if (authUser.usetype == 0 || authUser.usetype == 55) {
      const market = await Database.query()
        .from('market')
        .where('matchId', data.matchId)
        .where('Name', 'Match Odds')
        .first()

      if (market) {
        await Redis.srem('ACTIVE_FANCIES', `${data.matchId}|${market.Id}`)
        await Database.from('matchmst')
          .where('MstCode', data.matchId)
          .update({ has_fancy: 0, auto_add_fancy: 0 })
        await Redis.srem('auto_fancy_matches', data.matchId)
      }

      return response.json({
        message: 'Fancy deactivated successfully.',
      })
    }

    return response.badRequest({
      message: "You don' have permission",
    })
  }

  public async addManualFancy({ request, authUser, response }: HttpContextContract) {
    const data = await request.validate({
      schema: schema.create({
        runnerName: schema.string(),
        selectionId: schema.string(),
        match_id: schema.string(),
        is_manual: schema.boolean.optional(),
      }),
    })

    if (authUser.usetype == 0 || authUser.usetype == 55) {
      if (authUser.usetype == 55) {
        authUser = await UserService.checkPersmission(authUser, 'Active Matches and Manage Series')

        if (!authUser) {
          return response.badRequest({
            message: 'Invalid request.',
          })
        }
      }

      const match = await Database.query().from('matchmst').where('MstCode', data.match_id).first()
      if (match) {
        if (match.active == 0) {
          return response.badRequest({
            message: 'Match is not active.',
          })
        }
      } else {
        return response.badRequest({
          message: 'Match is not found.',
        })
      }

      const market = await Database.query()
        .from('market')
        .where('matchId', data.match_id)
        .where('Name', 'Match Odds')
        .first()
      if (!market) {
        return response.badRequest({
          message: 'Please activate match odds market first!',
        })
      }

      if (!(await Redis.sismember('ACTIVE_FANCIES', `${data.match_id}|${market.Id}`))) {
        return response.badRequest({
          message: 'Fancy is not activated.',
        })
      }

      const fancy = await Database.query()
        .from('matchfancy')
        .where('MatchID', data.match_id)
        .where('ind_fancy_selection_id', data.selectionId)
        .first()

      if (fancy) {
        return response.badRequest({
          message: 'Fancy already activated.',
        })
      }

      const allManualFancy: any = await Cache.get('manualFancyId:' + data.match_id)
      let isFancyExists: any

      if (allManualFancy) {
        isFancyExists = allManualFancy.find(
          (f: any) => f.SelectionId == data.selectionId || f.RunnerName == data.runnerName
        )
      }

      if (isFancyExists) {
        return response.badRequest({
          message: 'Fancy already exists!',
        })
      }

      const fancyData = {
        BackPrice1: 0,
        BackSize1: 100,
        GameStatus: 'Suspended',
        LayPrice1: 0,
        LaySize1: 100,
        RunnerName: data.runnerName,
        SelectionId: data.selectionId,
        type: 1,
      }

      const session = allManualFancy ? [...allManualFancy, fancyData] : [fancyData]

      await Cache.forever('manualFancyId:' + data.match_id, session)

      await Redis.del(`fancyId:${data.match_id}*`)
      const pattern = `fancies:${data.match_id}:*`
      const keys = await Redis.keys(pattern) // okay for small keyspaces
      if (keys.length) await Redis.del(...keys)

      // await Redis.sadd(
      //   'MANUAL_MARKET_LIST',
      //   JSON.stringify({
      //     marketId: data.marketId,
      //     marketName: data.marketName,
      //     match_id: data.match_id,
      //     series_id: data.series_id,
      //     sports_id: data.sports_id,
      //     totalMatched: data.totalMatched,
      //     runners: data.runners,
      //     is_manual: data.is_manual,
      //   })
      // )

      return response.json({
        message: 'Fancy Added.',
      })
    }

    return response.badRequest({
      message: "You don' have permission",
    })
  }

  private async updateLiability(matchId, fancyId, table = 'bet_entry', users: any[] = []) {
    const ids = await Database.from(table)
      .distinct('userId as id')
      .where('matchId', matchId)
      .where('fancyId', fancyId)
      .union(
        [
          (query) => {
            query
              .from(table)
              .distinct('ParantId as id')
              .where('matchId', matchId)
              .where('fancyId', fancyId)
          },
          (query) => {
            query
              .from(table)
              .distinct('DealerID as id')
              .where('matchId', matchId)
              .where('fancyId', fancyId)
          },
          (query) => {
            query
              .from(table)
              .distinct('MasterID as id')
              .where('matchId', matchId)
              .where('fancyId', fancyId)
          },
          (query) => {
            query
              .from(table)
              .distinct('SMasterID as id')
              .where('matchId', matchId)
              .where('fancyId', fancyId)
          },
          (query) => {
            query
              .from(table)
              .distinct('SAdminID as id')
              .where('matchId', matchId)
              .where('fancyId', fancyId)
          },
          (query) => {
            query
              .from(table)
              .distinct('AdminID as id')
              .where('matchId', matchId)
              .where('fancyId', fancyId)
          },
          (query) => {
            query
              .from(table)
              .distinct('CompanyID as id')
              .where('matchId', matchId)
              .where('fancyId', fancyId)
          },
          (query) => {
            query
              .from(table)
              .distinct('ParentExchCompanyID as id')
              .where('matchId', matchId)
              .where('fancyId', fancyId)
          },
        ],
        true
      )

    if (ids.length > 0) {
      const filteredIds = ids
        .filter((id) => {
          return !users.find((user) => user.id == id.id)
        })
        .map((el) => {
          el.type = 'RESULT'
          return el
        })

      await Bull.add(new UpdateLiability().key, filteredIds, { removeOnComplete: true })
    }

    for (const el of ids) {
      await Redis.publish(
        'BETS_UPDATE_DATA',
        JSON.stringify({
          user_id: el.id,
          match_id: matchId,
          data: {},
        })
      )

      await Redis.publish('ALL_BETS_UPDATE_DATA', JSON.stringify({ user_id: el.id, data: {} }))
    }
  }

  private async getFancy(id) {
    return await Database.query()
      .from('matchfancy')
      .leftJoin('matchmst', 'matchfancy.MatchID', '=', 'matchmst.MstCode')
      .where('matchfancy.ID', id)
      .select('matchfancy.*')
      .first()
  }

  private sleep(ms: number) {
    return new Promise((resolve) => setTimeout(resolve, ms))
  }
}
