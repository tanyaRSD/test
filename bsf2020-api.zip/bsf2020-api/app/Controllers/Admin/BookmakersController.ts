import Redis from '@ioc:Adonis/Addons/Redis'
import { HttpContextContract } from '@ioc:Adonis/Core/HttpContext'
import { schema } from '@ioc:Adonis/Core/Validator'
import Database from '@ioc:Adonis/Lucid/Database'
import MarketService from 'App/Services/MarketService'
import ThirdParty from 'App/Services/ThirdParty'
import axios from 'axios'

export default class BookmakersController {
  // dreamexch wala
  public async addBookmaker({ request, authUser, response }: HttpContextContract) {
    const data = await request.validate({
      schema: schema.create({
        matchId: schema.string(),
        type: schema.enum(['Bookmaker', 'Toss']),
        apiData: schema.object.nullableAndOptional().anyMembers(),
        is_auto: schema.boolean.optional(),
      }),
    })

    const matchId = data.matchId
    if (authUser.usetype == 0 || authUser.usetype == 55) {
      const match = await Database.query().from('matchmst').where('MstCode', data.matchId).first()

      if (!match) {
        return response.badRequest({
          message: 'Please activate match first!',
        })
      }

      // const mainMarket = await Database.query()
      //   .from('market')
      //   .where('matchId', matchId)
      //   .where('Name', 'Match Odds')
      //   .first()

      // if (!mainMarket) {
      //   return response.badRequest({
      //     message: 'Please activate match odds market first!',
      //   })
      // }
      let bookmakers: any[] = []

      try {
        if (!data.apiData) {
          const res = await axios.get(ThirdParty.bookmakerApiUrl + data.matchId)

          // New API format: data[eventId].bookmaker[] and data[eventId].toss[]
          const eventData = res.data?.data?.[data.matchId]
          if (eventData) {
            const bmType = data.type.toLowerCase() === 'toss' ? 'toss' : 'bookmaker'
            const markets = eventData[bmType] || []
            for (const m of markets) {
              bookmakers.push({
                title: m.na || data.type,
                market_id: m.mid,
                runners: (m.r || []).map((r: any) => ({
                  secId: r.rid,
                  runner: r.na,
                })),
              })
            }
          }

          // Old API format (commented out):
          // if (res.data?.Bookmaker?.length > 0) {
          //   const bmByMarket: any = {}
          //   for (const bm of res.data.Bookmaker) {
          //     const mid = bm.mid
          //     if (!bmByMarket[mid]) {
          //       bmByMarket[mid] = {
          //         title: bm.t || 'Bookmaker',
          //         market_id: mid,
          //         runners: [],
          //       }
          //     }
          //     bmByMarket[mid].runners.push({
          //       secId: bm.sid,
          //       runner: bm.nation,
          //     })
          //   }
          //   bookmakers = Object.values(bmByMarket)
          // }
        } else {
          // Use provided API data
          for (let bm in data.apiData) {
            bookmakers.push(data.apiData[bm])
          }
        }

        if (bookmakers.length > 0) {
          for (let b of bookmakers) {
            if (b.title.toLowerCase().includes(data.type.toLowerCase())) {
              let marketId = b.market_id?.toString() || ''
              if (!marketId.includes('B')) {
                marketId = marketId + 'B'
              }

              const result = await Database.query()
                .from('tblresult')
                .where('matchId', matchId)
                .where('marketId', marketId)
                .first()

              if (result) {
                return response.badRequest({
                  message: data.type + ' result already declared!',
                })
              }

              const dbMarket = await Database.query()
                .from('market')
                .where('matchId', matchId)
                .where('Id', marketId)
                .first()

              if (!dbMarket) {
                const runnersJson: any = []
                const runners: any = []

                for (const r of b.runners) {
                  const backLay: any = []

                  for (const { } of [1, 2, 3]) {
                    backLay.push({ size: '--', price: '--' })
                  }

                  const selectionId = parseInt(r.secId)
                  const runnerName = r.runner

                  runnersJson.push({
                    id: selectionId,
                    name: runnerName,
                    back: backLay,
                    lay: backLay,
                  })

                  runners.push({
                    selectionId: selectionId,
                    runnerName: runnerName,
                  })
                }

                const flag = await MarketService.createMarket(
                  {
                    marketId: marketId,
                    marketName: data.type,
                    market_runner_json: JSON.stringify(runnersJson),
                    match_id: matchId,
                    series_id: match.seriesId,
                    sports_id: match.SportID,
                    totalMatched: 0,
                    runners: runners,
                  },
                  true,
                  dbMarket
                )

                if (flag == 1) {
                  await Database.from('matchmst')
                    .where('MstCode', matchId)
                    .update({ has_bookmaker: 1 })

                  await Redis.publish('UPDATE_ACTIVE_MARKET', '')

                  await Redis.sadd(
                    'ACTIVE_MARKETS',
                    JSON.stringify({
                      sportId: match.SportID.toString(),
                      seriesId: match.seriesId.toString(),
                      matchId: matchId.toString(),
                      marketId: marketId.toString(),
                    })
                  )

                  await Redis.sadd('ACTIVE_BOOKMAKERS', matchId)

                  await MarketService.removeMarketCache(matchId)
                  await Redis.publish('UPDATE_MATCH_DATA', JSON.stringify({ match_id: matchId }))
                  await Redis.publish('DASHBOARD_UPDATE_USER', '')
                  await Redis.publish('DASHBOARD_UPDATE_ADMIN', '')

                  return response.json({
                    message: data.type + ' activated.',
                  })
                } else {
                  return response.badRequest({
                    message: data.type + ' not activated.',
                  })
                }
              } else {
                if (dbMarket.active == 1) {
                  return response.badRequest({
                    message: data.type + ' already active.',
                  })
                }

                await Redis.sadd(
                  'ACTIVE_MARKETS',
                  JSON.stringify({
                    sportId: match.SportID.toString(),
                    seriesId: match.seriesId.toString(),
                    matchId: matchId.toString(),
                    marketId: dbMarket.Id.toString(),
                  })
                )

                await Database.query().from('market').where('Id', dbMarket.Id).update({
                  active: 1,
                })

                await Database.from('matchmst')
                  .where('MstCode', matchId)
                  .update({ has_bookmaker: 1 })
                await MarketService.removeMarketCache(matchId)

                await Redis.publish('UPDATE_ACTIVE_MARKET', '')
                await Redis.publish('UPDATE_MATCH_DATA', JSON.stringify({ match_id: matchId }))
                await Redis.publish('DASHBOARD_UPDATE_USER', '')
                await Redis.publish('DASHBOARD_UPDATE_ADMIN', '')

                return response.json({
                  message: data.type + ' reactivated.',
                })
              }
            }
          }
        }

        return response.status(data.is_auto ? 200 : 400).json({
          message: 'Market not found',
        })
      } catch (e) {
        console.log(e)
        return response.badRequest({
          message: 'There is an error in third party api.',
        })
      }
    }

    return response.badRequest({
      message: "You don' have permission",
    })
  }

  public async addVirtualBookmaker({ request, authUser, response }: HttpContextContract) {
    const data = await request.validate({
      schema: schema.create({
        matchId: schema.string(),
        type: schema.enum(['Bookmaker', 'Toss']),
      }),
    })

    const matchId = data.matchId
    if (authUser.usetype == 0 || authUser.usetype == 55) {
      // fetching match instead of market
      const mainMarket = await Database.query()
        .from('matchmst')
        .where('MstCode', matchId)
        .firstOrFail()

      try {
        const res = await axios.get(ThirdParty.bookmakerApiUrl + matchId)

        // New API format: data[eventId].bookmaker[] and data[eventId].toss[]
        let bookmakers: any[] = []
        const eventData = res.data?.data?.[matchId]
        if (eventData) {
          const bmType = data.type.toLowerCase() === 'toss' ? 'toss' : 'bookmaker'
          const markets = eventData[bmType] || []
          for (const m of markets) {
            bookmakers.push({
              title: m.na || data.type,
              marketId: m.mid,
              runners: JSON.stringify((m.r || []).map((r: any) => ({ secId: r.rid, runner: r.na }))),
            })
          }
        }

        // Old API format (commented out):
        // if (res.data.Bookmaker) {
        //   const marketGroups: any = {}
        //   for (const bm of res.data.Bookmaker) {
        //     if (!marketGroups[bm.mid]) {
        //       marketGroups[bm.mid] = { title: bm.t, marketId: bm.mid, runners: [] }
        //     }
        //     marketGroups[bm.mid].runners.push({ secId: bm.sid, runner: bm.nation })
        //   }
        //   bookmakers = Object.values(marketGroups).map((g: any) => ({
        //     title: g.title,
        //     marketId: g.marketId,
        //     runners: JSON.stringify(g.runners),
        //   }))
        // } else if (res.data.gameList) {
        //   const sports = res.data.gameList
        //   if (Array.isArray(sports) && sports.length > 0) {
        //     const events = sports[0].eventList
        //     if (Array.isArray(events) && events.length > 0 && events[0].marketList.hasOwnProperty('bookmaker')) {
        //       bookmakers = events[0].marketList.bookmaker || []
        //     }
        //   }
        // }

        if (Array.isArray(bookmakers)) {
              for (const b of bookmakers) {
                  if (b.title.toLowerCase().includes(data.type.toLowerCase())) {
                    const marketId = b.marketId
                    const result = await Database.query()
                      .from('tblresult')
                      .where('matchId', matchId)
                      .where('marketId', marketId)
                      .first()

                    if (result) {
                      return response.badRequest({
                        message: data.type + ' result already declared!',
                      })
                    }

                    const dbMarket = await Database.query()
                      .from('market')
                      .where('matchId', matchId)
                      .where('Id', marketId)
                      .first()

                    if (!dbMarket) {
                      const runnersJson: any = []
                      const runners: any = []

                      for (const r of JSON.parse(b.runners)) {
                        const backLay: any = []

                        for (const { } of [1, 2, 3]) {
                          backLay.push({ size: '--', price: '--' })
                        }

                        const selectionId = parseInt(r.secId)
                        const runnerName = r.runner

                        runnersJson.push({
                          id: selectionId,
                          name: runnerName,
                          back: backLay,
                          lay: backLay,
                        })

                        runners.push({
                          selectionId: selectionId,
                          runnerName: runnerName,
                        })
                      }

                      const flag = await MarketService.createMarket(
                        {
                          marketId: marketId,
                          marketName: data.type,
                          market_runner_json: JSON.stringify(runnersJson),
                          match_id: matchId,
                          series_id: mainMarket.seriesId,
                          sports_id: mainMarket.sportsId,
                          totalMatched: 0,
                          runners: runners,
                        },
                        true,
                        dbMarket
                      )

                      if (flag == 1) {
                        await Database.from('matchmst')
                          .where('MstCode', matchId)
                          .update({ has_bookmaker: 1 })

                        await Redis.publish('UPDATE_ACTIVE_MARKET', '')

                        await Redis.sadd(
                          'ACTIVE_MARKETS',
                          JSON.stringify({
                            sportId: mainMarket.sportsId.toString(),
                            seriesId: mainMarket.seriesId.toString(),
                            matchId: matchId.toString(),
                            marketId: marketId.toString(),
                          })
                        )

                        await Redis.sadd('ACTIVE_BOOKMAKERS', matchId)

                        await MarketService.removeMarketCache(matchId)

                        await Redis.publish(
                          'UPDATE_MATCH_DATA',
                          JSON.stringify({ match_id: matchId })
                        )
                        await Redis.publish('DASHBOARD_UPDATE_USER', '')
                        await Redis.publish('DASHBOARD_UPDATE_ADMIN', '')

                        return response.json({
                          message: data.type + ' activated.',
                        })
                      } else {
                        return response.badRequest({
                          message: data.type + ' not activated.',
                        })
                      }
                    } else {
                      if (dbMarket.active == 1) {
                        return response.badRequest({
                          message: data.type + ' already active.',
                        })
                      }

                      await Redis.sadd(
                        'ACTIVE_MARKETS',
                        JSON.stringify({
                          sportId: mainMarket.sportsId.toString(),
                          seriesId: mainMarket.seriesId.toString(),
                          matchId: matchId.toString(),
                          marketId: dbMarket.Id.toString(),
                        })
                      )

                      await Database.query().from('market').where('Id', dbMarket.Id).update({
                        active: 1,
                      })

                      await Database.from('matchmst')
                        .where('MstCode', matchId)
                        .update({ has_bookmaker: 1 })
                      await MarketService.removeMarketCache(matchId)

                      await Redis.publish('UPDATE_ACTIVE_MARKET', '')
                      await Redis.publish(
                        'UPDATE_MATCH_DATA',
                        JSON.stringify({ match_id: matchId })
                      )
                      await Redis.publish('DASHBOARD_UPDATE_USER', '')
                      await Redis.publish('DASHBOARD_UPDATE_ADMIN', '')
                      return response.json({
                        message: data.type + ' reactivated.',
                      })
                    }
                  }
                }
        }
        return response.badRequest({
          message: 'Market not found',
        })
      } catch (e) {
        console.log(e)
        return response.badRequest({
          message: 'There is an error in third party api.',
        })
      }
    }

    return response.badRequest({
      message: "You don' have permission",
    })
  }

  // redis wala
  public async addBookmakerDemo({ request, authUser, response }: HttpContextContract) {
    const data = await request.validate({
      schema: schema.create({
        matchId: schema.string(),
      }),
    })

    const matchId = data.matchId
    if (authUser.usetype == 0 || authUser.usetype == 55) {
      const mainMarket = await Database.query()
        .from('market')
        .where('matchId', matchId)
        .where('Name', 'Match Odds')
        .first()
      if (!mainMarket) {
        return response.badRequest({
          message: 'Please activate match odds market first!',
        })
      }

      const dbMarket = await Database.query()
        .from('market')
        .where('matchId', matchId)
        .whereILike('Name', `%Bookmaker%`)
        .first()

      if (!dbMarket) {
        await Redis.sadd('ACTIVE_BOOKMAKERS', matchId)

        return response.json({
          message: 'Bookmaker activated.',
        })
      } else {
        const result = await Database.query()
          .from('tblresult')
          .where('matchId', matchId)
          .where('marketId', dbMarket.Id)
          .first()

        if (result) {
          return response.badRequest({
            message: 'Bookmaker result already declared!',
          })
        }

        if (dbMarket.active == 1) {
          return response.badRequest({
            message: 'Bookmaker already active.',
          })
        }

        await Redis.sadd(
          'ACTIVE_MARKETS',
          JSON.stringify({
            sportId: mainMarket.sportsId.toString(),
            seriesId: mainMarket.seriesId.toString(),
            matchId: matchId.toString(),
            marketId: dbMarket.Id.toString(),
          })
        )

        await Database.query().from('market').where('Id', dbMarket.Id).update({
          active: 1,
        })

        await Database.from('matchmst').where('MstCode', matchId).update({ has_bookmaker: 1 })
        await MarketService.removeMarketCache(matchId)
        await Redis.publish('UPDATE_ACTIVE_MARKET', '')
        await Redis.publish('UPDATE_MATCH_DATA', JSON.stringify({ match_id: matchId }))
        await Redis.publish('DASHBOARD_UPDATE_USER', '')

        await Redis.publish('DASHBOARD_UPDATE_ADMIN', '')
        return response.json({
          message: 'Bookmaker reactivated.',
        })
      }
    }

    return response.badRequest({
      message: "You don' have permission",
    })
  }

  // t2 bm wala
  public async addBookmakerOriginal({ request, authUser, response }: HttpContextContract) {
    const data = await request.validate({
      schema: schema.create({
        matchId: schema.string(),
      }),
    })

    const matchId = data.matchId
    if (authUser.usetype == 0 || authUser.usetype == 55) {
      const mainMarket = await Database.query()
        .from('market')
        .where('matchId', matchId)
        .where('Name', 'Match Odds')
        .first()
      if (!mainMarket) {
        return response.badRequest({
          message: 'Please activate match odds market first!',
        })
      }

      try {
        const res = await axios.get(ThirdParty.bookmakerApiUrl + matchId)

        // New API format: data[eventId].bookmaker[]
        let bm1: any[] = []
        const eventData = res.data?.data?.[matchId]
        if (eventData?.bookmaker?.length > 0) {
          for (const bm of eventData.bookmaker) {
            for (const r of (bm.r || [])) {
              bm1.push({ mid: bm.mid, sid: r.rid, nat: r.na })
            }
          }
        }

        // Old API format (commented out):
        // if (res.data.Bookmaker) {
        //   bm1 = res.data.Bookmaker
        //     .filter((b: any) => b.t && b.t.toLowerCase().includes('bookmaker'))
        //     .map((b: any) => ({ mid: b.mid, sid: b.sid, nat: b.nation }))
        // } else if (res.data.hasOwnProperty('t2')) {
        //   const d = res.data.t2
        //   if (Array.isArray(d) && d.length > 0 && d[0].hasOwnProperty('bm1') && Array.isArray(d[0].bm1)) {
        //     bm1 = d[0].bm1
        //   }
        // }

        if (bm1.length > 0) {
                let marketId: any
                const runnersJson: any = []
                const runners: any = []

                for (const bookmaker of bm1) {
                  marketId = bookmaker.mid

                  const backLay: any = []

                  for (const { } of [1, 2, 3]) {
                    backLay.push({ size: '--', price: '--' })
                  }

                  runnersJson.push({
                    id: parseInt(bookmaker.sid),
                    name: bookmaker.nat,
                    back: backLay,
                    lay: backLay,
                  })

                  runners.push({
                    selectionId: parseInt(bookmaker.sid),
                    runnerName: bookmaker.nat,
                  })
                }

                const result = await Database.query()
                  .from('tblresult')
                  .where('matchId', matchId)
                  .where('marketId', marketId)
                  .first()

                if (result) {
                  return response.badRequest({
                    message: 'Bookmaker result already declared!',
                  })
                }

                const dbMarket = await Database.query()
                  .from('market')
                  .where('matchId', matchId)
                  .where('Id', marketId)
                  .first()

                if (!dbMarket) {
                  const flag = await MarketService.createMarket(
                    {
                      marketId: marketId,
                      marketName: 'Bookmaker',
                      market_runner_json: JSON.stringify(runnersJson),
                      match_id: matchId,
                      series_id: mainMarket.seriesId,
                      sports_id: mainMarket.sportsId,
                      totalMatched: 0,
                      runners: runners,
                    },
                    true,
                    dbMarket
                  )

                  if (flag == 1) {
                    await Database.from('matchmst')
                      .where('MstCode', matchId)
                      .update({ has_bookmaker: 1 })

                    await Redis.publish('UPDATE_ACTIVE_MARKET', '')

                    await Redis.sadd(
                      'ACTIVE_MARKETS',
                      JSON.stringify({
                        sportId: mainMarket.sportsId.toString(),
                        seriesId: mainMarket.seriesId.toString(),
                        matchId: matchId.toString(),
                        marketId: marketId.toString(),
                      })
                    )

                    await Redis.sadd('ACTIVE_BOOKMAKERS', matchId)

                    await MarketService.removeMarketCache(matchId)

                    await Redis.publish('UPDATE_MATCH_DATA', JSON.stringify({ match_id: matchId }))
                    await Redis.publish('DASHBOARD_UPDATE_USER', '')
                    await Redis.publish('DASHBOARD_UPDATE_ADMIN', '')
                    return response.json({
                      message: 'Bookmaker activated.',
                    })
                  } else {
                    return response.badRequest({
                      message: 'Bookmaker not activated.',
                    })
                  }
                } else {
                  if (dbMarket.active == 1) {
                    return response.badRequest({
                      message: 'Bookmaker already active.',
                    })
                  }

                  await Redis.sadd(
                    'ACTIVE_MARKETS',
                    JSON.stringify({
                      sportId: mainMarket.sportsId.toString(),
                      seriesId: mainMarket.seriesId.toString(),
                      matchId: matchId.toString(),
                      marketId: dbMarket.Id.toString(),
                    })
                  )

                  await Database.query().from('market').where('Id', dbMarket.Id).update({
                    active: 1,
                  })

                  await Database.from('matchmst')
                    .where('MstCode', matchId)
                    .update({ has_bookmaker: 1 })
                  await MarketService.removeMarketCache(matchId)

                  await Redis.publish('UPDATE_ACTIVE_MARKET', '')
                  await Redis.publish('UPDATE_MATCH_DATA', JSON.stringify({ match_id: matchId }))
                  await Redis.publish('DASHBOARD_UPDATE_USER', '')
                  await Redis.publish('DASHBOARD_UPDATE_ADMIN', '')
                  return response.json({
                    message: 'Bookmaker reactivated.',
                  })
                }
        }

        return response.badRequest({
          message: 'Market not found',
        })
      } catch (e) {
        console.log(e)
        return response.badRequest({
          message: 'There is an error in third party api.',
        })
      }
    }

    return response.badRequest({
      message: "You don' have permission",
    })
  }

  public async removeBookmaker({ request, authUser, response }: HttpContextContract) {
    const data = await request.validate({
      schema: schema.create({
        matchId: schema.number(),
        type: schema.enum(['Bookmaker', 'Toss']),
      }),
    })

    if (authUser.usetype == 0 || authUser.usetype == 55) {
      const market = await Database.query()
        .from('market')
        .whereILike('Name', `%${data.type}%`)
        .whereILike('Id', `%B%`)
        .where('matchId', data.matchId)
        .first()

      const marketId = market.Id

      if (!market) {
        return response.badRequest({
          message: 'Market not found.',
        })
      }

      await Redis.srem(
        'ACTIVE_MARKETS',
        JSON.stringify({
          sportId: market.sportsId.toString(),
          seriesId: market.seriesId.toString(),
          matchId: market.matchId.toString(),
          marketId: marketId.toString(),
        })
      )

      await Database.query().from('market').where('Id', marketId).update({
        active: 0,
      })

      const bMarkets = await Database.query()
        .from('market')
        .where('active', 1)
        .whereILike('Id', `%B%`)
        .where('matchId', data.matchId)

      await MarketService.removeMarketCache(market.matchId)
      await Redis.publish('UPDATE_ACTIVE_MARKET', '')
      await Redis.publish('UPDATE_MATCH_DATA', JSON.stringify({ match_id: market.matchId }))

      if (!bMarkets) {
        await Database.from('matchmst')
          .where('MstCode', market.matchId)
          .update({ has_bookmaker: 0 })

        await Redis.publish('DASHBOARD_UPDATE_USER', '')
        await Redis.publish('DASHBOARD_UPDATE_ADMIN', '')
      }

      return response.json({
        message: data.type.toUpperCase() + ' deactivated.',
      })
    }

    return response.badRequest({
      message: "You don' have permission",
    })
  }
}