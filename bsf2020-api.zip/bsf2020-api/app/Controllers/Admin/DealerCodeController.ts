import { HttpContextContract } from '@ioc:Adonis/Core/HttpContext'
import { rules, schema } from '@ioc:Adonis/Core/Validator'
import Database from '@ioc:Adonis/Lucid/Database'

export default class DealerCodeController {
  public async index({ authUser, response }: HttpContextContract) {
    let data: any = []
    if (authUser.usetype == 2) {
      data = await Database.from('dealer_code').where('user_id', authUser?.mstrid)
    }

    return response.json(data)
  }
  public async store({ request, response, authUser }: HttpContextContract) {
    if (authUser.usetype == 2) {
      const data = await request.validate({
        schema: schema.create({
          code: schema.string({}, [rules.unique({ table: 'dealer_code', column: 'code' })]),
        }),
      })

      await Database.table('dealer_code').insert({
        ...data,
        user_id: authUser.mstrid,
      })

      return response.json({
        message: 'Code Added.',
      })
    }
    return response.badRequest({
      message: "You don't have permission",
    })
  }

  public async update({ request, response, authUser, params }: HttpContextContract) {
    if (authUser.usetype == 2) {
      const data = await request.validate({
        schema: schema.create({
          code: schema.string({}, [rules.unique({ table: 'dealer_code', column: 'code' })]),
        }),
        messages: {
          'code.unique': 'Code is already available.',
        },
      })

      const code = await Database.from('dealer_code')
        .where('id', params.id)
        .where('user_id', authUser.mstrid)
        .firstOrFail()

      await Database.from('dealer_code')
        .where('id', code.id)
        .update({
          ...data,
        })

      return response.json({
        message: 'Code Updated.',
      })
    }

    return response.badRequest({
      message: "You don't have permission",
    })
  }

  public async delete({ response, authUser, params }: HttpContextContract) {
    if (authUser.usetype == 2) {
      const code = await Database.from('dealer_code')
        .where('id', params.id)
        .where('user_id', authUser.mstrid)
        .firstOrFail()

      if (code) {
        await Database.from('dealer_code')
          .where('id', params.id)
          .where('user_id', authUser.mstrid)
          .delete()

        return response.json({
          message: 'Code deleted.',
        })
      }
    }
    return response.badRequest({
      message: "You don't have permission",
    })
  }
}
