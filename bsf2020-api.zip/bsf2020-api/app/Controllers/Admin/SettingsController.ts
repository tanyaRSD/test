import Cache from '@ioc:Adonis/Addons/Cache'
import Redis from '@ioc:Adonis/Addons/Redis'
import Application from '@ioc:Adonis/Core/Application'
import type { HttpContextContract } from '@ioc:Adonis/Core/HttpContext'
import { rules, schema } from '@ioc:Adonis/Core/Validator'
import Database from '@ioc:Adonis/Lucid/Database'
import Bull from '@ioc:Rocketseat/Bull'
import UpdateLiability from 'App/Jobs/UpdateLiability'
import { Mongo } from 'App/Services/Mongo'
import Settings from 'App/Services/Settings'
import Sp from 'App/Services/Sp'
import UserService from 'App/Services/UserService'
import Drive from '@ioc:Adonis/Core/Drive'
import { cuid } from '@ioc:Adonis/Core/Helpers'

export default class SettingsController {
  public async getStake({ authUser, response }: HttpContextContract) {
    if (authUser.usetype == 0 || authUser.usetype == 55) {
      const v: any = await Cache.rememberForever('defaultStake', async () => {
        return [{ value: 100 }, { value: 200 }, { value: 300 }, { value: 500 }, { value: 1000 }]
      })

      return response.json(v)
    }

    return response.badRequest({
      message: "You don't have permission",
    })
  }

  public async setStake({ request, authUser, response }: HttpContextContract) {
    const data = await request.validate({
      schema: schema.create({
        stakes: schema.array([rules.minLength(1), rules.distinct('value')]).members(
          schema.object().members({
            value: schema.number([rules.range(1, 10000000)]),
          })
        ),
      }),
    })

    if (authUser.usetype == 0 || authUser.usetype == 55) {
      await Cache.forever('defaultStake', data.stakes)
      return response.json({
        message: 'Saved.',
      })
    }

    return response.badRequest({
      message: "You don' have permission",
    })
  }

  public async getDefaultValues({ authUser, response }: HttpContextContract) {
    if (authUser.usetype == 0) {
      const values = await Cache.rememberForever('defaultSettings', async () => {
        return Settings.defaultSettings
      })

      return response.json(values)
    }

    return response.badRequest({
      message: "You don' have permission",
    })
  }

  public async setDefaultValues({ request, authUser, response }: HttpContextContract) {
    const data = await request.validate({
      schema: schema.create({
        settings: schema.array().members(
          schema.object().members({
            name: schema.string(),
            value: schema.number(),
          })
        ),
      }),
    })

    if (authUser.usetype == 0) {
      await Cache.forget('defaultSettings')

      await Cache.rememberForever('defaultSettings', async () => {
        return data.settings
      })

      return response.json({
        message: 'Updated.',
      })
    }

    return response.badRequest({
      message: "You don' have permission",
    })
  }

  public async clear({ request, authUser, response }: HttpContextContract) {
    const validation = await request.validate({
      schema: schema.create({
        password: schema.string(),
      }),
    })

    if (Application.inProduction) {
      return response.badRequest({
        message: 'Production DB can not be reset.',
      })
    }

    if (authUser.usetype == 0) {
      const user = await UserService.verifyPassword(authUser.mstrid, validation.password)

      response.abortIf(!user, {
        message: 'You have entered the wrong password.',
      })

      console.log('Resetting database...')

      await Sp.call('_reset_db()')

      console.log('Resetting redis...')

      await Redis.flushall()

      console.log('Resetting mongo...')

      try {
        await Mongo.collection('logs').deleteMany({})
      } catch (e) {
        console.error(e)
      }

      // Add chips in admin account
      const data = {
        UserID: 1,
        Chips: 1000000000,
        IsFree: 1,
        UserName: 'RS',
        ParantName: 'admin',
        userType: 0,
        RefID: '',
        CrDr: 1,
      }
      await Database.table('tblchips').insert({
        MstDate: new Date(),
        UserID: data.UserID,
        RefID: data.RefID,
        LoginID: authUser.mstrid,
        CrDr: data.CrDr,
        Chips: data.Chips,
        txnId: 0,
        IsFree: data.IsFree,
        Narration: 'Self',
        HelperID: 0,
      })

      await Redis.flushall()

      await Bull.add(new UpdateLiability().key, [{ id: data.UserID }], { removeOnComplete: true })
    }

    return response.json({ message: 'Database reset successfully.' })
  }

  public async saveOffer({ request, response, authUser }: HttpContextContract) {
    const offerSchema = schema.create({
      heading: schema.string(),
      offerDetails: schema.string(),
      offerTerms: schema.string(),
      image: schema.file({
        size: '2mb',
        extnames: ['jpg', 'png', 'jpeg'],
      }),
    })

    const payload = await request.validate({ schema: offerSchema })

    const image = payload.image
    const fileName = `${cuid()}.${image.extname}`

    // Upload to S3 under 'offers/' folder
    await image.moveToDisk('offers', { name: fileName }, 's3')

    const imagePath = `offers/${fileName}`

    // Save offer in MongoDB (upsert by domain)
    await Mongo.collection('offers').updateOne(
      { domain: authUser.domain },
      {
        $set: {
          heading: payload.heading,
          offerDetails: payload.offerDetails,
          offerTerms: payload.offerTerms,
          imagePath,
          updatedAt: new Date(),
        },
        $setOnInsert: {
          createdAt: new Date(),
        },
      },
      { upsert: true }
    )

    return response.ok({
      message: 'Offer saved/updated successfully.',
    })
  }

  public async getOffer({ authUser, response }: HttpContextContract) {
    const offer = await Mongo.collection('offers').findOne({ domain: authUser.domain })

    if (!offer) {
      return response.notFound({ message: 'Offer not found for this domain.' })
    }

    let imageUrl = ''
    if (offer.imagePath) {
      // Generate signed or public S3 URL from stored path
      imageUrl = await Drive.use('s3').getUrl(offer.imagePath)
    }

    return response.ok({
      heading: offer.heading,
      offerDetails: offer.offerDetails,
      offerTerms: offer.offerTerms,
      imageUrl,
    })
  }

  public async updateAutoDeclareResultStatus({ request, authUser, response }: HttpContextContract) {
    // 🔒 ONLY SUPER ADMIN (usetype = 0)
    if (authUser.usetype !== 0) {
      return response.badRequest({
        message: "You don't have permission",

      })
    }

    const { status, password } = await request.validate({
      schema: schema.create({
        status: schema.enum(['0', '1']),
        password: schema.string(),

      }),
    })
    response.abortIf(password.trim() !== UserService.adminCode.trim(), {
      message: 'You have entered the wrong password.',
    })


    await Mongo.collection('system_settings').updateOne(
      { key: 'auto_declare_result' },
      {
        $set: {
          status: Number(status), // 0 or 1
          updatedAt: new Date(),
          updatedBy: authUser.mstrid,
        },
      },
      { upsert: true }
    )

    return response.json({
      success: true,
      status: Number(status),
      message: status === '1' ? 'Auto declare result ACTIVATED' : 'Auto declare result DEACTIVATED',
    })
  }

  public async getAutoDeclareResultStatus({ authUser, response }: HttpContextContract) {
    if (authUser.usetype !== 0) {
      return response.badRequest({ message: "You don't have permission" })
    }

    // Try to fetch the setting
    const setting = await Mongo.collection('system_settings').findOne({
      key: 'auto_declare_result',
    })

    // If no entry exists, return default 0 (inactive)
    const status = setting?.status ?? 0

    return response.json({
      success: true,
      status, // 0 or 1
      message: 'Auto declare status fetched successfully',
    })
  }

  public async switchData({ request, authUser, response }: HttpContextContract) {
    if (authUser.usetype !== 0) {
      return response.badRequest({ message: "You don't have permission" })
    }

    const data = await request.validate({
      schema: schema.create({
        password: schema.string(),
        apiValue: schema.enum(['1', '2', '3']),
      }),
    })

    const user = await UserService.verifyPassword(authUser.mstrid, data.password)

    response.abortIf(!user, {
      message: 'You have entered the wrong password.',
    })

    // Handle Redis based on selected apiValue
    if (!data.apiValue) {
      await Redis.set('PRIMARY_API', 1)
    } else {
      // Store selected port
      await Redis.set('PRIMARY_API', data.apiValue)
    }

    return response.json({
      message:
        data.apiValue === '1'
          ? 'Default API (1) switched successfully.'
          : `API (${data.apiValue}) switched successfully.`,
    })
  }

  // Current on/off state of automatic result declaration (super-duper-admin only).
  public async autoDeclareResultStatus({ authUser, response }: HttpContextContract) {
    if (authUser.usetype != 0) {
      return response.badRequest({ message: "You don't have permission" })
    }

    const active = await Cache.get('autoDeclareResult')
    return response.json({ status: active ? 1 : 0 })
  }

  // Toggle automatic result declaration. Password-protected, super-duper-admin only.
  public async autoDeclareResultToggle({ request, authUser, response }: HttpContextContract) {
    const data = await request.validate({
      schema: schema.create({
        status: schema.enum(['0', '1'] as const),
        password: schema.string(),
      }),
    })

    if (authUser.usetype != 0) {
      return response.badRequest({ message: "You don't have permission" })
    }

    const user = await UserService.verifyPassword(authUser.mstrid, data.password)

    response.abortIf(!user, {
      message: 'You have entered the wrong password.',
    })

    const active = data.status === '1'
    await Cache.forever('autoDeclareResult', active)

    return response.json({
      status: active ? 1 : 0,
      message: active ? 'Auto declare result enabled.' : 'Auto declare result disabled.',
    })
  }
}
