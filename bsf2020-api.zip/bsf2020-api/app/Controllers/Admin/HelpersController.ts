import { HttpContextContract } from '@ioc:Adonis/Core/HttpContext'
import { rules, schema } from '@ioc:Adonis/Core/Validator'
import Database from '@ioc:Adonis/Lucid/Database'

export default class HelpersController {
  public async index({ response, authUser }: HttpContextContract) {
    if (authUser.usetype != 3) {
      const rows = await Database.from('createmaster')
        .select('*')
        .where('usetype', '55')
        .if(authUser.usetype != 0, (q: any) => {
          q.where('parentid', authUser.mstrid)
        })
      return response.json({
        data: rows,
      })
    }

    return response.badRequest({
      message: "You don't have permission",
    })
  }

  public async store({ request, authUser, response }: HttpContextContract) {
    const data = await request.validate({
      schema: schema.create({
        usecrdt: schema.string(),
        mstruserid: schema.string(),
        // phone: schema.string(),
        // mstrpassword: schema.string([rules.minLength(6), rules.regex(/[A-Z]/)]),
        mstrpassword: schema.string(),
        mstrname: schema.string(),
        usetype: schema.string.optional(),
        domain: schema.string([rules.exists({ table: 'domains', column: 'value' })]),
        permissions: schema.array().members(schema.string()),
        question: schema.string(),
        answer: schema.string(),
      }),
      messages: {
        'mstrpassword.minLength': 'Password must be at least {{ options.minLength }} characters.',
        'mstrpassword.regex': 'Password must contain at least one uppercase letter.',
      },
    })

    if (authUser.mstrid != 1) {
      if (data.permissions.indexOf('Active Matches and Manage Series') > -1) {
        return response.badRequest({
          message: 'Activate Matches Permission Not Allowed',
        })
      }
    }
    await Database.table('createmaster').insert({
      usecrdt: new Date(),
      mstruserid: data.mstruserid,
      mstrpassword: Database.raw('sha1(:password)', { password: data.mstrpassword }),
      mstrname: data.mstrname,
      usetype: 55,
      parentId: authUser.mstrid,
      ipadress: request.ip(),
      loginid: 1,
      permissions: JSON.stringify(data.permissions),
      domain: data.domain,
      question: data.question,
      answer: data.answer,
    })
    return response.json({
      message: 'Helper created.',
    })
  }

  public async update({ request, params, response }: HttpContextContract) {
    const data = await request.validate({
      schema: schema.create({
        mstrname: schema.string(),
      }),
    })

    await Database.from('createmaster').where('mstrid', params.id).where('usetype', 55).update(data)

    return response.json({
      message: 'Info updated.',
    })
  }

  public async destroy({ request, response }: HttpContextContract) {
    const mstrid = request.param('id')
    await Database.from('createmaster').delete().where('mstrid', mstrid)
    return response.json({
      message: 'Delete helper.',
    })
  }

  public async verifyAnswer({ request, authUser, response }: HttpContextContract) {
    const data = await request.validate({
      schema: schema.create({
        answer: schema.string(),
      }),
    })

    if (authUser.usetype == '55') {
      const answer = await Database.from('createmaster')
        .where('mstrid', authUser.mstrid)
        .select('answer')
        .firstOrFail()

      if (answer.answer) {
        if (data.answer.toLowerCase() == answer.answer.toLowerCase()) {
          return response.ok({
            status: true,
          })
        }
      }

      return response.badRequest({
        status: false,
        message: 'Wrong answer',
      })
    }

    return response.badRequest({
      message: "You don't have permission",
    })
  }
}
