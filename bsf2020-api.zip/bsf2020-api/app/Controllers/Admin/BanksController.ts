import Cache from '@ioc:Adonis/Addons/Cache'
import Redis from '@ioc:Adonis/Addons/Redis'
import Application from '@ioc:Adonis/Core/Application'
import Env from '@ioc:Adonis/Core/Env'
import { string } from '@ioc:Adonis/Core/Helpers'
import { HttpContextContract } from '@ioc:Adonis/Core/HttpContext'
import { rules, schema } from '@ioc:Adonis/Core/Validator'
import Database from '@ioc:Adonis/Lucid/Database'
import Bull from '@ioc:Rocketseat/Bull'
import UpdateLiability from 'App/Jobs/UpdateLiability'
import LiabilityEngine from 'App/Services/Ledger/LiabilityEngine'
import Parent from 'App/Services/Parent'
import Payment from 'App/Services/Payment'
import ThirdParty from 'App/Services/ThirdParty'
import UserService from 'App/Services/UserService'
import axios from 'axios'
import { DateTime } from 'luxon'
import moment from 'moment'
import * as XLSX from 'xlsx'

const depositBonus = Env.get('DEPOSIT_BONUS', 0)

export default class BanksController {
  public async index({ authUser, response }: HttpContextContract) {
    if (authUser.usetype == 55) {
      const bankAccountPermission = await UserService.checkPersmission(
        authUser,
        'Bank Account Add/Remove'
      )

      if (!bankAccountPermission) {
        return response.badRequest({
          message: 'You do not have permission to',
        })
      }

      authUser = bankAccountPermission
    }

    const res = await Database.query().from('bank_details').where('mstrid', authUser.mstrid)

    return response.json({
      status: true,
      data: res,
      payments: Payment.list,
    })
  }

  public async store({ request, authUser, response }: HttpContextContract) {
    const data: any = await request.validate({
      schema: schema.create({
        payment: schema.number(),
        acc_name: schema.string(),
        acc_num: schema.string.optional([rules.requiredWhen('payment', '=', 4)]),
        // ifsc_code: schema.string.optional([rules.requiredWhen('payment', '=', 4)]),
        ifsc_code: schema.string.optional(),
        // upi: schema.string.optional([rules.requiredWhen('payment', '!=', 4)]),
        upi: schema.string.optional(),
        bank_name: schema.string.optional([rules.requiredWhen('payment', '=', 9)]),
        // branch_name: schema.string.optional([rules.requiredWhen('payment', '=', 9)]),
        instructions: schema.string.optional(),
      }),
    })

    if (authUser.usetype == 55) {
      const bankAccountPermission = await UserService.checkPersmission(
        authUser,
        'Bank Account Add/Remove'
      )

      if (!bankAccountPermission) {
        return response.badRequest({
          message: 'You do not have permission to',
        })
      }

      authUser = bankAccountPermission
    }

    data.mstrid = authUser.mstrid

    await Database.table('bank_details').insert(data)

    const dataToPublish = {
      userId: authUser.mstrid,
      type: 'BANK_UPDATE',
      message: 'Bank details updated.',
    }

    await Redis.publish('BANK_UPDATE', JSON.stringify(dataToPublish))

    return response.json({
      status: true,
      message: 'Bank account added successfully!',
    })
  }

  public async getRequest({ request, authUser, response }: HttpContextContract) {
    const rq = request.only(['type', 'status'])
    let page = request.input('page', 1)
    let limit = request.input('limit', 50)
    let dealerId = request.input('userId', 0)

    // if (authUser.usetype == 55) {
    //   authUser = await UserService.checkPersmission(authUser, 'Request Approve and Reject')

    //   if (!authUser) {
    //     return response.badRequest({
    //       message: 'Invalid domain or Dealer does not exists!',
    //     })
    //   }
    // }

    if (authUser.usetype == 55) {
      const depositPermission = await UserService.checkPersmission(authUser, 'Deposit Request')
      const withdrawPermission = await UserService.checkPersmission(authUser, 'Withdraw Request')

      if (!depositPermission && !withdrawPermission) {
        return response.badRequest({
          message: 'Invalid domain or Dealer does not exists!',
        })
      }

      authUser = depositPermission ? depositPermission : withdrawPermission
    }

    const data = await Database.query()
      .from('bank_entry')
      .if(authUser.mstrid != 1, (q) => {
        q.where('dealer_id', authUser.mstrid)
      })
      .join('createmaster', 'createmaster.mstrid', '=', 'bank_entry.user_id')
      .join('createmaster as parent', 'parent.mstrid', '=', 'bank_entry.dealer_id')
      .select('bank_entry.*')
      .select([
        'createmaster.p_l',
        'createmaster.balance',
        'createmaster.mstrname',
        'createmaster.liability',
      ])
      .select(['parent.balance as my_wallet'])
      .orderBy('id', 'desc')
      .andWhere((query) => {
        for (const f in rq) {
          if (rq[f]) {
            query.where('bank_entry.' + f, rq[f])
          }
        }
      })
      .where(
        'req_date',
        '>=',
        request.input('from_date', DateTime.now().toFormat('yyyy-MM-dd')) + 'T00:00:00'
      )
      .where(
        'req_date',
        '<=',
        request.input('to_date', DateTime.now().toFormat('yyyy-MM-dd')) + 'T23:59:59'
      )
      .if(authUser.usetype == 0 && dealerId != 0, (q: any) => {
        q.where('bank_entry.dealer_id', dealerId)
      })
      .paginate(page, limit)

    return response.json({
      status: true,
      data: data,
    })
  }

  public async request({ request, authUser, response }: HttpContextContract) {
    let type = request.input('type')
    let data: any

    if (type != 0) {
      data = await Database.query()
        .from('bank_entry')
        .where('dealer_id', authUser.mstrid)
        .where('type', type)
        .where('status', 'PENDING')
        .orderBy('id', 'desc')
    } else if (type != 1) {
      data = await Database.query()
        .from('bank_entry')
        .where('dealer_id', authUser.mstrid)
        .orderBy('id', 'desc')
        .where('type', type)
        .where('status', 'PENDING')
    } else {
      data = await Database.query()
        .from('bank_entry')
        .where('dealer_id', authUser.mstrid)
        .orderBy('id', 'desc')
        .where('status', 'PENDING')
    }

    return response.json({
      status: true,
      data: data,
    })
  }

  public async updateRequest({ request, authUser, response }: HttpContextContract) {
    let data: any = await request.validate({
      schema: schema.create({
        id: schema.number(),
        status: schema.string(),
        Chips: schema.number(),
        remark: schema.string.optional(),
        transaction_id: schema.string.optional(),
      }),
    })

    if (Env.get('project') == 2 && data.status == 'COMPLETE') {
      await request.validate({
        schema: schema.create({
          transaction_id: schema.string(),
        }),
      })
    }

    if (authUser.usetype == 55) {
      const depositPermission = await UserService.checkPersmission(authUser, 'Deposit Request')
      const withdrawPermission = await UserService.checkPersmission(authUser, 'Withdraw Request')

      if (!depositPermission && !withdrawPermission) {
        return response.badRequest({
          message: 'Invalid domain or Master does not exists!',
        })
      }

      authUser = depositPermission ? depositPermission : withdrawPermission
    }

    if (data.status == 'HOLD') {
      await Database.query().from('bank_entry').where('id', data.id).update({
        status: 'HOLD',
      })

      return response.json({
        status: true,
        message: 'Request status changed to HOLD',
      })
    }

    const b = await Database.from('bank_entry')
      .where('id', data.id)
      .where('dealer_id', authUser.mstrid)
      .firstOrFail()

    const key = 'approved_request:' + data.id
    const count = await Redis.incr(key)
    await Redis.expire(key, 50)

    const user = await Database.from('createmaster').where('mstrid', b.user_id).firstOrFail()

    authUser = await Database.from('createmaster').where('mstrid', user.parentId).firstOrFail()

    response.abortIf(count > 1 || (b.status !== 'PENDING' && b.status !== 'HOLD'), {
      message: 'This request has already been processed.',
    })

    // Update chips
    if (data.status == 'COMPLETE' && data.Chips) {
      if (data.Chips > b.req_amount) {
        await Redis.decr(key)
        return response.badRequest({
          message: 'Amount should be less then request amount.',
        })
      }

      const dealerSettings = await Cache.get('dealer_setting:' + authUser.mstrid)

      if (
        dealerSettings &&
        b.type == 1 &&
        depositBonus == '1' &&
        user.deposit_bonus > 0 &&
        dealerSettings.deposit_bonus > 0
      ) {
        data.Chips = data.Chips + (data.Chips * dealerSettings.deposit_bonus) / 100
      }

      if (!(await Parent.validate(authUser, b.user_id))) {
        await Redis.decr(key)
        return response.badRequest({
          message: 'Invalid request.',
        })
      }

      if (Env.get('project') == 2) {
        const transId = await Database.from('bank_entry')
          .where('transaction_id', data.transaction_id)
          .first()

        if (transId) {
          await Redis.decr(key)
          return response.badRequest({
            message: 'Transaction Id Already Exists!',
          })
        }
      }

      data['UserName'] = user.mstrname
      data['IsFree'] = 1
      data['RefID'] = data.remark

      // Deposit gate off the MAINTAINED balance column (no live getLiability SP).
      // Only deposits (type 1) check the parent's balance; withdrawals go through
      // the payment API below.
      if (b.type != 2) {
        const gate = await Database.from('createmaster')
          .where('mstrid', user.parentId)
          .select('balance')
          .first()
        if (Number(gate?.balance ?? 0) < data.Chips && b.user_id != 1) {
          await Redis.decr(key)
          return response.badRequest({
            message: 'Balance insufficient child A/C',
          })
        }
      }

      // call api for withdraw case and IMPS case
      if (b.type != 1 && authUser.payment_type == 0) {
        let token = await Cache.get(`dealer_withdraw_token:${authUser.mstrid}`)

        if (!token) {
          if (!dealerSettings.withdraw_email || !dealerSettings.withdraw_password) {
            return response.badRequest({
              message: 'Payment gateway is not active. please contact upline.',
            })
          }

          const creds = {
            email: dealerSettings.withdraw_email,
            password: dealerSettings.withdraw_password,
          }

          try {
            const paymentUser: any = await axios.post(ThirdParty.paymentWithdrawLogin, creds, {
              headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
            })
            const now = Math.floor(Date.now() / 1000) // Divide by 1000 to convert milliseconds to seconds
            const timestamp = paymentUser.data.expires_in

            // Calculate the difference in seconds
            const differenceInSeconds = now - timestamp

            await Cache.put(
              `dealer_withdraw_token:${authUser.mstrid}`,
              paymentUser.data.access_token,
              differenceInSeconds
            )
            token = paymentUser.data.access_token
          } catch (err) {
            console.log(err)
            return response.badRequest({
              status: false,
              message: 'Error in payment withdraw api.',
            })
          }
        }

        try {
          const rData = {
            Amount: data.Chips,
            AccountNumber: b.acc_num.toString(),
            Bank: b.bank_name,
            IFSC: b.ifsc_code,
            Mode: 'IMPS',
            OrderId: string.generateRandom(16),
          }
          const withdrawRes = await axios.post(ThirdParty.paymentWithdrawUrl, rData, {
            headers: {
              'Accept': 'application/json',
              'Authorization': 'Bearer ' + token,
              'Content-Type': 'application/json',
            },
          })

          await Cache.forever(`payment_withdraw_${b.id}`, withdrawRes.data)

          const withdraw = withdrawRes.data

          if (!withdraw.hasOwnProperty('data')) {
            return response.badRequest({
              message: withdraw.message,
            })
          }

          let transactionId: any = rData.OrderId
          let code: any = 0

          if (withdraw.hasOwnProperty('status_code')) {
            code = withdraw.status_code
          } else if (withdraw.hasOwnProperty('Status_code')) {
            code = withdraw.Status_code
          }

          if ([101, 102, 103].indexOf(code) > -1) {
            return response.badRequest({
              message: withdraw.message,
            })
          }

          if ([104, 105, 110].indexOf(code) > -1) {
            await Database.query().from('bank_entry').where('id', data.id).update({
              status: 'FAILED',
              message: withdraw.message,
              status_code: code,
              transaction_id: transactionId,
            })

            return response.badRequest({
              message: withdraw.message,
            })
          } else {
            await Database.query().from('bank_entry').where('id', data.id).update({
              transaction_id: transactionId,
              message: withdraw.message,
              status_code: code,
            })
          }
        } catch (e) {
          console.log(e.data)

          return response.badRequest({
            message: 'Error in withdraw api.',
          })
        }
      }

      const trx = await Database.transaction()
      try {
        let insertId: any

        if (b.type != 2) {
          insertId = await trx
            .table('tblchips')
            .insert({
              MstDate: new Date(),
              UserID: b.user_id,
              RefID: data.RefID,
              LoginID: authUser.mstrid,
              CrDr: b.type,
              Chips: b.type == 2 ? -data.Chips : data.Chips,
              txnId: 0,
              //@ts-ignore
              IsFree: data.IsFree || '',
              //@ts-ignore
              Narration:
                data.IsFree == 1
                  ? b.type == 1 // 1 deposit to user
                    ? 'Chip deposit to ' + data.UserName
                    : 'Chip withdraw from ' + data.UserName
                  : b.type == 1
                    ? 'Coins deposited to ' + data.UserName
                    : 'Withdrawl coin from ' + data.UserName,
              HelperID: 0,
            })
            .returning('MstCode')
        } else {
          insertId = await trx.from('tblchips').where('withdrawId', data.id).select('MstCode')
        }

        const insId = insertId[0].insertId

        await trx.table('tblchips').insert({
          MstDate: new Date(),
          UserID: user.parentId,
          //@ts-ignore
          RefID: data.RefID,
          LoginID: authUser.mstrid,
          CrDr: b.type == 1 ? 2 : 1,
          Chips: b.type == 1 ? '-' + data.Chips : data.Chips,
          txnId: insId,
          //@ts-ignore
          IsFree: data.IsFree,
          //@ts-ignore
          Narration:
            data.IsFree == 1
              ? b.type == 2 // 2 = withdraw
                ? 'Chip withdraw from ' + data.UserName
                : 'Chip deposited to ' + data.UserName
              : b.type == 2
                ? 'Deposited to parant and withdrawal to' + data.UserName
                : 'Withdrawal to parant and deposited to ' + data.UserName,
          HelperID: 0,
        })

        // Incremental column maintenance (replaces dead job). The user side is
        // only written for deposits here (withdrawals reference existing rows).
        if (b.type != 2) {
          await LiabilityEngine.applyChip(trx, {
            accountId: b.user_id,
            freechips: b.type == 2 ? -data.Chips : data.Chips,
          })
        }
        await LiabilityEngine.applyChip(trx, {
          accountId: user.parentId,
          freechips: b.type == 1 ? -data.Chips : data.Chips,
        })

        // update request status
        await trx.from('bank_entry').where('id', data.id).update({
          status: data.status,
          remark: data.remark,
          approved_amount: data.Chips,
          transaction_id: data.transaction_id,
        })

        await trx.commit()
      } catch (err) {
        await trx.rollback()
        throw err
      }

      if (b.type == 2) {
        await Cache.put(`withdraw_request:${b.user_id}`, true, 86400)
      }
    } else {
      // update request status
      await Database.query().from('tblchips').where('WithdrawId', data.id).delete()

      await Database.query().from('bank_entry').where('id', data.id).update({
        status: data.status,
        remark: data.remark,
        approved_amount: 0,
      })

      await Bull.add(new UpdateLiability().key, [{ id: b.user_id }, { id: user.parentId }], {
        removeOnComplete: true,
      })
    }

    return response.json({
      status: true,
    })
  }

  public async status({ request, params, response }: HttpContextContract) {
    let data: any

    data = await request.validate({
      schema: schema.create({
        status: schema.boolean(),
        cd: schema.boolean(),
        cw: schema.boolean(),
      }),
    })

    await Database.query().from('bank_details').update(data).where('id', params.id)

    const user = await Database.query().from('bank_details').where('id', params.id).first()

    const dataToPublish = {
      userId: user.mstrid,
      type: 'BANK_UPDATE',
      message: 'Bank details updated.',
    }

    await Redis.publish('BANK_UPDATE', JSON.stringify(dataToPublish))

    return response.json({
      status: true,
      message: 'Bank details updated.',
    })
  }

  public async destroy({ params, response }: HttpContextContract) {
    const user = await Database.query().from('bank_details').where('id', params.id).first()

    await Database.query().from('bank_details').where('id', params.id).delete()

    const dataToPublish = {
      userId: user.mstrid,
      type: 'BANK_UPDATE',
      message: 'Bank details updated.',
    }

    await Redis.publish('BANK_UPDATE', JSON.stringify(dataToPublish))

    return response.json({
      status: true,
      message: 'Details removed successfully.',
    })
  }

  public async update({ request, params, authUser, response }: HttpContextContract) {
    const data = await request.validate({
      schema: schema.create({
        mstrid: schema.number(),
        payment: schema.number(),
        acc_name: schema.string(),
        acc_num: schema.string.optional(),
        upi: schema.string.optional(),
        bank_name: schema.string.optional(),
        branch_name: schema.string.optional(),
        instructions: schema.string.optional(),
      }),
    })

    if (authUser.usetype == 55) {
      const bankAccountPermission = await UserService.checkPersmission(
        authUser,
        'Bank Account Add/Remove'
      )

      if (!bankAccountPermission) {
        return response.badRequest({
          message: 'You do not have permission to',
        })
      }

      authUser = bankAccountPermission
    }

    data.mstrid = authUser.mstrid

    await Database.query().from('bank_details').where('id', params.id).update(data)

    const dataToPublish = {
      userId: data.mstrid,
      type: 'BANK_UPDATE',
      message: 'Bank details updated.',
    }

    await Redis.publish('BANK_UPDATE', JSON.stringify(dataToPublish))

    return response.json({
      status: true,
      message: 'Bank details updated.',
    })
  }

  public async dealerSettings({ authUser, request, response }: HttpContextContract) {
    if (authUser.usetype != 1) {
      return response.badRequest({
        message: `You do not have permission.`,
      })
    }

    const key = 'dealer_setting:' + authUser.mstrid

    if (request.method() == 'GET') {
      let result = await Cache.rememberForever(key, async () => {
        return {
          fast_withdraw: 0,
          min_deposit: 10,
          max_deposit: 1000000,
          min_withdraw: 10,
          max_withdraw: 1000000,
          deposit_bonus: 0,
        }
      })

      return response.json({
        data: result,
      })
    } else {
      let validations: any = schema.create({
        fast_withdraw: schema.number([rules.range(0, 100)]),
        min_deposit: schema.number([rules.range(0, 1000000)]),
        max_deposit: schema.number([rules.range(0, 1000000)]),
        min_withdraw: schema.number([rules.range(0, 1000000)]),
        max_withdraw: schema.number([rules.range(0, 1000000)]),
        deposit_email: schema.string.optional(),
        deposit_password: schema.string.optional(),
        withdraw_email: schema.string.optional(),
        withdraw_password: schema.string.optional(),
        deposit_bonus: schema.number(),
      })

      const data = await request.validate({
        schema: validations,
      })

      if (!data.deposit_bonus) {
        data.deposit_bonus = 0
      }

      const dealerSetting: any = await Cache.get(key)

      const newSettings = Object.assign(dealerSetting, data)

      await Cache.forget(key)
      await Cache.rememberForever(key, async () => {
        return newSettings
      })

      return response.json({
        status: true,
        message: 'Settings updated.',
      })
    }
  }

  public async updateDeposit({ request, params, response }: HttpContextContract) {
    const paymentData = await request.validate({
      schema: schema.create({
        order_id: schema.number(),
        order_number: schema.string(),
        payment_status: schema.number(),
        amount: schema.number(),
        utr: schema.string.optional(),
      }),
    })

    await Cache.forever(`payment_webbook_${paymentData.order_number}`, paymentData)

    const b = await Database.from('bank_entry')
      .where('req_amount', paymentData.amount)
      .where('dealer_id', params.id)
      .where('transaction_id', paymentData.order_number)
      .firstOrFail()

    let data: any = {
      id: b.id,
      transaction_id: paymentData.order_number,
      status: paymentData.payment_status == 2 ? 'COMPLETE' : 'REJECT',
      Chips: paymentData.amount,
    }

    const key = 'approved_request:' + data.id
    const count = await Redis.incr(key)
    await Redis.expire(key, 50)

    if (count > 1 || b.status !== 'PENDING') {
      return response.json({
        status: false,
        message: 'This request has already been processed.',
      })
    }

    // Update chips
    if (data.status == 'COMPLETE' && data.Chips) {
      if (data.Chips > b.req_amount) {
        await Redis.decr(key)
        return response.json({
          status: false,
          message: 'Amount should be less then request amount.',
        })
      }

      const userdetails = await Database.query()
        .from('createmaster')
        .where('mstrid', b.user_id)
        .firstOrFail()

      data['UserName'] = userdetails.mstrname
      data['IsFree'] = 1
      data['RefID'] = data.remark

      const user = await Database.from('createmaster')
        .where('mstrid', b.user_id)
        .select('parentId')
        .first()

      if (data.Chips > userdetails.freechips && b.type == 2) {
        return response.badRequest({
          message: 'You can not withdraw greater than credit limit.',
        })
      }

      // Deposit (type 1) draws from the parent; withdraw (type 2) from the user.
      const gateAccount = b.type != 1 ? b.user_id : user.parentId

      const trx = await Database.transaction()
      try {
        // Atomic balance gate off the MAINTAINED column — no live getLiability SP.
        // forUpdate serialises concurrent transfers so two withdrawals cannot both
        // pass (TOCTOU). The column already nets open liability and poker/king and
        // is kept true by the incremental engine + nightly reconciler.
        const gate = await trx
          .from('createmaster')
          .where('mstrid', gateAccount)
          .forUpdate()
          .select('balance')
          .first()

        if (Number(gate?.balance ?? 0) < data.Chips && b.user_id != 1) {
          await trx.rollback()
          await Redis.decr(key)
          return response.json({
            status: false,
            message: 'Balance insufficient child A/C',
          })
        }

        const insertId = await trx.table('tblchips').insert({
          MstDate: new Date(),
          UserID: b.user_id,
          RefID: data.RefID,
          LoginID: user.parentId,
          CrDr: b.type,
          Chips: b.type == 2 ? -data.Chips : data.Chips,
          txnId: 0,
          //@ts-ignore
          IsFree: data.IsFree || '',
          //@ts-ignore
          Narration:
            data.IsFree == 1
              ? b.type == 1 // 1 deposit to user
                ? 'Chip deposit to ' + data.UserName
                : 'Chip withdraw from ' + data.UserName
              : b.type == 1
                ? 'Coins deposited to ' + data.UserName
                : 'Withdrawl coin from ' + data.UserName,
          HelperID: 0,
        })

        const insId = insertId[0].insertId

        await trx.table('tblchips').insert({
          MstDate: new Date(),
          UserID: user.parentId,
          //@ts-ignore
          RefID: data.RefID,
          LoginID: user.parentId,
          CrDr: b.type == 1 ? 2 : 1,
          Chips: b.type == 1 ? '-' + data.Chips : data.Chips,
          txnId: insId,
          //@ts-ignore
          IsFree: data.IsFree,
          //@ts-ignore
          Narration:
            data.IsFree == 1
              ? b.type == 2 // 2 = withdraw
                ? data.UserName + ' Chip withdraw from ' + data.UserName
                : data.UserName + ' Chip deposited to ' + data.UserName
              : b.type == 2
                ? 'Deposited to parant and withdrawal to' + data.UserName
                : 'Withdrawal to parant and deposited to ' + data.UserName,
          HelperID: 0,
        })

        // Maintain denormalised balance columns incrementally for both sides
        // (replaces the dead UpdateLiability job). IsFree=1 here, so these flow
        // to freechips/balance.
        await LiabilityEngine.applyChip(trx, {
          accountId: b.user_id,
          freechips: b.type == 2 ? -data.Chips : data.Chips,
        })
        await LiabilityEngine.applyChip(trx, {
          accountId: user.parentId,
          freechips: b.type == 1 ? -data.Chips : data.Chips,
        })

        // update request status
        await trx.from('bank_entry').where('id', data.id).update({
          status: data.status,
          remark: data.remark,
          approved_amount: data.Chips,
          utr: paymentData.utr,
        })

        await trx.commit()
      } catch (err) {
        await trx.rollback()
        throw err
      }
    } else {
      // update request status
      await Database.query().from('bank_entry').where('id', data.id).update({
        status: data.status,
        remark: data.remark,
        approved_amount: 0,
        utr: paymentData.utr,
      })
    }

    await Redis.publish(
      'PAYMENT_UPDATE',
      JSON.stringify({
        userId: b.user_id,
        type: 'PAYMENT_UPDATE',
        message: 'Payment success.',
      })
    )

    return response.json({
      status: true,
      message: 'success',
    })
  }

  public async exportData({ request, authUser, response }: HttpContextContract) {
    const data = await request.validate({
      schema: schema.create({
        type: schema.string(),
        userId: schema.string(),
      }),
    })

    if (authUser.usetype != 0) {
      return response.badRequest({
        message: "You don't have permission",
      })
    }

    const result = await Database.query()
      .from('bank_entry')
      .if(authUser.mstrid != 1, (q) => {
        q.where('dealer_id', authUser.mstrid)
      })
      .join('createmaster', 'createmaster.mstrid', '=', 'bank_entry.user_id')
      .join('createmaster as parent', 'parent.mstrid', '=', 'bank_entry.dealer_id')
      .select('bank_entry.*')
      .select([
        'createmaster.p_l',
        'createmaster.balance',
        'createmaster.mstrname',
        'createmaster.liability',
      ])
      .select(['parent.balance as my_wallet'])
      .orderBy('id', 'desc')
      .where('bank_entry.type', data.type)
      .where('bank_entry.dealer_id', data.userId)

    const worksheet = XLSX.utils.json_to_sheet(result)
    const workbook = XLSX.utils.book_new()
    XLSX.utils.book_append_sheet(workbook, worksheet, 'My Sheet')

    const buffer = XLSX.write(workbook, { type: 'buffer', bookType: 'xlsx' })
    response.header(
      'Content-Type',
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    )
    response.header('Content-Disposition', 'attachment; filename="myfile.XLSX"')
    return response.send(buffer)
  }

  public async getTotal({ request, authUser, response }: HttpContextContract) {
    if (authUser.usetype == 1) {
      if (Application.inProduction && !authUser.domain.includes('exchbet')) {
        return response.badRequest({
          message: 'You do not have permission',
        })
      }

      const deposit = await Database.query()
        .from('bank_entry')
        .where(
          'req_date',
          '>=',
          request.input('from_date', DateTime.now().toFormat('yyyy-MM-dd')) + 'T00:00:00'
        )
        .where(
          'req_date',
          '<=',
          request.input('to_date', DateTime.now().toFormat('yyyy-MM-dd')) + 'T23:59:59'
        )
        .where('status', 'COMPLETE')
        .where('type', 1)
        .where((q) => {
          q.where('dealer_id', authUser.mstrid)
          q.orWhere(function (q) {
            q.where('dealer_id', 1)
            q.where('user_id', authUser.mstrid)
          })
        })
        .sum('approved_amount as deposit_amount')
        .first()

      const withdraw = await Database.query()
        .from('bank_entry')
        .where(
          'req_date',
          '>=',
          request.input('from_date', DateTime.now().toFormat('yyyy-MM-dd')) + 'T00:00:00'
        )
        .where(
          'req_date',
          '<=',
          request.input('to_date', DateTime.now().toFormat('yyyy-MM-dd')) + 'T23:59:59'
        )
        .where('status', 'COMPLETE')
        .where('type', 2)
        .where((q) => {
          q.where('dealer_id', authUser.mstrid)
          q.orWhere(function (q) {
            q.where('dealer_id', 1)
            q.where('user_id', authUser.mstrid)
          })
        })
        .sum('approved_amount as withdraw_amount')
        .first()

      return response.json({
        status: true,
        deposit_amount: deposit.deposit_amount || 0,
        withdraw_amount: withdraw.withdraw_amount || 0,
      })
    }

    return response.badRequest({
      message: 'You do not have permission',
    })
  }

  // public async deductAmount({ request, authUser, response }: HttpContextContract) {
  //   if (authUser.usetype == 0) {
  //     const data = await request.validate({
  //       schema: schema.create({
  //         deduct_amount: schema.number(),
  //         dealer_id: schema.string(),
  //       }),
  //     })

  //     const deposit = await this.getApprovedAmount(data.dealer_id, 1)

  //     const withdraw = await this.getApprovedAmount(data.dealer_id, 2)

  //     const deductable_amount = deposit.amount - withdraw.amount

  //     if (data.deduct_amount <= 0) {
  //       return response.badRequest({
  //         message: 'Amount must be positive',
  //       })
  //     }

  //     if (deductable_amount < data.deduct_amount) {
  //       return response.badRequest({
  //         message: 'Amount should be less than the available amount',
  //       })
  //     }

  //     await Database.table('deduct_dealer_amount').insert({
  //       dealer_id: data.dealer_id,
  //       deducted_by: authUser.mstrid,
  //       amount: -data.deduct_amount,
  //     })

  //     return response.json({
  //       status: true,
  //       message: 'Amount deducted!',
  //     })
  //   }

  //   return response.badRequest({
  //     message: 'You do not have permission',
  //   })
  // }

  public async getDeductAmount({ request, authUser, response }: HttpContextContract) {
    if (authUser.usetype == 0) {
      const dealerId = request.input('dealer_id', 0)

      const deposit = await this.getApprovedAmount(dealerId, 1)

      const withdraw = await this.getApprovedAmount(dealerId, 2)

      const deductAmount = deposit.amount - withdraw.amount || 0

      return response.json({
        status: true,
        deduct_amount: deductAmount,
      })
    }

    return response.badRequest({
      message: 'You do not have permission',
    })
  }

  public async getDeductData({ request, authUser, response }: HttpContextContract) {
    if (authUser.usetype == 0) {
      let page = request.input('page') ? request.input('page') : 1
      let limit = request.input('limit', 50)
      const dealerId = request.input('dealer_id', 0)

      const data = await Database.from('deduct_dealer_amount')
        .leftJoin('createmaster', 'deduct_dealer_amount.dealer_id', 'createmaster.mstrid')
        .where('dealer_id', dealerId)
        .select('deduct_dealer_amount.*', 'createmaster.mstruserid AS username')
        .orderBy('deduct_dealer_amount.id', 'desc')
        .paginate(page, limit)

      return response.json({
        status: true,
        data: data,
      })
    }

    return response.badRequest({
      message: 'You do not have permission',
    })
  }

  public async updateDeductAmount({ request, authUser, response }: HttpContextContract) {
    const data: any = await request.validate({
      schema: schema.create({
        dealer_id: schema.number(),
        type: schema.enum(['1', '2']),
        Chips: schema.number(),
        remark: schema.string.optional(),
        // status: schema.string(),
        // transaction_id: schema.string.optional([rules.requiredWhen('status', '=', 'COMPLETE')]),
      }),
    })

    const deposit = await this.getApprovedAmount(data.dealer_id, 1)

    const withdraw = await this.getApprovedAmount(data.dealer_id, 2)

    const deductAmount = deposit.amount - withdraw.amount

    if (data.Chips <= 0) {
      return response.badRequest({
        message: 'Amount must be positive',
      })
    }

    if (deductAmount <= 0 && data.type == '2') {
      return response.badRequest({
        message: `Deductable amount must be greater than zero`,
      })
    }

    if (deductAmount < data.Chips && data.type == '2') {
      return response.badRequest({
        message: 'Amount should be less than the deductable amount',
      })
    }

    // const b = await Database.from('bank_entry').where('id', data.id).firstOrFail()
    const key = 'approved_request:' + authUser.mstrid
    // const count = await Redis.incr(key)
    await Redis.expire(key, 50)

    // const user = await Database.from('createmaster')
    //   .where('mstrid', b.user_id)
    //   .select('parentId')
    //   .first()

    // response.abortIf(count > 1 || b.status !== 'PENDING', {
    //   message: 'This request has already been processed.',
    // })

    // Update chips
    if (data.Chips) {
      // if (data.Chips > b.req_amount) {
      //   await Redis.decr(key)
      //   return response.badRequest({
      //     message: 'Amount should be less then request amount.',
      //   })
      // }

      if (authUser.usetype !== 0) {
        await Redis.decr(key)
        return response.badRequest({
          message: 'Invalid request.',
        })
      }

      // if (!(await Parent.validate(authUser, b.user_id))) {
      //   await Redis.decr(key)
      //   return response.badRequest({
      //     message: 'Invalid request.',
      //   })
      // }

      const userdetails = await Database.query()
        .from('createmaster')
        .where('mstrid', data.dealer_id)
        .where('usetype', '1')
        .firstOrFail()

      // const transId = await Database.from('bank_entry')
      //   .where('transaction_id', data.transaction_id)
      //   .first()

      // if (transId) {
      //   await Redis.decr(key)
      //   return response.badRequest({
      //     message: 'Transaction Id Already Exists!',
      //   })
      // }

      data['UserName'] = userdetails.mstrname
      data['IsFree'] = 1
      data['RefID'] = data.remark
      data['status'] = 'COMPLETE'

      const liability = await UserService.getLiability(
        data.type != 1 ? userdetails.mstrid : authUser.mstrid
      )
      const pokerLiability: any = await UserService.getPokerLiability(
        data.type != 1 ? userdetails.mstrid : authUser.mstrid
      )

      const kingLiability: any = await UserService.getKingLiability(
        data.type != 1 ? userdetails.mstrid : authUser.mstrid
      )

      if (data.type != 2) {
        if (
          liability[0].Balance - pokerLiability - kingLiability < data.Chips &&
          userdetails.mstrid != 1
        ) {
          await Redis.decr(key)
          return response.badRequest({
            message: 'Balance insufficient child A/C',
          })
        }
      }

      // call api for withdraw case and IMPS case

      let insertId: any

      // if (data.type != 2) {
      insertId = await Database.table('tblchips')
        .insert({
          MstDate: new Date(),
          UserID: userdetails.mstrid,
          RefID: data.RefID,
          LoginID: authUser.mstrid,
          CrDr: data.type,
          Chips: data.type == 2 ? -data.Chips : data.Chips,
          txnId: 0,
          //@ts-ignore
          IsFree: data.IsFree || '',
          //@ts-ignore
          Narration:
            data.IsFree == 1
              ? data.type == 1 // 1 deposit to user
                ? 'Chip deposit to ' + data.UserName
                : 'Chip withdraw from ' + data.UserName
              : data.type == 1
                ? 'Coins deposited to ' + data.UserName
                : 'Withdrawl coin from ' + data.UserName,
          HelperID: 0,
        })
        .returning('MstCode')
      // }

      // else {
      //    insertId = await Database.from('tblchips').where('withdrawId', data.id).select('MstCode')
      // }

      const insId = insertId[0].insertId

      await Database.table('tblchips').insert({
        MstDate: new Date(),
        UserID: authUser.mstrid,
        //@ts-ignore
        RefID: data.RefID,
        LoginID: authUser.mstrid,
        CrDr: data.type == 1 ? 2 : 1,
        Chips: data.type == 1 ? '-' + data.Chips : data.Chips,
        txnId: insId,
        //@ts-ignore
        IsFree: data.IsFree,
        //@ts-ignore
        Narration:
          data.IsFree == 1
            ? data.type == 2 // 2 = withdraw
              ? 'Chip withdraw from ' + data.UserName
              : 'Chip deposited to ' + data.UserName
            : data.type == 2
              ? 'Deposited to parant and withdrawal to' + data.UserName
              : 'Withdrawal to parant and deposited to ' + data.UserName,
        HelperID: 0,
      })

      await Bull.add(
        new UpdateLiability().key,
        [{ id: userdetails.mstrid }, { id: authUser.mstrid }],
        { removeOnComplete: true }
      )

      let insertData: any = {
        sender_name: authUser.mstruserid,
        receiver_name: userdetails.mstruserid,
        user_id: userdetails.mstrid,
        dealer_id: authUser.mstrid,
        status: 'COMPLETE',
        type: data.type,
        req_date: moment().format('YYYY-MM-DD HH:mm:ss'),
        req_amount: data.amount,
        // acc_type: data.acc_type,
        username: authUser.mstruserid,
        desc: data.type == 1 ? 'Deduct Amount --> Deposit' : 'Deduct Amount --> Withdraw',
        fast_withdraw: 0,
        req_method: 0,
        approved_amount: data.Chips,
        transaction_id: string.generateRandom(50),
        remark: data.remark,
      }

      await Database.table('bank_entry').insert(insertData)

      // update request status
      // await Database.query().from('bank_entry').where('id', data.id).update({
      //   status: data.status,
      //   remark: data.remark,
      //   approved_amount: data.Chips,
      //   transaction_id: data.transaction_id,
      // })

      // if (data.type == 2) {
      //   await Cache.put(`withdraw_request:${userdetails.mstrid}`, true, 86400)
      // }

      await Database.table('deduct_dealer_amount').insert({
        dealer_id: data.dealer_id,
        deducted_by: authUser.mstrid,
        amount: data.type == '2' ? -data.Chips : data.Chips,
        available_amount: deductAmount,
        remark: data.remark,
        date: new Date(),
      })
    }

    return response.json({
      status: true,
      message: 'Success',
    })
  }

  public async getApprovedAmount(dealerId: any, type: any) {
    return Database.query()
      .from('bank_entry')
      .where('status', 'COMPLETE')
      .where('type', type)
      .where((q) => {
        q.where('dealer_id', dealerId)
        q.orWhere(function (q) {
          q.where('dealer_id', 1)
          q.where('user_id', dealerId)
        })
      })
      .sum('approved_amount as amount')
      .first()
  }
}
