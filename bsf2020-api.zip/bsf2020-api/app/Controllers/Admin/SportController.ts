import Redis from '@ioc:Adonis/Addons/Redis'
import { HttpContextContract } from '@ioc:Adonis/Core/HttpContext'
import { schema } from '@ioc:Adonis/Core/Validator'
import Database from '@ioc:Adonis/Lucid/Database'
import UserService from 'App/Services/UserService'
import Cache from '@ioc:Adonis/Addons/Cache'

export default class SportController {
  // public async index({ response, authUser }: HttpContextContract) {
  //   const sports = await Database.query()
  //     .from('sportmst')
  //     .if(authUser.mstrid !== 1 && authUser.usetype !== 55, (query) => {
  //       query.whereNotIn(
  //         'sportmst.id',
  //         Database.from('blocked_sports')
  //           .select('sport_id')
  //           .whereNot('user_id', authUser.mstrid)
  //           .whereIn('user_id', authUser.parentIds)
  //       )
  //     })
  //     .leftJoin('blocked_sports', (query) => {
  //       query
  //         .on('blocked_sports.sport_id', '=', 'sportmst.id')
  //         .andOnVal('blocked_sports.user_id', '=', authUser.mstrid)
  //     })
  //     .orderBy('sportmst.order')
  //     .select('sportmst.*', Database.rawQuery('IF(blocked_sports.sport_id,0,1) as active'))
  //   return response.json({
  //     data: sports,
  //   })
  // }
  public async index({ response, authUser }: HttpContextContract) {

    // ✅ Unique cache key (user based)
    // const cacheKey = `sports_index_${authUser.mstrid}_${authUser.usetype}`

    // ✅ 1. Redis Check
    // if (authUser.mstrid !== 0) {
    //   const cachedData = await Cache.get(cacheKey)
    //   if (cachedData) {
    //     return response.json({
    //       data: JSON.parse(cachedData),
    //     })
    //   }
    // }
    // ---------------- EXISTING QUERY SAME ---------------- //
    const sports = await Database.query()
      .from('sportmst')
      .if(authUser.mstrid !== 1 && authUser.usetype !== 55, (query) => {
        query.whereNotIn(
          'sportmst.id',
          Database.from('blocked_sports')
            .select('sport_id')
            .whereNot('user_id', authUser.mstrid)
            .whereIn('user_id', authUser.parentIds)
        )
      })
      .leftJoin('blocked_sports', (query) => {
        query
          .on('blocked_sports.sport_id', '=', 'sportmst.id')
          .andOnVal('blocked_sports.user_id', '=', authUser.mstrid)
      })
      .orderBy('sportmst.order')
      .select(
        'sportmst.*',
        Database.rawQuery('IF(blocked_sports.sport_id,0,1) as active')
      )

    // ✅ 2. Save to Redis
    // await Cache.put(cacheKey, JSON.stringify(sports), 300) // 5 min cache

    return response.json({
      data: sports,
    })
  }

  public async update({ request, authUser, response, params }: HttpContextContract) {
    const data = await request.validate({
      schema: schema.create({
        active: schema.boolean(),
      }),
    })

    const sport = await Database.query()
      .from('sportmst')
      .where('id', params.id)
      .if(authUser.mstrid !== 1 && authUser.usetype !== 55, (query) => {
        query.whereNotIn(
          'id',
          Database.from('blocked_sports')
            .select('sport_id')
            .whereNot('user_id', authUser.mstrid)
            .whereIn('user_id', authUser.parentIds)
        )
      })
      .first()
    if (sport) {
      if ((authUser.usetype == 0 || authUser.usetype == 55) && sport.active != data.active) {
        await Database.from('sportmst').where('id', params.id).update(data)
        const cacheKey = `sports_index_${authUser.mstrid}_${authUser.usetype}`
        await Cache.forget(cacheKey)
      }

      if (
        await Database.query()
          .from('blocked_sports')
          .where('sport_id', params.id)
          .where('user_id', authUser.mstrid)
          .first()
      ) {
        await Database.query()
          .from('blocked_sports')
          .where('sport_id', params.id)
          .where('user_id', authUser.mstrid)
          .delete()
      } else {
        await Database.table('blocked_sports').insert({
          sport_id: params.id,
          user_id: authUser.mstrid,
          company_id: authUser.mstrid,
          domain_id: authUser.domainId,
        })
      }

      UserService.deleteKeys(await Redis.keys('dashboard:*')).then()
    }

    return response.json({
      message: 'Status updated.',
    })
  }
}
