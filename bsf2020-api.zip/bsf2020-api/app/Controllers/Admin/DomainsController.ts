import Application from '@ioc:Adonis/Core/Application'
import Drive from '@ioc:Adonis/Core/Drive'
import Env from '@ioc:Adonis/Core/Env'
import { HttpContextContract } from '@ioc:Adonis/Core/HttpContext'
import { rules, schema } from '@ioc:Adonis/Core/Validator'
import Database from '@ioc:Adonis/Lucid/Database'
import Cache from '@ioc:Adonis/Addons/Cache'
import Domains from 'App/Services/domains'

export default class DomainsController {
  public async index({ authUser, request, response }: HttpContextContract) {
    let data: any = []
    const purpose = request.input('purpose')
    if (authUser.usetype == 0 || authUser.usetype == 55) {
      data = await Database.from('domains').if(
        purpose == 'createUser' && Application.inProduction,
        (q) => {
          q.whereNotExists(
            Database.from('createmaster')
              .whereColumn('domains.value', 'createmaster.domain')
              .limit(1)
          )
        }
      )
    }

    return response.json(data)
  }
  public async store({ request, response, authUser }: HttpContextContract) {
    if (authUser.usetype == 0 || authUser.usetype == 55) {
      const data = await request.validate({
        schema: schema.create({
          name: schema.string(),
          url: schema.string([
            rules.url({
              protocols: ['http', 'https'],
            }),
            rules.normalizeUrl({
              stripWWW: true,
              removeSingleSlash: true,
            }),
          ]),
          mobile: schema.string([rules.mobile()]),
          headline: schema.string(),
          admin_headline: schema.string.optional(),
          logo: schema.file({
            size: '3mb',
            extnames: ['jpg', 'JPG', 'png', 'jpeg'],
          }),
          login_banner: schema.file.optional({
            size: '3mb',
            extnames: ['jpg', 'JPG', 'png', 'jpeg'],
          }),
          alternate_url: schema.string.nullableAndOptional([
            rules.url({
              protocols: ['http', 'https'],
            }),
            rules.normalizeUrl({
              stripWWW: true,
              removeSingleSlash: true,
            }),
          ]),
        }),
      })

      await data.logo.moveToDisk('domains', {}, 's3')
      // @ts-ignore
      const imgUrl: any = data.logo.filePath

      let bannerUrl: any

      if (data.login_banner) {
        await data.login_banner.moveToDisk('domains', {}, 's3')
        // @ts-ignore
        bannerUrl = data.login_banner.filePath
      }

      await Database.table('domains').insert({
        name: data.name,
        value: data.url,
        mobile: data.mobile,
        headline: data.headline,
        admin_headline: data.admin_headline || '',
        logo: imgUrl,
        login_banner: bannerUrl,
        alternate_url: data.alternate_url,
      })

      await Domains.init()

      return response.json({
        message: 'Domain created.',
      })
    }
    return response.badRequest({
      message: "You don't have permission",
    })
  }

  public async update({ request, response, authUser, params }: HttpContextContract) {
    if (authUser.usetype == 0 || authUser.usetype == 55) {
      const data = await request.validate({
        schema: schema.create({
          logo: schema.file.optional({
            size: '3mb',
            extnames: ['jpg', 'JPG', 'png', 'jpeg'],
          }),
          admin_headline: schema.string.nullableAndOptional(),
          show_register: schema.boolean.optional(),
          login_banner: schema.file.optional({
            size: '3mb',
            extnames: ['jpg', 'JPG', 'png', 'jpeg'],
          }),
          alternate_url: schema.string.nullableAndOptional([
            rules.url({
              protocols: ['http', 'https'],
            }),
            rules.normalizeUrl({
              stripWWW: true,
              removeSingleSlash: true,
            }),
          ]),
        }),
      })

      const domain = await Database.from('domains').where('id', params.id).first()

      if (domain) {
        if (data.logo) {
          await data.logo.moveToDisk('domains', {}, 's3')
          // @ts-ignore
          const imgUrl: any = data.logo.filePath

          if (domain.logo) {
            const host = Env.get('S3_ENDPOINT')
            const bucket = Env.get('S3_BUCKET')
            await Drive.use('s3').delete(domain.logo.replace(host + '/' + bucket + '/', ''))
          }

          await Database.from('domains').where('id', domain.id).update('logo', imgUrl)
        }

        if (data.login_banner) {
          await data.login_banner.moveToDisk('domains', {}, 's3')
          // @ts-ignore
          const imgUrl: any = data.login_banner.filePath

          if (domain.login_banner) {
            const host = Env.get('S3_ENDPOINT')
            const bucket = Env.get('S3_BUCKET')
            await Drive.use('s3').delete(domain.login_banner.replace(host + '/' + bucket + '/', ''))
          }

          await Database.from('domains').where('id', domain.id).update('login_banner', imgUrl)
        }

        await Database.from('domains')
          .where('id', domain.id)
          .update({
            admin_headline: data.admin_headline || '',
            alternate_url: data.alternate_url || '',
            show_register: data.show_register,
          })

        await Cache.forget(`domain:${domain.value}`)
        await Cache.forget(`banner:${domain.value}`)
        await Cache.forget(`social:${domain.value}`)
        await Cache.forget(`demo:${domain.value}`)
        await Domains.init()

        return response.json({
          message: 'Domain updated.',
        })
      }
    } else if (authUser.domainId == params.id && authUser.usetype == 11) {
      let data = await request.validate({
        schema: schema.create({
          mobile: schema.string.nullableAndOptional(),
          headline: schema.string.nullableAndOptional(),
          alternate_url: schema.string.nullableAndOptional([
            rules.url({
              protocols: ['http', 'https'],
            }),
            rules.normalizeUrl({
              stripWWW: true,
              removeSingleSlash: true,
            }),
          ]),
          login_banner: schema.file.optional({
            size: '3mb',
            extnames: ['jpg', 'JPG', 'png', 'jpeg'],
          }),
        }),
      })

      const domain = await Database.from('domains').where('id', params.id).first()
      if (!data.headline) {
        data.headline = ''
      }

      if (!data.mobile) {
        data.mobile = ''
      }

      if (!data.alternate_url) {
        data.alternate_url = ''
      }

      if (data.login_banner) {
        await data.login_banner.moveToDisk('domains', {}, 's3')
        // @ts-ignore
        const imgUrl: any = data.login_banner.filePath

        if (domain.login_banner) {
          const host = Env.get('S3_ENDPOINT')
          const bucket = Env.get('S3_BUCKET')
          await Drive.use('s3').delete(domain.login_banner.replace(host + '/' + bucket + '/', ''))
        }

        await Database.from('domains').where('id', domain.id).update('login_banner', imgUrl)

        delete data.login_banner
      }

      if (domain && domain.value == authUser.domain) {
        await Database.from('domains').where('id', domain.id).update(data)
        await Cache.forget(`domain:${domain.value}`)
        await Cache.forget(`banner:${domain.value}`)
        await Cache.forget(`social:${domain.value}`)
        await Cache.forget(`demo:${domain.value}`)
        await Domains.init()

        return response.json({
          message: 'Info updated.',
        })
      }
    }

    return response.badRequest({
      message: "You don't have permission",
    })
  }

  public async domainSettings({ request, response, authUser, params }: HttpContextContract) {
    if (authUser.domainId == params.id && authUser.usetype == 11) {
      let data = await request.validate({
        schema: schema.create({
          mobile: schema.string.nullableAndOptional(),
          headline: schema.string.nullableAndOptional(),
          alternate_url: schema.string.nullableAndOptional([
            rules.url({
              protocols: ['http', 'https'],
            }),
            rules.normalizeUrl({
              stripWWW: true,
              removeSingleSlash: true,
            }),
          ]),
          login_banner: schema.file.optional({
            size: '3mb',
            extnames: ['jpg', 'JPG', 'png', 'jpeg'],
          }),
          facebook: schema.string.nullableAndOptional([
            rules.url({
              protocols: ['http', 'https'],
            }),
          ]),
          instagram: schema.string.nullableAndOptional([
            rules.url({
              protocols: ['http', 'https'],
            }),
          ]),
          telegram: schema.string.nullableAndOptional([
            rules.url({
              protocols: ['http', 'https'],
            }),
          ]),
          email: schema.string.nullableAndOptional([rules.email()]),
          user_headline: schema.string.nullableAndOptional(),
        }),
      })

      const domain = await Database.from('domains').where('id', params.id).first()
      if (!data.headline) {
        data.headline = ''
      }

      if (!data.mobile) {
        data.mobile = ''
      }

      if (!data.alternate_url) {
        data.alternate_url = ''
      }

      if (!data.facebook) {
        data.facebook = ''
      }

      if (!data.instagram) {
        data.instagram = ''
      }

      if (!data.telegram) {
        data.telegram = ''
      }

      if (!data.email) {
        data.email = ''
      }

      if (!data.user_headline) {
        data.user_headline = ''
      }

      if (data.login_banner) {
        await data.login_banner.moveToDisk('domains', {}, 's3')
        // @ts-ignore
        const imgUrl: any = data.login_banner.filePath

        if (domain.login_banner) {
          const host = Env.get('S3_ENDPOINT')
          const bucket = Env.get('S3_BUCKET')
          await Drive.use('s3').delete(domain.login_banner.replace(host + '/' + bucket + '/', ''))
        }

        await Database.from('domains').where('id', domain.id).update('login_banner', imgUrl)

        delete data.login_banner
      }

      if (domain && domain.value == authUser.domain) {
        await Database.from('domains').where('id', domain.id).update(data)

        return response.json({
          message: 'Info updated.',
        })
      }
    }

    return response.badRequest({
      message: "You don't have permission",
    })
  }
}
