/*
|--------------------------------------------------------------------------
| Http Exception Handler
|--------------------------------------------------------------------------
|
| AdonisJs will forward all exceptions occurred during an HTTP request to
| the following class. You can learn more about exception handling by
| reading docs.
|
| The exception handler extends a base `HttpExceptionHandler` which is not
| mandatory, however it can do lot of heavy lifting to handle the errors
| properly.
|
*/

import Redis from '@ioc:Adonis/Addons/Redis'
import { HttpContextContract } from '@ioc:Adonis/Core/HttpContext'
import HttpExceptionHandler from '@ioc:Adonis/Core/HttpExceptionHandler'
import Logger from '@ioc:Adonis/Core/Logger'
import { DateTime } from 'luxon'

export default class ExceptionHandler extends HttpExceptionHandler {
  constructor() {
    super(Logger)
  }

  public async report(error: any, ctx: HttpContextContract) {
    if (error.status >= 500) {
      await Redis.lpush(
        'errors',
        JSON.stringify({
          dateTime: DateTime.now().toLocaleString(DateTime.DATETIME_SHORT_WITH_SECONDS),
          requestId: ctx.request.id(),
          user: ctx.authUser?.mstrid,
          ip: ctx.request.ips(),
          url: ctx.request.url(),
          handler: ctx.route?.handler,
          body: ctx.request.body(),
          error,
        })
      )
    }

    return super.report(error, ctx)
  }
}
