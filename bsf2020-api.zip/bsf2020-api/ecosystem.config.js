module.exports = {
  apps: [
    {
      name: 'api',
      script: 'server.js',
      instances: 'max',
      exec_mode: 'cluster',
      autorestart: true,
      merge_logs: true,
      kill_timeout: 3000,
      wait_ready: true,
      listen_timeout: 8000,
    },
  ],
}
