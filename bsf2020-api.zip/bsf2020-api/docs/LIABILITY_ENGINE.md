# Liability & Balance Engine

This document describes the incremental money engine that replaces the legacy
"recompute the whole downline via the `getLiability` stored procedure on every
transaction" approach. It exists to (a) keep every **upper panel's** liability
continuously maintained and (b) sustain high concurrency (target: 20k users)
without per-request full-subtree scans.

## The problem with the legacy design

`getLiability(id)` recomputes an account's balance/liability live by aggregating
its **entire downline** across `tblbets`, `bet_entry`, `tblchipdet` and several
views. It was called synchronously on every deposit, withdraw, bet place, result
declaration and settlement — and only ever for the acting user, never the
ancestors. So upper panels' `createmaster.liability/balance` columns drifted and
had to be recomputed live (the bottleneck), and concurrent writes raced.

## The model

Liability is **not** additive per bet. Market liability is a per-market
worst-case:

```
marketLiability(account) = Σ over markets  LEAST(0, MIN over selections (net))
```

So the unit of incremental maintenance is the **selection**, for the client and
**every ancestor**, scaled by that ancestor's partnership share.

### Tables

| Table | Grain | Meaning |
|---|---|---|
| `exposure_ledger` | (account, match, market, selection) | running partnership-scaled net P/L if that selection wins |
| `account_market_liability` | (account, match, market) | cached `LEAST(0, MIN(net))` — always ≤ 0 |
| `createmaster.liability` | account | `Σ account_market_liability.liability` (≤ 0) |
| `createmaster.freechips` | account | deposited free chips (tblchips, unsettled) |
| `createmaster.chip` | account | settled ledger P/L (tblchipdet) |
| `createmaster.balance` | account | `freechips + (isClient ? chip : 0) + liability` |

Every bet row already stores each ancestor's id (`DealerID…ParentExchCompanyID`)
and share (`Dealer…ParentExchCompany`), so the chain and weights come straight
off the row — see [`app/Services/Ledger/Hierarchy.ts`](../app/Services/Ledger/Hierarchy.ts).

## Lifecycle events

| Event | Effect | Maintenance |
|---|---|---|
| Create user | new account | transactional `createmaster`+`tblpartner`; liability 0 |
| Deposit / Withdraw | free chips | ±delta to `freechips`/`balance`; **no recompute** |
| Bet place / delete | exposure | ledger delta for client + each ancestor; recompute the one affected market's worst-case |
| Result declare | exposure → realized | release the market (ledger/summary → 0); fold realized P/L into `chip`/`balance` |
| Settlement | move settled balances | ±delta to `chip`/`balance` |

Each event runs in **one DB transaction**; the balance gate is an atomic
conditional update, removing the concurrent-withdrawal TOCTOU race.

## Cost

Per event: `O(chain depth × selections in one market)` — a handful of rows —
instead of `O(entire downline)`. Chain depth ≤ 7.

## Safety: reconciliation

The legacy `getLiability` SP is retained **only** as an off-hours reconciler. A
scheduled job recomputes the truth for every account and logs/repairs any drift
between the maintained columns and the authoritative recompute. This is what
makes trusting incremental deltas safe for real money.

## Invariants (asserted by the reconciler)

1. `createmaster.liability == Σ account_market_liability.liability` (per account)
2. `account_market_liability.liability == LEAST(0, MIN(exposure_ledger.net))` per market
3. `createmaster.balance == freechips + (isClient ? chip : 0) + liability`
4. Every value ≤ 0 where the schema/model requires it (all liability buckets).

## Rollout

No production traffic yet, so the engine is wired directly (no shadow phase).
The reconciler is the ongoing correctness guard.
