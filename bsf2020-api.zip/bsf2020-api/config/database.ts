/**
 * Config source: https://git.io/JesV9
 *
 * Feel free to let us know via PR, if you find something broken in this config
 * file.
 */

import Env from '@ioc:Adonis/Core/Env'
import { DatabaseConfig } from '@ioc:Adonis/Lucid/Database'

const databaseConfig: DatabaseConfig = {
  /*
  |--------------------------------------------------------------------------
  | Connection
  |--------------------------------------------------------------------------
  |
  | The primary connection for making database queries across the application
  | You can use any key from the `connections` object defined in this same
  | file.
  |
  */
  connection: Env.get('DB_CONNECTION'),

  connections: {
    /*
    |--------------------------------------------------------------------------
    | MySQL config
    |--------------------------------------------------------------------------
    |
    | Configuration for MySQL database. Make sure to install the driver
    | from npm when using this connection
    |
    | npm i mysql2
    |
    */
    mysql: {
      client: 'mysql2',
      connection: {
        // Single database server: point both reads and writes at the same host.
        // (No read replica — a `replicas` split here would create two separate
        // pools and route SELECTs to a non-existent read host, adding latency.)
        host: Env.get('MYSQL_HOST'),
        port: Env.get('MYSQL_PORT'),
        user: Env.get('MYSQL_USER'),
        password: Env.get('MYSQL_PASSWORD', ''),
        database: Env.get('MYSQL_DB_NAME'),
      },
      pool: {
        /**
         * Pool is sized to the database's capacity, not the user count. With
         * short transactions (the incremental liability engine keeps them tiny)
         * a modest pool per app node sustains very high concurrency; scale out
         * horizontally rather than ballooning a single pool. Keep
         * (max * node_count) safely under MySQL `max_connections`.
         */
        min: Number(Env.get('DB_POOL_MIN', 2)),
        max: Number(Env.get('DB_POOL_MAX', 50)),
        // Fail fast instead of queueing forever when the pool is saturated.
        acquireTimeoutMillis: Number(Env.get('DB_POOL_ACQUIRE_TIMEOUT', 30000)),
        createTimeoutMillis: Number(Env.get('DB_POOL_CREATE_TIMEOUT', 30000)),
        idleTimeoutMillis: Number(Env.get('DB_POOL_IDLE_TIMEOUT', 30000)),
      },
      migrations: {
        naturalSort: true,
      },
      healthCheck: true,
      debug: false,
    },
  },
}

export default databaseConfig
