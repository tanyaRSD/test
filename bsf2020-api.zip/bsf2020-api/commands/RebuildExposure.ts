import { BaseCommand, flags } from '@adonisjs/core/build/standalone'

/**
 * liability:rebuild-exposure
 * ==================================================================
 * Rebuilds the ANCESTOR open-bet exposure ledger from `tblbets` (market bets).
 *
 * Clients are intentionally excluded — getLiability computes their market
 * liability live from `vewuserpnldetails`. Upper panels, for whom getLiability
 * returns ~0, are the ones whose open-bet liability the ledger maintains.
 *
 * Idempotent: it first reverses the existing ledger contribution out of the
 * createmaster columns, clears the ledger tables, then replays every open
 * matched market bet. Safe to run as the one-time backfill AND nightly.
 *
 *     node ace liability:rebuild-exposure
 */
export default class RebuildExposure extends BaseCommand {
  public static commandName = 'liability:rebuild-exposure'
  public static description = 'Rebuild ancestor open-bet exposure ledger from tblbets (market bets)'
  public static settings = { loadApp: true, stayAlive: false }

  @flags.number({ description: 'Progress log interval (bets)', alias: 'p' })
  public progress: number

  public async run() {
    const Database = (await import('@ioc:Adonis/Lucid/Database')).default
    const LiabilityEngine = (await import('App/Services/Ledger/LiabilityEngine')).default
    const { LEVELS, LiabilityBucket } = await import('App/Services/Ledger/Hierarchy')

    const progressEvery = this.progress || 500

    // 1. Reverse the existing market-ledger contribution out of the columns so a
    //    re-run does not double count.
    this.logger.info('Reversing existing market-ledger contribution from columns...')
    await Database.rawQuery(
      `UPDATE createmaster c
         JOIN (SELECT account_id, SUM(liability) s
                 FROM account_market_liability GROUP BY account_id) a
           ON c.mstrid = a.account_id
        SET c.liability = COALESCE(c.liability, 0) - a.s,
            c.balance   = COALESCE(c.balance, 0)   - a.s`
    )

    // 2. Clear the ledger tables.
    await Database.rawQuery('DELETE FROM exposure_ledger')
    await Database.rawQuery('DELETE FROM account_market_liability')

    // 3. Replay every open, matched, non-poker market bet.
    const bets = await Database.from('tblbets')
      .whereNull('Result')
      .whereNull('ResultID')
      .where('IsMatched', 1)
      .where('is_poker', 0)

    this.logger.info(`Replaying ${bets.length} open market bet(s)...`)

    const selectionCache = new Map<string, number[]>()
    let n = 0

    for (const bet of bets) {
      const marketId = String(bet.MarketId)

      if (!selectionCache.has(marketId)) {
        const sels = (
          await Database.from('tblselection').where('marketId', marketId).distinct('selectionId')
        ).map((r: any) => Number(r.selectionId))
        selectionCache.set(marketId, sels)
      }
      const selections = selectionCache.get(marketId) as number[]
      if (selections.length === 0) continue

      // Ancestor id + share come straight off the denormalised bet row.
      const ancestors = LEVELS.map((l) => ({
        accountId: Number((bet as any)[l.idColumn] ?? 0),
        sharePct: Number((bet as any)[l.shareColumn] ?? 0),
      }))

      const deltas = LiabilityEngine.marketBetAncestorDeltas({
        matchId: Number(bet.MatchId),
        marketId,
        betSelectionId: Number(bet.SelectionId),
        stake: Number(bet.Stack),
        pl: Number(bet.P_L),
        isBack: Number(bet.isBack),
        selections,
        ancestors,
        sign: 1,
      })

      if (deltas.length > 0) {
        await LiabilityEngine.inTransaction((trx) =>
          LiabilityEngine.applyExposure(trx, LiabilityBucket.Market, deltas)
        )
      }

      if (++n % progressEvery === 0) this.logger.info(`...${n}/${bets.length}`)
    }

    this.logger.success(`Rebuilt ancestor exposure from ${bets.length} open market bet(s).`)
  }
}
