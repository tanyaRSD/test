import { BaseCommand, flags } from '@adonisjs/core/build/standalone'

/**
 * liability:reconcile
 * ==================================================================
 * Recomputes the authoritative balance/liability/etc. for accounts using the
 * legacy getLiability stored procedure (the source of truth), compares them to
 * the maintained `createmaster` columns, reports drift, and — with --repair —
 * writes the authoritative values back.
 *
 * Two uses:
 *   1. One-time BACKFILL — seed the maintained columns from truth before we
 *      start trusting them on the hot path:
 *          node ace liability:reconcile --repair
 *   2. Ongoing DRIFT GUARD — run nightly to detect/repair any divergence the
 *      incremental engine may have accumulated:
 *          node ace liability:reconcile           # report only
 *          node ace liability:reconcile --repair  # auto-correct
 *
 * Other flags:
 *   --id <n>            reconcile a single account
 *   --concurrency <n>   parallel accounts per batch (default 10)
 *   --epsilon <n>       drift threshold to report, in chips (default 0.01)
 */
export default class ReconcileLiability extends BaseCommand {
  public static commandName = 'liability:reconcile'
  public static description =
    'Recompute authoritative balance/liability per account, report and optionally repair drift'

  public static settings = { loadApp: true, stayAlive: false }

  @flags.boolean({ description: 'Write authoritative values back into createmaster' })
  public repair: boolean

  @flags.number({ description: 'Reconcile only this account id' })
  public id: number

  @flags.number({ description: 'Accounts processed in parallel per batch', alias: 'c' })
  public concurrency: number

  @flags.number({ description: 'Drift threshold (chips) to report', alias: 'e' })
  public epsilon: number

  public async run() {
    const Database = (await import('@ioc:Adonis/Lucid/Database')).default
    const UserService = (await import('App/Services/UserService')).default
    const { Mongo } = await import('App/Services/Mongo')

    const concurrency = this.concurrency || 10
    const epsilon = this.epsilon ?? 0.01

    // Columns we maintain and therefore reconcile.
    const COLS = [
      'balance',
      'liability',
      'freechips',
      'chip',
      'p_l',
      'sessionLiability',
      'unmatchliability',
      'profit_loss',
    ] as const

    const ids: number[] = this.id
      ? [this.id]
      : (await Database.from('createmaster').select('mstrid').orderBy('mstrid', 'asc')).map(
          (r: any) => Number(r.mstrid)
        )

    this.logger.info(
      `Reconciling ${ids.length} account(s) — mode: ${this.repair ? 'REPAIR' : 'report only'}`
    )

    let checked = 0
    let drifted = 0
    let repaired = 0
    const runStartedAt = new Date()

    /** Compute the authoritative figures for one account (mirrors UserService.updateLiability). */
    const authoritativeFor = async (accountId: number) => {
      const rows: any = await UserService.getLiability(accountId)
      if (!rows || rows.length === 0) return null
      const d = rows[0]
      const poker: any = await UserService.getPokerLiability(accountId)
      const king: any = await UserService.getKingLiability(accountId)
      const profitLoss: any = await UserService.getProfitLoss(accountId)

      let liability = this.num(d.Liability) - this.num(poker) - this.num(king)
      let balance = this.num(d.Balance) - this.num(poker) - this.num(king)

      // getLiability only computes bet liability for CLIENTS (the views key on
      // the client's UserId); for upper panels it returns ~0. Their open-bet
      // liability lives in the maintained ancestor ledger, so source it there —
      // otherwise --repair would wipe the ledger-maintained value back to 0.
      const acc: any = await Database.from('createmaster')
        .where('mstrid', accountId)
        .select('usetype')
        .first()
      const isClient = Number(acc?.usetype) === 3

      if (!isClient) {
        const agg: any = await Database.from('account_market_liability')
          .where('account_id', accountId)
          .sum('liability as s')
          .first()
        const ledgerLiability = this.num(agg?.s)
        // d.Balance for an ancestor is just freechips; add the ledger liability.
        balance = balance + ledgerLiability
        liability = ledgerLiability
      }

      return {
        balance,
        liability,
        freechips: this.num(d.FreeChip),
        chip: this.num(d.Chip),
        p_l: this.num(d.chipspnl),
        sessionLiability: this.num(d.sessionLiability),
        unmatchliability: this.num(d.unmatchliability),
        profit_loss: this.num(profitLoss?.total),
      }
    }

    const processOne = async (accountId: number) => {
      const truth = await authoritativeFor(accountId)
      checked++
      if (!truth) return

      const current: any = await Database.from('createmaster')
        .where('mstrid', accountId)
        .select(...COLS)
        .first()

      const diffs: Record<string, { was: number; now: number }> = {}
      for (const col of COLS) {
        const was = this.num(current?.[col])
        const now = this.num((truth as any)[col])
        if (Math.abs(was - now) > epsilon) diffs[col] = { was, now }
      }

      if (Object.keys(diffs).length === 0) return
      drifted++

      this.logger.warning(
        `drift mstrid=${accountId} ` +
          Object.entries(diffs)
            .map(([c, v]) => `${c}:${v.was}→${v.now}`)
            .join(' ')
      )

      // Audit every divergence so we can investigate engine gaps over time.
      try {
        await Mongo.collection('liability_reconcile').insertOne({
          accountId,
          diffs,
          repaired: !!this.repair,
          runStartedAt,
          createdAt: new Date(),
        })
      } catch (e) {
        // Mongo logging is best-effort; never block reconciliation on it.
      }

      if (this.repair) {
        await Database.from('createmaster')
          .where('mstrid', accountId)
          .update(
            COLS.reduce((acc, col) => {
              acc[col] = (truth as any)[col]
              return acc
            }, {} as Record<string, number>)
          )
        repaired++
      }
    }

    // Bounded-concurrency batches so we don't overwhelm the DB with the heavy SP.
    for (let i = 0; i < ids.length; i += concurrency) {
      const batch = ids.slice(i, i + concurrency)
      await Promise.all(batch.map((accountId) => processOne(accountId)))
      if ((i / concurrency) % 20 === 0) {
        this.logger.info(`...${Math.min(i + concurrency, ids.length)}/${ids.length}`)
      }
    }

    this.logger.success(
      `Done. checked=${checked} drifted=${drifted} repaired=${repaired} ` +
        `(${this.repair ? 'repaired' : 'report-only — run with --repair to correct'})`
    )
  }

  /** Parse a possibly-null/string decimal to a number, defaulting to 0. */
  private num(v: any): number {
    const n = parseFloat(v)
    return Number.isFinite(n) ? n : 0
  }
}
