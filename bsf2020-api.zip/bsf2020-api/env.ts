/*
|--------------------------------------------------------------------------
| Validating Environment Variables
|--------------------------------------------------------------------------
|
| In this file we define the rules for validating environment variables.
| By performing validation we ensure that your application is running in
| a stable environment with correct configuration values.
|
| This file is read automatically by the framework during the boot lifecycle
| and hence do not rename or move this file to a different location.
|
*/

import Env from '@ioc:Adonis/Core/Env'

export default Env.rules({
  HOST: Env.schema.string({ format: 'host' }),
  PORT: Env.schema.number(),
  APP_KEY: Env.schema.string(),
  APP_NAME: Env.schema.string(),
  DRIVE_DISK: Env.schema.enum(['local', 's3'] as const),
  NODE_ENV: Env.schema.enum(['development', 'production', 'testing'] as const),
  DB_CONNECTION: Env.schema.string(),
  MYSQL_HOST: Env.schema.string({ format: 'host' }),
  // Unused on a single-server setup (no read replica). Kept optional for envs
  // that still define it; the app routes all queries to MYSQL_HOST.
  MYSQL_READ_HOST: Env.schema.string.optional({ format: 'host' }),
  MYSQL_PORT: Env.schema.number(),
  MYSQL_USER: Env.schema.string(),
  MYSQL_PASSWORD: Env.schema.string.optional(),
  MYSQL_DB_NAME: Env.schema.string(),
  REDIS_CONNECTION: Env.schema.enum(['local'] as const),
  REDIS_HOST: Env.schema.string({ format: 'host' }),
  REDIS_PORT: Env.schema.number(),
  REDIS_PASSWORD: Env.schema.string.optional(),
  BULL_REDIS_HOST: Env.schema.string({ format: 'host' }),
  BULL_REDIS_PORT: Env.schema.number(),
  BULL_REDIS_PASSWORD: Env.schema.string.optional(),
  SQL_DEBUG: Env.schema.boolean(),
  SMTP_HOST: Env.schema.string({ format: 'host' }),
  SMTP_PORT: Env.schema.number(),
  SMTP_USERNAME: Env.schema.string(),
  SMTP_PASSWORD: Env.schema.string(),
  SMTP_FROM_ADDRESS: Env.schema.string(),
  TZ: Env.schema.string(),
  S3_KEY: Env.schema.string(),
  S3_SECRET: Env.schema.string(),
  S3_BUCKET: Env.schema.string(),
  S3_REGION: Env.schema.string(),
  S3_ENDPOINT: Env.schema.string.optional(),
  POKER_PARTNER_ID: Env.schema.string(),
  DREAM_PARTNER_ID: Env.schema.string(),
  DREAM_CURRENCY: Env.schema.string(),
  DREAM_PUBLIC_KEY: Env.schema.string(),
  APP_PRIVATE_KEY: Env.schema.string(),
  PROD_VERSION: Env.schema.number(),
  PAYMENT_USERNAME: Env.schema.string(),
  PAYMENT_PASSWORD: Env.schema.string(),
  GAMEHUB_USERNAME: Env.schema.string.optional(),
  GAMEHUB_PASSWORD: Env.schema.string.optional(),
  GAMEHUB_CURRENCY: Env.schema.string.optional(),
  GAMEHUB_SALT: Env.schema.string.optional(),
  SINGLE_DOMAIN: Env.schema.string(),
  SINGLE_DEALER: Env.schema.string(),
})
