import { ApplicationContract } from '@ioc:Adonis/Core/Application'
import Env from '@ioc:Adonis/Core/Env'
import { Mongo, mongoInstance } from 'App/Services/Mongo'

export default class AppProvider {
  constructor(protected app: ApplicationContract) {}

  public register() {
    // Register your own bindings
  }

  public async boot() {}

  public async ready() {
    // to start mongo connection
    console.log('Mongo connected:', (await Mongo.collections()).length)

    await import('../start/socket')
    await import('../start/socket-main')
    if (Env.get('project') == 1) {
      await import('../start/signature')
    }

    setTimeout(() => {
      if (typeof process.send !== 'undefined') {
        process.send('ready')
      }
    }, 1000)
  }

  public async shutdown() {
    // Cleanup, since app is going down
    await mongoInstance.close()
  }
}
